module.exports = {
  env: {
    mocha: true,
  },
  rules: {
    '@typescript-eslint/explicit-function-return-type': 0,
  },
};
