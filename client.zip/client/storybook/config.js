/* eslint-disable import/no-extraneous-dependencies */
import { configure, addParameters } from '@storybook/vue';

import '../src/register-globals';

const req = require.context('@/components', true, /.stories.js$/);

function loadStories() {
  req.keys().forEach(filename => req(filename));
}

addParameters({
  backgrounds: [
    { name: 'transparent', value: 'transparent', default: true },
    { name: 'white', value: 'white' },
    { name: 'dark', value: '#2e3a4c' },
  ],
});

configure(loadStories, module);
