/* eslint-disable */
/**
 *  VUE DOES NOT USE THIS FILE!
 *
 *  THIS FILE IS ONLY HERE SO THAT WEBSTORM'S BUILT IN COMPLETION CAN FIND
 *  THE MODULES IN SASS FILES
 */

const path = require('path');

module.exports = {
  resolve: {
    alias: {
      '@': path.resolve('./src'),
    },
  },
};
