# workspace

## Global dependencies
* [Yarn](https://yarnpkg.com/en/)
    * This project uses [yarn](https://yarnpkg.com/en/) instead of NPM because it's better. 
* (optional) [Vue CLI](https://cli.vuejs.org/)

## Contribution Guidelines
the goal of this stuff is to have a clean commit history that makes it easy for anyone to 
see which features are in which stage of development 

* rebase develop into your working branches rather than merge to avoid
having a ton of merge commits
    * `git pull origin develop --rebase`
* at least one of your commit messages should include a jira ticket id, if one is available
    * ```
    [KRAK-696] Side Nav Layout
    
    - adds layout component for side nav layout
    - adds routes for blah blah 
    ```
* when merging PRs please use the [squash feature](https://help.github.com/en/articles/about-pull-request-merges#squash-and-merge-your-pull-request-commits)
and make sure the message includes a ticket ID if there's a ticket for the work

## API
The API needs to be running to develop against
https://mygithub.gsk.com/gsk-tech/platform-catalogue-frontend

## Vue Stuff

### Resources

Getting started with Vue:
* The best resource for learning Vue is the [official guide](https://vuejs.org/v2/guide/)
* Also review the [style guide](https://vuejs.org/v2/style-guide/)

Info for using Typescript with Vue:
* [Official Typescript/Vue](https://vuejs.org/v2/guide/typescript.html#Recommended-Configuration)
* [Vue Class Component Typescript Example](https://github.com/vuejs/vue-class-component/blob/master/example/src/App.vue)
* [Vue Property Decorator](https://github.com/kaorun343/vue-property-decorator)
* [Vuex Module Decorators](https://championswimmer.in/vuex-module-decorators/)

Example Projects (Typescript):
* [Vue Typescript Admin Template](https://github.com/Armour/vue-typescript-admin-template)
* [Vue Order Admin](https://github.com/xieguangcai/vue-order-admin)
    * this one is super similar to the one above but is larger


### Pro Tips

* when using gsk webcomponents, don't `camelCase` property names because the linter will change it to `hyphen-case` and break your code
    * Bad `<gsk-one-icon-button icon="pizza" offIcon="pizza" />` (will be changed to `off-icon="gsk-pizza"`)
    * Good `<gsk-one-icon-button icon="pizza" officon="pizza" />`

## General Info

* There is a file `webpack.config.js` in the project root. This file is not used by the build system.
It's only purpose is to be used by your editor (webstorm in my case) so that the editor knows how to 
resolve aliased imports in scss files or style tags in vue templates. 
