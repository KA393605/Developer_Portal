/**
 * if someone commits a yarn.lock with entries pointing to
 * DevOps-CorpPlatforms/_packaging/one-platform-components it will not for
 * devs / systems without access to that registry (azure devops, most devs)
 *
 * this does a simple rewrite of the file to point to the enterprise artifacts
 * registry
 */

const fs = require('fs');
const path = require('path');

const lockFilePath = path.join(__dirname, 'yarn.lock');

const lockFile = fs.readFileSync(lockFilePath, { encoding: 'utf-8' });

const o = new RegExp(
  'https://pkgs.dev.azure.com/DevOps-CorpPlatforms/_packaging/one-platform-components/',
  'ig',
);

const n = 'https://pkgs.dev.azure.com/DevOps-Artifacts/_packaging/gsk-artifacts/';

const out = lockFile.toString().replace(o, n);

fs.writeFileSync(lockFilePath, out);
