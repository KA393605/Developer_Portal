/* eslint-disable @typescript-eslint/no-var-requires */
const MonacoEditorPlugin = require('monaco-editor-webpack-plugin');

module.exports = {
  transpileDependencies: [
    'vuex-module-decorators',
    'lit-element',
    /^@gsk-platforms\/gsk/,
    /^@authentic\/mwc-/,
  ],
  devServer: {
    compress: true,
    proxy: {
      '^/auth': {
        target: 'http://localhost:3000/',
        changeOrigin: true,
      },
      '^/api': {
        target: 'http://localhost:3000/',
        changeOrigin: true,
      },
    },
  },
  configureWebpack: {
    plugins: [
      new MonacoEditorPlugin({
        languages: ['yaml', 'json'],
      }),
    ],
  },
  chainWebpack: config => {
    // attempt to build dev mode faster
    config.module
      .rule('vue')
      .use('vue-loader')
      .loader('vue-loader')
      .tap(options => {
        // modify the options...
        options.prettify = false;
        return options;
      });
  },
};
