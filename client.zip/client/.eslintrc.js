module.exports = {
  root: true,
  env: {
    node: true,
  },
  extends: [
    'plugin:@typescript-eslint/recommended',
    'prettier/@typescript-eslint',
    'plugin:vue/recommended',
    '@vue/airbnb',
    '@vue/prettier',
    '@vue/typescript',
  ],
  rules: {
    'no-console': 'error', // use logger function
    'no-debugger': process.env.NODE_ENV === 'production' ? 'error' : 'off',
    'import/no-extraneous-dependencies': 1,
    'import/prefer-default-export': false,
    'arrow-parens': [1, 'as-needed'],
    'max-len': [
      'error',
      {
        code: 100,
        tabWidth: 2,
        ignoreComments: true,
        ignoreTrailingComments: true,
        ignoreUrls: true,
        ignoreStrings: true,
        ignoreTemplateLiterals: true,
        ignoreRegExpLiterals: true,
        // attempt to ignore html attributes...
        ignorePattern: '[a-z]+=".+"',
      },
    ],
    '@typescript-eslint/no-object-literal-type-assertion': [true, { 'allow-arguments': true }],
    '@typescript-eslint/no-parameter-properties': false,
    '@typescript-eslint/interface-name-prefix': false,
    '@typescript-eslint/no-use-before-define': ['error', { functions: false }],
    '@typescript-eslint/explicit-function-return-type': {
      allowExpressions: true,
    },
  },
  parserOptions: {
    parser: '@typescript-eslint/parser',
  },
};
