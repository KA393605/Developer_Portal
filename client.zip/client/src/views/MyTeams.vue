<template>
  <section class="listings__container bg" :class="{ empty: !teams.length }">
    <max-width :container-style="headerStyle">
      <div class="listings__header">
        <h5 class="heading">
          My Teams
        </h5>
      </div>
    </max-width>

    <max-width class="listings__content">
      <div v-if="loading || error || teams.length" class="button-container">
        <router-link :to="newTeamLink" class="button">
          <gsk-fab
            icon="plus"
            class="button"
            extended
            primary
            label="New Team"
            @click="createNewTeam"
          ></gsk-fab>
        </router-link>
      </div>
      <div v-if="loading" class="flex-center loading-container">
        <gsk-circular-progress />
      </div>
      <div v-else-if="error" class="flex-center loading-container">
        <h4>Server Error</h4>
      </div>
      <template v-else-if="teams.length">
        <div class="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>Team Name</th>
                <th>
                  Team Members
                </th>
                <th></th>
              </tr>
            </thead>
            <team-listings
              v-for="team in teams"
              :key="team.teamId"
              :team="team"
              @delete="delTeam"
            />
          </table>
        </div>
      </template>
      <empty-state
        v-else
        title="Create your first team"
        button-text="New Team"
        :link="newTeamLink"
        :image-src="imageSrc"
      />
    </max-width>
    <delete-dialog
      :open.sync="openDelete"
      center-content
      button-text="Yes, delete"
      headerlabel="Are you sure you want to delete this Team?"
      @delete="deleteTeam"
    ></delete-dialog>
  </section>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { RawLocation } from 'vue-router';
import GButton from '@/components/gsk-components/GskButton.vue';
import MaxWidth from '@/components/MaxWidth.vue';
import EmptyState from '@/components/EmptyState.vue';
import { RouteNames } from '@/constants';
import HelpTooltip from '@/components/HelpTooltip.vue';
import ListingEntry from '@/components/Publish/ListingEntry.vue';
import DeleteDialog from '@/components/dialogs/DeleteDialog.vue';
import GDialog from '@/components/gsk-components/GskDialog.vue';
import HelpLink from '@/components/HelpLink.vue';
import { TeamsModule } from '@/store/modules/teams.module';
import UserCircle from '@/components/UserCircle.vue';
import UserList from '@/components/UserList.vue';
import TeamListings from '@/components/teams/TeamListings.vue';
import { Team } from '@/types/teams.types';

/* eslint-disable-next-line @typescript-eslint/no-var-requires */
const img = require('@/assets/computer.svg');

@Component({
  components: {
    UserCircle,
    GButton,
    MaxWidth,
    EmptyState,
    HelpTooltip,
    ListingEntry,
    DeleteDialog,
    GDialog,
    HelpLink,
    UserList,
    TeamListings,
  },
})
export default class MyTeamsView extends Vue {
  private loading: boolean = true;
  private error: boolean = false;
  private deleteId: number = 0;
  private openDelete: boolean = false;
  public isAdminMode: boolean = false;
  public isFeatured: boolean = false;
  public listingId: number = -1;

  get headerStyle() {
    return {
      backgroundColor: 'var(--theme-lightest)',
    };
  }

  get imageSrc() {
    return img;
  }

  get teams() {
    return TeamsModule.teams;
  }

  get newTeamLink(): RawLocation {
    return { name: RouteNames.NewTeam };
  }

  delTeam(team: Team) {
    this.openDelete = true;
    this.deleteId = team.teamId;
  }

  async deleteTeam(): Promise<void> {
    await TeamsModule.deleteTeam(this.deleteId)
      .then(() => {
        this.openDelete = false;
        return this.loadTeams();
      })
      .catch(() => {
        this.openDelete = false;
      });
  }

  loadTeams() {
    return TeamsModule.getAllTeams()
      .catch(() => {
        this.error = true;
      })
      .finally(() => {
        this.loading = false;
      });
  }

  createNewTeam() {
    // PublishingModule.resetPublishingState();
    // this.$log('Create a new team');
  }

  async created() {
    if (this.hasLoadedTeams) {
      this.loading = false;
      this.loadTeams();
    } else {
      await this.loadTeams();
    }
  }

  get hasLoadedTeams(): boolean {
    return TeamsModule.hasLoadedTeams;
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/breakpoints.scss';
@import '~@/styles/theme.scss';
@import '~@/styles/typography.scss';
$content-margin: 88px;
.admin-row {
  display: flex;
}

#team-details {
  cursor: pointer;
}

.admin-span-row {
  display: flex;
  margin-left: 88px;
}

.admin-span {
  width: 165px;
  align-self: center;
}

.admin-switch {
  align-self: center;
  height: 23px;
}

.admin-content {
  margin-left: 100px;
}

#admin-button {
  margin: 0 45px;
}

.bg {
  background-color: $theme-white;
}
.table-wrapper {
  // account for menu
  padding-bottom: 9rem;
}
.listings {
  &__container {
    flex: 1;
    width: 100%;

    &.empty {
      display: flex;
      flex-direction: column;

      .max-width__container {
        margin-bottom: 32px;
      }
    }
  }
  &__header {
    display: flex;
    align-items: center;
    height: auto;
    padding: 64px 0;

    > .heading {
      flex: 1;
      margin: 0;
    }
  }
  &__content {
    margin-top: 0;
    margin-bottom: 0;

    @include breakpoint($medium) {
      margin-top: $content-margin;
      margin-bottom: $content-margin;
    }
    .button-container {
      width: 100%;
      position: relative;
      text-align: right;
      @include breakpoint($medium) {
        height: 0;
      }

      .button {
        position: relative;
        margin: 0;
        top: -0.6rem;

        @include breakpoint($medium) {
          right: 0;
          top: -3.6rem;
        }
      }
    }
  }
}
</style>
