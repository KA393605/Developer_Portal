<template>
  <div class="bot-console all">
    <max-width :container-style="headerStyle">
      <div class="bot-console__header">
        <h3 class="bot-console__title">
          <strong>Access Management</strong>
        </h3>
        <p id="access-management-subtitle" class="bot-console__subtitle">
          Welcome to your Access Management. This is where you can edit roles and create users.
        </p>
        <div class="bot-console__search">
          <g-select v-model="env" label=" " class="select-env" :options="envOptions"></g-select>
          <div>
            <g-textfield
              id="search-users"
              v-model="user"
              trailingiconcontent="search"
              trailingiconinteraction
              :placeholder="searchPlaceholder"
              outlined
              label=" "
              helper-text-content=""
              @trailingiconinteraction.native="onSearchUser(user)"
              @keyup.enter.native="onSearchUser(user)"
            ></g-textfield>
            <gsk-linear-progress v-if="isSearching" class="lin-progress"></gsk-linear-progress>
          </div>
          <g-button
            id="create-btn"
            v-model="env"
            label="Create User"
            :options="envOptions"
            inverted
            @click="showCreateUserForm = true"
          ></g-button>
        </div>
      </div>
    </max-width>
    <max-width>
      <table id="table">
        <thead>
          <tr>
            <th>UserID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Roles</th>
            <th>Device License</th>
            <th>Edit</th>
          </tr>
        </thead>

        <div v-if="loading" class="bot-console__loading">
          <gsk-circular-progress mini></gsk-circular-progress>
        </div>

        <tbody v-else>
          <tr v-for="user in usersWithRoles" :key="user.mudId">
            <td>{{ user.username }}</td>
            <td>{{ user.firstName }}</td>
            <td>{{ user.lastName }}</td>
            <td>{{ user.email }}</td>
            <td>
              <ul v-for="role in user.roles" :key="role" style="list-style: none">
                <li>{{ role }}</li>
              </ul>
            </td>
            <td v-if="hasLicense(user)">
              <ul v-for="license in user.licenseFeatures" :key="license" style="list-style: none">
                <li>{{ license }}</li>
              </ul>
            </td>
            <td v-else>None</td>
            <td>
              <gsk-icon-button
                v-if="isCurrentUser(user)"
                icon="pencil"
                officon="pencil"
                disabled
              ></gsk-icon-button>
              <gsk-icon-button
                v-else
                icon="pencil"
                officon="pencil"
                @click="editUserPermissions(user)"
              ></gsk-icon-button>
            </td>
          </tr>
        </tbody>
      </table>
      <div v-if="noUserFound">
        <p>
          <i class="no-grant">
            The user you are looking for does not have any roles in this environment. Try searching
            in a different environment or create/edit their roles.
          </i>
        </p>
      </div>
    </max-width>
    <create-new-user
      v-if="showCreateUserForm"
      :env-options="envOptions"
      :env="env"
      @close="showCreateUserForm = false"
    ></create-new-user>
    <edit-user
      v-if="showEditUserForm"
      :env-options="envOptions"
      :env="env"
      :user-to-edit="selectedUserToEdit"
      @close="showEditUserForm = false"
    ></edit-user>
  </div>
</template>
<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator';
import MaxWidth from '@/components/MaxWidth.vue';
import GButton from '@/components/gsk-components/GskButton.vue';
import GTextfield from '@/components/gsk-components/GskTextfield.vue';
import { SelectOption } from '@/components/form/form.types';
import * as API from '@/api/rpa-admin.api';

import { FindRolesResponse } from '@/types/rpa-admin.types';
import GPeoplePicker from '@/components/gsk-components/GskPeoplePicker.vue';
import CreateNewUser from '@/components/RPA/CreateNewUser.vue';
import EditUser from '@/components/RPA/EditUser.vue';
import GSelect from '@/components/gsk-components/GskSelect.vue';
import { TextfieldInfo } from '@/constants';
import { UserModule } from '@/store/modules/user.module';
import { RpaModule } from '@/store/modules/rpa.module';

const props = {
  minwidth: true,
  noripple: true,
};

@Component({
  components: {
    GPeoplePicker,
    MaxWidth,
    GButton,
    GTextfield,
    CreateNewUser,
    GSelect,
    EditUser,
  },
})
export default class AccessManagement extends Vue {
  public env: string = 'dev';
  public showCreateUserForm: boolean = false;
  public showEditUserForm: boolean = false;
  public loading: boolean = false;
  public usersWithRoles: FindRolesResponse[] = [];
  public selectedUserToEdit: FindRolesResponse = {
    email: '',
    username: '',
    firstName: '',
    lastName: '',
    licenseFeatures: [],
    roles: [],
    id: -2,
    env: '',
    userAcctFound: false,
  };
  public searchPlaceholder: string = TextfieldInfo.accessManagementSearchPlaceholder;
  public user: string = '';
  public isSearching: boolean = false;
  public noUserFound: boolean = false;

  isCurrentUser(user: FindRolesResponse) {
    return user.username === UserModule.user.mudId || !this.rolesUserCanGrant.length;
  }

  get rolesUserCanGrant(): SelectOption[] {
    return RpaModule.rolesUserCanGrant[this.env];
  }

  async onSearchUser(user: string) {
    this.isSearching = true;
    this.noUserFound = false;
    this.usersWithRoles = [];
    // this.usersWithRoles = (await API.searchUserAndFindRoles(user, this.apiUrl, this.env)).filter(
    //   userInfo => userInfo.userAcctFound,
    // );
    try {
      this.usersWithRoles = await API.searchUserAndFindRoles(user, this.env);
    } catch (e) {
      this.isSearching = false;
    }

    if (this.usersWithRoles.length < 1) {
      this.noUserFound = true;
    }
    this.isSearching = false;
  }

  @Watch('env')
  newUserInfoOnEnvChange() {
    this.usersWithRoles = [];
    if (this.isExistingSearchQuery) {
      this.onSearchUser(this.user);
    }
  }

  get isExistingSearchQuery(): boolean {
    return !!this.user;
  }

  get apiUrl(): string {
    const { hostname } = location;
    if (/^localhost|^uat\.|^dev\./.test(hostname)) {
      return 'https://qa.api.gsk.com/tools/search/query';
    }
    return 'https://api.gsk.com/tools/search/query';
  }

  hasLicense(user: FindRolesResponse) {
    return user.licenseFeatures.length > 0;
  }

  get envOptions(): SelectOption[] {
    return [
      {
        key: '1',
        value: 'dev',
        label: 'Dev',
      },
      {
        key: '2',
        value: 'qa',
        label: 'QA',
      },
      {
        key: '3',
        value: 'prod',
        label: 'Production',
      },
    ];
  }

  editUserPermissions(user: FindRolesResponse): void {
    this.selectedUserToEdit = user;
    this.showEditUserForm = true;
  }

  public get containerStyle(): Record<string, string | number> {
    return {
      width: '1515px',
    };
  }

  public get headerStyle(): object {
    return {
      borderBottom: 'none',
      backgroundColor: 'var(--theme-primary)',
      width: '100%',
    };
  }
}
</script>

<style scoped lang="scss">
@import '~@/styles/breakpoints.scss';
@import '~@/styles/theme.scss';

/*gsk-icon-button[disabled] {*/
/*  pointer-events: none;*/
/*}*/

.select-env {
  margin-right: 15px;
  /*margin-top: 4px !important;*/
}

.no-grant {
  color: var(--theme-danger);
}

#search-users {
  min-width: 500px;
}

.lin-progress {
  width: 500px;
  padding: 0 1px;
}

#create-btn {
  align-self: flex-end;
  margin-left: 42px;
  margin-bottom: 8px;
}

td > ul {
  list-style: none;
  padding: 0;
}

#table th {
  font-weight: bold;
  color: var(--theme-medium);
}

.bot-console {
  width: 100%;
  height: auto;

  &.loading {
    display: flex;
    flex-direction: column;
  }

  &__loading {
    flex: 1;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  &__header {
    padding: 48px 0;
    text-align: center;
  }
  &__title {
    margin-top: 0;
    margin-bottom: 16px;
    color: var(--theme-white);
  }
  &__subtitle {
    margin-bottom: 8px;
    color: var(--theme-white);
  }

  &__search {
    max-width: 720px;
    margin: 0 auto;
    display: flex;
    justify-content: space-between;
    align-content: center;

    gsk-textfield,
    gsk-select {
      width: 100%;
    }

    .tf {
      margin-top: 0;
    }
    gsk-textfield {
      max-width: 70%;
    }

    gsk-select {
      max-width: 30%;
    }
  }

  &__tabs {
    box-shadow: 4px 4px 10px 0 rgba(215, 215, 215, 0.2);
    margin-bottom: 48px;

    .gsk-tabs {
      max-width: 1216px;
      margin: 0 auto;
    }
  }

  &__bot-list {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
  }

  &__tree {
    max-width: 300px;
    width: 100%;
    &.selected > .tree-content {
      background-color: var(--theme-primary--hover--light);
    }

    &:not(.selected) > .tree-content:hover {
      background: var(--theme-primary--hover--light);
    }
    .tree-node {
      .tree-content {
        border-radius: 4px;
      }
    }
  }

  &__selected-bot {
    width: 100%;
    max-width: 800px;
  }

  &__list {
    margin-bottom: 48px;

    table {
      table-layout: fixed;
    }
  }

  &__no-results {
    width: 100%;
    text-align: center;
    img {
      max-width: 300px;
    }
  }

  &__error {
    margin-bottom: 8px;
  }

  &__error-message {
    color: var(--theme-danger);
    margin-top: 8px;
  }

  &__pagination {
    display: flex;
    align-items: center;
    justify-content: center;
    padding-left: 0;
    list-style: none;
    width: 100%;
  }

  &__page-link {
    --gsk-theme-primary: var(--theme-dark);
    &.active {
      --gsk-theme-primary: var(--theme-primary);
    }

    &.arrow {
      visibility: hidden;

      &.show {
        visibility: visible;
      }
    }
  }

  &.all {
    .bot-console__tree .tree-node.has-child i.has-child,
    .bot-console__tree .tree-node.has-child .tree-children {
      display: block;
      i.has-child,
      .tree-children {
        display: none;
      }
    }
  }
}
</style>
