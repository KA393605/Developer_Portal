<template>
  <full-screen-form :close-route="closeRoute">
    <div class="promote-prod" :class="{ isDisabled: loading }">
      <h6 class="promote-prod__title">Request to promote to production</h6>
      <div class="promote-prod__input text-field">
        <g-textfield
          id="projectName"
          :value="projectName"
          :label="nameLabel"
          disabled
          name="projectName"
          outlined
          type="text"
          helper-text-content=" "
        />
        <g-textfield
          id="projectDescription"
          :value="projectDescription"
          :label="descriptionLabel"
          disabled
          name="projectDescription"
          type="textarea"
          outlined
          helper-text-content=" "
        />
        <g-button
          id="settingsButton"
          type="text"
          icon="pencil"
          officon="pencil"
          label="Edit Details"
          @click.native="editSettings"
        />
      </div>
      <div class="promote-prod__input">
        <gsk-autocomplete
          id="pandoraId"
          label="Pandora ID"
          name="pandoraId"
          type="text"
          :get-choices.prop="getPandoraIdChoices"
          async
          required
          @change="setPandoraId"
        />
      </div>
      <div class="promote-prod__input">
        <g-textfield
          id="businessPurpose"
          v-model="businessPurpose"
          :label="businessPurposeLabel"
          name="businessPurpose"
          type="textarea"
          outlined
          required
          :placeholder="businessPurposePlaceholder"
          :validationmessage="businessPurposeValidationMessage"
        />
      </div>
      <div class="promote-prod__terms">
        <gsk-formfield :label="termsLabel">
          <gsk-checkbox
            id="terms"
            name="terms"
            value="1"
            :checked="termsChecked"
            @change="termsChange"
          />
        </gsk-formfield>
      </div>
      <div class="promote-prod__button">
        <g-analytics v-slot="{ sendClick }" :click-data="analyticsData">
          <g-button
            id="submitButton"
            unelevated
            :disabled="submitDisable"
            @click="submitRequest(sendClick)"
          >
            Submit Request
          </g-button>
        </g-analytics>
      </div>
    </div>

    <gsk-snackbar
      ref="snack"
      class="snackbar"
      labeltext="Request sent for promotion to Production enviroment"
      actiontext="OK"
    >
      <gsk-icon-button id="iconButton" slot="dismiss" icon="gsk_close" officon="gsk_close" />
    </gsk-snackbar>
  </full-screen-form>
</template>
<script lang="ts">
import { Component } from 'vue-property-decorator';
import { mixins } from 'vue-class-component';
import { Checkbox } from '@gsk-platforms/gsk-checkbox/gsk-checkbox';
import { Snackbar } from '@gsk-platforms/gsk-snackbar/gsk-snackbar';
import { DeepReadonly } from 'ts-essentials';
import FullScreenForm from '@/components/FullScreenForm.vue';
import GButton from '@/components/gsk-components/GskButton.vue';
import GTextfield from '@/components/gsk-components/GskTextfield.vue';
import { ProjectDetailsModule } from '@/store/modules/project-details.module';
import Form from '@/components/mixins/formChecks';
import { Environments, RouteNames, TextfieldInfo } from '@/constants';
import { openSnackbar } from '@/utils/components';
import * as Projects from '@/types/projects.types';
import { addAnalyticsRouteParams, ClickData } from '@/analytics';
import * as API from '@/api/projects.api';
import GAnalytics from '@/components/GAnalytics';

// TODO: this page would be better as a true modal on the env page

@Component({
  components: {
    FullScreenForm,
    GButton,
    GTextfield,
    GAnalytics,
  },
})
export default class PromoteProdView extends mixins(Form) {
  private loading: boolean = true;
  public termsLabel: string =
    'By submitting this request, you agree to the ONE Platform Shared Responsibilities ' +
    'Agreement. Smart Controls have all been reviewed for submission.';

  private pandoraId: string = '';
  private pandoraErrorMessage: string = '';
  private businessPurpose: string = ProjectDetailsModule.purpose;
  private termsChecked: boolean = false;
  public nameLabel: string = TextfieldInfo.nameLabel;
  public descriptionLabel: string = TextfieldInfo.descriptionLabel;
  public businessPurposeLabel: string = TextfieldInfo.businessPurposeLabel;
  public businessPurposePlaceholder: string = TextfieldInfo.businessPurposePlaceholder;
  public businessPurposeValidationMessage: string = TextfieldInfo.businessPurposeValidationMessage;

  get analyticsData(): ClickData {
    return {
      clickTarget: 'promote-to-prod-form-submit',
      projectName: this.projectName,
      projectId: this.project.projectId,
      pandoraId: this.pandoraId,
    };
  }

  get closeRoute() {
    return {
      name: RouteNames.ProjectDetails,
      params: addAnalyticsRouteParams(
        {
          id: ProjectDetailsModule.projectDetails.projectId.toString(),
        },
        {
          projectName: this.projectName,
          projectId: this.project.projectId,
        },
      ),
    };
  }

  get project(): DeepReadonly<Projects.Project> {
    return ProjectDetailsModule.projectDetails;
  }

  get pandoraValid() {
    return !this.pandoraErrorMessage && !!this.pandoraId;
  }

  termsChange(e: Event) {
    if (e.target) {
      this.termsChecked = (e.target as Checkbox).checked;
    }
  }

  editSettings() {
    ProjectDetailsModule.setBusinessPurpose(this.businessPurpose);
    this.$router.push({
      name: RouteNames.ProjectSettings,
      params: { id: this.project.projectId.toString() },
    });
  }

  async getPandoraIdChoices(query: string): Promise<Projects.PandoraIdLabel[]> {
    const choices = await API.getPandoraIDs(query);
    return choices.data.map(res => ({ label: `${res.id} - ${res.name}`, value: res.id }));
  }

  setPandoraId(e: CustomEvent) {
    if (e.detail.selectedChoice) {
      this.pandoraId = e.detail.selectedChoice.value;
    }
  }

  submitRequest(sendClick: () => {}): Promise<void> {
    sendClick();
    const promoteQuery: Projects.PromoteQuery = {
      confirm: true,
      projectDescription: this.projectDescription,
      businessJustification: this.businessPurpose,
      pandoraId: this.pandoraId,
    };
    this.loading = true;
    this.pandoraErrorMessage = '';

    return ProjectDetailsModule.promoteEnvironment({
      projectEnvId: this.$route.params.env,
      query: promoteQuery,
      srcEnv: Environments.Qa,
    })
      .then(result => {
        this.$router.push({
          name: RouteNames.ProjectEnvDetails,
          params: addAnalyticsRouteParams(
            {
              id: this.project.projectId.toString(),
              env: result.projectEnvironmentId.toString(),
              section: 'auth',
            },
            {
              projectName: ProjectDetailsModule.projectDetails.projectName,
              projectId: ProjectDetailsModule.projectDetails.projectId,
            },
          ),
        });
        openSnackbar.call(this, 'Request sent for promotion to Production environment');
      })
      .catch(e => {
        if (e.response.status === 400) {
          if (/pandora/gi.test(e.response.data.message)) {
            this.pandoraErrorMessage = e.response.data.message;
            openSnackbar.call(this, e.response.data.message);
          } else {
            openSnackbar.call(this, 'AIR Error: Promotion request failed');
          }
        } else {
          openSnackbar.call(this, 'Server Error: Promotion request failed');
        }
      })
      .finally(() => {
        this.loading = false;
      });
  }

  set projectName(v) {}
  get projectName(): string {
    return this.project.projectName;
  }

  set projectDescription(v) {}
  get projectDescription(): string {
    return this.project.projectDescription;
  }

  get submitDisable(): boolean {
    return !this.pandoraId || !this.businessPurpose || !this.termsChecked;
  }

  openSnackbar() {
    if (this.$refs.snack) {
      (this.$refs.snack as Snackbar).open();
    }
  }

  async created() {
    if (ProjectDetailsModule.projectDetails.projectId === +this.$route.params.id) {
      this.$log('populated form without loading fresh data');
    } else {
      this.$log('populated form by loading fresh data');
      await ProjectDetailsModule.getProject(this.$route.params.id);
    }

    this.loading = false;
  }
}
</script>
<style lang="scss" scoped>
@import '~@/styles/breakpoints.scss';
@import '~@/styles/theme.scss';

.snackbar {
  color: $theme-typography--on-dark;
  --gsk-theme-secondary: #{$theme-typography--on-dark};
}

gsk-formfield {
  min-width: 150px;
}

.loadingDisabled {
  pointer-events: none;
  user-select: none;
  user-focus: none;
  opacity: 0.5;
}

.promote-prod {
  display: flex;
  flex-direction: column;
  width: 100%;
  max-width: 700px;
  margin-bottom: 3rem;
  @include breakpoint($desktop) {
    padding: 0;
  }

  &__title {
    text-align: center;
    margin-bottom: 40px;
  }

  &__input {
    &.text-field {
      // account for helper text height
      margin-bottom: calc(2rem - 19px);
    }
    margin-bottom: 2rem;
  }

  &__button {
    margin-top: 2rem;
    text-align: center;
  }

  #settingsButton {
    float: right;
  }
}
</style>
