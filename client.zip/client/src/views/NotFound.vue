<template>
  <div class="about">
    <h1>Page Not Found</h1>
    <h2><router-link to="/">Return Home</router-link></h2>
  </div>
</template>
<style scoped>
.about {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  > * {
    margin: 1em;
  }
}
</style>
