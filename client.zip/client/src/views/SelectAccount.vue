<template>
  <div class="bot-console" :class="{ loading: !ready, all: allBotsShowing }">
    <max-width :container-style="headerStyle">
      <p class="bot-console__subtitle">
        Coming Soon
      </p>
    </max-width>
  </div>
</template>
<script lang="ts">
import { Component, Emit, Vue } from 'vue-property-decorator';
import LiquorTree from 'liquor-tree';
import MaxWidth from '@/components/MaxWidth.vue';
import NavigationTabs from '@/components/NavigationTabs.vue';
import GTextfield from '@/components/gsk-components/GskTextfield.vue';
import GSelect from '@/components/gsk-components/GskSelect.vue';
import SelectedBotInfo from '@/components/SelectedBotInfo.vue';
import { SelectOption } from '@/components/form/form.types';

import { Bot, BotNode } from '@/types/rpa-admin.types';
import { UINavigationItem } from '@/types';
import { RpaModule } from '@/store/modules/rpa.module';

const props = {
  minwidth: true,
  noripple: true,
};

@Component({
  components: {
    GSelect,
    MaxWidth,
    NavigationTabs,
    GTextfield,
    tree: LiquorTree,
    SelectedBotInfo,
  },
})
export default class BotConsoleView extends Vue {
  public searchPlaceholder: string = 'Search RPA Console';
  public env: string = 'dev';
  public show: boolean = false;
  public allBotsShowing: boolean = false;
  public treeOptions = {
    filter: {
      emptyText: 'No results found.',
    },
  };
  public treeFilter: string = '';

  get envOptions(): SelectOption[] {
    return [
      {
        key: '1',
        value: 'dev',
        label: 'Dev',
      },
      {
        key: '2',
        value: 'qa',
        label: 'QA',
      },
      {
        key: '3',
        value: 'prod',
        label: 'Production',
      },
    ];
  }

  public page: number = 1;
  public bots: Bot[] = [];
  public ready: boolean = false;
  public errorMessage: string = '';

  updateEnv(e: string): void {
    if (this.hasFolder(e)) {
      this.$router.push({ path: `/rpa-console/${e}/${this.type}` }).catch(() => {});
    } else {
      this.$router.push({ path: `/rpa-console/${e}` }).catch(() => {});
    }
  }

  hasFolder(env: string): boolean {
    const folders = RpaModule.buBotsUserCanPromote[env];
    if (folders) {
      return !!folders.find(bu => bu === this.type);
    }
    return false;
  }

  get getEnv(): string {
    const routeEnv = this.$route.params.env;
    if (routeEnv) {
      return routeEnv;
    }
    return 'dev';
  }

  protected filters: { search: string } = {
    search: '',
  };

  @Emit('onSearch')
  protected onSearch(value: string) {
    return value;
  }

  public tab: UINavigationItem = {
    props,
    text: '',
    key: '',
    replace: true,
    route: {},
  };

  public get tabBarProps(): object {
    return {
      noripple: true,
    };
  }

  public get tabs(): UINavigationItem[] {
    return (this.types || []).reduce((array: UINavigationItem[], type) => {
      array.push({
        props,
        text: type.trim(),
        key: type,
        route: {
          path: `/rpa-console/${this.env}/${type}`,
        },
      });
      return array;
    }, []);
  }

  public get headerStyle(): object {
    return {
      borderBottom: 'none',
      backgroundColor: 'var(--theme-primary)',
      width: '100%',
    };
  }

  getBots(env: string, type: string): void {
    this.ready = true;
    RpaModule.getBots({ env, folder: type, search: '%%' });
  }

  get treeKey(): string {
    return this.type + this.env;
  }

  get botResponse(): Bot[] {
    if (RpaModule.botsInBu[this.type]) {
      return RpaModule.botsInBu[this.type][this.env] || [];
    }
    return [];
  }

  created() {
    this.env = this.getEnv;
  }

  get type(): string {
    const { type } = this.$route.params;
    return this.types.find(t => t === type) || this.types[0];
  }

  get types(): string[] {
    return RpaModule.buBotsUserCanPromote[this.env];
  }

  get noPermissionsOnEnv(): boolean {
    if (RpaModule.buBotsUserCanPromote[this.env]) {
      return RpaModule.buBotsUserCanPromote[this.env].length < 1;
    }
    return false;
  }
}
</script>

<style scoped lang="scss">
@import '~@/styles/breakpoints.scss';
@import '~@/styles/theme.scss';
/*.tree-highlights .tree-node.matched > .tree-content{*/
/*  background: #fff1ee;*/
/*}*/

.select-env {
  margin-right: 15px;
  /*margin-top: 4px !important;*/
}

.bot-console {
  width: 100%;
  height: auto;

  &.loading {
    display: flex;
    flex-direction: column;
  }

  &__loading {
    flex: 1;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  &__header {
    padding: 48px 0;
    text-align: center;
  }
  &__title {
    color: var(--theme-white);
    margin-top: 0;
    margin-bottom: 16px;
  }
  &__subtitle {
    color: var(--theme-white);
    margin-bottom: 8px;
  }

  &__search {
    max-width: 720px;
    margin: 0 auto;
    display: flex;
    justify-content: space-between;
    align-content: center;

    gsk-textfield,
    gsk-select {
      width: 100%;
    }

    .tf {
      margin-top: 0;
    }
    gsk-textfield {
      max-width: 70%;
    }

    gsk-select {
      max-width: 30%;
    }
  }

  &__tabs {
    box-shadow: 4px 4px 10px 0 rgba(215, 215, 215, 0.2);
    margin-bottom: 48px;

    .gsk-tabs {
      max-width: 1216px;
      margin: 0 auto;
      display: flex;
      padding-left: 40px;
    }
  }

  &__bot-list {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
  }

  &__tree {
    max-width: 300px;
    width: 100%;
    &.selected > .tree-content {
      background-color: var(--theme-primary--hover--light);
    }

    &:not(.selected) > .tree-content:hover {
      background: var(--theme-primary--hover--light);
    }
    .tree-node {
      .tree-content {
        border-radius: 4px;
      }

      /*&.has-child {*/
      /*  i.has-child,*/
      /*  .tree-children {*/
      /*    !*display: none;*!*/
      /*  }*/
      /*}*/
    }
  }

  &__selected-bot {
    width: 100%;
    max-width: 800px;
  }

  &__list {
    margin-bottom: 48px;

    table {
      table-layout: fixed;
    }
  }

  &__no-results {
    width: 100%;
    text-align: center;
    img {
      max-width: 300px;
    }
  }

  &__error {
    margin-bottom: 8px;
  }

  &__error-message {
    color: var(--theme-danger);
    margin-top: 8px;
  }

  &__pagination {
    display: flex;
    align-items: center;
    justify-content: center;
    padding-left: 0;
    list-style: none;
    width: 100%;
  }

  &__page-link {
    --gsk-theme-primary: var(--theme-dark);
    &.active {
      --gsk-theme-primary: var(--theme-primary);
    }

    &.arrow {
      visibility: hidden;

      &.show {
        visibility: visible;
      }
    }
  }

  &.all {
    .bot-console__tree .tree-node.has-child i.has-child,
    .bot-console__tree .tree-node.has-child .tree-children {
      display: block;
      i.has-child,
      .tree-children {
        display: none;
      }
    }
  }
}
</style>
