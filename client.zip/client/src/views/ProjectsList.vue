<template>
  <section class="projects__container bg" :class="{ empty: projects.length === 0 }">
    <max-width :container-style="headerStyle">
      <div class="projects__header">
        <h5>
          Projects
          <help-link doc-path="1. Projects" />
        </h5>
        <p>With projects, you can connect services, manage keys, and register APIs</p>
      </div>
    </max-width>
    <div v-if="loading" class="flex-center loading-container">
      <gsk-circular-progress />
    </div>
    <ProjectList
      v-else-if="projects.length"
      :projects="projects"
      :filters="filters"
      :list-mode="listMode"
      class="bg"
    />
    <empty-state
      v-else
      title="You don't have any projects"
      subtitle="Create a new one and add your team."
      button-text="New Project"
      :link="newProjectsLink"
      :image-src="emptyImageSrc"
    />
  </section>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { ProjectsModule } from '@/store/modules/projects.module';
import ProjectList from '@/components/projects/project-list.vue';
import ProjectListOptions from '@/components/projects/project-list-options.vue';
import GButton from '@/components/gsk-components/GskButton.vue';
import MaxWidth from '@/components/MaxWidth.vue';
import EmptyState from '@/components/EmptyState.vue';
import { RouteNames } from '@/constants';
import HelpLink from '@/components/HelpLink.vue';
/* eslint-disable-next-line @typescript-eslint/no-var-requires */
const img = require('@/assets/projects.svg');

@Component({
  components: {
    ProjectList,
    ProjectListOptions,
    GButton,
    MaxWidth,
    EmptyState,
    HelpLink,
  },
})
export default class ProjectsListView extends Vue {
  protected filters: { search: string } = {
    search: '',
  };
  protected listMode: string = 'cards';
  private newProjectOpen: boolean = false;
  private loading: boolean = true;

  get headerStyle() {
    return {
      backgroundColor: 'var(--theme-lightest)',
    };
  }

  protected changeProjectViewMode(mode: string) {
    this.listMode = mode;
  }

  protected searchProject(val: string) {
    this.filters.search = val;
  }

  async created() {
    await ProjectsModule.getProjects();
    this.loading = false;
  }

  get projects() {
    return ProjectsModule.projects;
  }

  get newProjectsLink() {
    return {
      name: RouteNames.NewProject,
    };
  }

  get emptyImageSrc() {
    return img;
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/breakpoints.scss';
@import '~@/styles/theme.scss';
.bg {
  background-color: $theme-white;
}
.loading-container {
  margin-top: 3rem;
}

.projects {
  &__container {
    display: flex;
    flex-direction: column;
    flex: 1;
    width: 100%;

    &.empty {
      display: flex;
      flex-direction: column;

      .max-width__container {
        margin-bottom: 32px;
      }
    }
  }
  &__header {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: center;
    padding: 64px 0;

    @include breakpoint($medium) {
      /*height: 168px;*/
    }

    > h5 {
      margin: 0;
    }
  }
}
</style>
