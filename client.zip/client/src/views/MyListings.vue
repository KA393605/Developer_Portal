<template>
  <section class="listings__container bg" :class="{ empty: !listings.length }">
    <max-width :container-style="headerStyle">
      <div class="listings__header">
        <h5 class="heading">
          My Listings
          <help-link doc-path="2. My Listings.md" />
        </h5>
      </div>
      <gsk-formfield v-if="isAdmin" label="Manage All Listings">
        <gsk-checkbox @change="useAdminMode"></gsk-checkbox>
      </gsk-formfield>
    </max-width>

    <max-width class="listings__content">
      <div v-if="loading || error || listings.length" class="button-container">
        <router-link :to="{ name: publishNew }" class="button">
          <gsk-fab
            icon="plus"
            class="button"
            extended
            primary
            label="Publish New"
            @click="publishNewListing"
          ></gsk-fab>
        </router-link>
      </div>
      <div v-if="loading" class="flex-center loading-container">
        <gsk-circular-progress />
      </div>
      <div v-else-if="error" class="flex-center loading-container">
        <h4>Server Error</h4>
      </div>
      <template v-else-if="listings.length">
        <div class="table-wrapper">
          <table>
            <thead key="head">
              <tr>
                <th colspan="2">Name</th>
                <th>Type</th>
                <!--                <th>Version</th>-->
                <th>
                  <!--                  <span style="display: flex;">-->
                  Owners
                  <!--                    <help-tooltip text="Exactly what it sounds like" />-->
                  <!--                  </span>-->
                </th>
                <th>Status</th>
                <th>Last Update</th>
                <th></th>
              </tr>
            </thead>

            <listing-entry
              v-for="l in listings"
              :key="l.listingId"
              :listing="l"
              :is-admin-mode="isAdminMode"
              @unpublish="reloadListings"
              @delete="handleDelete"
              @add="addNewVersion"
              @admin="openAdminDialog"
            />
          </table>
        </div>
      </template>
      <empty-state
        v-else
        title="Publish your first listing"
        subtitle="Publish a listing to be discovered, shared, and consumed on the product catalog."
        button-text="Publish New"
        :link="publishLink"
        :image-src="imageSrc"
        @click="publishNewListing"
      />
    </max-width>
    <delete-dialog
      :open.sync="openDelete"
      center-content
      button-text="Yes, delete"
      headerlabel="Are you sure you want to delete this listing?"
      @delete="deleteListing"
    >
      Deleting this listing will remove it from the catalog and your listings.
    </delete-dialog>
    <delete-dialog
      :open.sync="openDiscard"
      center-content
      button-text="Yes, delete"
      headerlabel="Are you sure you want to delete this draft?"
      @delete="discardDraft"
    >
      Deleting this draft will discard all of your saved work.
    </delete-dialog>
    <g-dialog
      :key="listingId"
      :open.sync="adminDialog"
      conter-content
      :headerlabel="listingName"
      hideactionbuttons
    >
      <div v-for="content in adminDialogContent" :key="content.title">
        <div class="admin-row">
          <div class="admin-span-row">
            <span class="admin-flex-item admin-span">
              {{ content.title }}
            </span>
            <gsk-switch
              class="admin-flex-item admin-switch"
              :name="content.radioValue"
              :checked.prop="content.checked"
              @change="checkedSwitch(content)"
            ></gsk-switch>
          </div>
          <p class="admin-flex-item admin-content">{{ content.content }}</p>
        </div>
      </div>
      <div>Published: {{ listingPublishedDate }}</div>
    </g-dialog>
    <g-dialog
      :open.sync="openNoNewVersions"
      center-content
      headerlabel="There are no new versions for this API"
    >
      To register a new version for this API in the gateway, reach out to
      <a href="mailto:apigateway_support@gsk.com">apigateway_support@gsk.com</a>
    </g-dialog>
  </section>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { RawLocation } from 'vue-router';
import { Switch } from '@gsk-platforms/gsk-switch/gsk-switch';
import GButton from '@/components/gsk-components/GskButton.vue';
import MaxWidth from '@/components/MaxWidth.vue';
import EmptyState from '@/components/EmptyState.vue';
import { RouteNames, Statuses } from '@/constants';
import { PublishingModule } from '@/store/modules/publishing.module';
import HelpTooltip from '@/components/HelpTooltip.vue';
import { MyListing, MyListingVersion, adminRole } from '@/types/publishing.types';
import ListingEntry from '@/components/Publish/ListingEntry.vue';
import DeleteDialog from '@/components/dialogs/DeleteDialog.vue';
import GDialog from '@/components/gsk-components/GskDialog.vue';
import * as API from '@/api/publishing.api';
import { UserModule } from '@/store/modules/user.module';
import HelpLink from '@/components/HelpLink.vue';

/* eslint-disable-next-line @typescript-eslint/no-var-requires */
const img = require('@/assets/computer.svg');

@Component({
  components: {
    GButton,
    MaxWidth,
    EmptyState,
    HelpTooltip,
    ListingEntry,
    DeleteDialog,
    GDialog,
    HelpLink,
  },
})
export default class MyListingsView extends Vue {
  private loading: boolean = true;
  private error: boolean = false;
  private deleteId: number = 0;
  private openDelete: boolean = false;
  private openDiscard: boolean = false;
  private adminDialog: boolean = false;
  private discardBug: boolean = false;
  private openNoNewVersions: boolean = false;
  public publishNew: string = RouteNames.PublishListing;
  private listingName: string = '';
  private listingPublishedDate: string = '';
  public isAdminMode: boolean = false;
  private isOwner: boolean = false;
  public isFeatured: boolean = false;
  public listingId: number = -1;

  get adminDialogContent(): adminRole[] {
    return [
      {
        title: 'Is Featured',
        radioValue: 'feature',
        checked: this.listingIsFeatured,
        content: 'Turn on to feature listing in catalog',
      },
      {
        title: 'Can Manage',
        radioValue: 'manage',
        checked: this.userIsOwner,
        content: 'Turn on to give yourself owner rights to this listing',
      },
    ];
  }

  get userIsOwner(): boolean {
    return this.isOwner;
  }

  set userIsOwner(isOwner: boolean) {
    this.isOwner = isOwner;
  }

  get listingIsFeatured(): boolean {
    return this.isFeatured;
  }

  set listingIsFeatured(isFeatured: boolean) {
    this.isFeatured = isFeatured;
  }

  get headerStyle() {
    return {
      backgroundColor: 'var(--theme-lightest)',
    };
  }

  get imageSrc() {
    return img;
  }

  get listings() {
    return PublishingModule.myListings;
  }

  get publishLink(): RawLocation {
    return { name: RouteNames.PublishListing };
  }

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  handleDelete(listing: MyListing, listingVersion: MyListing['versions'][0]) {
    const isDraft = listing.statusName !== Statuses.Published;
    this.deleteId = listing.listingId;
    if (isDraft) {
      // FIXME: workaround because discard doesn't work if never published
      this.discardBug = listing.publishDate === null;
      this.openDiscard = true;
    } else {
      this.openDelete = true;
    }
  }

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  async openAdminDialog(listing: MyListing, listingVersion: MyListingVersion) {
    this.listingId = listing.listingId;
    const { isCurrentOwner, isFeaturedFlag } = await this.getAdminSettings(listing.listingId);
    this.adminDialog = true;
    this.listingName = listing.listingName;
    const date = new Date(listing.publishDate);
    this.listingPublishedDate = date.toLocaleDateString();
    this.userIsOwner = isCurrentOwner;
    // this.isFeatured = isFeaturedFlag;
    this.listingIsFeatured = isFeaturedFlag;
  }

  reloadListings() {
    this.loadAllListings();
  }

  async discardDraft() {
    if (this.discardBug) {
      await this.afterDelete(PublishingModule.deleteDraftListing(this.deleteId));
    } else {
      await this.afterDelete(PublishingModule.discardDraftListing(this.deleteId));
    }
  }

  async deleteListing() {
    await this.afterDelete(PublishingModule.deleteDraftListing(this.deleteId));
  }

  async canPublishNewVersion(listing: MyListing): Promise<boolean> {
    try {
      const { versions } = (await API.getRegistrationVersions(listing.registrationId)).data;
      // 1480: Comment out below if/else to see multiple versions dummy data
      if (versions === null) {
        return false;
      } else {
        return !!versions.length;
      }
      // 1480: Uncomment below to see "multiple versions"
      // return true;
    } catch (e) {
      this.$log('error', e);
      return false;
    }
  }

  afterDelete(p: Promise<unknown>) {
    return p
      .then(() => {
        this.openDiscard = false;
        this.openDelete = false;
        return this.loadListings();
      })
      .finally(() => {
        this.openDiscard = false;
        this.openDelete = false;
      });
  }

  async addNewVersion(listing: MyListing) {
    // TODO: this whole ass thing
    // const canPublish = await this.canPublishNewVersion(listing);
    // if (canPublish) {
    //   PublishingModule.setDraftListing(this.transformedListing(listing));
    //   PublishingModule.updatePublishFlow();
    //   await PublishingModule.getRegistrationVersions(listing.registrationId);
    //   this.$router.push({
    //     name: RouteNames.PublishListing,
    //     params: {
    //       listingId: listing.listingId.toString(),
    //     },
    //     query: { mode: 'version' },
    //   });
    // } else {
    //   this.openNoNewVersions = true;
    // }
  }

  loadListings() {
    return PublishingModule.getMyListings()
      .catch(() => {
        this.error = true;
      })
      .finally(() => {
        this.loading = false;
      });
  }

  loadAllListings() {
    return PublishingModule.getAllListings()
      .catch(() => {
        this.error = true;
      })
      .finally(() => {
        this.loading = false;
      });
  }

  addSelfAsOwner() {
    API.addSelfAsOwner(this.listingId, !this.userIsOwner);
    this.loadAllListings();
  }

  setListingAsFeatured() {
    API.setListingAsFeatured(this.listingId, !this.listingIsFeatured);
    this.reloadListings();
  }

  async getAdminSettings(
    listingId: number,
  ): Promise<{ isCurrentOwner: boolean; isFeaturedFlag: boolean }> {
    return (await API.getAdminSettings(listingId)).data;
  }

  publishNewListing() {
    PublishingModule.resetPublishingState();
  }

  useAdminMode() {
    this.isAdminMode = !this.isAdminMode;
    if (this.isAdminMode) {
      this.loadAllListings();
    } else {
      this.loadListings();
    }
  }

  async created() {
    await this.loadListings();
  }

  get userRoleName(): string {
    if (UserModule.user.roles[0]) {
      return UserModule.user.roles[0].roleName;
    } else return '';
  }

  get isAdmin(): boolean {
    return this.userRoleName === 'Listing Admin';
  }

  checkedSwitch(content: adminRole) {
    const selectedSwitch = content.radioValue;
    if (selectedSwitch === 'manage') {
      this.addSelfAsOwner();
    } else if (selectedSwitch === 'feature') {
      this.setListingAsFeatured();
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/breakpoints.scss';
@import '~@/styles/theme.scss';
@import '~@/styles/typography.scss';
$content-margin: 88px;
.admin-row {
  display: flex;
  /*justify-content: space-between;*/
  /*border: 1px solid lightseagreen;*/
}

.admin-span-row {
  display: flex;
  margin-left: 88px;
  /*border: 2px solid green;*/
}

.admin-row > .admin-flex-item {
  /*border: 1px solid gray;*/
}

.admin-span {
  width: 165px;
  align-self: center;
}

.admin-switch {
  align-self: center;
  height: 23px;
}

.admin-content {
  margin-left: 100px;
}

#admin-button {
  margin: 0 45px;
}

.bg {
  background-color: $theme-white;
}
.table-wrapper {
  // account for menu
  padding-bottom: 9rem;
}
.listings {
  &__container {
    flex: 1;
    width: 100%;
    /*overflow-x: visible;*/

    &.empty {
      display: flex;
      flex-direction: column;

      .max-width__container {
        margin-bottom: 32px;
      }
    }
  }
  &__header {
    display: flex;
    align-items: center;
    height: auto;
    padding: 64px 0;

    > .heading {
      flex: 1;
      margin: 0;
    }
  }
  &__content {
    margin-top: 0;
    margin-bottom: 0;

    @include breakpoint($medium) {
      margin-top: $content-margin;
      margin-bottom: $content-margin;
    }
    .button-container {
      width: 100%;
      position: relative;
      text-align: right;
      @include breakpoint($medium) {
        height: 0;
      }

      .button {
        position: relative;
        margin: 0;
        top: -0.6rem;

        @include breakpoint($medium) {
          right: 0;
          top: -3.6rem;
        }
      }
    }
  }
}
</style>
