<template>
  <max-width>
    <div>
      <h2>Test Form</h2>
      <generated-form v-model="testFormModel"></generated-form>
    </div>
  </max-width>
</template>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import GeneratedForm from '@/components/form/GeneratedForm.vue';
import { ExtendedPropertiesDetails } from '@/components/form/form.types';
import MaxWidth from '@/components/MaxWidth.vue';

@Component({
  components: {
    GeneratedForm,
    MaxWidth,
  },
})
export default class PlaceholderView extends Vue {
  private testFormModel: ExtendedPropertiesDetails['fields'] = [
    {
      type: 'select',
      key: 'delivered-by',
      label: 'Delivered By (BU)',
      required: true,
      helpText: 'helper text',
      value: '',
      options: [
        {
          value: 'One',
        },
        {
          value: 'Two',
        },
        {
          value: 'Three',
        },
      ],
    },
    {
      type: 'multi-select',
      key: 'multi-select',
      label: 'Select some stuff',
      required: true,
      helpText: 'helper text',
      value: ['is'],
      options: [
        {
          value: 'Multiselect',
        },
        {
          value: 'is',
        },
        {
          value: 'using',
        },
        {
          value: 'checkboxes',
        },
        {
          value: 'for now',
        },
      ],
    },
    {
      type: 'radio',
      key: 'bot-status',
      label: 'What is the status of your bot?',
      required: true,
      helpText: 'helper text',
      value: '',
      options: [
        {
          value: 'DEV',
        },
        {
          value: 'QA',
        },
        {
          value: 'PROD',
        },
      ],
    },
    {
      type: 'checkbox',
      key: 'checkbox',
      label: 'What is the status of your bot?',
      required: true,
      helpText: 'helper text',
      value: ['DEV'],
      options: [
        {
          value: 'DEV',
        },
        {
          value: 'QA',
        },
        {
          value: 'PROD',
        },
      ],
    },
    {
      type: 'text',
      key: 'bp',
      label: 'Business Process',
      required: true,
      helpText: 'helper text',
      value: '',
    },
    {
      type: 'long-text',
      key: 'bot-description',
      label: 'Some Description',
      required: true,
      helpText: 'helper text',
      value: '',
    },
    {
      type: 'people-picker',
      key: 'permissions',
      label: 'Owners',
      required: true,
      helpText: 'helper text',
      value: [
        {
          fullName: 'Stephan Tabor',
          mudId: 'st536122',
          email: 'stephan.x.tabor@gsk.com',
        },
      ],
    },
  ];
}
</script>
