<template>
  <div id="api-catalog" style="width:100%;" :class="{ empty }">
    <search-banner :banner-info="bannerData" @onSearch="searchListing"></search-banner>

    <div v-if="hasTypes">
      <div v-if="!hasSearchQuery" class="api-catalog__tabs">
        <div class="api-catalog__tabs-container">
          <navigation-tabs
            :links="tabs"
            :container-props="tabBarProps"
            class="tabs"
          ></navigation-tabs>
        </div>
      </div>
      <div v-if="catalogs.length > 0 && !empty && !loading" class="catalog-listings">
        <max-width v-if="hasSearchQuery">
          <span class="results_message f-body--small">
            <router-link :to="catalogLink">Product Catalog</router-link>
            » {{ numResultsText }} for
            <strong>"{{ searchQuery }}"</strong>
          </span>
        </max-width>
        <card-list-with-header
          v-for="catalog in catalogs"
          :key="catalog.listingTypeId"
          :header="catalog.listingTypeName"
          :catalog="catalog"
          :filters="filters"
        ></card-list-with-header>
      </div>
      <div v-else class="catalog-loading">
        <gsk-circular-progress></gsk-circular-progress>
      </div>
    </div>
    <div v-else class="catalog-loading">
      <gsk-circular-progress></gsk-circular-progress>
    </div>

    <!-- Show if no listings -->
    <div v-show="empty && !loading" class="api-catalog__empty">
      <max-width :class="{ hasSearchQuery }" class="search_result_message">
        <span class="results_message f-body--small">
          <router-link :to="catalogLink">Product Catalog</router-link>
          » {{ numResultsText }} for
          <strong>"{{ searchQuery }}"</strong>
        </span>
      </max-width>
      <div class="no_listings">
        <img src="@/assets/uh-oh.png" alt="A file folder and document stacked" />
        <h6>No Listings Found</h6>
        <p>It seems we can't find any results base on your search.</p>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator';
import CardListWithHeader from '@/components/catalog/CardListWithHeader/CardListWithHeader.vue';
import SearchBanner from '@/components/catalog/SearchBanner/SearchBanner.vue';
import {
  ListingsModule as ListingCatalogModule,
  ListingsPaginated,
} from '@/store/modules/listings.module';
import GButton from '@/components/gsk-components/GskButton.vue';
import NavigationTabs from '@/components/NavigationTabs.vue';
import { UINavigationItem } from '@/types';
import { RouteNames } from '@/constants';
import { slugify } from '@/utils/routing';
import MaxWidth from '@/components/MaxWidth.vue';
import { EnumsModule } from '@/store/modules/enums.module';

const props = {
  minwidth: true,
  noripple: true,
};

@Component({
  components: {
    CardListWithHeader,
    SearchBanner,
    GButton,
    NavigationTabs,
    MaxWidth,
  },
})
export default class ListingsCatalogView extends Vue {
  protected filters: { search: string } = {
    search: '',
  };

  async created() {
    console.log('Enums');
    const { getAllEnumTypes, hasEnums } = EnumsModule;
    if (hasEnums) {
      this.callNoAwait(getAllEnumTypes);
    } else {
      await getAllEnumTypes();
    }
  }

  callNoAwait(fn: () => void): void {
    fn();
  }

  protected searchListing(value: string) {
    const location = {
      name: RouteNames.Listings,
      query: {
        q: value,
      },
    };
    if (!value) {
      delete location.query;
    }
    this.$router.push(location);
  }

  public loading: boolean = true;

  get hasSearchQuery(): boolean {
    return !!this.$route.query.q;
  }

  get hasTypes(): boolean {
    return ListingCatalogModule.listingTypes.length > 0;
  }

  get searchQuery(): string {
    if (this.hasSearchQuery) {
      const { q } = this.$route.query;
      return this.routerQueryString(q);
    }
    return '';
  }

  get numSearchResults(): number {
    return this.catalogs.reduce((count, listing) => {
      return count + listing.count;
    }, 0);
  }

  get numResultsText(): string {
    const count = this.numSearchResults;
    if (count === 1) {
      return count + ' result';
    } else {
      return count + ' results';
    }
  }

  protected routerQueryString(q: string | (string | null)[]): string {
    return Array.isArray(q) ? q.join(',') : q;
  }

  @Watch('$route', { deep: true, immediate: true })
  async getListingTypes() {
    let { listingTypes, catalogTypeHistory, types } = ListingCatalogModule;
    if (listingTypes.length < 1) {
      // Listing Types doesn't exist in local storage
      this.loading = true;
      await ListingCatalogModule.getCatalogListingTypes();
      listingTypes = ListingCatalogModule.listingTypes;
    } else {
      ListingCatalogModule.getCatalogListingTypes();
    }
    if (this.$route.params.type) {
      const { type } = this.$route.params;
      const listingType = listingTypes.find(t => slugify(t.listingTypeName) === type);
      if (!listingType) {
        this.loading = false;
        throw new TypeError('Listing Type Not Found');
      } else {
        if (!catalogTypeHistory.hasOwnProperty(type)) {
          this.loading = true;
          await ListingCatalogModule.getCurrentTypes(listingType.listingTypeId);
        } else {
          ListingCatalogModule.getCurrentTypes(listingType.listingTypeId);
        }
      }
    } else if (this.$route.query.q) {
      let { q } = this.$route.query;
      q = this.routerQueryString(q);
      this.loading = true;
      await ListingCatalogModule.getSearchResults(q);
    } else {
      if (types.length < 1) {
        this.loading = true;
        await ListingCatalogModule.getInitialListings();
      } else {
        ListingCatalogModule.getInitialListings();
      }
    }
    this.loading = false;
  }

  get empty(): boolean {
    return this.catalogs.length === 0;
  }

  get catalogLink(): import('vue-router').Location {
    return { name: RouteNames.Listings };
  }

  get catalogs(): ListingsPaginated[] {
    const { catalogTypeHistory, types } = ListingCatalogModule;
    if (this.$route.params.type) {
      const { type } = this.$route.params;
      if (catalogTypeHistory.hasOwnProperty(type)) {
        return catalogTypeHistory[type];
      } else return [];
    } else if (this.$route.query.q) {
      const { searchResults } = ListingCatalogModule;
      if (searchResults.length > 0) {
        return searchResults;
      } else return [];
    }
    return types;
  }

  public get tabs(): UINavigationItem[] {
    const catalogs = ListingCatalogModule.listingTypes;
    let array = (catalogs || [])
      .filter(type => type.listingTypeId !== 0)
      .reduce((array: UINavigationItem[], type) => {
        array.push({
          props,
          text: type.listingTypeName.trim(),
          key: slugify(type.listingTypeName),
          route: {
            name: RouteNames.ListingType,
            params: {
              type: slugify(type.listingTypeName),
            },
          },
        });
        return array;
      }, []);

    return [
      {
        props,
        text: 'featured',
        key: 'featured',
        route: {
          name: RouteNames.Listings,
        },
        exact: true,
      },
      ...array,
    ];
  }

  public get tabBarProps(): object {
    return {
      noripple: true,
    };
  }

  get bannerData() {
    return {
      bannerText: 'Discover and build faster',
      searchInfo: '???',
    };
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/theme.scss';

.catalog-listings {
  flex: 1;
}

.results_message {
  padding-top: 40px;
  display: block;
}

.search_result_message:not(.hasSearchQuery) {
  visibility: hidden;
}
.search_result_message.hasSearchQuery {
  margin-bottom: 40px;
}

.catalog-loading {
  flex: 1;
  display: flex;
  justify-content: center;
  align-items: center;
  margin-top: 100px;
}

.api-catalog {
  &__tabs {
    position: sticky;
    top: 0;
    background: white;
    z-index: 3;
    box-shadow: 4px 4px 10px 0 rgba(215, 215, 215, 0.2);
    border: solid 1px var(--theme-lighter);
  }
  &__tabs-container {
    max-width: 775px;
    width: 100%;
    margin: 0 auto;
  }
  &__empty {
    .no_listings {
      margin: auto;
      width: 320px;
      text-align: center;
    }

    h6 {
      margin-bottom: 0;
    }

    p {
      margin: 8px 0 32px;
    }

    .button-container {
      margin: 0;
    }
    img {
      max-width: 320px;
    }
  }
}
.button-container {
  margin-top: 40px;
  margin-bottom: 40px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  align-content: center;

  .search-container {
    width: 100%;
    max-width: 250px;
  }
}
.new-project {
  --gsk-theme-primary: #{$theme-primary};
  font-size: 12px;
  height: 48px;
  > span {
    padding: 0 10px;
  }
}
.apis {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-around;
}
</style>
