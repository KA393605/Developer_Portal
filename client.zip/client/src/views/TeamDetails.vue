<template>
  <full-screen-form :close-route="closeRoute" show-back title="Team Details">
    <div class="new-project" :class="{ isDisabled: loading }">
      <h5 id="team-details">Team Details</h5>
      <p id="team-name">
        <strong>{{ teamName }}</strong>
      </p>
      <p>{{ teamDescription }}</p>
      <table id="team-members-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>
              Team Role
              <router-link :to="helpRoute">
                <gsk-icon-button mini on icon="question" />
              </router-link>
            </th>
          </tr>
        </thead>
        <tr v-for="member in teamMembers" :key="member.mudId">
          <td>
            <div id="member-name" class="inline-divs">
              <user-circle id="team-user-circle" :user="member" />
              <div class="inline-divs member-fullname">
                {{ member.fullName }}
              </div>
            </div>
          </td>
          <td>
            <p>{{ member.roleName }}</p>
          </td>
        </tr>
      </table>
    </div>
  </full-screen-form>
</template>
<script lang="ts">
import { Component } from 'vue-property-decorator';
import { mixins } from 'vue-class-component';
import { RawLocation } from 'vue-router';
import FullScreenForm from '@/components/FullScreenForm.vue';
import GButton from '@/components/gsk-components/GskButton.vue';
import { createProject } from '@/api/projects.api';
import Form from '@/components/mixins/formChecks';
import { RouteNames, TextfieldInfo } from '@/constants';
import GTextfield from '@/components/gsk-components/GskTextfield.vue';
import { ClickData } from '@/analytics';
import { openSnackbar } from '@/utils/components';
import GAnalytics from '@/components/GAnalytics';
import { Team, TeamMember } from '@/types/teams.types';
import { TeamsModule } from '@/store/modules/teams.module';
import { HELP_ROOT_PATH } from '@/constants/help.constants';
import UserCircle from '@/components/UserCircle.vue';

@Component({
  components: {
    FullScreenForm,
    GButton,
    GTextfield,
    GAnalytics,
    UserCircle,
  },
})
export default class NewTeamView extends mixins(Form) {
  private loading: boolean = false;
  private projectName: string = '';
  private projectDescription: string = '';
  public nameLabel: string = TextfieldInfo.nameLabel;
  public namePlaceholder: string = TextfieldInfo.namePlaceholder;
  public nameValidationMessage: string = TextfieldInfo.nameValidationMessage;
  public descriptionLabel: string = TextfieldInfo.descriptionLabel;
  public descriptionPlaceholder: string = TextfieldInfo.descriptionPlaceholder;
  public descriptionValidationMessage: string = TextfieldInfo.descriptionValidationMessage;

  get analyticsData(): ClickData {
    return {
      clickTarget: 'new-project-form-submit-button',
      projectName: this.projectName,
      projectDescription: this.projectDescription,
    };
  }

  back() {
    this.$router.safeBack(this.closeRoute);
  }

  get teamDescription(): string {
    return this.team.teamDescription;
  }

  get teamName(): string {
    return this.team.teamName;
  }

  get teamMembers(): TeamMember[] {
    return this.team.teamMembers;
  }

  get team(): Team {
    return TeamsModule.teamsRecord[this.teamId];
  }

  get teamId(): number {
    return Number(this.$route.params.teamId);
  }

  created() {
    console.log('Router: ', this.$route.params);
    console.log('Team', TeamsModule.teams);
  }

  get helpRoute(): RawLocation {
    return `/${HELP_ROOT_PATH}`;
  }

  get closeRoute(): RawLocation {
    return {
      name: RouteNames.ProjectsList,
    };
  }

  get disabled(): boolean {
    return this.loading;
  }

  get submitDisabled(): boolean {
    return !this.projectName || !this.projectDescription;
  }
}
</script>
<style lang="scss" scoped>
@import '~@/styles/breakpoints.scss';
@import '~@/styles/theme.scss';

#team-details {
  margin-bottom: 14px;
}

#team-members-table {
  margin-top: 50px;
}

#team-name {
  margin-bottom: 0;
}

#team-user-circle {
  position: relative;
  display: inline;
  margin-left: 12px;
}

#member-name {
  display: inline-flex;
}

.inline-divs {
  display: inline;
}

.member-fullname {
  margin-left: 12px;
}

gsk-radio,
gsk-text-field,
gsk-select {
  --gsk-theme-primary: #{$theme-primary};
}
gsk-select {
  width: 100%;
  margin-bottom: 30px;
}

.new-project {
  --gsk-theme-primary: #{$theme-primary};
  display: flex;
  flex-direction: column;
  padding: 0 2rem;
  width: 100%;
  max-width: 700px;
  @include breakpoint($desktop) {
    padding: 0;
  }

  &__input {
    &.text-field {
      // account for helper text height
      margin-bottom: calc(2rem - 19px);
    }
    margin-bottom: 2rem;
  }

  &__button {
    text-align: right;

    #submitButton {
      margin-left: 24px;
    }
  }
}
</style>
