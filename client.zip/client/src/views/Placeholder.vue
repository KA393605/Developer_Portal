<template>
  <div class="about">
    <h1>
      <pre>{{ $route.path }}</pre>
    </h1>
  </div>
</template>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';

@Component
export default class PlaceholderView extends Vue {}
</script>
<style scoped>
.about {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
}
</style>
