<template>
  <full-screen-form ref="projectConnectForm" :close-route="listingPath">
    <div class="new-project" :class="{ isDisabled: loading }">
      <h6 class="new-project__title">Connect {{ listingName }} to a Project</h6>
      <p class=".f-subtitle new-project__subtitle">
        Connecting this service to a project will connect all of its available versions.
      </p>
      <div class="new-project__input">
        <g-radio-group
          v-if="!loading"
          v-model="serviceEnv"
          :options="serviceEnvOptions"
          :label="listingText"
          name="serviceEnv"
          class="radio-group"
          inline
        />
      </div>
      <div v-if="projects.length > 0" class="new-project__input">
        <g-radio-group
          v-model="projectType"
          :options="projectTypeOptions"
          name="projectType"
          label="Add to new or existing project?"
          class="radio-group"
          inline
        />
      </div>

      <template v-if="!isExistingProject">
        <div class="new-project__input text-field">
          <g-textfield
            id="projectName"
            v-model="projectName"
            :label="nameLabel"
            required
            name="projectName"
            outlined
            type="text"
            helper-text-content=""
            :validationmessage="nameValidationMessage"
            :placeholder="namePlaceholder"
            maxlength="50"
          />
        </div>

        <div class="new-project__input">
          <g-textfield
            id="projectDescription"
            v-model="projectDescription"
            :label="descriptionLabel"
            required
            name="projectDescription"
            type="textarea"
            outlined
            maxlength="255"
            helper-text-content=""
            :validationmessage="descriptionValidationMessage"
            :placeholder="descriptionPlaceholder"
          />
        </div>
      </template>
      <div v-else-if="projects.length > 0" class="new-project__input">
        <g-select v-if="ready" v-model="projectId" :options="projects" label="Select Project*" />
      </div>
      <div class="new-project__button">
        <g-button class="f-text-button--primary" type="text" label="Dismiss" @click="back" />
        <g-analytics v-slot="{ sendClick }" :click-data="connectAnalytics">
          <g-button id="submitButton" :disabled="!formIsValid" @click="save(sendClick)">
            Connect
          </g-button>
        </g-analytics>
      </div>
    </div>
  </full-screen-form>
</template>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { DeepReadonly } from 'ts-essentials';
import { Location } from 'vue-router';
import FullScreenForm from '@/components/FullScreenForm.vue';
import GButton from '@/components/gsk-components/GskButton.vue';
import GSelect from '@/components/gsk-components/GskSelect.vue';
import { ProjectsModule } from '@/store/modules/projects.module';
import { ProjectDetailsModule } from '@/store/modules/project-details.module';
import { ListingsModule as ListingCatalogModule } from '@/store/modules/listings.module';
import { RouteNames, TextfieldInfo } from '@/constants';
import { addServiceToProject, createProject } from '@/api/projects.api';
import GRadioGroup from '@/components/gsk-components/GskRadioGroup.vue';
import GTextfield from '@/components/gsk-components/GskTextfield.vue';
import { openSnackbar } from '@/utils/components';
import { SelectOption, SelectValue } from '@/components/form/form.types';
import { ListingEnvironment } from '@/api/listings.api';
import { addAnalyticsRouteParams, ClickData } from '@/analytics';
import GAnalytics from '@/components/GAnalytics';

interface NewProjectForm {
  projectName: string;
  projectDescription: string;
  requestedServiceId: number;
}

enum ProjectTypes {
  New = 'NEW',
  Existing = 'EXISTING',
}

@Component({
  components: {
    FullScreenForm,
    GButton,
    GSelect,
    GRadioGroup,
    GTextfield,
    GAnalytics,
  },
})
export default class ProjectConnectView extends Vue {
  private loading: boolean = true;
  public listingName: string = ListingCatalogModule.currentListing.listingName;
  private projectId: string | number = '';
  private projectName: string = '';
  private projectDescription: string = '';
  private ready: boolean = false;
  private serviceEnvs: ListingEnvironment[] = [];
  public nameLabel: string = TextfieldInfo.nameLabel;
  public namePlaceholder: string = TextfieldInfo.namePlaceholder;
  public nameValidationMessage: string = TextfieldInfo.nameValidationMessage;
  public descriptionLabel: string = TextfieldInfo.descriptionLabel;
  public descriptionPlaceholder: string = TextfieldInfo.descriptionPlaceholder;
  public descriptionValidationMessage: string = TextfieldInfo.descriptionValidationMessage;

  projectTypeOptions: SelectOption[] = [
    {
      label: 'Existing',
      value: ProjectTypes.Existing,
    },
    {
      label: 'New',
      value: ProjectTypes.New,
    },
  ];
  private projectType: SelectValue = this.projectTypeOptions[0].value;

  back() {
    this.$router.safeBack(this.listingPath);
  }

  get listingPath(): Location {
    return {
      name: RouteNames.ListingDetails,
      params: {
        listingId: this.$route.params.listingId,
      },
    };
  }

  get listingId() {
    return this.$route.params.id;
  }
  get listingText() {
    return `Select the ${this.listingName} environment`;
  }

  private serviceEnv: SelectValue = '';
  get serviceEnvOptions(): DeepReadonly<SelectOption[]> {
    return this.serviceEnvs.length
      ? this.serviceEnvs.map(env => {
          return {
            label: env.environmentName,
            value: env.serviceId.toString(),
          };
        })
      : [{ value: '', label: '' }];
  }

  get snackbarLabel() {
    return this.isExistingProject ? 'Service connected' : 'New project created';
  }

  get snackbarError() {
    return this.isExistingProject
      ? 'Error: Could not connect service'
      : 'Error: could not create new project';
  }

  get projects() {
    return ProjectsModule.projects.map(project => {
      return {
        key: project.projectId,
        value: project.projectId,
        label: project.projectName,
      };
    });
  }

  async getNewProjectDetails(data: NewProjectForm): Promise<number> {
    const {
      data: { projectId },
    } = await createProject(data);
    return projectId;
  }

  get formIsValid() {
    if (this.isExistingProject) {
      return true;
    }
    return !!this.projectName && !!this.projectDescription;
  }

  get newProjectFormData(): NewProjectForm {
    return {
      projectName: this.projectName,
      projectDescription: this.projectDescription,
      requestedServiceId: +this.serviceEnv,
    };
  }

  get selectedProjectName(): string | null {
    if (this.isExistingProject) {
      return (
        this.projects.find(projectOption => projectOption.value === this.projectId)?.label ?? null
      );
    }
    return this.projectName;
  }
  get connectAnalytics(): ClickData {
    return {
      clickTarget: 'connect-form-connect-button',
      projectType: this.isExistingProject ? ProjectTypes.Existing : ProjectTypes.New,
      projectName: this.selectedProjectName,
      serviceName: this.listingName,
      serviceEnv: this.serviceEnvOptions.find(so => so.value === this.serviceEnv)?.label,
      serviceId: +this.serviceEnv,
    };
  }

  async save(sendAnalytics: () => void): Promise<void> {
    let id;
    this.loading = true;
    sendAnalytics();
    try {
      if (!this.isExistingProject) {
        id = await this.getNewProjectDetails(this.newProjectFormData).catch(error => {
          throw new Error(error.response.data.message);
        });
      } else {
        await this.addService(+this.serviceEnv).catch(error => {
          throw new Error(error.response.data.message);
        });
        id = this.projectId;
      }
    } catch (e) {
      this.$log('error', e);
      openSnackbar.call(this, e.message);
      return;
    } finally {
      this.loading = false;
    }

    openSnackbar.call(this, this.snackbarLabel);
    const data = this.connectAnalytics;
    this.$router.push({
      name: RouteNames.ProjectDetails,
      params: addAnalyticsRouteParams(
        { id: id + '' },
        {
          projectName: data.projectName,
          projectType: data.projectType,
        },
      ),
    });
  }

  async created() {
    if (ListingCatalogModule.noCurrentListing) {
      // when user navigates directly to this page
      await Promise.all([
        // TODO: handle 404 for listing deets
        ListingCatalogModule.getListingDetails(+this.$route.params.listingId),
        ListingCatalogModule.getListingEnvironments(+this.$route.params.listingId),
        ProjectsModule.getProjects(),
      ]);
    } else {
      // when linked here from service details page
      await Promise.all([
        ListingCatalogModule.getListingEnvironments(+this.$route.params.listingId),
        ProjectsModule.getProjects(),
      ]);
    }

    this.serviceEnvs = ListingCatalogModule.environments;
    this.serviceEnv = this.serviceEnvOptions[0].value;

    // preselect the last viewed project
    if (ProjectDetailsModule.isInitialState) {
      const p = ProjectsModule.projects[0];
      if (p) {
        this.projectId = p.projectId;
      } else {
        this.projectTypeOptions.shift();
      }
    } else {
      this.projectId = ProjectDetailsModule.projectDetails.projectId;
    }
    this.loading = false;
    this.ready = true;
  }

  get isExistingProject() {
    this.projectType =
      // eslint-disable-next-line max-len
      ProjectsModule.projects.length === 0 && !this.loading ? ProjectTypes.New : this.projectType;
    return this.projectType === ProjectTypes.Existing;
  }

  async addService(serviceEnvId: number) {
    const projectId = this.projectId;
    await ProjectDetailsModule.getProject(this.projectId);

    let projectEnvId = 0;
    const env = ProjectDetailsModule.devEnv;
    if (env) {
      projectEnvId = env.projectEnvironmentId;
    } else {
      this.$log('There is no dev environment, which should be impossible');
      return;
    }

    await addServiceToProject({ projectId, projectEnvId, serviceEnvId });
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/breakpoints.scss';
@import '~@/styles/theme.scss';

gsk-formfield,
.radio-group::v-deep gsk-formfield {
  min-width: 150px;
}

.new-project {
  display: flex;
  flex-direction: column;
  padding: 0 2rem;
  width: 100%;
  max-width: 700px;
  @include breakpoint($desktop) {
    padding: 0;
  }

  &__title {
    margin-bottom: 8px;
  }

  &__subtitle {
    margin-top: 0;
    margin-bottom: 40px;
    color: $theme-typography;
  }

  &__input {
    &.text-field {
      // account for helper text height
      margin-bottom: calc(2rem - 19px);
    }

    margin-bottom: 2rem;
  }

  &__button {
    margin-top: 2rem;
    text-align: right;

    #submitButton {
      margin-right: 24px;
    }
  }

  &__env,
  &__project-type {
    display: inline;
    position: relative;
    top: -16px;
    left: -10px;

    &:nth-of-type(2) {
      left: 50px;
    }

    &:nth-of-type(4) {
      left: 27px;
    }
  }
}
</style>
