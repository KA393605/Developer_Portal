<template>
  <full-screen-form :close-route="projectRoute" title="Project Details">
    <div class="settings" :class="{ disabled }">
      <h6 class="settings__heading">Update Project Details</h6>
      <div class="settings__input text-field">
        <g-textfield
          v-model="projectName"
          :label="nameLabel"
          :validationmessage="nameValidationMessage"
          :placeholder="namePlaceholder"
          required
          outlined
          maxlength="50"
          :disabled="disabled"
        />
      </div>
      <div class="settings__input">
        <g-textfield
          v-model="projectDescription"
          :label="descriptionLabel"
          :placeholder="descriptionPlaceholder"
          :validationmessage="descriptionValidationMessage"
          required
          type="textarea"
          maxlength="255"
          outlined
          :disabled="disabled"
        />
      </div>
      <div class="settings__buttons">
        <g-analytics v-slot="{ sendClick }" :click-data="analyticsData">
          <g-button :disabled="!showCancel || disabled" @click="save(sendClick)">
            Save
          </g-button>
        </g-analytics>
      </div>
    </div>
  </full-screen-form>
</template>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { RawLocation } from 'vue-router';
import FullScreenForm from '@/components/FullScreenForm.vue';
import GButton from '@/components/gsk-components/GskButton.vue';
import GTextfield from '@/components/gsk-components/GskTextfield.vue';
import { ProjectDetailsModule } from '@/store/modules/project-details.module';
import { openSnackbar } from '@/utils/components';
import { TextfieldInfo } from '@/constants';
import GAnalytics from '@/components/GAnalytics';
import { addAnalyticsRouteParams, ClickData } from '@/analytics';

@Component({
  components: {
    FullScreenForm,
    GButton,
    GTextfield,
    GAnalytics,
  },
})
export default class ProjectDetailsUpdateView extends Vue {
  // TODO: form validation
  private initialProjectName: string = '';
  private initialProjectDescription: string = '';
  private projectName: string = '';
  private projectDescription: string = '';
  public nameLabel: string = TextfieldInfo.nameLabel;
  public namePlaceholder: string = TextfieldInfo.namePlaceholder;
  public nameValidationMessage: string = TextfieldInfo.nameValidationMessage;
  public descriptionLabel: string = TextfieldInfo.descriptionLabel;
  public descriptionPlaceholder: string = TextfieldInfo.descriptionPlaceholder;
  public descriptionValidationMessage: string = TextfieldInfo.descriptionValidationMessage;

  get loading(): boolean {
    return ProjectDetailsModule.projectLoading;
  }

  async save(sendClick: Function): Promise<void> {
    sendClick();
    try {
      await ProjectDetailsModule.updateProjectDetails({
        projectId: this.$route.params.id,
        projectName: this.projectName,
        projectDescription: this.projectDescription,
      });
      if (typeof this.$route.query.from === 'string') {
        this.$router.push(this.$route.query.from);
      } else {
        this.$router.push(this.projectRoute);
      }
    } catch (e) {
      openSnackbar.call(this, 'Server Error: Could not save project details');
    }
  }

  close() {
    this.$router.replace(this.projectRoute);
  }

  get showCancel() {
    if (!this.projectName) {
      return false;
    }
    return (
      this.initialProjectDescription !== this.projectDescription ||
      this.initialProjectName !== this.projectName
    );
  }

  get disabled(): boolean {
    return ProjectDetailsModule.projectLoading || this.loading;
  }

  get analyticsData(): ClickData {
    return {
      clickTarget: 'project-details-form-submit',
      projectName: this.projectName,
      projectId: +this.$route.params.id,
    };
  }

  get projectRoute(): RawLocation {
    const { id } = this.$route.params;
    return {
      name: 'project-details',
      params: addAnalyticsRouteParams(
        { id },
        {
          projectName: this.projectName,
          projectId: id,
        },
      ),
    };
  }

  async created() {
    if (ProjectDetailsModule.projectDetails.projectId === +this.$route.params.id) {
      this.$log('populated form without loading fresh data');
    } else {
      this.$log('populated form by loading fresh data');
      await ProjectDetailsModule.getProject(this.$route.params.id);
    }

    this.initialProjectName = ProjectDetailsModule.projectDetails.projectName;
    this.projectName = ProjectDetailsModule.projectDetails.projectName;
    this.initialProjectDescription = ProjectDetailsModule.projectDetails.projectDescription;
    this.projectDescription = ProjectDetailsModule.projectDetails.projectDescription;
  }
}
</script>
<style lang="scss" scoped>
@import '~@/styles/form-modal.scss';
.text-field {
  // account for helper text height
  margin-bottom: calc(2rem - 19px);
}
</style>
