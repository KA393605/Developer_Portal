<template>
  <full-screen-form :close-route="closeRoute" show-back title="Edit Team">
    <div class="new-project" :class="{ isDisabled: loading }">
      <h6 class="new-project__title">EditTeam</h6>
      <g-textfield
        id="teamName"
        v-model="teamName"
        :label="nameLabel"
        required
        name="teamName"
        outlined
        type="text"
        maxlength="50"
        :placeholder="teamNamePlaceholder"
        :validationmessage="teamValidationMessage"
      />
      <g-textfield
        id="teamDescription"
        v-model="teamDescription"
        :label="descriptionLabel"
        required
        name="teamDescription"
        type="textarea"
        helper-text-content="Enter a short description of your team"
        :placeholder="teamDescriptionPlaceholder"
        :validationmessage="teamValidationMessage"
        maxlength="255"
      />

      <div class="new-member-picker">
        <g-people-picker
          id="team-picker"
          v-model="addMembers"
          label="Add Member"
          outlined
          helper-text-content=""
          validationmessage="Your team needs at least one owner"
          :valid="lengthValid"
        />
        <g-button id="add-member-btn" icon="plus" elevation="1" @click="addTeamMembers">
          Add
        </g-button>
      </div>
      <table id="team-members-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>
              Team Role
              <router-link :to="helpRoute">
                <gsk-icon-button mini on icon="question" />
              </router-link>
            </th>
            <th></th>
          </tr>
        </thead>
        <tr v-for="member in teamMembers" :key="member.mudId">
          <td>
            <div id="member-name" class="inline-divs">
              <user-circle id="team-user-circle" :user="member" />
              <div class="inline-divs member-fullname">
                {{ member.fullName }}
              </div>
            </div>
          </td>
          <td>
            <template>
              <g-select
                :key="member.mudId"
                :value="member.roleId"
                class="select-team-role"
                label="Team Role"
                :options="teamRoleNames"
                placeholder="Select"
                @input="updateUserRole(member, $event)"
              ></g-select>
            </template>
          </td>
          <td>
            <gsk-icon-button
              icon="trash"
              officon="trash"
              @click="deleteMember(member)"
            ></gsk-icon-button>
          </td>
        </tr>
      </table>

      <g-button class="save-team-btn" elevation="1" :disabled="canNotEdit" @click="saveTeam">
        Save Team
      </g-button>
    </div>
  </full-screen-form>
</template>
<script lang="ts">
import { Component } from 'vue-property-decorator';
import { mixins } from 'vue-class-component';
import { RawLocation } from 'vue-router';
import FullScreenForm from '@/components/FullScreenForm.vue';
import GButton from '@/components/gsk-components/GskButton.vue';
import Form from '@/components/mixins/formChecks';
import { RoleNames, Roles, RouteNames, teamRoleNamesById, TextfieldInfo } from '@/constants';
import GTextfield from '@/components/gsk-components/GskTextfield.vue';
import { openSnackbar } from '@/utils/components';
import GPeoplePicker from '@/components/gsk-components/GskPeoplePicker.vue';
import { HELP_ROOT_PATH } from '@/constants/help.constants';
import { UserModule } from '@/store/modules/user.module';
import UserCircle from '@/components/UserCircle.vue';
import { BaseUser } from '@/types/users.types';
import {
  Team,
  TeamMember,
  UpdateTeamRequest,
} from '@/types/teams.types';
import { SelectOption } from '@/components/form/form.types';
import GSelect from '@/components/gsk-components/GskSelect.vue';
import { TeamsModule } from '@/store/modules/teams.module';

@Component({
  components: {
    FullScreenForm,
    GButton,
    GTextfield,
    GPeoplePicker,
    UserCircle,
    GSelect,
  },
})
export default class EditTeamView extends mixins(Form) {
  public loading: boolean = false;
  public teamId: number = 0;
  public team: Team = {
    teamId: 0,
    iconUrl: '',
    teamName: '',
    teamDescription: '',
    teamMembers: [],
    creatorOfTeam: {
      mudId: '',
      roleId: 0,
      email: '',
      firstName: '',
      lastName: '',
      fullName: '',
    },
    currentUserTeamInfo: {
      mudId: '',
      roleId: 0,
      roleName: '',
      userId: 0,
    },
    createTimestamp: '',
    lastMemberToUpdateTeam: {
      mudId: '',
      roleId: 0,
      email: '',
      firstName: '',
      lastName: '',
      fullName: '',
    },
  };
  public teamName: string = '';
  public teamDescription: string = '';
  public addMembers: TeamMember[] = [];
  public teamMembers: TeamMember[] = [];
  public nameLabel: string = TextfieldInfo.teamNameLabel;
  public teamNamePlaceholder: string = TextfieldInfo.teamNamePlaceholder;
  public teamValidationMessage: string = TextfieldInfo.teamValidationMessage;
  public descriptionLabel: string = TextfieldInfo.descriptionLabel;
  public teamDescriptionPlaceholder: string = TextfieldInfo.teamDescriptionPlaceholder;
  public teamDescriptionValidationMessage: string = TextfieldInfo.teamDescriptionValidationMessage;
  public teamRoleNames: SelectOption[] = [
    { value: Roles.TeamOwner + '', label: RoleNames.TeamOwner },
    { value: Roles.TeamMember + '', label: RoleNames.TeamMember },
  ];

  back() {
    this.$router.safeBack(this.closeRoute);
  }

  backToTeams() {
    this.$router.push({ name: RouteNames.MyTeams });
  }

  addTeamMembers() {
    this.addMembers.forEach(member => {
      const { mudId, email, firstName, lastName, fullName } = member;
      this.teamMembers.push({
        roleId: Roles.TeamMember,
        mudId,
        email,
        firstName,
        lastName,
        fullName,
      });
    });
  }

  updateUserRole(m: TeamMember, roleId: string) {
    const newTeamRoleId = Number(roleId);
    m.roleId = newTeamRoleId;
    m.roleName = teamRoleNamesById[newTeamRoleId];
  }

  deleteMember(member: TeamMember): void {
    this.teamMembers = this.teamMembers.filter(m => {
      return m.mudId !== member.mudId;
    });
  }

  async saveTeam(): Promise<void> {
    await TeamsModule.editTeam(this.updateTeam)
      .then(() => {
        this.$router.push({ name: RouteNames.MyTeams });
        openSnackbar.call(this, 'Team Updated');
      })
      .catch(err => {
        this.$router.push({ name: RouteNames.MyTeams });
        openSnackbar.call(this, err.message, { type: 'error' });
      });
  }

  get updateTeam(): UpdateTeamRequest {
    return {
      teamId: this.teamId,
      teamDescription: this.teamDescription,
      teamName: this.teamName,
      iconUrl: this.team.iconUrl,
      lastUpdateUserId: this.team.creatorOfTeam.userId,
      teamMembers: this.teamMembers,
    };
  }

  get canNotEdit(): boolean {
    return (
      !this.teamDescription || !this.teamName || this.teamMembers.length < 2 || this.noTeamOwners
    );
  }

  get noTeamOwners(): boolean {
    return (
      this.teamMembers.filter(member => {
        return member.roleId === Roles.TeamOwner;
      }).length < 1
    );
  }

  get helpRoute(): RawLocation {
    return `/${HELP_ROOT_PATH}`;
  }

  get closeRoute(): RawLocation {
    return {
      name: RouteNames.MyTeams,
    };
  }

  get currentUser(): BaseUser {
    return UserModule.user;
  }

  created() {
    this.teamId = Number(this.$route.params.teamId);
    this.team = JSON.parse(JSON.stringify(TeamsModule.teamsRecord[this.teamId]));
    this.teamDescription = this.team.teamDescription;
    this.teamName = this.team.teamName;
    this.teamMembers = this.team.teamMembers;
  }

  get lengthValid(): boolean {
    return this.addMembers.length > 0;
  }

  get disabled(): boolean {
    return this.loading;
  }

  get submitDisabled(): boolean {
    return !this.teamName || !this.teamDescription;
  }
}
</script>
<style lang="scss" scoped>
@import '~@/styles/breakpoints.scss';
@import '~@/styles/theme.scss';

.new-member-picker {
  display: inline-grid;
  grid-template-columns: 2fr 1fr 1fr;
  margin-top: 2rem;
}

#team-picker {
  max-width: 400px;
}

#add-member-btn {
  align-self: end;
  justify-self: center;
  margin-bottom: 6px;
}

#team-members-table {
  margin-top: 2rem;
}

#member-name {
  display: inline-flex;
}

.select-team-role {
  width: fit-content;
}

.save-team-btn {
  margin-top: 4rem;
  margin-bottom: 8rem;
  display: flex;
  justify-content: center;
}

.member-fullname {
  margin-left: 12px;
}

gsk-radio,
gsk-text-field,
gsk-select {
  --gsk-theme-primary: #{$theme-primary};
}

.new-project {
  --gsk-theme-primary: #{$theme-primary};
  display: flex;
  flex-direction: column;
  padding: 0 2rem;
  width: 100%;
  max-width: 700px;
  @include breakpoint($desktop) {
    padding: 0;
  }

  &__input {
    &.text-field {
      // account for helper text height
      margin-bottom: calc(2rem - 19px);
    }
    margin-bottom: 2rem;
  }

  &__button {
    text-align: right;

    #submitButton {
      margin-left: 24px;
    }
  }
}
</style>
