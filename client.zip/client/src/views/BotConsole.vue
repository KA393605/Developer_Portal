<template>
  <div class="bot-console" :class="{ loading: !ready, all: allBotsShowing }">
    <max-width :container-style="headerStyle">
      <div class="bot-console__header">
        <h3 class="bot-console__title">
          <strong>RPA Console</strong>
        </h3>
        <p class="bot-console__subtitle">
          Welcome to your RPA Deployment Console. This is where you can promote RPA processes across
          environments.
        </p>
        <div class="bot-console__search">
          <g-select
            v-model="env"
            label=" "
            class="select-env"
            :options="envOptions"
            @input="updateEnv"
          />
          <g-textfield
            v-model="treeFilter"
            class="bot-console__search-box"
            value
            trailingiconcontent="search"
            trailingiconinteraction
            :placeholder="searchPlaceholder"
            outlined
            label=" "
            helper-text-content=""
            @input.native="onSearchBots"
          ></g-textfield>
        </div>
      </div>
    </max-width>
    <div class="bot-console__tabs">
      <navigation-tabs :links="tabs" :container-props="tabBarProps" class="tabs" />
    </div>
    <template v-if="ready && !errorMessage && botTree !== undefined && botTree.length > 0">
      <max-width>
        <div class="bot-console__bot-list">
          <div class="bot-console__tree">
            <tree
              ref="tree"
              :key="treeKey"
              class="bot-console__tree"
              :data="botTree"
              :options="treeOptions"
              @node:selected="onNodeSelected"
            >
              <p slot-scope="{ node }" class="tree-text f-text-button">{{ node.text }}</p>
            </tree>
          </div>
          <div class="bot-console__selected-bot">
            <selected-bot-info
              :selected-node="selectedBot"
              :show.sync="show"
              :folders="types"
            ></selected-bot-info>
          </div>
        </div>
      </max-width>
    </template>
    <template v-else-if="ready && errorMessage">
      <div class="bot-console__no-results">
        <img src="@/assets/uh-oh.png" />
        <h3 class="gsk-typography--headline4 bot-console__error">Error encountered:</h3>
        <h4 class="gsk-typography--headline5 bot-console__error-message">{{ errorMessage }}</h4>
      </div>
    </template>
    <template v-else-if="noPermissionsOnEnv">
      <div class="bot-console__no-results">
        <img src="@/assets/uh-oh.png" />
        <h3 class="gsk-typography--headline4 bot-console__error">Error encountered:</h3>
        <h4 class="gsk-typography--headline5 bot-console__error-message">
          You do not have permission to promote bots in this environment
        </h4>
      </div>
    </template>
    <template v-else>
      <div class="bot-console__loading">
        <gsk-circular-progress></gsk-circular-progress>
      </div>
    </template>
  </div>
</template>
<script lang="ts">
import { Component, Emit, Vue, Watch } from 'vue-property-decorator';
import LiquorTree from 'liquor-tree';
import MaxWidth from '@/components/MaxWidth.vue';
import NavigationTabs from '@/components/NavigationTabs.vue';
import GTextfield from '@/components/gsk-components/GskTextfield.vue';
import GSelect from '@/components/gsk-components/GskSelect.vue';
import SelectedBotInfo from '@/components/SelectedBotInfo.vue';
import { SelectOption } from '@/components/form/form.types';

import {
  Bot,
  BotTree,
  PromoteBot,
  BotChild,
  FolderExistsObject,
  ChildFolderExistsObject,
  BotNode,
} from '@/types/rpa-admin.types';
import { UINavigationItem } from '@/types';
import { RpaModule } from '@/store/modules/rpa.module';

const props = {
  minwidth: true,
  noripple: true,
};

@Component({
  components: {
    GSelect,
    MaxWidth,
    NavigationTabs,
    GTextfield,
    tree: LiquorTree,
    SelectedBotInfo,
  },
})
export default class BotConsoleView extends Vue {
  public searchPlaceholder: string = 'Search RPA Console';
  public env: string = 'dev';
  public selectedBot: BotNode = this.defaultBotNodeValue;
  public show: boolean = false;
  public allBotsShowing: boolean = false;
  public treeOptions = {
    filter: {
      emptyText: 'No results found.',
    },
  };
  public treeFilter: string = '';

  get envOptions(): SelectOption[] {
    return [
      {
        key: '1',
        value: 'dev',
        label: 'Dev',
      },
      {
        key: '2',
        value: 'qa',
        label: 'QA',
      },
      {
        key: '3',
        value: 'prod',
        label: 'Production',
      },
    ];
  }

  public page: number = 1;
  public bots: Bot[] = [];
  public ready: boolean = false;
  public errorMessage: string = '';

  @Watch('$route.params', { immediate: true })
  updateStuff(newParams: { env: string; type: string }) {
    this.treeFilter = '';
    if (!this.$route.params.type) {
      this.$router.push({ path: `/rpa-console/${this.env}/${this.type}` }).catch(() => {});
      return;
    }
    const { env, type } = newParams;
    this.ready = false;
    this.tab = {
      props,
      text: this.$route.params.type,
      key: this.$route.params.type,
      replace: true,
      route: {},
    };
    this.loadBotDirectory(env, type);
    this.selectedBot = this.defaultBotNodeValue;
  }

  updateEnv(e: string): void {
    if (this.hasFolder(e)) {
      this.$router.push({ path: `/rpa-console/${e}/${this.type}` }).catch(() => {});
    } else {
      this.$router.push({ path: `/rpa-console/${e}` }).catch(() => {});
    }
  }

  hasFolder(env: string): boolean {
    const folders = RpaModule.buBotsUserCanPromote[env];
    if (folders) {
      return !!folders.find(bu => bu === this.type);
    }
    return false;
  }

  get getEnv(): string {
    const routeEnv = this.$route.params.env;
    if (routeEnv) {
      return routeEnv;
    }
    return 'dev';
  }

  protected filters: { search: string } = {
    search: '',
  };

  @Emit('onSearch')
  protected onSearch(value: string) {
    return value;
  }

  onNodeSelected(value: BotNode) {
    this.treeFilter = '';
    this.selectedBot = value;
    this.show = true;
  }

  public tab: UINavigationItem = {
    props,
    text: '',
    key: '',
    replace: true,
    route: {},
  };

  public get tabBarProps(): object {
    return {
      noripple: true,
    };
  }

  public get tabs(): UINavigationItem[] {
    return (this.types || []).reduce((array: UINavigationItem[], type) => {
      array.push({
        props,
        text: type.trim(),
        key: type,
        route: {
          path: `/rpa-console/${this.env}/${type}`,
        },
      });
      return array;
    }, []);
  }

  public get headerStyle(): object {
    return {
      borderBottom: 'none',
      backgroundColor: 'var(--theme-primary)',
      width: '100%',
    };
  }

  async loadBotDirectory(env: string, type: string) {
    this.errorMessage = '';
    if (this.types.length >= 1) {
      if (RpaModule.botsInBu[type]) {
        if (RpaModule.botsInBu[type][env]) {
          // Get bots in the background cause we've gotten these bots before
          this.getBots(env, type);
        } else {
          // Folder exists but env is new
          this.getBotsAsync(env, type);
        }
      } else {
        // New folder and env
        this.getBotsAsync(env, type);
      }
    }
  }

  async getBotsAsync(env: string, type: string): Promise<void> {
    const botPromise = RpaModule.getBots({ env: env, folder: type, search: '%%' });
    botPromise
      .catch(err => {
        this.errorMessage = err.response.data.error.replace('mot', 'not');
      })
      .finally(() => {
        this.ready = true;
      });
  }

  getBots(env: string, type: string): void {
    this.ready = true;
    RpaModule.getBots({ env, folder: type, search: '%%' });
  }

  private filterBots(): BotNode {
    const filteredBots: Bot[] = this.botResponse.filter(bot => {
      return bot.name.toLowerCase().includes(this.treeFilter.toLowerCase());
    });
    // Bot[] -> PromoteBot[]
    const mappedFilteredBots: PromoteBot[] = filteredBots.map(bot => {
      return {
        ...bot,
        gskId: bot.id,
        text: bot.name,
        loading: false,
        timestamp: '',
        error: false,
        hasBeenPromoted: '',
      };
    });
    return {
      children: [],
      data: {
        bots: mappedFilteredBots,
      },
      id: '',
      isBatch: false,
      isEditing: false,
      parent: '',
      showChildren: false,
    };
  }

  onSearchBots(): void {
    if (this.treeFilter === '') {
      this.selectedBot = this.defaultBotNodeValue;
    } else {
      this.selectedBot = this.filterBots();
    }
  }

  get treeKey(): string {
    return this.type + this.env;
  }

  get botResponse(): Bot[] {
    if (RpaModule.botsInBu[this.type]) {
      return RpaModule.botsInBu[this.type][this.env] || [];
    }
    return [];
  }

  // TODO: Do this better
  get botTree(): BotTree[] {
    function createNewFolder(path: string): BotTree {
      // path at 0
      return {
        text: path,
        children: [],
        data: { bots: [] },
      };
    }

    function createNewChild(path: string): BotChild {
      // path at 1
      return {
        text: path,
        data: { bots: [] },
      };
    }

    function createNewBot(bot: Bot): PromoteBot {
      // bot
      return {
        ...bot,
        error: false,
        gskId: bot.id,
        loading: false,
        text: bot.name,
        timestamp: '',
        hasBeenPromoted: '',
      };
    }

    function doesFolderExist(result: BotTree[], path: string): FolderExistsObject {
      let folderExists = false;
      let folderIndex = -1;

      result.forEach((bot, i) => {
        if (bot.text === path) {
          folderExists = true;
          folderIndex = i;
        }
      });

      return { folderExists, folderIndex };
    }

    function doesChildFolderExist(
      result: BotTree[],
      path: string,
      parentIndex: number,
    ): ChildFolderExistsObject {
      let childExists = false;
      let childIndex = -1;

      result[parentIndex].children.forEach((child: BotChild, i: number) => {
        if (child.text === path) {
          childExists = true;
          childIndex = i;
        }
      });

      return { childExists, childIndex };
    }

    let result: BotTree[] = [];

    // Bot[] --> BotTree[]
    this.botResponse.forEach(bot => {
      const path = bot.path.split('\\').slice(3);
      const hasHelperTasks = path.length > 2;
      const { folderExists, folderIndex } = doesFolderExist(result, path[0]);

      if (folderExists) {
        if (hasHelperTasks) {
          // Check if Helper Task Folder exists
          const { childExists, childIndex } = doesChildFolderExist(result, path[1], folderIndex);

          if (childExists) {
            let newBot = createNewBot(bot);
            result[folderIndex].children[childIndex].data.bots.push(newBot);
          } else {
            // put sub folder in child array and file in bot array
            let child = createNewChild(path[1]);
            let newBot = createNewBot(bot);

            child.data.bots.push(newBot);
            result[folderIndex].children.push(child);
          }
        } else {
          // put file in data of main folder
          let newBot = createNewBot(bot);

          result[folderIndex].data.bots.push(newBot);
        }
      } else {
        if (hasHelperTasks) {
          // create new folder with sub folder and put file in bot array of the sub folder
          let newFolder = createNewFolder(path[0]);
          let child = createNewChild(path[1]);
          let newBot = createNewBot(bot);

          child.data.bots.push(newBot);
          newFolder.children.push(child);

          result.push(newFolder);
        } else {
          // create new folder and put file in bot array
          let newFolder = createNewFolder(path[0]);
          let newBot = createNewBot(bot);

          newFolder.data.bots.push(newBot);

          result.push(newFolder);
        }
      }
    });

    return result;
  }

  get defaultBotNodeValue(): BotNode {
    return {
      children: [],
      data: {
        bots: [],
      },
      id: '',
      isBatch: false,
      isEditing: false,
      parent: '',
      showChildren: true,
    };
  }

  async created(): Promise<void> {
    this.env = this.getEnv;
  }

  get type(): string {
    const { type } = this.$route.params;
    return this.types.find(t => t === type) || this.types[0];
  }

  get types(): string[] {
    return RpaModule.buBotsUserCanPromote[this.env];
  }

  get noPermissionsOnEnv(): boolean {
    if (RpaModule.buBotsUserCanPromote[this.env]) {
      return RpaModule.buBotsUserCanPromote[this.env].length < 1;
    }
    return false;
  }
}
</script>

<style scoped lang="scss">
@import '~@/styles/breakpoints.scss';
@import '~@/styles/theme.scss';
/*.tree-highlights .tree-node.matched > .tree-content{*/
/*  background: #fff1ee;*/
/*}*/

.select-env {
  margin-right: 15px;
  /*margin-top: 4px !important;*/
}

.bot-console {
  width: 100%;
  height: auto;

  &.loading {
    display: flex;
    flex-direction: column;
  }

  &__loading {
    flex: 1;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  &__header {
    padding: 48px 0;
    text-align: center;
  }
  &__title {
    color: var(--theme-white);
    margin-top: 0;
    margin-bottom: 16px;
  }
  &__subtitle {
    color: var(--theme-white);
    margin-bottom: 8px;
  }

  &__search {
    max-width: 720px;
    margin: 0 auto;
    display: flex;
    justify-content: space-between;
    align-content: center;

    gsk-textfield,
    gsk-select {
      width: 100%;
    }

    .tf {
      margin-top: 0;
    }
    gsk-textfield {
      max-width: 70%;
    }

    gsk-select {
      max-width: 30%;
    }
  }

  &__tabs {
    box-shadow: 4px 4px 10px 0 rgba(215, 215, 215, 0.2);
    margin-bottom: 48px;

    .gsk-tabs {
      max-width: 1216px;
      margin: 0 auto;
      display: flex;
      padding-left: 40px;
    }
  }

  &__bot-list {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
  }

  &__tree {
    max-width: 300px;
    width: 100%;
    &.selected > .tree-content {
      background-color: var(--theme-primary--hover--light);
    }

    &:not(.selected) > .tree-content:hover {
      background: var(--theme-primary--hover--light);
    }
    .tree-node {
      .tree-content {
        border-radius: 4px;
      }

      /*&.has-child {*/
      /*  i.has-child,*/
      /*  .tree-children {*/
      /*    !*display: none;*!*/
      /*  }*/
      /*}*/
    }
  }

  &__selected-bot {
    width: 100%;
    max-width: 800px;
  }

  &__list {
    margin-bottom: 48px;

    table {
      table-layout: fixed;
    }
  }

  &__no-results {
    width: 100%;
    text-align: center;
    img {
      max-width: 300px;
    }
  }

  &__error {
    margin-bottom: 8px;
  }

  &__error-message {
    color: var(--theme-danger);
    margin-top: 8px;
  }

  &__pagination {
    display: flex;
    align-items: center;
    justify-content: center;
    padding-left: 0;
    list-style: none;
    width: 100%;
  }

  &__page-link {
    --gsk-theme-primary: var(--theme-dark);
    &.active {
      --gsk-theme-primary: var(--theme-primary);
    }

    &.arrow {
      visibility: hidden;

      &.show {
        visibility: visible;
      }
    }
  }

  &.all {
    .bot-console__tree .tree-node.has-child i.has-child,
    .bot-console__tree .tree-node.has-child .tree-children {
      display: block;
      i.has-child,
      .tree-children {
        display: none;
      }
    }
  }
}
</style>
