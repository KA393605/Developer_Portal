<template>
  <div v-if="provisioning" class="provisioning flex-center">
    <gsk-circular-progress label="Provisioning project environment..."></gsk-circular-progress>
  </div>
  <div v-else class="container">
    <g-analytics v-slot="{ sendClick }" :click-data="promoteAnalytics">
      <gsk-fab
        class="promote-button"
        :class="{ hide: nextEnv.hide }"
        :disabled="nextEnv.disabled || promoting"
        primary
        extended
        :label="'Promote to ' + nextEnv.name"
        @click="promote(sendClick)"
      />
    </g-analytics>
    <div class="layout">
      <navigation-list class="list" :links="sectionLinks" />
      <project-env-auth
        v-if="section === 'auth'"
        :environment-details="authDetails"
        :environment-status="envStatus"
        :meta="authDetails.meta"
        :environment-name="currentEnvironmentName"
        :project-id="+id"
        :project-env-id="+env"
        class="content"
      />
      <project-env-services
        v-else-if="section === 'services'"
        :connected-services="connectedServices.connectedServices"
        :meta="connectedServices.meta"
        :environment-name="currentEnvironmentName"
        :environment-status="envStatus"
        :project-id="+id"
        :project-env-id="+env"
        class="content"
      />
      <div v-else class="content"></div>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import { DeepReadonly } from 'ts-essentials';
import { RawLocation, Route } from 'vue-router';
import { ProjectDetailsModule } from '@/store/modules/project-details.module';
import { Environments, RouteNames, Statuses } from '@/constants';
import ProjectEnvServices from '@/components/project-details/ProjectEnvServices.vue';
import ProjectEnvAuth from '@/components/project-details/ProjectEnvAuth.vue';
import GButton from '@/components/gsk-components/GskButton.vue';
import * as API from '@/api/projects.api';
import { openSnackbar } from '@/utils/components';
import { addAnalyticsRouteParams, ClickData } from '@/analytics';
import { ProjectEnvironmentDetails2 } from '@/types/projects.types';
import DeleteDialog from '@/components/dialogs/DeleteDialog.vue';
import UserCircle from '@/components/UserCircle.vue';
import { UINavigationItem } from '@/types';
import NavigationList from '@/components/NavigationList.vue';
import GAnalytics from '@/components/GAnalytics';

enum parts {
  AUTH = 'auth',
  SERVICES = 'services',
  STATUS = 'status',
}

type NavigationGuard<V extends Vue = Vue> = (
  to: Route,
  from: Route,
  next: (to?: RawLocation | false | ((vm: V) => any) | void) => void,
  isUpdate: boolean,
) => unknown;

function loadEnvData(
  projectId: number,
  projectEnvId: number,
  next: () => void,
  done: () => void = () => {},
) {
  ProjectDetailsModule.getProjectEnvironmentPart({
    projectId,
    projectEnvId,
    partName: parts.STATUS,
  }).then(() => {
    const provisioning =
      ProjectDetailsModule.envs[projectId][projectEnvId].status.statusName ===
      Statuses.Provisioning;
    if (!provisioning) {
      // only load these up when done provisioning until the new orchestration is in place
      // TODO: refactor after orchestration is done
      for (const part of [parts.AUTH, parts.SERVICES]) {
        ProjectDetailsModule.getProjectEnvironmentPart({
          projectId,
          projectEnvId,
          partName: part,
        });
      }
      done();
    }
    next();
  });
}

const beforeRoute: NavigationGuard = (to, from, next, isUpdate): void => {
  const projectId = Number(to.params.id);
  const projectEnvId = Number(to.params.env);
  const section = to.params.section;
  // default to auth section if user nagivates to no section
  if (section !== parts.AUTH && section !== parts.SERVICES) {
    to.params.section = parts.AUTH;
    return next({ ...to, replace: true });
  }

  // switching between sections
  if (isUpdate && to.params.env === from.params.env) {
    ProjectDetailsModule.getProjectEnvironmentPart({
      projectId,
      projectEnvId,
      partName: section,
    });
    return next();
  }

  // not switching between sections, just arriving to project env
  loadEnvData(projectId, projectEnvId, next);
};

@Component({
  components: {
    GButton,
    NavigationList,
    ProjectEnvServices,
    ProjectEnvAuth,
    DeleteDialog,
    UserCircle,
    GAnalytics,
  },
  beforeRouteEnter(to, from, next) {
    beforeRoute(to, from, next, false);
  },
  beforeRouteUpdate(to, from, next) {
    beforeRoute(to, from, next, true);
  },
})
export default class ProjectEnvView extends Vue {
  @Prop({ required: true, type: String }) readonly env!: string;
  @Prop({ required: true, type: String }) readonly section!: string;
  @Prop({ required: true, type: String }) readonly id!: string;

  private promoting: boolean = false;
  private pollId: number = -1;
  private pollDelay: number = 10 * 1000;

  get promoteAnalytics(): ClickData {
    return {
      clickTarget: 'project-env-promote-button',
      projectName: ProjectDetailsModule.projectDetails.projectName,
      projectId: ProjectDetailsModule.projectDetails.projectId,
      promoteTo: this.nextEnv.name,
    };
  }

  get projectId(): number {
    return Number(this.id);
  }

  get projectEnvId(): number {
    return Number(this.env);
  }

  getSectionRoute(section: string): UINavigationItem['route'] {
    return {
      ...this.$route,
      params: {
        ...this.$route.params,
        section,
      },
    };
  }

  get envStatus() {
    return this.projectEnv.status;
  }

  get sectionLinks(): UINavigationItem[] {
    return [
      {
        key: parts.AUTH,
        route: this.getSectionRoute(parts.AUTH),
        exact: true,
        text: 'Authentication',
        props: {
          noripple: true,
        },
      },
      {
        key: parts.SERVICES,
        exact: true,
        route: this.getSectionRoute(parts.SERVICES),
        text: 'Services',
      },
      // {
      //   key: 'registrations',
      //   exact: true,
      //   route: this.getSectionRoute('registrations'),
      //   text: 'Registrations',
      // },
    ];
  }

  get provisioning() {
    return this.projectEnv.status.statusName === Statuses.Provisioning;
  }

  get projectEnv(): ProjectEnvironmentDetails2 {
    return ProjectDetailsModule.envs[this.projectId][this.projectEnvId];
  }

  get authDetails() {
    return this.projectEnv.auth;
  }

  get connectedServices() {
    return this.projectEnv.services;
  }

  get environments(): DeepReadonly<API.Projects.ProjectEnvironment[]> {
    return ProjectDetailsModule.projectDetails.environments || [];
  }

  get currentEnvironment() {
    return this.environments.find(
      env => env.projectEnvironmentId.toString() === this.$route.params.env,
    );
  }

  get currentEnvironmentName(): Environments | '' {
    if (this.currentEnvironment) {
      return this.currentEnvironment.environmentName as Environments;
    }
    return '';
  }

  get nextEnv() {
    const currentEnv = this.currentEnvironment;
    let nextEnv: Environments | undefined;

    if (currentEnv) {
      switch (currentEnv.environmentName) {
        case Environments.Dev:
          nextEnv = Environments.Qa;
          break;
        case Environments.Qa:
          nextEnv = Environments.Prod;
          break;
        case Environments.Prod:
          break;
        default:
          break;
      }
    }

    if (nextEnv) {
      return {
        name: nextEnv,
        disabled: false,
        hide: false,
      };
    }

    return {
      name: '',
      disabled: true,
      hide: true,
    };
  }

  promote(sendClick: () => void) {
    if (this.promoting) {
      return;
    }

    sendClick();

    if (this.nextEnv.name === Environments.Prod) {
      this.$router.push({
        name: RouteNames.PromoteToProd,
        params: addAnalyticsRouteParams(
          {},
          {
            projectName: ProjectDetailsModule.projectDetails.projectName,
            projectId: ProjectDetailsModule.projectDetails.projectId,
          },
        ),
      });
    } else if (this.nextEnv.name === Environments.Qa) {
      this.promoting = true;
      ProjectDetailsModule.promoteEnvironment({
        projectEnvId: this.$route.params.env,
        srcEnv: Environments.Dev,
      })
        .then(res => {
          this.$router.push({
            name: RouteNames.ProjectEnvDetails,
            params: addAnalyticsRouteParams(
              {
                id: this.$route.params.id,
                env: res.projectEnvironmentId.toString(),
                section: parts.AUTH,
              },
              {
                projectName: ProjectDetailsModule.projectDetails.projectName,
                projectId: ProjectDetailsModule.projectDetails.projectId,
              },
            ),
          });
        })
        .catch(() => {
          openSnackbar.call(this, 'Server Error: Promotion request failed');
        })
        .finally(() => {
          this.promoting = false;
        });
    }
  }

  created() {
    if (this.provisioning) {
      this.pollId = setInterval(() => {
        loadEnvData(
          this.projectId,
          this.projectEnvId,
          () => {},
          () => clearInterval(this.pollId),
        );
      }, this.pollDelay);
    }
  }

  beforeDestroy() {
    clearInterval(this.pollId);
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/theme.scss';
@import '~@/styles/breakpoints.scss';
@import '~@/styles/typography.scss';

.layout {
  display: grid;
  width: var(--content-max-width);
  grid-template-columns: 100%;
  @include breakpoint($medium) {
    grid-template-columns: 200px 1fr;
  }
}
.list {
  margin-top: 2rem;
  @include breakpoint($small) {
    width: 200px;
  }
  @include breakpoint($medium) {
    margin-top: 0;
  }
}
.content {
  width: 100%;
  padding-top: 2.5rem;
  @include breakpoint($medium) {
    max-width: calc(var(--content-max-width) - 200px);
    padding-top: 0;
    flex: 5;
  }
}

.loading-container {
  margin-top: 3rem;
}

.container {
  position: relative;
  padding-top: 40px;
  @include breakpoint($medium) {
    padding-top: 56px;
  }
  &::v-deep {
    .content-heading {
      margin-top: 0;
      margin-bottom: 1.5rem;
    }

    .trash-icon {
      cursor: pointer;
      color: $theme-dark;
    }
  }
}

.hide {
  opacity: 0;
  pointer-events: none;
  user-focus: none;
  user-select: none;
}

.promote-button {
  margin-bottom: 3rem;
  width: 100%;
  @include breakpoint($larger-tablet) {
    position: absolute;
    right: 0;
    top: -1.8em;
    margin-bottom: 0;
    width: auto;
  }
}

.provisioning {
  padding-top: 3rem;
  flex: 1;
}
</style>
