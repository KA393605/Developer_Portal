<template>
  <section class="publish" style="width: 100%;">
    <div v-if="loading" id="loading" class="flex-center">
      <gsk-circular-progress />
    </div>
    <portal-target name="publish-new" multiple></portal-target>
    <portal-target name="draft-preview"></portal-target>
    <max-width :container-style="headerStyle">
      <header class="header">
        <div class="header-content-wrapper">
          <h5 class="publish_header wba">
            <template v-if="isAddingNewVersion">
              Add New Version
            </template>
            <template v-else-if="flowState.edit">
              {{ currentDraftListing.listingName }}
            </template>
            <template v-else>Publish New {{ product }}</template>
            <help-link doc-path="2. My Listings.md" />
          </h5>
          <div>
            <g-button
              class="save-draft-button"
              type="text"
              label="Save Draft"
              :disabled="!pm.saveDraftEnabled"
              @click="saveDraft"
            ></g-button>
            <gsk-fab
              label="Publish"
              :disabled="!pm.publishEnabled"
              primary
              extended
              @click="publish"
            ></gsk-fab>
          </div>
        </div>
        <div class="add-user-icon">
          <user-list class="user-list" :users="owners" truncate />
          <g-button type="text" icon="locked" secondary @click="showPermissions = true">
            Permissions
          </g-button>
        </div>
      </header>
    </max-width>
    <div class="wrapper">
      <div class="tab-column">
        <vertical-tab
          :tabs="getStatusList"
          :active-tab.sync="activeTab"
          class="tabs"
        ></vertical-tab>
      </div>
      <div class="content-column">
        <component :is="currentComponent" :flow-state="flowState" @publish="publish"></component>
      </div>
    </div>
    <listing-permissions
      v-if="showPermissions"
      :listing-id="listingId"
      @close="showPermissions = false"
    />
  </section>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import uniqBy from 'lodash/uniqBy';
import { RawLocation } from 'vue-router';
import cloneDeep from 'lodash/cloneDeep';
import { AxiosPromise } from 'axios';
import pick from 'lodash/pick';
import VerticalTab from '@/components/Publish/VerticalTab.vue';
import { UITab } from '@/types';
import GSelect from '@/components/gsk-components/GskSelect.vue';
import ProductDetails from '@/components/Publish/ProductDetails.vue';
import ProductCard from '@/components/Publish/ProductCard.vue';
import ListingPermissions from '@/components/Publish/Permissions.vue';
import AddDocumentation from '@/components/Publish/AddDocumentation.vue';
import DefaultLayout from '@/layouts/DefaultLayout.vue';
import MaxWidth from '@/components/MaxWidth.vue';
import UserList from '@/components/UserList.vue';
import GButton from '@/components/gsk-components/GskButton.vue';
import { ListingTypes, RouteNames } from '@/constants';
import * as API from '@/api/publishing.api';
import {
  DraftListingModule,
  ListingUser,
  SavedDetails,
  SavedListingModule,
} from '@/types/listings.types';
import { PublishingModule } from '@/store/modules/publishing.module';
import { UserModule } from '@/store/modules/user.module';
import { openSnackbar } from '@/utils/components';
import { FormField } from '@/components/form/form.types';
import HelpLink from '@/components/HelpLink.vue';

@Component({
  components: {
    VerticalTab,
    GSelect,
    SelectProd: ProductDetails,
    ProductCard,
    AddDocumentation,
    DefaultLayout,
    MaxWidth,
    UserList,
    GButton,
    ListingPermissions,
    HelpLink,
  },
})
export default class PublishNew extends Vue {
  @Prop(String) readonly listingId!: string | undefined;

  public product: string = 'Listing';
  private showPermissions: boolean = false;
  private loading: boolean = false;

  public get owners(): ListingUser[] {
    const { user: u } = UserModule;
    if (u.userId === -1) {
      return [];
    }
    const owner: ListingUser = {
      firstName: u.firstName,
      lastName: u.lastName,
      fullName: u.fullName,
      email: u.email,
      userId: u.userId,
      mudId: u.mudId,
      roleId: 1,
      roleName: 'Owner',
    };

    return uniqBy([owner].concat(this.currentDraftListing.listingUsers), 'mudId');
  }

  public get pm(): typeof PublishingModule {
    return PublishingModule;
  }

  transformFormFields(form: FormField[]): SavedDetails {
    return form.map(field => {
      return pick(field, ['value', 'key', 'type']);
    });
  }

  async saveDraft() {
    let op: AxiosPromise<number | boolean>;
    const draft = cloneDeep(this.currentDraftListing);
    if (draft.listingTypeId !== ListingTypes.API) {
      delete draft.registrationId;
      delete draft.registrationVersionId;
    }
    if (!PublishingModule.isCustomComponent) {
      (draft.extendedProperties.details as SavedDetails) = this.transformFormFields(
        draft.extendedProperties.details,
      );
    }
    this.loading = true;
    if (this.listingId) {
      op = API.updateDraftListing(draft, this.listingId);
    } else {
      PublishingModule.addUsersWithPermissions(this.owners);
      op = API.createDraftListing(draft);
    }
    op.then(res => {
      if (!this.listingId) {
        if (typeof res.data === 'number') {
          this.$router.replace({
            name: RouteNames.PublishListing,
            params: {
              listingId: res.data.toString(),
            },
            query: {
              mode: 'edit',
            },
          });
          PublishingModule.setMode({
            mode: {
              version: false,
              edit: true,
            },
            initial: false,
          });
        }
      }
      openSnackbar.call(this, 'Draft saved!');
    })
      .catch(e => {
        openSnackbar.call(this, 'Error: could not create draft!', { type: 'error' });
        this.$log('error', e);
      })
      .finally(() => (this.loading = false));
  }

  public async publish() {
    if (!PublishingModule.publishEnabled) {
      this.$log('warn', 'attempting to publish but publish should not be enabled');
      return;
    }
    this.loading = true;
    if (this.listingId) {
      const draft = cloneDeep(this.currentDraftListing);
      if (draft.listingTypeId !== ListingTypes.API) {
        delete draft.registrationId;
        delete draft.registrationVersionId;
      }
      if (!PublishingModule.isCustomComponent) {
        (draft.extendedProperties.details as SavedDetails) = this.transformFormFields(
          draft.extendedProperties.details,
        );
      }
      try {
        await API.publishDraftListing(draft, this.listingId);
      } catch (e) {
        openSnackbar.call(this, 'Error: could not update listing!', { type: 'error' });
        this.$log('error', e);
        return;
      } finally {
        this.loading = false;
      }
      this.$router.push({
        name: RouteNames.ListingDetails,
        params: {
          listingId: this.listingId,
        },
      });
    } else {
      PublishingModule.addUsersWithPermissions(this.owners);
      const draft = cloneDeep(this.currentDraftListing);
      if (draft.listingTypeId !== ListingTypes.API) {
        delete draft.registrationId;
        delete draft.registrationVersionId;
      }
      if (!PublishingModule.isCustomComponent) {
        (draft.extendedProperties.details as SavedDetails) = this.transformFormFields(
          draft.extendedProperties.details,
        );
      }
      try {
        const id = (await API.publishNewDraftListing(draft)).data;
        this.$router.push({
          name: RouteNames.ListingDetails,
          params: {
            listingId: id.toString(),
          },
        });
      } catch (e) {
        openSnackbar.call(this, 'Error: could not publish new listing!', { type: 'error' });
        this.$log('error', e);
        return;
      } finally {
        this.loading = false;
      }
      openSnackbar.call(this, 'Published new listing!');
    }
  }

  get flowState() {
    return PublishingModule.mode;
  }

  public async created() {
    const edit = this.$route.query.mode === 'edit';
    const version = this.$route.query.mode === 'version';
    this.loading = true;
    await PublishingModule.getListingTypes();

    if (edit && this.listingId) {
      await PublishingModule.getListing({ isVersion: false, id: this.listingId });
      PublishingModule.setMode({
        mode: {
          edit,
          version,
        },
        initial: true,
      });
    }

    // new listing, make sure self user is in the list
    if (!this.flowState.edit && !this.flowState.version) {
      PublishingModule.setMode({
        initial: true,
        mode: {
          edit,
          version,
        },
      });
      await UserModule.getUserInfo();
      PublishingModule.addUsersWithPermissions(this.owners);
    }
    this.loading = false;
  }

  public get currentComponent(): Vue.VueConstructor | void {
    // Get current component string from store and return corresponding vue component
    const c = PublishingModule.activeTab.component || '';
    const components: { [key: string]: Vue.VueConstructor } = {
      ProductCard,
      ProductDetails,
      AddDocumentation,
    };
    return components[c];
  }

  get isAddingNewVersion(): boolean {
    return false;
  }

  public get getStatusList(): UITab[] {
    return PublishingModule.statusList;
  }

  public get activeTab(): UITab {
    return PublishingModule.activeTab;
  }

  public set activeTab(tab: UITab) {
    PublishingModule.updateActiveTab(tab);
  }

  public get currentDraftListing(): DraftListingModule {
    return PublishingModule.draftListing;
  }

  public get userPermissionsLink(): RawLocation {
    return {
      name: RouteNames.ListingPermissions,
    };
  }

  public get headerStyle(): object {
    return {
      backgroundColor: 'var(--theme-lightest)',
    };
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/breakpoints.scss';
@import '~@/styles/theme.scss';

#loading {
  position: fixed;
  top: calc(var(--header-height) + 1px);
  left: 0;
  background: rgba(white, 0.8);
  width: 100vw;
  height: var(--full-height-minus-header);
  z-index: 1000;
}

.publish::v-deep {
  .max-width__content {
    max-width: 1288px;
  }
  #vertical-list-style {
    margin: 0;
  }
  + .footer {
    display: none;
  }
}

.wrapper {
  display: flex;
  flex-flow: row wrap;
  flex-direction: column;
  border: 1px solid white;
  max-width: 1288px;
  margin: 0 auto;
  padding: 36px 20px 120px;
  @include breakpoint($desktop) {
    display: grid;
    grid-template-columns: 2fr 5fr;
    grid-column-gap: 1em;
    grid-auto-rows: minmax(100px, auto);
  }
}

.tabs {
  margin-left: 50px;
}

.publish_header {
  flex: 1;
  padding-bottom: 1rem;
  margin: 0;
  @include breakpoint($desktop) {
  }
}

.permissions-btn {
  margin-left: 5px;
}

.add-user-icon {
  display: flex;
}

.header {
  min-height: 192px;
}
.header-content-wrapper {
  display: flex;
  align-items: center;
  padding-top: 40px;
}
.save-draft-button {
  margin-right: 1rem;
}
</style>
