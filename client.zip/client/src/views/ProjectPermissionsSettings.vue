<template>
  <full-screen-form
    :close-route="projectRoute"
    :closed="modalClosed"
    title="Edit Permissions"
    show-back
  >
    <div class="settings" :class="{ disabled }">
      <h6 class="settings__heading">Set permissions for this project</h6>
      <div class="settings__input">
        <p>Who can edit this project?</p>
        <g-people-picker
          v-model="owners"
          label="add owners"
          outlined
          :disabled="disabled"
          helper-text-content=""
          validationmessage="Your project needs at least one owner"
          required
          :valid="lengthValid"
        />
      </div>
      <div class="settings__buttons">
        <g-analytics v-slot="{ sendClick }" :click-data="analyticsData">
          <g-button
            :disabled="!canSave || disabled"
            @click="
              sendClick();
              save();
            "
          >
            Save
          </g-button>
        </g-analytics>
      </div>
    </div>
  </full-screen-form>
</template>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { RawLocation } from 'vue-router';
import FullScreenForm from '@/components/FullScreenForm.vue';
import GButton from '@/components/gsk-components/GskButton.vue';
import GPeoplePicker from '@/components/gsk-components/GskPeoplePicker.vue';
import { ProjectDetailsModule } from '@/store/modules/project-details.module';
import { RoleNames, Roles, RouteNames } from '@/constants';
import { ProjectUser } from '@/types/projects.types';
import { AnalyticsUser, ClickData } from '@/analytics';
import { UserModule } from '@/store/modules/user.module';
import GAnalytics from '@/components/GAnalytics';

interface UserRole extends AnalyticsUser {
  roleId: Roles;
  roleName?: RoleNames;
}

interface AddUser {
  projectId: number;
  user: UserRole;
}

interface RemoveUser {
  projectId: number;
  user: UserRole;
}

@Component({
  components: {
    FullScreenForm,
    GButton,
    GPeoplePicker,
    GAnalytics,
  },
})
export default class ProjectPermissionsView extends Vue {
  private owners: ProjectUser[] = [];
  private initialState: string = JSON.stringify(this.owners);
  private modalClosed: boolean = false;

  get loading() {
    return ProjectDetailsModule.projectPermissionsLoading;
  }

  async save(): Promise<void> {
    this.$log('line 42', this.owners);
    await ProjectDetailsModule.updateProjectPermissions({
      projectId: this.$route.params.id,
      skipGet: this.removedSelf,
      users: this.owners.map(owner => {
        owner.roleId = Roles.Owner;
        return owner;
      }),
    });
    if (this.removedSelf) {
      // will 403 if user gets redirected to project they don't have permission to view
      this.$router.replace(this.projectsRoute);
    } else {
      this.$router.push(this.projectRoute);
    }
  }

  get analyticsData(): ClickData {
    return {
      clickTarget: 'project-permissions-save',
      projectName: ProjectDetailsModule.projectDetails.projectName,
      projectId: ProjectDetailsModule.projectDetails.projectId,
      removedUsers: this.userDiff.removed.length,
      addedUsers: this.userDiff.added.length,
    };
  }

  get userDiff() {
    const originalOwners: ProjectUser[] = JSON.parse(this.initialState);
    const ogSet = new Set(originalOwners.map(o => o.mudId));
    const currentSet = new Set(this.owners.map(o => o.mudId));
    const formatUser = (u: ProjectUser): AddUser | RemoveUser => ({
      projectId: +this.$route.params.id,
      user: {
        roleId: Roles.Owner,
        roleName: RoleNames.Owner,
        mudId: u.mudId,
        email: u.email,
      },
    });

    // in current, but not in old === added
    const added: AddUser[] = this.owners.filter(o => !ogSet.has(o.mudId)).map(formatUser);

    // in old, but not in current === removed
    const removed: RemoveUser[] = originalOwners
      .filter(o => !currentSet.has(o.mudId))
      .map(formatUser);

    return {
      added,
      removed,
    };
  }

  get removedSelf(): boolean {
    return this.userDiff.removed.some(removal => removal.user.mudId === this.self.mudId);
  }

  get self() {
    return UserModule.user;
  }

  close() {
    this.modalClosed = true;
  }

  get disabled(): boolean {
    return this.loading;
  }

  get lengthValid() {
    return this.owners.length > 0;
  }

  get canSave() {
    return this.lengthValid && this.initialState !== JSON.stringify(this.owners);
  }

  get projectRoute(): RawLocation {
    const { id } = this.$route.params;
    return { name: RouteNames.ProjectDetails, params: { id } };
  }

  get projectsRoute(): RawLocation {
    return { name: RouteNames.ProjectsList };
  }

  async created() {
    if (ProjectDetailsModule.projectDetails.projectId === +this.$route.params.id) {
      this.$log('populated form without loading fresh data');
    } else {
      this.$log('populated form by loading fresh data');
      await ProjectDetailsModule.getProject(this.$route.params.id);
    }

    this.owners = ProjectDetailsModule.projectDetails.projectUsers;
    this.initialState = JSON.stringify(this.owners);
  }
}
</script>
<style lang="scss" scoped>
@import '~@/styles/form-modal.scss';
</style>
