<template>
  <full-screen-form :close-route="closeRoute" show-back title="Add New Project">
    <div class="new-project" :class="{ isDisabled: loading }">
      <h6 class="new-project__title">Add a new project</h6>
      <div class="new-project__input text-field">
        <g-textfield
          id="projectName"
          v-model="projectName"
          :label="nameLabel"
          required
          name="projectName"
          outlined
          type="text"
          maxlength="50"
          :placeholder="namePlaceholder"
          :validationmessage="nameValidationMessage"
        />
      </div>
      <div class="new-project__input">
        <g-textfield
          id="projectDescription"
          v-model="projectDescription"
          :label="descriptionLabel"
          required
          name="projectDescription"
          type="textarea"
          helper-text-content="Enter a short description of your project"
          :placeholder="descriptionValidationMessage"
          :validationmessage="descriptionValidationMessage"
          maxlength="255"
        />
      </div>
      <div class="new-project__button">
        <g-button class="f-text-button--primary" type="text" label="Dismiss" @click="back" />
        <g-analytics v-slot="{ sendClick }" :click-data="analyticsData">
          <g-button
            id="submitButton"
            :disabled="submitDisabled"
            unelevated
            @click="save(sendClick)"
          >
            Create Project
          </g-button>
        </g-analytics>
      </div>
    </div>
  </full-screen-form>
</template>
<script lang="ts">
import { Component } from 'vue-property-decorator';
import { mixins } from 'vue-class-component';
import { RawLocation } from 'vue-router';
import FullScreenForm from '@/components/FullScreenForm.vue';
import GButton from '@/components/gsk-components/GskButton.vue';
import { createProject } from '@/api/projects.api';
import Form from '@/components/mixins/formChecks';
import { RouteNames, TextfieldInfo } from '@/constants';
import GTextfield from '@/components/gsk-components/GskTextfield.vue';
import { addAnalyticsRouteParams, ClickData } from '@/analytics';
import { openSnackbar } from '@/utils/components';
import GAnalytics from '@/components/GAnalytics';

@Component({
  components: {
    FullScreenForm,
    GButton,
    GTextfield,
    GAnalytics,
  },
})
export default class ProjectNewView extends mixins(Form) {
  private loading: boolean = false;
  private projectName: string = '';
  private projectDescription: string = '';
  public nameLabel: string = TextfieldInfo.nameLabel;
  public namePlaceholder: string = TextfieldInfo.namePlaceholder;
  public nameValidationMessage: string = TextfieldInfo.nameValidationMessage;
  public descriptionLabel: string = TextfieldInfo.descriptionLabel;
  public descriptionPlaceholder: string = TextfieldInfo.descriptionPlaceholder;
  public descriptionValidationMessage: string = TextfieldInfo.descriptionValidationMessage;

  get analyticsData(): ClickData {
    return {
      clickTarget: 'new-project-form-submit-button',
      projectName: this.projectName,
      projectDescription: this.projectDescription,
    };
  }

  async save(sendAnalytics: () => {}): Promise<void> {
    this.loading = true;
    sendAnalytics();
    return createProject({
      projectDescription: this.projectDescription,
      projectName: this.projectName,
    })
      .then(({ data: { projectId } }) => {
        openSnackbar.call(this, 'New project created!');
        this.$router.push({
          name: RouteNames.ProjectDetails,
          params: addAnalyticsRouteParams(
            { id: projectId.toString() },
            {
              projectId: projectId,
              projectName: this.projectName,
            },
          ),
        });
      })
      .catch(e => {
        this.$log('error', e);
        openSnackbar.call(this, 'Server Error: Could not create new project', {
          type: 'error',
        });
      })
      .finally(() => {
        this.loading = false;
      });
  }

  back() {
    this.$router.safeBack(this.closeRoute);
  }

  get closeRoute(): RawLocation {
    return {
      name: RouteNames.ProjectsList,
    };
  }

  get disabled(): boolean {
    return this.loading;
  }

  get submitDisabled(): boolean {
    return !this.projectName || !this.projectDescription;
  }
}
</script>
<style lang="scss" scoped>
@import '~@/styles/breakpoints.scss';
@import '~@/styles/theme.scss';

gsk-radio,
gsk-text-field,
gsk-select {
  --gsk-theme-primary: #{$theme-primary};
}
gsk-select {
  width: 100%;
  margin-bottom: 30px;
}

.new-project {
  --gsk-theme-primary: #{$theme-primary};
  display: flex;
  flex-direction: column;
  padding: 0 2rem;
  width: 100%;
  max-width: 700px;
  @include breakpoint($desktop) {
    padding: 0;
  }

  &__input {
    &.text-field {
      // account for helper text height
      margin-bottom: calc(2rem - 19px);
    }
    margin-bottom: 2rem;
  }

  &__button {
    text-align: right;

    #submitButton {
      margin-left: 24px;
    }
  }
}
</style>
