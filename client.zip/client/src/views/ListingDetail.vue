<template>
  <max-width>
    <div id="listing-detail" class="container" :class="{ draft }">
      <div
        v-if="currentListing.listingId === -1"
        style="display: flex; justify-content: center; align-items: center; width: 100%;"
      >
        <gsk-circular-progress />
      </div>
      <div v-if="currentListing.listingId !== -1" class="listing-detail-container">
        <div class="listing-detail--left">
          <listing-details
            class="listing-detail--left-content"
            :listing="currentListing"
            :draft="draft"
          />
        </div>
        <div class="listing-detail--right">
          <div class="listing-detail--right__tabs">
            <navigation-tabs
              :no-router="draft"
              :links="tabs"
              :container-props="tabBarProps"
              :active-link.sync="tab"
              class="tabs"
            />
          </div>
          <div class="listing-detail--right__body">
            <template v-if="draft">
              <listing-detail-info-view :listing="currentListing" :active-tab="tab" />
            </template>
            <template v-else>
              <router-view />
            </template>
          </div>
        </div>
      </div>
    </div>
  </max-width>
</template>

<script lang="ts">
import { Component, Vue, Prop } from 'vue-property-decorator';
import { Location } from 'vue-router';
import GButton from '@/components/gsk-components/GskButton.vue';
import NavigationTabs from '@/components/NavigationTabs.vue';
import { FullListing, ListingSection } from '@/types/listings.types';
import { UINavigationItem } from '@/types';
import { ListingsModule as ListingCatalogModule } from '@/store/modules/listings.module';
import MaxWidth from '@/components/MaxWidth.vue';
import ListingDetailInfoView from './ListingDetailInfo.vue';
import { slugify } from '@/utils/routing';
import ListingDetails from '@/components/listing/ListingDetails.vue';
import { addAnalyticsRouteParams } from '@/analytics';
import { listingTypesById, RouteNames } from '@/constants';

// tab props
const props = {
  minwidth: true,
  noripple: true,
};

@Component({
  components: {
    GButton,
    NavigationTabs,
    MaxWidth,
    ListingDetailInfoView,
    ListingDetails,
  },
})
export default class ListingDetailView extends Vue {
  @Prop() readonly listingId!: number;
  @Prop() readonly listing!: FullListing;
  @Prop() readonly draft!: boolean;
  public version: string = '';

  public tab: UINavigationItem = {
    props,
    text: '',
    key: '',
    replace: true,
    route: {},
  };

  public get currentListing(): FullListing {
    if (this.draft) {
      return this.listing;
    } else {
      return ListingCatalogModule.detailedListing;
    }
  }

  formatNoRouteTab(tab: ListingSection): UINavigationItem {
    return {
      ...tab,
      props,
      text: tab.sectionName,
      key: tab.sectionName,
      replace: false,
      route: {},
    };
  }
  formatRouteTab(section: ListingSection, index: number): UINavigationItem {
    return {
      ...section,
      props,
      text: section.sectionName,
      key: index.toString(),
      replace: true,
      route: {
        name: RouteNames.ListingSection,
        params: {
          info: slugify(section.sectionName),
        },
        query: this.$route.query,
      },
    };
  }

  public get tabBarProps(): object {
    return {
      noripple: true,
    };
  }

  public get tabs(): UINavigationItem[] {
    let docSections = this.currentListing.extendedProperties.documentationSections.map(
      s => s.sectionInfo,
    );
    if (!Array.isArray(docSections)) {
      docSections = [];
    }
    return docSections.map((section: ListingSection, i: number) =>
      this.draft ? this.formatNoRouteTab(section) : this.formatRouteTab(section, i),
    );
  }

  protected async created(): Promise<void> {
    if (!this.draft) {
      ListingCatalogModule.getCatalogListingTypes();
      if (
        this.listingId.toString() !==
        (ListingCatalogModule.currentListing.listingId || 0).toString()
      ) {
        ListingCatalogModule.resetCurrentListing();
      }
      await ListingCatalogModule.getListingDetails(this.listingId);
      if (!this.$route.params.info && this.tabs[0]) {
        const route = this.tabs[0].route;
        const analyticsData = {
          listingName: this.currentListing.listingName,
          listingType: listingTypesById[this.currentListing.listingTypeId],
        };
        if (typeof route === 'string') {
          const r: Location = this.$router.resolve(route).location;
          r.params = addAnalyticsRouteParams(r.params, analyticsData);
          this.$router.replace(r);
        } else {
          const r: Location = { ...route };
          r.params = addAnalyticsRouteParams(r.params, analyticsData);
          this.$router.replace(r);
        }
      }
    } else {
      if (this.tabs[0]) {
        this.tab = this.tabs[0];
      }
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/theme.scss';
@import '~@/styles/breakpoints.scss';
@import '~@/styles/typography.scss';

.container {
  width: 100%;
  padding-top: 30px;

  @include breakpoint($desktop) {
    display: flex;
    padding: 60px 0;
    margin: 0 auto;
    max-width: 1440px;
  }
}

.listing-detail-container {
  display: block;
  @include breakpoint($desktop) {
    display: flex;
    justify-content: space-between;
    width: 100%;
  }
}

.listing-detail {
  &--left {
    @include breakpoint($desktop) {
      width: 100%;
      max-width: 288px;
    }
  }
  &--right {
    flex: 1;
    max-width: 800px;
    width: 100%;
    margin-bottom: 88px;
    @include breakpoint($desktop) {
      margin-left: 20px;
      min-width: 800px;
    }

    &__tabs {
      width: 100%;
      position: sticky;
      top: 0;
      background: white;

      &::after {
        content: '';
        display: block;
        width: 100%;
        height: 1px;
        background-color: $theme-lightest;
      }

      .tabs {
        width: 100%;
        max-width: fit-content;
      }
    }

    &__body {
      height: auto;
      overflow: auto;
    }
  }
}

.draft {
  padding: 0;
  padding-top: 64px;
}

.listing-detail rapi-doc {
  // Below we can define our own color theme for the editor
  --error-color: var(--gsk-theme-error);
  --success-color: var(--theme-mint, #2cc99d);
  --hover-bg: #f7f7f7;
  --get-color: var(--theme-mint, #2cc99d);
  --put-color: var(--theme-sunflower, #ecb028);
  --post-color: var(--theme-peach, #f59e9e);
  --delete-color: var(--gsk-theme-error);
  --patch-color: #fc0;
  --link-color: #47afe8;
  --primary-color: #362bff;
  --dark-primary-color: #e15b00;
  --primary-text: #ffffff;
  --header-bg: #444;
  --header-fg: #ccc;
  --layout: column;
  --font-mono: Monaco, 'Andale Mono', 'Roboto Mono', Consolas;
  --font-mono-size: 14px;
  --font-regular: rapidoc, Helvetica, Arial;
  --title-font-size: 16px;
  --border-radius: 2px;
}
</style>
