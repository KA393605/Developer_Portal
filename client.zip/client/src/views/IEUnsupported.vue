<template>
  <div class="ie">
    <div class="ie__top-bar">
      <img src="@/assets/logo-white.svg" alt="GSK Logo" />
      <p class="f-overline ie__title">Developer Portal</p>
    </div>
    <div class="ie__main">
      <div class="ie__inner">
        <h1 class="gsk-typography--headline2">Your browser is not suported</h1>
        <p class="f-body ie__subtitle">
          To use this site, visit GSKs Application Installation Tool and follow the instructions to
          download a supported browser.
        </p>
        <div class="ie__browsers">
          <a
            id="chrome"
            class="ie__browser"
            href="http://software.gsk.com/MySoftware/Desktopdefault.aspx?tabid=852&amp;txtSearch=6300680072006F006D006500&amp;noBuild=True"
          >
            <img src="@/assets/chrome.png" alt="Google Chrome Logo" />
            <p class="f-text-button--primary">Download Chrome</p>
          </a>
          <a
            id="firefox"
            class="ie__browser"
            href="http://software.gsk.com/MySoftware/Desktopdefault.aspx?tabid=852&amp;txtSearch=660069007200650066006F007800&amp;noBuild=True"
          >
            <img src="@/assets/firefox.png" alt="Firefox Logo" />
            <p class="f-text-button--primary">Download Firefox</p>
          </a>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';

@Component({})
export default class IEUnsupported extends Vue {}
</script>
<style lang="scss" scoped>
.ie {
  width: 100%;
  height: 100%;

  &__top-bar {
    background-color: #2b2926;
    display: flex;
    justify-content: flex-start;
    align-items: center;
    align-content: center;
    padding: 32px 40px;

    img {
      padding-right: 16px;
      max-height: 16px;
    }
    p {
      color: #ffffff;
      margin: 0;
    }
  }

  &__main {
    height: 100%;
    display: flex;
    justify-content: center;
    align-content: center;
    align-items: center;
  }

  &__inner {
    width: 100%;
    max-width: 600px;
    text-align: center;

    h1 {
      margin-top: 0;
    }
  }

  &__title {
    margin-bottom: 0;
  }

  &__subtitle {
    margin: 16px auto 40px;
  }

  &__browsers {
    display: flex;
    justify-content: center;
    align-content: center;
    align-items: center;

    img {
      max-width: 80px;
    }
  }

  &__browser {
    text-decoration: none;

    &:first-child {
      margin-right: 32px;
    }

    &:last-child {
      margin-left: 32px;
    }
  }
}
</style>
