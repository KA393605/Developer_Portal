<template>
  <full-screen-form :close-route="closeRoute" show-back title="Create New Team">
    <div class="new-project" :class="{ isDisabled: loading }">
      <h6 class="new-project__title">Create New Team</h6>
      <g-textfield
        id="teamName"
        v-model="teamName"
        :label="nameLabel"
        required
        name="teamName"
        outlined
        type="text"
        maxlength="50"
        :placeholder="teamNamePlaceholder"
        :validationmessage="teamValidationMessage"
      />
      <g-textfield
        id="teamDescription"
        v-model="teamDescription"
        :label="descriptionLabel"
        required
        name="teamDescription"
        type="textarea"
        helper-text-content="Enter a short description of your team"
        :placeholder="teamDescriptionPlaceholder"
        :validationmessage="teamValidationMessage"
        maxlength="255"
      />

      <div class="new-member-picker">
        <g-people-picker
          id="team-picker"
          v-model="addMembers"
          label="Add Member"
          outlined
          helper-text-content=""
          validationmessage="Your team needs at least one owner"
          :valid="lengthValid"
        />
        <g-button id="add-member-btn" icon="plus" elevation="1" @click="addTeamMembers">
          Add
        </g-button>
      </div>
      <table id="team-members-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>
              Team Role
              <router-link :to="helpRoute">
                <gsk-icon-button mini on icon="question" />
              </router-link>
            </th>
            <th></th>
          </tr>
        </thead>
        <tr v-for="member in teamMembers" :key="member.mudId">
          <td>
            <div id="member-name" class="inline-divs">
              <user-circle id="team-user-circle" :user="member" />
              <div class="inline-divs member-fullname">
                {{ member.fullName }}
              </div>
            </div>
          </td>
          <td>
            <template v-if="isCurrentUser(member)">
              <p>{{ ownerRoleName }}</p>
            </template>
            <template v-else>
              <g-select
                :key="member.mudId"
                :value="member.roleId"
                class="select-team-role"
                label="Team Role"
                :options="teamRoleNames"
                placeholder="Select"
                @input="updateUserRole(member, $event)"
              ></g-select>
            </template>
          </td>
          <td>
            <gsk-icon-button
              v-if="notCurrentUser(member)"
              icon="trash"
              officon="trash"
              @click="deleteMember(member)"
            ></gsk-icon-button>
          </td>
        </tr>
      </table>

      <g-button class="save-team-btn" elevation="1" :disabled="canNotCreate" @click="createTeam">
        Create Team
      </g-button>
    </div>
  </full-screen-form>
</template>
<script lang="ts">
import { Component } from 'vue-property-decorator';
import { mixins } from 'vue-class-component';
import { RawLocation } from 'vue-router';
import FullScreenForm from '@/components/FullScreenForm.vue';
import GButton from '@/components/gsk-components/GskButton.vue';
import Form from '@/components/mixins/formChecks';
import { RoleNames, Roles, RouteNames, teamRoleNamesById, TextfieldInfo } from '@/constants';
import GTextfield from '@/components/gsk-components/GskTextfield.vue';
import { openSnackbar } from '@/utils/components';
import GPeoplePicker from '@/components/gsk-components/GskPeoplePicker.vue';
import { HELP_ROOT_PATH } from '@/constants/help.constants';
import { UserModule } from '@/store/modules/user.module';
import UserCircle from '@/components/UserCircle.vue';
import { BaseUser } from '@/types/users.types';
import { CreateTeamRequest, TeamMember } from '@/types/teams.types';
import { SelectOption } from '@/components/form/form.types';
import GSelect from '@/components/gsk-components/GskSelect.vue';
import { TeamsModule } from '@/store/modules/teams.module';

@Component({
  components: {
    FullScreenForm,
    GButton,
    GTextfield,
    GPeoplePicker,
    UserCircle,
    GSelect,
  },
})
export default class NewTeamView extends mixins(Form) {
  private loading: boolean = false;
  private teamName: string = '';
  private teamDescription: string = '';
  private addMembers: TeamMember[] = [];
  private teamMembers: TeamMember[] = [];
  public nameLabel: string = TextfieldInfo.teamNameLabel;
  public teamNamePlaceholder: string = TextfieldInfo.teamNamePlaceholder;
  public teamValidationMessage: string = TextfieldInfo.teamValidationMessage;
  public descriptionLabel: string = TextfieldInfo.descriptionLabel;
  public teamDescriptionPlaceholder: string = TextfieldInfo.teamDescriptionPlaceholder;
  public teamDescriptionValidationMessage: string = TextfieldInfo.teamDescriptionValidationMessage;
  public teamRoleNames: SelectOption[] = [
    { value: Roles.TeamOwner + '', label: RoleNames.TeamOwner },
    { value: Roles.TeamMember + '', label: RoleNames.TeamMember },
  ];

  back() {
    this.$router.safeBack(this.closeRoute);
  }

  backToTeams() {
    this.$router.push({ name: RouteNames.MyTeams });
  }

  addTeamMembers() {
    this.addMembers.forEach(member => {
      this.teamMembers.push({
        ...member,
        roleName: RoleNames.TeamMember,
        roleId: Roles.TeamMember,
      });
    });
    this.addMembers = [];
  }

  updateUserRole(m: TeamMember, e: string) {
    const newTeamRoleId = Number(e);
    m.roleId = newTeamRoleId;
    m.roleName = teamRoleNamesById[newTeamRoleId];
  }

  deleteMember(member: TeamMember): void {
    this.teamMembers = this.teamMembers.filter((m: TeamMember) => {
      return m.mudId !== member.mudId;
    });
  }

  async createTeam(): Promise<void> {
    await TeamsModule.createTeam(this.team)
      .then(() => {
        this.$router.push({ name: RouteNames.MyTeams });
        openSnackbar.call(this, 'New Team Created');
      })
      .catch(err => {
        this.$router.push({ name: RouteNames.MyTeams });
        openSnackbar.call(this, err.message, { type: 'error' });
      });
  }

  get team(): CreateTeamRequest {
    return {
      teamName: this.teamName,
      teamDescription: this.teamDescription,
      iconUrl: '',
      createUserId: this.currentUser.userId,
      teamMembers: this.teamMembers,
    };
  }

  get canNotCreate(): boolean {
    return !this.teamDescription || !this.teamName || this.teamMembers.length < 2;
  }

  get helpRoute(): RawLocation {
    return `/${HELP_ROOT_PATH}`;
  }

  get closeRoute(): RawLocation {
    return {
      name: RouteNames.MyTeams,
    };
  }

  notCurrentUser(member: TeamMember): boolean {
    return member.mudId !== this.currentUserMudId;
  }

  isCurrentUser(member: TeamMember): boolean {
    return member.mudId === this.currentUserMudId;
  }

  get currentUserMudId(): string {
    return this.currentUser.mudId;
  }

  get currentUser(): BaseUser {
    return UserModule.user;
  }

  created() {
    this.teamMembers.push({
      roleId: Roles.TeamOwner,
      mudId: this.currentUserMudId,
      email: this.currentUser.email,
      firstName: this.currentUser.firstName,
      lastName: this.currentUser.lastName,
      fullName: this.currentUser.fullName,
    });
  }

  get ownerRoleName(): string {
    return RoleNames.TeamOwner;
  }

  get lengthValid(): boolean {
    return this.addMembers.length > 0;
  }

  get disabled(): boolean {
    return this.loading;
  }

  get submitDisabled(): boolean {
    return !this.teamName || !this.teamDescription;
  }
}
</script>
<style lang="scss" scoped>
@import '~@/styles/breakpoints.scss';
@import '~@/styles/theme.scss';

.new-member-picker {
  display: inline-grid;
  grid-template-columns: 2fr 1fr 1fr;
  margin-top: 2rem;
}

#team-picker {
  max-width: 400px;
}

#add-member-btn {
  align-self: end;
  justify-self: center;
  margin-bottom: 6px;
}

#team-members-table {
  margin-top: 2rem;
}

#member-name {
  display: inline-flex;
}

.select-team-role {
  width: fit-content;
}

.save-team-btn {
  margin-top: 4rem;
  margin-bottom: 8rem;
  display: flex;
  justify-content: center;
}

.member-fullname {
  margin-left: 12px;
}

gsk-radio,
gsk-text-field,
gsk-select {
  --gsk-theme-primary: #{$theme-primary};
}

.new-project {
  --gsk-theme-primary: #{$theme-primary};
  display: flex;
  flex-direction: column;
  padding: 0 2rem;
  width: 100%;
  max-width: 700px;
  @include breakpoint($desktop) {
    padding: 0;
  }

  &__input {
    &.text-field {
      // account for helper text height
      margin-bottom: calc(2rem - 19px);
    }
    margin-bottom: 2rem;
  }

  &__button {
    text-align: right;

    #submitButton {
      margin-left: 24px;
    }
  }
}
</style>
