<template>
  <section class="project-details__container">
    <portal to="modal">
      <g-analytics v-slot="{ sendClick }" :click-data="confirmDeleteAnalytics">
        <delete-dialog
          :open.sync="openDelete"
          button-text="Yes, delete project"
          headerlabel="Delete Project"
          @delete="
            confirmDelete();
            sendClick();
          "
        >
          Are you sure you want to delete {{ projectDetails.projectName }}?
        </delete-dialog>
      </g-analytics>
    </portal>
    <max-width :container-style="headerStyle">
      <header class="project-details__header">
        <div class="header-row">
          <section class="header-info">
            <div v-if="projectDetails.projectName" class="text">
              <h5 class="project-name">
                {{ projectDetails.projectName }}
                <help-link doc-path="1. Projects" />
              </h5>
              <p class="f-body project-description">
                {{ projectDetails.projectDescription }}
              </p>
            </div>
            <div class="project-user-list">
              <user-list :users="projectUsers" truncate class="u-list" />
              <router-link :to="permissionsLink">
                <g-button icon="locked" type="text" secondary>permissions</g-button>
              </router-link>
            </div>
          </section>

          <div class="button">
            <div ref="menuContainer" class="menu-container">
              <gsk-icon-button class="settings-icon" icon="cog" officon="cog" @click="showMenu" />
              <gsk-menu ref="settingsMenu">
                <gsk-list class="settings-list">
                  <router-link :to="settingsLink">
                    <gsk-list-item>
                      <p class="f-body--small">Edit Project Details</p>
                    </gsk-list-item>
                  </router-link>
                  <router-link :to="permissionsLink">
                    <gsk-list-item>
                      <p class="f-body--small">Set Permissions</p>
                    </gsk-list-item>
                  </router-link>
                  <g-analytics v-slot="{ sendClick }" :click-data="deleteAnalytics">
                    <gsk-list-item
                      class="menu-delete"
                      @click="
                        openDelete = true;
                        sendClick();
                      "
                    >
                      <p class="f-body--small">Delete Project</p>
                    </gsk-list-item>
                  </g-analytics>
                </gsk-list>
              </gsk-menu>
            </div>
          </div>
        </div>
        <navigation-tabs :links="tabs" :container-props="tabBarProps" class="tabs" />
      </header>
    </max-width>
    <max-width class="content">
      <!-- don't remove this key -->
      <router-view :key="$route.params.env" />
    </max-width>
  </section>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { Location } from 'vue-router';
import { Menu } from '@gsk-platforms/gsk-menu/gsk-menu';
import sortBy from 'lodash/sortBy';
import GButton from '@/components/gsk-components/GskButton.vue';
import NavigationTabs from '@/components/NavigationTabs.vue';
import { ProjectDetailsModule } from '@/store/modules/project-details.module';
import MaxWidth from '@/components/MaxWidth.vue';
import UserList from '@/components/UserList.vue';
import { UINavigationItem } from '@/types';
import { RouteNames } from '@/constants';
import DeleteDialog from '@/components/dialogs/DeleteDialog.vue';
import { addAnalyticsRouteParams, ClickData } from '@/analytics';
import GAnalytics from '@/components/GAnalytics';
import HelpLink from '@/components/HelpLink.vue';

// tab props
const props = {
  noripple: true,
};

type GskMenu = Menu;

@Component({
  components: {
    GButton,
    NavigationTabs,
    MaxWidth,
    UserList,
    DeleteDialog,
    GAnalytics,
    HelpLink,
  },
  async beforeRouteEnter(to, from, next) {
    if (ProjectDetailsModule.projectDetails.projectId !== Number(to.params.id)) {
      ProjectDetailsModule.setEmptyProject();
      await ProjectDetailsModule.getProject(to.params.id);
    }

    if (!to.params.env) {
      // if there is no env param, user has navigated directly to project and we need
      // to redirect to an env route
      const env = ProjectDetailsModule.defaultEnv;
      if (env) {
        next({
          name: RouteNames.ProjectEnvDetails,
          params: addAnalyticsRouteParams(
            {
              id: to.params.id,
              env: env.projectEnvironmentId.toString(),
              section: 'auth',
            },
            {
              projectName: ProjectDetailsModule.projectDetails.projectName,
              projectId: ProjectDetailsModule.projectDetails.projectId,
            },
          ),
        });
      }
    }

    next();
  },
})
export default class ProjectDetailView extends Vue {
  private openDelete: boolean = false;

  get deleteAnalytics(): ClickData {
    return {
      clickTarget: 'delete-project-menu-option',
      projectName: this.projectDetails.projectName,
      projectId: this.projectDetails.projectId,
    };
  }

  get confirmDeleteAnalytics(): ClickData {
    return {
      clickTarget: 'delete-project-confirm',
      projectName: this.projectDetails.projectName,
      projectId: this.projectDetails.projectId,
    };
  }

  showMenu() {
    const menu = this.$refs.settingsMenu as GskMenu;
    menu.setAnchorCorner(menu.Corner.BOTTOM_START);
    menu.setAnchorElement(this.$refs.menuContainer as Element);
    menu.setAnchorMargin({ bottom: 16 });
    menu.open = !menu.open;
  }

  async confirmDelete() {
    const projectId = +this.$route.params.id;
    await ProjectDetailsModule.deleteProject(projectId);
    this.$router.replace({ name: RouteNames.ProjectsList });
  }

  get headerStyle() {
    return {
      backgroundColor: 'var(--theme-lightest)',
    };
  }

  get tabBarProps() {
    return {
      noripple: true,
    };
  }

  get projectDetails() {
    return ProjectDetailsModule.projectDetails;
  }

  get projectUsers() {
    return ProjectDetailsModule.projectDetails.projectUsers;
  }

  get environments() {
    return ProjectDetailsModule.projectDetails.environments || [];
  }

  get tabs(): UINavigationItem[] {
    return sortBy(this.environments, ['environmentId']).map(
      (env): UINavigationItem => ({
        props,
        text: env.environmentName,
        key: env.environmentName,
        replace: true,
        route: {
          name: RouteNames.ProjectEnvDetails,
          params: {
            env: env.projectEnvironmentId.toString(),
          },
        },
        disabled: env.projectEnvironmentId === -1,
      }),
    );
  }

  get permissionsLink(): Location {
    return {
      name: RouteNames.ProjectPermissions,
      params: {
        id: this.$route.params.id,
      },
    };
  }
  get settingsLink(): Location {
    return {
      name: RouteNames.ProjectSettings,
      params: {
        id: this.$route.params.id,
      },
    };
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/theme.scss';
@import '~@/styles/breakpoints.scss';

.content {
  background: $theme-white;
  padding-bottom: 40px;
  flex: 1;
}

.project-user-list {
  margin-top: 1.5rem;
  display: flex;
}

.settings-icon {
  cursor: pointer;
  color: $theme-dark;
  font-size: 1.5rem;
}

.settings-list {
  a {
    color: $theme-dark;
  }
}

.project-name {
  padding-right: 4rem;
  margin-bottom: 0;
}

.menu-container {
  position: relative;
  text-align: right;
  width: 160px;
}

.settings-list:last-child, // last child is here for reasons
.menu-delete {
  color: $theme-danger;
}

.disabled {
  pointer-events: none;
  user-select: none;
  user-focus: none;
  opacity: 0.5;
  cursor: not-allowed;
}

.tabs {
  max-width: 500px;
  margin-bottom: -1px;
}

.header-info {
  max-width: 100%;
}

.header-row {
  display: flex;
  margin: 64px 0 40px;
  position: relative;

  .button {
    position: absolute;
    top: 108px;
    right: 0;
    display: flex;
    align-items: flex-start;
    justify-content: flex-start;
    @include breakpoint($small) {
      top: 0;
      justify-content: flex-end;
    }
    padding-left: 3rem;
    flex: 1;
  }
}

.input {
  border: none;
  background: none;
}
.project-details {
  &__container {
    display: flex;
    flex-direction: column;
    flex: 1;
    width: 100%;
    background: $theme-lightest;
  }
  &__header {
    margin-bottom: 0;

    .text {
      > h5 {
        margin-top: 0;
      }
      > p {
        margin-bottom: 0;
      }
    }
  }
  &__body {
    padding: 0 40px;
    background: #fff;
  }
}
.u-list {
  max-width: 300px;
}
</style>
