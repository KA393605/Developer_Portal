<template>
  <div v-if="section && section.sectionTemplateType" class="listing-section">
    <div class="listing-section__content">
      <template v-if="showMarkdown">
        <!-- eslint-disable-next-line vue/no-v-html -->
        <Promised :promise="compiledMarkdown">
          <template #pending>
            <gsk-circular-progress style="margin-top: 2rem;"></gsk-circular-progress>
          </template>
          <template v-slot="data">
            <div class="gsk-markdown" @click="handleMarkdownClick" v-html="data"></div>
          </template>
          <template #rejected="err">
            <div class="listing-section__no-docs">
              <img src="@/assets/uh-oh.png" />
              <h6>No documentation</h6>
            </div>
          </template>
        </Promised>
      </template>
      <div v-else-if="showOpenApi" class="listing-section__endpoints">
        <rapi-doc
          :spec-url="path"
          theme="light"
          show-header="false"
          show-info
          allow-authentication="false"
          layout="column"
          allow-try="false"
          primary-color="#f36633"
          regular-font="Arial"
        ></rapi-doc>
      </div>
      <div v-else-if="noContent" class="listing-section__no-docs">
        <img src="@/assets/uh-oh.png" />
        <h6>No documentation yet</h6>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import { Promised } from 'vue-promised';
import GButton from '@/components/gsk-components/GskButton.vue';
import NavigationTabs from '@/components/NavigationTabs.vue';
import { FullListing, ListingSection } from '@/types/listings.types';
import { ListingsModule } from '@/store/modules/listings.module';
import * as API from '@/api/github.api';
import { slugify } from '@/utils/routing';
import { getProxyUrl } from '@/api/service/urls';
import { ListingSectionTemplateTypes } from '@/constants';
import {
  marked,
  replaceLinkedRepoRelativeLinks,
  replaceLinkedUrlRelativeLinks,
} from '@/utils/markdown';
import { analyticsClick } from '@/analytics';

@Component({
  name: 'ListingDetailInfo',
  components: {
    GButton,
    NavigationTabs,
    Promised,
  },
})
export default class ListingDetailInfoView extends Vue {
  @Prop() listing!: FullListing;
  @Prop() activeTab!: ListingSection;

  public isDraft: boolean = false;
  public listingSections: ListingSection[] = [
    {
      sectionName: '',
      sectionTemplateType: '',
      sectionTemplateTypeId: 1,
      sectionContent: '',
    },
  ];
  public markdown: string = '';
  public listingSwaggerDoc: string = '';
  public repoName: string = '';
  public contentPath: string = '';
  public renderedMarkdown: string = '';

  get hasContent() {
    return !!this.section.sectionContent || !!this.section.sectionContentUrl;
  }
  get noContent() {
    return !this.hasContent;
  }
  get showMarkdown() {
    return (
      this.hasContent && this.section.sectionTemplateType === ListingSectionTemplateTypes.Markdown
    );
  }
  get showOpenApi() {
    return (
      this.hasContent && this.section.sectionTemplateType === ListingSectionTemplateTypes.OpenApi
    );
  }

  get compiledMarkdown(): Promise<string> {
    if (this.section.sectionContentUrl) {
      const url: string = this.section.sectionContentUrl;
      const { githubRepo } = this.currentListing.extendedProperties;
      if (githubRepo) {
        const [owner, name] = githubRepo.full_name.split('/');
        const args: Parameters<typeof API.getRepoFileContents> = [
          owner,
          name,
          this.section.sectionContentUrl,
        ];
        if (this.$route.query.version) {
          args.push(this.$route.query.version.toString());
        }
        return API.getRepoFileContents(...args)
          .then(r => r.data)
          .then(md => marked(md))
          .then(html => {
            return replaceLinkedRepoRelativeLinks(html, githubRepo, url, this.versionQuery);
          });
      }
      return API.getExternalDocumentation(url)
        .then(r => r.data)
        .then(html => {
          return replaceLinkedUrlRelativeLinks(html, url);
        })
        .then(md => marked(md, { baseUrl: url }));
    }
    return Promise.resolve(marked(this.sectionContent, { sanitize: false }));
  }

  get versionQuery(): string {
    const v = this.$route.query.version;
    if (Array.isArray(v)) {
      // assigning this is necessary because typescript is kind of dumb here
      // not an error in 3.6 though
      const v0 = v[0];
      if (v0 !== null) {
        return v0;
      }
    } else if (v) {
      return v;
    }
    return '';
  }

  get path() {
    if (this.isDraft) {
      return this.draftSwaggerUrl;
    }
    const p = ListingsModule.currentListingSwaggerPath;
    if (p.startsWith('http')) {
      return getProxyUrl(p);
    }

    // if no http, it's the local path to our endpoint
    // return p;
    return this.makeFileUrl(this.section.sectionContent);
  }

  get draftSwaggerUrl() {
    if (this.section.sectionTemplateType === ListingSectionTemplateTypes.OpenApi) {
      if (this.section.sectionContentUrl) {
        // TODO: api spec overflow y some hidden
        return getProxyUrl(this.section.sectionContentUrl);
      }
      return this.makeFileUrl(this.section.sectionContent);
    } else {
      return;
    }
  }

  public makeFileUrl(str: string): string {
    URL.revokeObjectURL(this.section.sectionContent);
    return URL.createObjectURL(new Blob([str], { type: 'text/json' }));
  }

  public get currentListing(): FullListing {
    if (this.listing !== undefined) {
      this.isDraft = true;
      return this.listing;
    } else {
      return ListingsModule.currentListing;
    }
  }

  get tab(): ListingSection {
    return this.activeTab;
  }

  get section(): ListingSection {
    const ds = this.currentListing.extendedProperties.documentationSections;
    const sections: ListingSection[] = ds.map(s => s.sectionInfo);
    let sct: ListingSection = {
      sectionName: '',
      sectionTemplateType: '',
      sectionTemplateTypeId: -1,
      sectionContent: '',
    };
    if (this.isDraft) {
      sct = this.tab;
    } else {
      sct = sections.filter(section => slugify(section.sectionName) === this.pageName)[0];
    }
    return sct;
  }

  get sectionName() {
    if (this.section === undefined) return '';
    return this.section.sectionName;
  }

  get sectionTemplateType(): string {
    if (this.section === undefined) return '';

    return this.section.sectionTemplateType;
  }

  get sectionContent(): string {
    if (this.section === undefined) {
      return '';
    }
    if (
      this.section.sectionTemplateType === ListingSectionTemplateTypes.Markdown &&
      this.section.sectionContent
    ) {
      // attempt to remove frontmatter, some of the results have malformed frontmatter though...
      return this.section.sectionContent.replace(/^---[\s\S]*---/, '');
    }
    return this.section.sectionContent;
  }

  get pageName(): string {
    return this.$route.params.info;
  }

  handleMarkdownClick(e: MouseEvent) {
    // to track link clicks in the markdown
    const { target } = e;
    if (target) {
      let t = target as HTMLElement;
      let parentLink = t.closest('a');
      let href = '';
      if (t.tagName === 'A') {
        href = (t as HTMLAnchorElement).href;
      } else if (parentLink) {
        href = parentLink.href;
      }

      if (href) {
        analyticsClick({
          clickTarget: 'listing-documentation-link',
          link: href,
        });
      }
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/breakpoints.scss';
@import '~@/styles/markdown.scss';
@import '~@/styles/typography.scss';
@import '~@/styles/theme.scss';

.error-text {
  margin: 1rem;
  color: $theme-danger;
}

.listing-section {
  height: 100%;
  &__content {
    height: 100%;

    .gsk-markdown,
    .listing-section__endpoints {
      &::v-deep {
        @extend .gsk-markdown;
        .anchor {
          display: none;
        }
      }

      width: 100%;
    }

    .gsk-markdown {
      padding: 0;
    }
  }

  textarea,
  &__content div {
    display: inline-block;
    width: 49%;
    height: 100%;
    vertical-align: top;
    box-sizing: border-box;
    padding: 0 20px 0 0;
  }

  code {
    color: #f66;
  }
  &__no-docs {
    width: 100%;
    display: block;
    max-width: 500px;
    margin: 100px auto 0;
    text-align: center;
    @include breakpoint(phone) {
      margin: 50px auto 0;
    }

    img {
      width: 100%;
      max-width: 300px;
    }
  }
}
</style>
