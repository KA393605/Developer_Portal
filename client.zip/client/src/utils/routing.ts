/**
 * All of this taken from Vue Router source code since
 * I need to use it but it's not exposed through the package
 */
import Router, { Route } from 'vue-router';

const trailingSlashRE = /\/?$/;

function queryIncludes(current: Route['query'], target: Route['query']): boolean {
  for (const key in target) {
    if (!(key in current)) {
      return false;
    }
  }
  return true;
}

function isObjectEqual(a = {}, b = {}): boolean {
  // handle null value #1566
  if (!a || !b) return a === b;
  const aKeys = Object.keys(a);
  const bKeys = Object.keys(b);
  if (aKeys.length !== bKeys.length) {
    return false;
  }
  return aKeys.every((key): boolean => {
    // @ts-ignore
    const aVal = a[key];
    // @ts-ignore
    const bVal = b[key];
    // check nested equality
    if (typeof aVal === 'object' && typeof bVal === 'object') {
      return isObjectEqual(aVal, bVal);
    }
    return String(aVal) === String(bVal);
  });
}

export function isSameRoute(a: Route, b: Route): boolean {
  if (a.path && b.path) {
    return (
      a.path.replace(trailingSlashRE, '') === b.path.replace(trailingSlashRE, '') &&
      a.hash === b.hash &&
      isObjectEqual(a.query, b.query)
    );
  } else if (a.name && b.name) {
    return (
      a.name === b.name &&
      a.hash === b.hash &&
      isObjectEqual(a.query, b.query) &&
      isObjectEqual(a.params, b.params)
    );
  } else {
    return false;
  }
}

export function isIncludedRoute(current: Route, target: Route): boolean {
  return (
    current.path
      .replace(trailingSlashRE, '/')
      .indexOf(target.path.replace(trailingSlashRE, '/')) === 0 &&
    (!target.hash || current.hash === target.hash) &&
    queryIncludes(current.query, target.query)
  );
}

export function removeQuery(router: Router, route: Route, ...queries: string[]): void {
  const query: Route['query'] = {};
  const querySet = new Set(queries);
  Object.keys(route.query).forEach((key: string): void => {
    if (!querySet.has(key)) {
      query[key] = route.query[key];
    }
  });
  const newRoute: Route = {
    ...route,
    query,
  };
  router.replace(newRoute);
}

/**
 * remove spaces and replace with hyphens
 */
export function slugify(str: string): string {
  return str
    .toLowerCase()
    .trim()
    .replace(/ /g, '-');
}
