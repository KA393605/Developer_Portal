/**
 * syncs up stored details in saved listings with the template:
 * strategy is to take the values from the saved fields and insert them
 * into a copy of the template fields
 */
import keyBy from 'lodash/keyBy';
import cloneDeep from 'lodash/cloneDeep';
import { FormField } from '@/components/form/form.types';
import { ListingTypeTemplate } from '@/types/listings.types';

export function processDetails(form: FormField[], template: ListingTypeTemplate): FormField[] {
  // avoid modifying / pointing to the base template fields
  const tFields = cloneDeep(template.publishing.details.form.fields);
  const formMap = keyBy(form, 'key');
  return tFields.map(tField => {
    const field = formMap[tField.key];
    if (field) {
      // in case someone changes the type of field but leaves the key the same
      if (field.type === tField.type) {
        tField.value = field.value;
      }
    }
    return tField;
  });
}
