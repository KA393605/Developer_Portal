import { LinearProgress } from '@gsk-platforms/gsk-linear-progress/gsk-linear-progress';

const getProgressBar = (): LinearProgress | null => document.querySelector('#top-progress');

export function progressStart(): void {
  const bar = getProgressBar();
  if (bar) {
    bar.open();
  }
}

export function progressStop(): void {
  const bar = getProgressBar();
  if (bar) {
    bar.close();
  }
}
