// for whatever reason putting this in the
// untyped-modules.d.ts file breaks stuff

import Vue from 'vue';

declare module 'vue/types/vue' {
  interface Vue {
    $mq: string;
  }
}
