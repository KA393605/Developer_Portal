/* eslint-disable @typescript-eslint/no-explicit-any */
// declare module '@material/drawer/dismissible/foundation.js' {
//   type MDCDismissibleDrawerFoundation = any;
//   export = MDCDismissibleDrawerFoundation;
// }
// declare module '@material/drawer/modal/foundation.js' {
//   type MDCModalDrawerFoundation = any;
//   export = MDCModalDrawerFoundation;
// }
// declare module '@material/top-app-bar/fixed/foundation.js' {
//   type MDCFixedTopAppBarFoundation = any;
//   export = MDCFixedTopAppBarFoundation;
// }
// declare module '@material/top-app-bar/short/foundation.js' {
//   type MDCShortTopAppBarFoundation = any;
//   export = MDCShortTopAppBarFoundation;
// }
// declare module '@material/top-app-bar/standard/foundation.js' {
//   type MDCTopAppBarFoundation = any;
//   export = MDCTopAppBarFoundation;
// }
//
// declare module '@material/list' {
//   export type MDCList = any;
// }
// declare module '@material/menu' {
//   export type Corner = any;
// }
// declare module '@material/menu-surface' {
//   export type MDCMenuSurface = any;
// }
// declare module '@material/menu-surface/foundation' {
//   export type AnchorMargin = any;
// }

declare module 'vue-monaco' {
  export type VueMonaco = any;
}

declare module 'vue-clickaway' {
  interface ClickawayMixin {
    directives: { onClickaway: import('vue').DirectiveOptions };
  }

  export const directive: import('vue').DirectiveOptions;
  export const mixin: ClickawayMixin;
  export const version: string;
}

declare module 'vue-mq';

declare module 'liquor-tree';
