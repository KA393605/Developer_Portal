export enum RouteNames {
  NewProject = 'projects-new',
  ProjectSettings = 'project-settings',
  PromoteSettings = 'promote-settings',
  ProjectPermissions = 'project-permissions',
  ProjectsList = 'projects-list',
  ProjectDetails = 'project-details',
  ProjectEnvDetails = 'project-details-env',
  PromoteToProd = 'promote-to-prod',
  Listings = 'catalog',
  ListingDetails = 'catalog-listing',
  ListingConnect = 'catalog-service-connect',
  ListingType = 'catalog-type',
  ListingSection = 'catalog-listing-section',
  Create = 'create',
  NotFound = 'not-found',
  MyListings = 'my-listings',
  PublishListing = 'publish-listing',
  ListingPermissions = 'listing-permissions',
  MarkdownEditor = 'markdown',
  BotEnv = 'bot-env',
  BotConsole = 'bot-console',
  BotConsoleAccess = 'access-management',
  BotType = 'bot-type',
  SwitchAccount = 'switch-account',
  MyTeams = 'my-teams',
  NewTeam = 'new-team',
  EditTeam = 'edit-team',
  TeamDetails = 'team-details',
}

export enum Ping {
  Logout = 'https://federation-qa.gsk.com/idp/startSLO.ping',
}

export enum Events {
  ShowSnackbar = 'show-snackbar',
}

export enum Environments {
  Dev = 'Dev',
  Qa = 'QA',
  Prod = 'Prod',
}

const _apiUrls: Map<string, string> = new Map([
  ['DEV', 'https://dev.api.gsk.com'],
  ['QA', 'https://qa.api.gsk.com'],
  ['PROD', 'https://api.gsk.com'],
]);
export const APIGatewayURLMapping = _apiUrls;

export enum Statuses {
  Provisioning = 'Provisioning',
  Provisioned = 'Provisioned',
  Success = 'Success',
  PendingApproval = 'PendingApproval',
  Approved = 'Approved',
  ApprovedAndProvisioned = 'ApprovedAndProvisioned',
  KeysReceived = 'KeysReceived',
  Active = 'Active',
  Rejected = 'Rejected',
  Deleted = 'Deleted',
  Failed = 'Failed',
  Draft = 'Draft',
  Published = 'Published',
}

export enum Roles {
  Owner = 1,
  TechnicalOwner = 2,
  Contributor = 3,
  RiskPartner = 4,
  TeamOwner = 8,
  TeamMember = 9,
}

export enum RoleNames {
  Owner = 'owner',
  TechnicalOwner = 'Technical Owner',
  Contributor = 'Contributor',
  RiskPartner = 'Risk Partner',
  TeamOwner = 'Team Owner',
  TeamMember = 'Team Member',
}

export enum ListingTypes {
  API = 1,
  WebComponent = 2,
  MobileComponent = 3,
  RPA = 4,
  GithubRepo = 5,
}

export const teamRoleNamesById: Record<string, string> = {
  3: RoleNames.TeamOwner,
  4: RoleNames.TeamMember,
};

export const listingTypesById: Record<number, string> = {
  1: 'API',
  2: 'Web Component',
  3: 'Mobile Component',
  4: 'RPA',
  5: 'Github Repo',
};

export enum ListingSectionTemplateTypes {
  OpenApi = 'open-api',
  Markdown = 'markdown',
}

export const ListingSectionTemplateTypeIds = {
  [ListingSectionTemplateTypes.OpenApi]: 2,
  [ListingSectionTemplateTypes.Markdown]: 1,
};

// we dont' need an enum for this
export enum TextfieldInfo {
  nameLabel = 'Project Name',
  teamNameLabel = 'Team Name',
  namePlaceholder = 'What would you like to call your project?',
  teamNamePlaceholder = 'What would you like to call your team?',
  nameValidationMessage = 'Please enter a project name',
  teamValidationMessage = 'Please enter a team name',
  descriptionLabel = 'Description',
  descriptionPlaceholder = 'Provide a brief description of your project, you’ll be able to edit this later.',
  teamDescriptionPlaceholder = 'Provide a brief description of your team',
  descriptionValidationMessage = 'Please enter a short description of your project',
  teamDescriptionValidationMessage = 'Please enter a short description of your team',
  businessPurposeLabel = 'Business Purpose',
  businessPurposePlaceholder = 'What is the business purpose for promoting to production?',
  businessPurposeValidationMessage = 'Please enter a business purpose',
  searchPlaceholder = 'Search our product catalog',
  accessManagementSearchPlaceholder = 'Search for an Existing User (MudId or Account Id)',
}
