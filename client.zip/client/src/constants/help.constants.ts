/**
 * these env vars are required at build time if they need to be customized
 */
export const HELP_ROOT_PATH: string = process.env.VUE_APP_HELP_ROOT_PATH || 'help/';
export const HELP_REPO_OWNER: string = process.env.VUE_APP_HELP_REPO_OWNER || 'gsk-tech';
export const HELP_REPO_NAME: string =
  process.env.VUE_APP_HELP_REPO_NAME || 'developer-portal-help-docs';
export const HELP_REPO_BRANCH: string = process.env.VUE_APP_HELP_REPO_BRANCH || 'master';
