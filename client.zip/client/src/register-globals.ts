import Vue from 'vue';
import { directive as onClickaway } from 'vue-clickaway';
import VueClipboard from 'vue-clipboard2';
import PortalVue from 'portal-vue';
import { LoggerPlugin } from './utils/logger';
import '@gsk-platforms/gsk-layout-grid/dist/gsk-layout-grid.css';
import './styles/main.scss';
import './register-custom-elements';
import './utils/progress';
import './utils/router-enhancements';

Vue.config.productionTip = false;

// directives
Vue.directive('onClickaway', onClickaway);

// plugins
Vue.use(LoggerPlugin);
Vue.use(PortalVue);
Vue.use(VueClipboard);
