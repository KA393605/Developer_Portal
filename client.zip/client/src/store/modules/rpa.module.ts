import { Action, getModule, Module, Mutation, VuexModule } from 'vuex-module-decorators';
import Vue from 'vue';
import store from '@/store';
import * as API from '@/api/rpa-admin.api';
import { Bot, Permission, UserPermission } from '@/types/rpa-admin.types';
import { SelectOption } from '@/components/form/form.types';

@Module({ name: 'rpa', store, dynamic: true })
class Rpa extends VuexModule {
  public rolesUserCanGrant: Record<string, SelectOption[]> = {};
  public buBotsUserCanPromote: Record<string, string[]> = {};
  public botsInBu: Record<string, Record<string, Bot[]>> = {};
  public haveUserPermissions: boolean = false;

  public get userHasRoles(): boolean {
    return this.haveUserPermissions;
  }

  @Mutation
  public setRolesUserCanGrant(permissionsByEnv: { env: string; resp: UserPermission[] }) {
    const { env, resp } = permissionsByEnv;
    let canGrant: SelectOption[] = [];
    resp.forEach(permission => {
      // Why doesn't concat work here?
      // canGrant.concat(permission.canGrant);
      permission.canGrant.forEach(role => {
        canGrant.push({ value: role });
      });
    });

    this.rolesUserCanGrant[env] = canGrant;
    this.haveUserPermissions = true;
  }

  @Mutation
  public setBuFolders(promotionsByEnv: { env: string; resp: UserPermission[] }) {
    const { env, resp } = promotionsByEnv;
    let canPromote: string[] = [];
    resp.forEach(action => {
      if (action.action === 'promote-bot') {
        canPromote.push(action.bu);
      }
    });
    this.buBotsUserCanPromote[env] = canPromote;
  }

  @Mutation
  public setBotsByBu(botsByBu: { bots: Bot[]; folder: string; env: string }) {
    const { folder, bots, env } = botsByBu;
    if (!this.botsInBu[folder]) {
      // this.botsInBu[folder] = {};
      Vue.set(this.botsInBu, folder, {});
    }
    // this.botsInBu[folder][env] = bots;
    Vue.set(this.botsInBu[folder], env, bots);
  }

  @Action
  public async getUserPermissions(env: string): Promise<void> {
    const resp: Permission[] = (await API.getUserPermissions(env)).data.permissions;
    this.setRolesUserCanGrant({ env, resp });
    this.setBuFolders({ env, resp });
  }

  @Action
  public async getBots(getBotsRequest: {
    env: string;
    folder: string;
    search: string;
  }): Promise<void> {
    const resp = await API.getBots(getBotsRequest);
    const { folder, env } = getBotsRequest;
    this.setBotsByBu({ bots: resp, folder, env });
  }
}

export const RpaModule = getModule(Rpa);
