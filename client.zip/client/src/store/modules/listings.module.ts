import { Action, getModule, Module, Mutation, VuexModule } from 'vuex-module-decorators';
import get from 'lodash/get';
import Vue from 'vue';
import * as API from '@/api/listings.api';
import { getListingTypes, ListingTypesResponse } from '@/api/publishing.api';
// eslint-disable-next-line import/no-cycle
import store from '@/store';
import { FullListing, SavedFullListing } from '@/types/listings.types';
import URLs from '@/api/service/urls';
import { ListingSectionTemplateTypes } from '@/constants';
import { slugify } from '@/utils/routing';
import { processDetails } from '@/utils/listings';

interface PaginationMeta {
  meta: {
    total: number;
    resultsPerPage: number;
    pageNumber: number;
    pagesLeft: number;
  };
}

const PER_PAGE = 200;

export type ListingsPaginated = API.Listings.Listings & PaginationMeta;

export interface ListingCatalogState {
  types: ListingsPaginated[];
}

@Module({ name: 'catalog', store, dynamic: true })
class ListingCatalogModule extends VuexModule implements ListingCatalogState {
  public types: ListingsPaginated[] = [];
  public searchResults: ListingsPaginated[] = [];
  public listingTypes: ListingTypesResponse[] = [];
  public currentListing: SavedFullListing = getEmptyListing();
  public environments: API.ListingEnvironment[] = [];
  public catalogTypeHistory: Record<string, ListingsPaginated[]> = {};

  public get noCurrentListing(): boolean {
    return this.currentListing.listingId === -1;
  }

  public get detailedListing(): FullListing {
    const type = this.listingTypes.find(
      lt => lt.listingTypeId === this.currentListing.listingTypeId,
    );
    const { details } = this.currentListing.extendedProperties;
    return {
      ...this.currentListing,
      extendedProperties: {
        ...this.currentListing.extendedProperties,
        details: type ? processDetails(details, type.listingTemplate) : [],
      },
    };
  }

  @Mutation
  public resetCurrentListing() {
    this.currentListing = getEmptyListing();
  }

  @Mutation
  public setInitialListings(types: ListingsPaginated[]): void {
    this.types = types;
  }

  @Mutation
  public setCatalogTypeHistory(listing: ListingsPaginated[]): void {
    const { listingTypeName } = listing[0];
    if (!this.catalogTypeHistory.hasOwnProperty(slugify(listingTypeName))) {
      Vue.set(this.catalogTypeHistory, slugify(listingTypeName), listing);
    }
  }

  @Mutation
  public setSearchResults(listings: ListingsPaginated[]): void {
    this.searchResults = listings;
  }

  @Mutation
  public setCurrentListing(listing: SavedFullListing): void {
    this.currentListing = listing;
  }

  @Mutation
  public setEnvironments(environments: API.ListingEnvironment[]): void {
    this.environments = environments;
  }

  @Mutation
  public setCatalogListingTypes(listingTypes: ListingTypesResponse[]): void {
    this.listingTypes = listingTypes;
  }

  public get currentListingSwaggerPath(): string {
    const ds = this.currentListing.extendedProperties.documentationSections;
    if (Array.isArray(ds)) {
      const section = ds.find(
        (sec): boolean =>
          sec.sectionInfo.sectionTemplateType === ListingSectionTemplateTypes.OpenApi,
      );
      if (section && section.sectionInfo.sectionContentUrl) {
        return section.sectionInfo.sectionContentUrl;
      }
    }
    if (this.currentListing.listingId) {
      return URLs.ListingOpenApiSpec.replace(
        ':listingId',
        this.currentListing.listingId.toString(),
      );
    }
    return '';
  }

  @Action({ commit: 'setCatalogListingTypes' })
  public async getCatalogListingTypes(): Promise<ListingTypesResponse[]> {
    return (await getListingTypes()).data.filter(lt => lt.count > 0);
  }

  @Action({ commit: 'setInitialListings' })
  public async getInitialListings(): Promise<ListingsPaginated[]> {
    const result = await API.getListings({
      pageNumber: 1,
      resultsPerPage: PER_PAGE,
      filter: {
        isFeatured: true,
      },
    });
    return (result.data.types || []).map(
      (listingType): ListingsPaginated => {
        // type(Name|Id) not returned at the top level where needed
        // assuming the "listings" of the listingType are homogeneous we can get
        // the info we want from the individual listing
        const listingTypeName =
          listingType.listingTypeName || get(listingType.listings[0], 'listingTypeName', '');
        const listingTypeId =
          listingType.listingTypeId || get(listingType.listings[0], 'listingTypeId');
        return {
          ...listingType,
          listingTypeName,
          listingTypeId,
          meta: {
            total: listingType.count,
            resultsPerPage: PER_PAGE,
            pageNumber: 2,
            pagesLeft: Math.ceil((listingType.count - PER_PAGE) / PER_PAGE), // TODO: Pagination
          },
        };
      },
    );
  }

  @Action({ commit: 'setCatalogTypeHistory' })
  public async getCurrentTypes(typeId: number): Promise<ListingsPaginated[]> {
    const result = await API.getListings({
      pageNumber: 1,
      resultsPerPage: PER_PAGE,
      filter: {
        typeId: typeId,
      },
    });
    const { count, types } = result.data;
    return (types || []).map(
      (listing): ListingsPaginated => {
        return {
          ...listing,
          meta: {
            total: count,
            resultsPerPage: PER_PAGE,
            pageNumber: 1,
            pagesLeft: Math.ceil((count - PER_PAGE) / PER_PAGE),
          },
        };
      },
    );
  }

  @Action({ commit: 'setSearchResults' })
  public async getSearchResults(q: string): Promise<ListingsPaginated[]> {
    const result = await API.getListings({
      pageNumber: 1,
      resultsPerPage: PER_PAGE,
      filter: {
        query: q,
      },
    });
    const { count, types } = result.data;
    return (types || []).map(
      (listing): ListingsPaginated => {
        return {
          ...listing,
          meta: {
            total: count,
            resultsPerPage: PER_PAGE,
            pageNumber: 1,
            pagesLeft: Math.ceil((count - PER_PAGE) / PER_PAGE),
          },
        };
      },
    );
  }

  @Action({ commit: 'setCurrentListing' })
  public async getListingDetails(listingId: number): Promise<SavedFullListing> {
    const result = await API.getListingDetails(listingId);
    return result.data;
  }

  @Action({ commit: 'setEnvironments' })
  public async getListingEnvironments(listingId: number): Promise<API.ListingEnvironment[]> {
    return (await API.getListingAvailableEnvironments(listingId)).data;
  }
}

function getEmptyListing(): SavedFullListing {
  return {
    listingId: -1,
    hasImage: false,
    listingTypeId: 1,
    listingTypeName: '',
    listingName: '',
    listingDescription: '',
    statusName: '',
    statusId: -1,
    iconUrl: '',
    listingTeamName: '',
    listingTeamIcon: '',
    isFeaturedFlag: false,
    createTimestamp: '',
    updateTimestamp: '',
    publishTimestamp: '',
    owners: [
      {
        firstName: '',
        lastName: '',
        mudId: '',
        email: '',
      },
    ],
    extendedProperties: {
      image: '',
      keywords: [],
      details: [],
      githubRepo: null,
      documentationSections: [
        {
          sectionInfo: {
            sectionName: '',
            sectionTemplateType: '',
            sectionTemplateTypeId: 1,
            sectionContent: '',
          },
          meta: {
            canDelete: true,
            canRename: true,
            canEditContent: true,
            canLinkContent: true,
            canReorder: true,
          },
        },
      ],
    },
    publishedBy: {
      firstName: '',
      lastName: '',
      mudId: '',
      email: '',
    },
    versions: [],
  };
}

export const ListingsModule = getModule(ListingCatalogModule);
