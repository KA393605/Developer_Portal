import { Action, getModule, Module, Mutation, VuexModule } from 'vuex-module-decorators';
// eslint-disable-next-line import/no-cycle
import store from '@/store';

import * as API from '@/api/projects.api';

export interface ProjectsState {
  projects: API.Projects.ProjectListProject[];
}

@Module({ dynamic: true, store, name: 'projects' })
class Projects extends VuexModule {
  public projects: ProjectsState['projects'] = [];

  @Mutation
  public setProjects(projects: API.Projects.ProjectListProject[]): void {
    this.projects = projects || [];
  }

  @Action({ commit: 'setProjects' })
  public async getProjects(): Promise<API.Projects.ProjectListProject[]> {
    return (await API.getProjects()).data.projects;
  }
}

export const ProjectsModule = getModule(Projects);
