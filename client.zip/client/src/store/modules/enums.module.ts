import { Module, VuexModule, Action, Mutation, getModule } from 'vuex-module-decorators';
import store from '@/store';
import { enumType } from '@/types/enum.types';
import * as API from '@/api/enums.api';

@Module({ name: 'enums', store, dynamic: true })
class EnumTypesModule extends VuexModule {
  public hasEnums: boolean = false;
  public enumTypes: Record<string, enumType[]> = {};

  @Mutation
  public setEnumType(enumObj: { enums: Record<string, enumType[]> }): void {
    const { enums } = enumObj;
    this.enumTypes = enums;
  }

  @Mutation
  public setHasEnumStatus(): void {
    this.hasEnums = true;
  }

  @Action
  public async getAllEnumTypes(): Promise<void> {
    const enumResponse = await API.getAllEnums();
    this.setHasEnumStatus();
    this.setEnumType({ enums: enumResponse });
  }
}

export const EnumsModule = getModule(EnumTypesModule);
