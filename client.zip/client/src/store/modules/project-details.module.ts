import { Action, getModule, Module, Mutation, VuexModule } from 'vuex-module-decorators';
import Vue from 'vue';
import { AxiosResponse } from 'axios';
// eslint-disable-next-line import/no-cycle
import store from '@/store';
import * as API from '@/api/projects.api';
import { First } from '@/types/util.types';
import { Environments, Statuses } from '@/constants';
import { EnvMeta, ProjectEnvironmentConnectedService } from '@/types/projects.types';

export interface ProjectDetailsState {
  projectDetails: API.Projects.Project;
  projectLoading: boolean;
  projectPermissionsLoading: boolean;
  purpose: string;
}

function getEmptyProjectState(): API.Projects.Project {
  return {
    projectId: -1,
    projectName: '',
    projectDescription: '',
    createTimestamp: '',
    statusId: -1,
    statusName: '',
    lastUpdateUser: {
      firstName: '',
      lastName: '',
      mudId: '',
      email: '',
    },
    billableUser: {
      firstName: '',
      lastName: '',
      mudId: '',
      email: '',
    },
    publisherUser: {
      firstName: '',
      lastName: '',
      mudId: '',
      email: '',
    },
    environments: [],
    projectUsers: [],
  };
}

function getInitialMeta(): EnvMeta {
  return {
    meta: {
      loading: false,
      error: false,
      initial: true,
    },
  };
}

function getEmptyProjectEnv(): API.Projects.ProjectEnvironmentDetails2 {
  return {
    auth: {
      meta: getInitialMeta().meta,
      OAuth: {
        clientId: '',
        secret: '',
        callbackUrls: [],
      },
      basic: {
        ApiKey: '',
      },
    },
    services: {
      connectedServices: [],
      meta: getInitialMeta().meta,
    },
    status: {
      statusId: -1,
      statusName: '',
      meta: getInitialMeta().meta,
    },
  };
}
function addEnvDefaults(projectResult: AxiosResponse<API.Projects.Project>) {
  // Add QA and Prod dummy environments if they don't already exist
  const environments = projectResult.data.environments;
  if (!environments.find((env): boolean => env.environmentName === Environments.Qa)) {
    // create dummy record
    environments.push({
      environmentId: 2,
      environmentName: Environments.Qa,
      projectEnvironmentId: -1,
      statusName: 'Not Initialized',
      statusId: -1,
      sequenceNumber: 2,
    });
  }
  if (!environments.find((env): boolean => env.environmentName === Environments.Prod)) {
    // create dummy record
    environments.push({
      environmentId: 3,
      environmentName: Environments.Prod,
      projectEnvironmentId: -1,
      statusName: 'Not Initialized',
      statusId: -1,
      sequenceNumber: 3,
    });
  }
  return projectResult.data;
}

type ProjectEnvs = Record<number, Record<number, API.Projects.ProjectEnvironmentDetails2>>;

@Module({ dynamic: true, store, name: 'projectDetails' })
class ProjectDetails extends VuexModule implements ProjectDetailsState {
  public projectDetails: ProjectDetailsState['projectDetails'] = getEmptyProjectState();
  public projectLoading: boolean = false;
  public projectPermissionsLoading: boolean = false;
  public envs: ProjectEnvs = {};
  // envs ->
  // { [projectId]: { [projectEnvId]: ProjectEnvironmentDetails

  /**
   * The reason I put the following property and 2 methods
   * is to "save" the business purpose from the promote to prod
   * screen when you click to edit.
   */
  public purpose: string = '';

  public get isInitialState(): boolean {
    return this.projectDetails.projectId === -1;
  }

  @Mutation
  public ensureProjectEnvironment(payload: {
    projectId: number;
    projectEnvId: number;
    partName: keyof API.Projects.ProjectEnvironmentDetails2;
  }) {
    const project = this.envs[payload.projectId];
    const env = project && project[payload.projectEnvId];
    if (!project) {
      Vue.set(this.envs, payload.projectId, {});
    }

    if (!env) {
      Vue.set(this.envs[payload.projectId], payload.projectEnvId, getEmptyProjectEnv());
    }
  }

  @Mutation
  public setProjectEnvironmentPartMeta(payload: {
    projectId: number;
    projectEnvId: number;
    partName: keyof API.Projects.ProjectEnvironmentDetails2;
    meta: Partial<API.Projects.EnvMeta['meta']>;
  }) {
    // ensure mutation should be called before this one
    const part = this.envs[payload.projectId][payload.projectEnvId][payload.partName];
    part.meta = {
      ...part.meta,
      ...payload.meta,
    };
  }

  @Mutation
  public setProjectEnvironmentPart(
    payload: { envPart: API.Projects.ProjectEnvironmentPart } & {
      projectId: number;
      projectEnvId: number;
      partName: keyof API.Projects.ProjectEnvironmentDetails2;
    },
  ) {
    // ensure mutation should be called before this one
    const projectEnvs = this.envs[payload.projectId];
    const oldEnv = projectEnvs && projectEnvs[payload.projectEnvId];
    const part: API.Projects.ProjectEnvironmentPart & API.Projects.EnvMeta = {
      ...payload.envPart,
      meta: {
        loading: false,
        error: false,
        initial: false,
      },
    };
    Vue.set(projectEnvs, payload.projectEnvId, {
      ...oldEnv,
      [payload.partName]: part,
    });
  }

  @Action
  public async getProjectEnvironmentPart(
    payload: First<Parameters<typeof API.getProjectEnvStatus>> & {
      partName: keyof API.Projects.ProjectEnvironmentDetails2;
    },
  ) {
    this.ensureProjectEnvironment(payload);
    this.setProjectEnvironmentPartMeta({ ...payload, meta: { loading: true } });
    const api = {
      auth: API.getProjectEnvAuth,
      services: API.getProjectEnvServices,
      status: API.getProjectEnvStatus,
    };
    const f = api[payload.partName];
    try {
      const r = await f(payload);
      this.setProjectEnvironmentPart({ ...payload, envPart: r.data });
    } catch (e) {
      this.setProjectEnvironmentPartMeta({ ...payload, meta: { error: true } });
      this.setProjectEnvironmentPartMeta({
        ...payload,
        meta: { loading: false },
      });
    }
  }

  @Mutation
  public setBusinessPurpose(newval: string): void {
    this.purpose = newval;
  }

  public get defaultEnv(): API.Projects.ProjectEnvironment | void {
    const { environments = [] } = this.projectDetails;
    const env = environments
      .slice()
      .reverse()
      .find((env): boolean => env.statusName === Statuses.Success);
    if (env) {
      return env;
    }

    return environments.find((env): boolean => env.environmentName === Environments.Dev);
  }

  public get devEnv(): API.Projects.ProjectEnvironment | undefined {
    const { environments = [] } = this.projectDetails;
    return environments.find((env): boolean => env.environmentName === Environments.Dev);
  }

  @Mutation
  public setEmptyProject(): void {
    this.projectDetails = getEmptyProjectState();
  }

  @Mutation
  public setProject(projectDetails: API.Projects.Project): void {
    this.projectDetails = projectDetails;
  }

  @Mutation
  public setProjectLoading(isLoading: boolean): void {
    this.projectLoading = isLoading;
  }

  @Mutation
  public setProjectPermissionsLoading(isLoading: boolean): void {
    this.projectPermissionsLoading = isLoading;
  }

  @Action
  public async getProject(projectId: string | number): Promise<API.Projects.Project> {
    this.setProjectLoading(true);
    this.setProjectPermissionsLoading(true);
    return this.baseGetProject(projectId).finally(() => {
      this.setProjectLoading(false);
      this.setProjectPermissionsLoading(false);
    });
  }

  @Action
  public async baseGetProject(projectId: string | number): Promise<API.Projects.Project> {
    this.setProjectPermissionsLoading(true);
    return API.getProjectDetails(projectId)
      .then(projectResult => addEnvDefaults(projectResult))
      .then(project => {
        this.setProject(project);
        return project;
      });
  }

  @Action
  public async updateProjectDetails(
    payload: First<Parameters<typeof API.updateProjectDetails>>,
  ): Promise<void> {
    this.setProjectLoading(true);
    await API.updateProjectDetails(payload);
    await this.getProject(payload.projectId);
  }

  @Action
  public async updateProjectPermissions(
    payload: First<Parameters<typeof API.updateProjectPermissions>> & { skipGet: boolean },
  ): Promise<void> {
    this.setProjectPermissionsLoading(true);
    await API.updateProjectPermissions(payload);
    if (!payload.skipGet) {
      await this.getProject(payload.projectId);
    }
  }

  @Action({ rawError: true })
  public async promoteEnvironment(
    payload: First<Parameters<typeof API.promoteProjectEnvironment>>,
  ): Promise<API.ProjectEnvironmentPromotion> {
    const result = await API.promoteProjectEnvironment(payload);
    await this.baseGetProject(this.projectDetails.projectId);
    return result.data;
  }

  @Action
  public async deleteProject(projectId: string | number): Promise<void> {
    await API.deleteProject(projectId);
    this.setEmptyProject();
  }

  @Mutation
  public setConnectedServices(payload: {
    projectId: number;
    projectEnvId: number;
    connectedServices: ProjectEnvironmentConnectedService[];
  }) {
    const env = this.envs[payload.projectId][payload.projectEnvId];
    env.services.connectedServices = payload.connectedServices;
  }

  @Action({ rawError: true })
  public async removeConnectedService(payload: {
    projectId: number;
    projectEnvId: number;
    serviceEnvId: number;
    connectedServices: ProjectEnvironmentConnectedService[];
  }) {
    const { projectId, projectEnvId, serviceEnvId } = payload;
    const partName = 'services';
    this.setProjectEnvironmentPartMeta({
      projectId,
      projectEnvId,
      partName,
      meta: { loading: true },
    });
    API.removeServiceFromProject({ projectId, projectEnvId, serviceEnvId })
      .then(() => {
        this.setConnectedServices(payload);
        this.setProjectEnvironmentPartMeta({
          projectId,
          projectEnvId,
          partName,
          meta: { loading: false },
        });
      })
      .catch(err => {
        return new Promise((_, reject) => {
          this.setProjectEnvironmentPartMeta({
            projectId,
            projectEnvId,
            partName,
            meta: { error: true, loading: false },
          });
          reject(err);
        });
      });
  }

  @Mutation
  public setCallbackUrls(payload: { projectId: number; projectEnvId: number; urls: string[] }) {
    const env = this.envs[payload.projectId][payload.projectEnvId];
    env.auth.OAuth.callbackUrls = payload.urls;
  }

  @Action({ rawError: true })
  public async updateCallbackUrls(payload: {
    projectId: number;
    projectEnvId: number;
    urls: string[];
  }) {
    this.setProjectEnvironmentPartMeta({
      projectId: payload.projectId,
      projectEnvId: payload.projectEnvId,
      partName: 'auth',
      meta: { loading: true },
    });
    API.updateCallbackUrls(payload.projectEnvId, {
      urls: payload.urls,
    })
      .then(res => {
        const urls = res.data.connectionDetails.callbackUrls;
        this.setCallbackUrls({ ...payload, urls });
        this.setProjectEnvironmentPartMeta({
          projectId: payload.projectId,
          projectEnvId: payload.projectEnvId,
          partName: 'auth',
          meta: { loading: false },
        });
      })
      .catch(err => {
        return new Promise((_, reject) => {
          this.setProjectEnvironmentPartMeta({
            projectId: payload.projectId,
            projectEnvId: payload.projectEnvId,
            partName: 'auth',
            meta: { error: true, loading: false },
          });
          reject(err);
        });
      });
  }
}

export const ProjectDetailsModule = getModule(ProjectDetails);
