import { AxiosPromise } from 'axios';
import axios from '@/api/service';
import URLs from '@/api/service/urls';
import { User } from '@/types/users.types';

export function getUser(): AxiosPromise<User> {
  return axios.get(URLs.UserInfo, { baseURL: window.location.origin, maxRedirects: 0 });
}

export function logoutUser(): AxiosPromise<unknown> {
  return axios.get(URLs.LogoutUser, { baseURL: window.location.origin, maxRedirects: 0 });
}
