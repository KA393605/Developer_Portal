import { AxiosError, AxiosPromise } from 'axios';
import { Omit as StrictOmit } from 'ts-essentials';
import { isNetworkOrIdempotentRequestError } from 'axios-retry';
import axios, { AxiosRetryRequestConfig } from '@/api/service';
import URLs from '@/api/service/urls';
import * as Projects from '@/types/projects.types';
import { PaginatedFilterableRequest } from '@/types';
import { PaginatedResponseBodyProjects } from '@/types/api.types';
import { Environments } from '@/constants';
import { First } from '@/types/util.types';

export { Projects };
export type ProjectsAPIQuery = PaginatedFilterableRequest<{ search?: string }>;
export type ProjectsAPIResponse = PaginatedResponseBodyProjects<Projects.ProjectListProject>;
export interface ProjectEnvironmentPromotion {
  projectEnvironmentId: number;
  environmentId: number;
  environmentName: string;
  statusId: number;
  statusName: string;
}

export function getProjects(): AxiosPromise<ProjectsAPIResponse> {
  return axios.get<ProjectsAPIResponse>(URLs.Projects);
}

export function createProject(
  data: Projects.CreateProjectRequestBody,
): AxiosPromise<{ projectId: number }> {
  return axios.post(URLs.Projects, data);
}

export function promoteProjectToQA({
  projectEnvId,
}: {
  projectEnvId: number | string;
}): AxiosPromise<ProjectEnvironmentPromotion> {
  return axios.post(URLs.ProjectPromoteToQA, null, { params: { projectEnvId } });
}

export function promoteProjectToProd({
  projectEnvId,
  query,
}: {
  projectEnvId: string | number;
  query: Projects.PromoteQuery;
}): AxiosPromise<ProjectEnvironmentPromotion> {
  return axios.post(URLs.ProjectPromoteToProd, query, { params: { projectEnvId } });
}

export function promoteRequiresApproval({
  projectEnvId,
}: {
  projectEnvId: string | number;
}): AxiosPromise<{ registrationId: number } | ''> {
  return axios.get(URLs.ProjectPromoteRequiresApproval, {
    params: { projectEnvId },
  });
}

export function promoteProjectEnvironment(
  payload:
    | (First<Parameters<typeof promoteProjectToQA>> & { srcEnv: Environments.Dev })
    | (First<Parameters<typeof promoteProjectToProd>> & { srcEnv: Environments.Qa }),
): AxiosPromise<ProjectEnvironmentPromotion> {
  if (payload.srcEnv === Environments.Dev) {
    return promoteProjectToQA(payload);
  } else {
    return promoteProjectToProd(payload);
  }
}

export function getProjectDetails(projectId: number | string): AxiosPromise<Projects.Project> {
  return axios.get<Projects.Project>(URLs.Project, { params: { projectId } });
}

export function getPandoraIDs(query: string): AxiosPromise<Projects.PandoraApiResponse[]> {
  return axios.get(URLs.PandoraIDs, { params: { query } });
}

export function getProjectPermissions(
  projectId: number | string,
): AxiosPromise<Projects.ProjectPermissions> {
  return axios.get<Projects.ProjectPermissions>(URLs.ProjectPermissions, {
    params: { projectId },
  });
}

/**
 * this one is janky right after a project is created
 * something with the deets not being fully into the keyvault service i think
 */
export function getProjectEnv(params: {
  projectId: Projects.Project['projectId'];
  projectEnvId: Projects.ProjectEnvironment['projectEnvironmentId'];
}): AxiosPromise<Projects.ProjectEnvironmentDetails> {
  return axios.get(URLs.ProjectEnvironment, {
    params,
    'axios-retry': {
      retries: 3,
      retryDelay: (): number => 1000,
      retryCondition(err: AxiosError): boolean {
        return (
          isNetworkOrIdempotentRequestError(err) || (err.response || { status: 0 }).status === 404
        );
      },
    },
  } as AxiosRetryRequestConfig);
}

export function getProjectEnvStatus(params: {
  projectId: Projects.Project['projectId'];
  projectEnvId: Projects.ProjectEnvironment['projectEnvironmentId'];
}): AxiosPromise<Projects.ProjectEnvironmentStatus> {
  return axios.get(URLs.ProjectEnvironmentStatus, {
    params,
  });
}

export function getProjectEnvAuth(params: {
  projectId: Projects.Project['projectId'];
  projectEnvId: Projects.ProjectEnvironment['projectEnvironmentId'];
}): AxiosPromise<Projects.ProjectEnvironmentAuth> {
  return axios.get(URLs.ProjectEnvironmentAuth, {
    params,
  });
}

export function getProjectEnvServices(params: {
  projectId: Projects.Project['projectId'];
  projectEnvId: Projects.ProjectEnvironment['projectEnvironmentId'];
}): AxiosPromise<Projects.ProjectEnvironmentServices> {
  return axios.get(URLs.ProjectEnvironmentServices, {
    params,
  });
}

export function updateProjectPermissions({
  projectId,
  users,
}: {
  projectId: string | number;
  users: StrictOmit<Projects.ProjectUser, 'roleName'>[];
}): AxiosPromise<{}> {
  return axios.put(URLs.ProjectPermissions, users, { params: { projectId } });
}

export function updateProjectDetails({
  projectId,
  projectName,
  projectDescription,
}: {
  projectId: string | number;
  projectName: string;
  projectDescription: string;
}): AxiosPromise<{}> {
  return axios.patch(URLs.Project, { projectName, projectDescription }, { params: { projectId } });
}

export function deleteProject(projectId: string | number): AxiosPromise<{}> {
  return axios.delete(URLs.Project, { params: { projectId } });
}

export function addServiceToProject({
  projectId,
  projectEnvId,
  serviceEnvId,
}: {
  projectId: string | number;
  projectEnvId: number;
  serviceEnvId: number;
}): AxiosPromise<{}> {
  return axios.post(
    URLs.ProjectEnvironmentService,
    {},
    {
      params: { projectId, projectEnvId, serviceEnvId },
    },
  );
}

export function removeServiceFromProject({
  projectId,
  projectEnvId,
  serviceEnvId,
}: {
  projectId: string | number;
  projectEnvId: number;
  serviceEnvId: number;
}): AxiosPromise<{}> {
  return axios.delete(URLs.ProjectEnvironmentService, {
    params: { projectId, projectEnvId, serviceEnvId },
  });
}

export interface UpdateCallbackUrlsResponse {
  projectEnvironmentConnectionId: number;
  projectEnvironmentId: number;
  connectionDetails: {
    callbackUrls: string[];
    clientId: string;
    oAuth: string;
  };
}

export function updateCallbackUrls(
  projectEnvId: string | number,
  urls: { urls: string[] },
): AxiosPromise<UpdateCallbackUrlsResponse> {
  return axios.put(URLs.ProjectEnvironmentCallbackUrls, urls, { params: { projectEnvId } });
}
