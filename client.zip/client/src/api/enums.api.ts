import axios from '@/api/service';
import URLs from '@/api/service/urls';
import { enumType } from '@/types/enum.types';

export async function getAllEnums(): Promise<Record<string, enumType[]>> {
  const enums = await axios.get(URLs.Enums, {});
  return enums.data;
}
