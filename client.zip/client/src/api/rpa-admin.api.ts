import { AxiosPromise } from 'axios';
import axios from '@/api/service';
import URLs from '@/api/service/urls';
import { PaginatedFilterableRequest } from '@/types';
import {
  PaginatedResponseBodyBotPromotion,
  PaginatedResponseBodyRpaBotDependencies,
  PaginatedResponseBodyRpaBots,
  PaginatedResponseBodyRpaFolders,
  ResponseBodyBotAAEnv,
} from '@/types/api.types';
import { UserModule } from '@/store/modules/user.module';
import {
  Bot,
  BotDependency,
  CreateUserRequest,
  CreateUserResponse,
  EditUserRequest,
  FindRolesResponse,
  GetUserRolesResponse,
  MudIDSearchResponse,
  PromoteBotRequest,
  UserEnvPermissions,
  UserSearchResponse,
} from '@/types/rpa-admin.types';

const xmlJs = import('xml-js');

export type BotsAPIQuery = PaginatedFilterableRequest<{ search?: string }>;
export type BotsAPIResponse = PaginatedResponseBodyRpaBots<Bot>;
export type BotDependenciesAPIResponse = PaginatedResponseBodyRpaBotDependencies<BotDependency>;
export type FoldersAPIResponse = PaginatedResponseBodyRpaFolders<string>;
export type PromoteBotApiResponse = PaginatedResponseBodyBotPromotion<string>;
export type BotsUpdateAAEnvResponse = ResponseBodyBotAAEnv<number>;

/*
{
      "path": "Automation Anywhere\\My Tasks\\Platforms\\DependencyDemo\\SubTaskofTestBot.atmx",
      "size": 4523,
      "lastModifiedBy": "va667773",
      "name": "SubTaskofTestBot.atmx",
      "id": "2490",
      "lastModified": "2019-07-24T18:22:11.556Z",
      "locked": false
    },
 */

export async function getBots({
  env,
  folder,
  search,
}: {
  env: string;
  folder: string;
  search: string;
}): Promise<Bot[]> {
  const resp = await axios.get<BotsAPIResponse>(URLs.Bots, { params: { env, folder, search } });
  return resp.data.bots;
}

export function getUserPermissions(env: string): AxiosPromise<UserEnvPermissions> {
  return axios.get<UserEnvPermissions>(URLs.BotUserPermissions, { params: { env } });
}

export function getBot({ env, id }: { env: string; id: string }): AxiosPromise<BotsAPIResponse> {
  return axios.get<BotsAPIResponse>(URLs.Bot, { params: { env, id } });
}

export async function validateUserMudId(
  id: string,
  SEARCH_URL: string,
): Promise<UserSearchResponse[]> {
  const fields = ['email', 'mudId', 'first_name', 'last_name'].join(',');
  const src = 'people';
  const q = id;
  const bearer = `bearer ${UserModule.user.accessToken}`;
  const result = (
    await axios.get(SEARCH_URL, {
      params: { q, src, fields },
      headers: { Authorization: bearer },
    })
  ).data.entries.map((potentialUser: MudIDSearchResponse) => {
    if (potentialUser.link === q) {
      return JSON.parse(potentialUser.content);
    }
  });
  return result;
}

export async function validateFunctionalAcct(targetId: string): Promise<Record<string, any>> {
  const { mudId } = UserModule.user;
  const result = await axios.get(URLs.ValidateFuncAcct, { params: { targetId, mudId } });
  const xmlModule = await xmlJs;
  return xmlModule.xml2js(result.data, { compact: true });
}

// Leaving this here cause we'll probably end up using the search api again
// export async function searchUserAndFindRoles(
//   query: string,
//   SEARCH_URL: string,
//   env: string,
// ): Promise<FindRolesResponse[]> {
//   const fields = ['email', 'mudId', 'first_name', 'last_name'].join(',');
//   const src = 'people';
//   const q = query;
//   const bearer = `bearer ${UserModule.user.accessToken}`;
//   const limit = '10';
//   const result = (
//     await axios.get(SEARCH_URL, {
//       params: { q, src, fields, limit },
//       headers: { Authorization: bearer },
//     })
//   ).data.entries.map(async (user: UserSearchResponse) => {
//     return await axios
//       .get(URLs.BotUserRoles, { params: { env, username: user.link } })
//       .then(res => {
//         return {
//           ...res.data,
//           env,
//           userAcctFound: true,
//         };
//       })
//       .catch(() => {
//         const { EMAIL, FIRST_NAME, LAST_NAME, MUDID } = JSON.parse(user.content);
//         return {
//           email: EMAIL,
//           username: MUDID,
//           firstName: FIRST_NAME,
//           lastName: LAST_NAME,
//           licenseFeatures: [],
//           roles: [],
//           id: -1,
//           env,
//           userAcctFound: false,
//         };
//       });
//   });
//   return await Promise.all(result);
// }

export async function searchUserAndFindRoles(
  username: string,
  env: string,
): Promise<FindRolesResponse[]> {
  return await axios.get(URLs.BotUserRoles, { params: { env, username } }).then(res => {
    return [res.data];
  });
}

export function getUserRoles(env: string, username: string): AxiosPromise<GetUserRolesResponse> {
  return axios.get<GetUserRolesResponse>(URLs.BotUserRoles, { params: { env, username } });
}

export function getTopLevelFolders(): AxiosPromise<FoldersAPIResponse> {
  return axios.get<FoldersAPIResponse>(URLs.BotsTopLevelFolders);
}

export function getBotDependencies({
  env,
  id,
}: {
  env: string;
  id: string;
}): AxiosPromise<BotDependenciesAPIResponse> {
  return axios.get(URLs.BotDependencies, { params: { env, id } });
}

export function updateBotEnvironment(
  promoteBotRequest: PromoteBotRequest,
): AxiosPromise<PromoteBotApiResponse> {
  return axios.post(URLs.PromoteBot, promoteBotRequest);
}

export function createNewUser(
  createUserRequest: CreateUserRequest,
): AxiosPromise<CreateUserResponse> {
  return axios.post(URLs.CreateUser, createUserRequest);
}

export function updateUserRoles(updateUserRequest: EditUserRequest): AxiosPromise<EditUserRequest> {
  return axios.patch(URLs.EditUser, updateUserRequest);
}

export function updateAAEnv({ env }: { env: string }): AxiosPromise<BotsUpdateAAEnvResponse> {
  return axios.post(URLs.UpdateAAEnvironment, { env });
}
