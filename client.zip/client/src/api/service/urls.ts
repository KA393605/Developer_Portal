/**
 * other than Base, all of these match up to paths
 * defined in server controllers
 */
enum URLs {
  Base = '/api',
  Listings = '/listings/search',
  ListingDetails = '/listings/:listingId',
  ListingEnvironments = '/listings/:listingId/environments',
  ListingOpenApiSpec = '/api/listings/:listingId/open-api-spec',
  ProjectsSearch = '/projects/search',
  Projects = '/projects',
  Project = '/projects/:projectId',
  ProjectPermissions = '/projects/:projectId/users',
  ProjectEnvironment = '/projects/:projectId/environments/:projectEnvId',
  ProjectEnvironmentStatus = '/projects/:projectId/environments/:projectEnvId/status',
  ProjectEnvironmentAuth = '/projects/:projectId/environments/:projectEnvId/auth',
  ProjectEnvironmentServices = '/projects/:projectId/environments/:projectEnvId/services',
  ProjectEnvironmentCallbackUrls = '/projects/environments/:projectEnvId/connections/callbackUrls',
  ProjectEnvironmentService = '/projects/:projectId/environments/:projectEnvId/services/:serviceEnvId',
  ProjectPromoteEnvironment = '/projects/environment/:projectEnvId/promote',
  ProjectPromoteToProd = '/projects/environments/:projectEnvId/promotetoprod',
  ProjectPromoteToQA = '/projects/environments/:projectEnvId/promotetoqa',
  ProjectPromoteRequiresApproval = '/projects/environments/:projectEnvId/prodServiceCheck',
  UserInfo = '/auth/user',
  LogoutUser = '/auth/logout',
  SaveListingDraft = '/publishing/draftListing',
  SaveListingDraftVersion = '/publishing/draftListing',
  UpdateListingDraftVersion = '/publishing/draftListingVersion/:listingVersionId',
  GetRegistrations = '/publishing/availableRegistrations',
  GetRegistrationVersions = '/publishing/availableRegistrationVersions/:registrationId',
  GithubDocs = '/listings/docs/github',
  MyListings = '/publishing',
  AllListings = '/publishing/all',
  AddSelfAsOwner = '/publishing/draftListing/:listingId/addSelfAsOwner/:setAsOwner',
  SetListingAsFeatured = '/publishing/draftListing/:listingId/isFeatured/:setAsFeatured',
  GetAdminSettings = '/publishing/draftListing/:listingId/adminSettings',
  UnpublishListing = '/publishing/draftListing/:listingId/unpublish',
  ListingTypes = '/publishing/listingTypes',

  // publishing
  GetUserDraftListings = '/publishing',
  GetListingTypes = '/publishing/listingTypes',
  GetListingType = '/publishing/listingTypes/:listingTypeId',
  CreateListingType = '/publishing/listingTypes',
  UpdateListingType = '/publishing/listingTypes',
  GetUserGithubRepos = '/publishing/github/user-repos/:mudId',
  GetGithubRepoFiles = '/publishing/github/repo-files',
  GetGithubRepoFileContents = '/publishing/github/file-contents',

  // versioned, aka APIs/Services/Registrations
  GetDraftListingVersion = '/publishing/draftListingVersion/:draftListingVersionId',
  CreateDraftListingVersion = '/publishing/draftListing/:draftListingId/version',
  UpdateDraftListingVersion = '/publishing/draftListingVersion/:draftListingVersionId',
  PublishNewDraftListingVersion = '/publishing/draftListing/:draftListingId/publishNewVersion/',
  PublishDraftListingVersion = '/publishing/draftListingVersion/:draftListingVersionId/publish/',
  DiscardDraftListingVersion = '/publishing/draftListingVersion/:draftListingVersionId/discardDraft',
  DeleteDraftListingVersion = '/publishing/draftListingVersion/:draftListingVersionId',
  GetAvailableRegistrations = '/publishing/availableRegistrations',
  GetAvailableRegistrationVersions = '/publishing/availableRegistrationVersions/:registrationId',

  // unversioned, everything else
  GetDraftListing = '/publishing/draftListing/:draftListingId',
  CreateDraftListing = '/publishing/draftListing',
  UpdateDraftListing = '/publishing/draftListing/:draftListingId',
  PublishNewDraftListing = '/publishing/draftListing/publish',
  PublishDraftListing = '/publishing/draftListing/:draftListingId/publish',
  DiscardDraftListing = '/publishing/draftListing/:draftListingId/discardDraft',
  DeleteDraftListing = '/publishing/draftListing/:draftListingId',
  UpdateListingPermissions = '/publishing/draftListing/:draftListingId/permissions',

  Proxy = '/publishing/proxy',
  PandoraIDs = '/air/pandora',

  // RPA Bot Console
  BotHealth = '/rpa-admin/health',
  Bot = '/rpa-admin/bot',
  BotDependencies = '/rpa-admin/bot/dependencies',
  PromoteBot = '/rpa-admin/bot/promotion',
  Bots = '/rpa-admin/bots',
  CreateUser = '/rpa-admin/user',
  EditUser = '/rpa-admin/user',
  ValidateFuncAcct = '/rpa-admin/functional-acct',
  // BotUserRoles = '/rpa-admin/user/roles',
  BotUserRoles = '/rpa-admin/user',
  BotUserPermissions = '/rpa-admin/user/permissions',
  BotsTopLevelFolders = '/rpa-admin/folders',
  UpdateAAEnvironment = '/rpa-admin/updateAAEnv',

  // Enums
  Enums = '/enums',

  // Teams
  UserTeams = '/teams/all',
  DeleteTeam = '/teams/delete/:id',
  CreateTeam = '/teams/create',
  EditTeam = '/teams/update/:id',

  // help / docs
  HelpFileTree = '/help/tree',
}

export function getProxyUrl(url: string): string {
  return location.origin + '/api' + URLs.Proxy + '?url=' + encodeURIComponent(url);
}

export default URLs;
