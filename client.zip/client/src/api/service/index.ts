/* eslint-disable-next-line @typescript-eslint/no-unused-vars */
import axios, { AxiosRequestConfig, AxiosResponse } from 'axios';
import axiosRetry, { IAxiosRetryConfig, exponentialDelay } from 'axios-retry';
import { debug } from 'loglevel';
import URLs from './urls';

export interface AxiosRetryRequestConfig extends AxiosRequestConfig {
  'axios-retry'?: IAxiosRetryConfig;
}

const service = axios.create({
  baseURL: window.location.origin + URLs.Base,
});
axiosRetry(service, { retries: 0, retryDelay: exponentialDelay });

service.interceptors.response.use(
  /* eslint-disable-next-line @typescript-eslint/no-explicit-any */
  function(response): AxiosResponse<any> {
    // Do something with response data
    return response;
  },
  /* eslint-disable-next-line @typescript-eslint/no-explicit-any */
  function(error): any {
    // Do something with response error
    if (error.response && error.response.status === 401) {
      debug('session expired, redirecting to login');
      if (process.env.NODE_ENV === 'development') {
        debug('node env is dev, redirecting to localhost:3000/auth/ping/login');
        window.location.assign('http://localhost:3000/auth/ping/login');
      } else {
        window.location.assign('/auth/ping/login');
      }
    }
    return Promise.reject(error);
  },
);

/**
 * this will replace url path params that look like ":param" in /url/path/:param
 * with the equivalent key value pair from axios request config.params
 *
 * Given:
 *   url    -- /listings/:listingId/users/:userId
 *   params -- { listingId: 1, userId: 3, otherParam: 'hello' }
 *
 * the resulting url would be:
 *   /listings/1/users/3?otherParam=hello
 */
service.interceptors.request.use(
  (config): AxiosRequestConfig => {
    let url = config.url || '';
    if (config.params && url.includes(':')) {
      const params = { ...config.params };
      Object.entries(params as Record<string, string | number>).forEach(([key, val]): void => {
        const midPattern = `(/)(:${key})(/)`;
        const endPattern = `(/):${key}$`;
        if (new RegExp(`${midPattern}|${endPattern}`).test(url)) {
          const encodedValue = encodeURIComponent(String(val));
          const mid = new RegExp(midPattern, 'g');
          url = url.replace(mid, `$1${encodedValue}$3`);
          const end = new RegExp(endPattern, 'g');
          url = url.replace(end, `$1${encodedValue}`);
          delete params[key];
          debug(
            'api service: removing',
            `"${key}"`,
            `from config.params and substituting ":${key}" with "${encodedValue}" in url path`,
          );
        }
      });
      config.url = url;
      config.params = params;
    }

    return config;
  },
);

/*

service.interceptors.response.use(undefined, err => (err: AxiosError) => {
    let res = err.response;
    if (res!.status === 401 && res!.config  && !res.config.__isRetryRequest) {
      return new Promise((resolve, reject) => {
          success => {
            setTokens(success.access_token, success.refresh_token)
            err.config.__isRetryRequest = true
            err.config.headers.Authorization = 'Bearer ' + getAccessToken()
            resolve(axios(err.config))
          },
          error => {
            console.log('Refresh login error: ', error)
            reject(error)
          }
        )
      })
    }

  }
);

 */

export default service;
