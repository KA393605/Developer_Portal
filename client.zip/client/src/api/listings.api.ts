import { AxiosPromise } from 'axios';
import axios from '@/api/service';
import { PaginatedFilterableRequest } from '@/types';
import URLs from '@/api/service/urls';
import * as Listings from '@/types/listings.types';
import { PaginatedListingsResponseBody, PaginatedResponseBody } from '@/types/api.types';

export { Listings };
export type ListingAPIQuery = PaginatedFilterableRequest<{
  typeId?: number;
  isFeatured?: boolean;
  query?: string;
}>;
export type ListingsAPIResponseBody = PaginatedListingsResponseBody<Listings.Listings>;
export interface ListingEnvironment {
  environmentName: string;
  environmentId: number;
  serviceId: number;
}

export function getListings(query: ListingAPIQuery): AxiosPromise<ListingsAPIResponseBody> {
  return axios.post<ListingsAPIResponseBody>(URLs.Listings, query);
}

export function getListingDetails(
  listingId: number | string,
): AxiosPromise<Listings.SavedFullListing> {
  return axios.get<Listings.SavedFullListing>(URLs.ListingDetails, {
    params: {
      listingId,
    },
  });
}

export function getListingAvailableEnvironments(
  listingId: number | string,
): AxiosPromise<ListingEnvironment[]> {
  return axios.get(URLs.ListingEnvironments, {
    params: {
      listingId,
    },
  });
}

export function getAvailableRegistrations(): AxiosPromise<Listings.GetRegistrationsResponseBody> {
  return axios.get(URLs.GetRegistrations);
}
