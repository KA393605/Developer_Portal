import { AxiosPromise } from 'axios';
import axios from '@/api/service';
import URLs from '@/api/service/urls';
import { CreateTeamRequest, TeamsResponse, UpdateTeamRequest } from '@/types/teams.types';

export async function getAllTeams(): Promise<TeamsResponse> {
  const teams = await axios.get(URLs.UserTeams, {});
  return teams.data;
}

export function deleteTeam(teamId: number): AxiosPromise<boolean> {
  return axios.delete(URLs.DeleteTeam, {
    params: { id: teamId },
  });
}

export function createTeam(newTeam: CreateTeamRequest): AxiosPromise<number> {
  return axios.post(URLs.CreateTeam, newTeam);
}

export function editTeam(updateTeam: UpdateTeamRequest): AxiosPromise<boolean> {
  const { teamId } = updateTeam;
  return axios.put(URLs.EditTeam, updateTeam, { params: { id: teamId } });
}
