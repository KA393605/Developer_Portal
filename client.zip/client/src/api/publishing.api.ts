import { AxiosPromise } from 'axios';
import axios from '@/api/service';
import URLs from '@/api/service/urls';
import {
  GetRegistrationVersionsResponseBody,
  GithubRepo,
  MyListing,
} from '@/types/publishing.types';
import * as Listings from '@/types/listings.types';

export function getMyListings(): AxiosPromise<{ count: number; listings: MyListing[] }> {
  return axios.post(URLs.MyListings, { results: 100 });
}

export interface ListingTypesResponse {
  count: number;
  defaultIcon: string | null;
  listingTemplate: Listings.ListingTypeTemplate;
  listingTypeDescription: string;
  listingTypeId: number;
  listingTypeName: string;
  sequenceNumber: number;
}

export function getListingTypes(): AxiosPromise<ListingTypesResponse[]> {
  return axios.get(URLs.GetListingTypes);
}

export function getAllListings(): AxiosPromise<{ count: number; listings: MyListing[] }> {
  return axios.post(URLs.AllListings);
}

export function addSelfAsOwner(listingId: number, setAsOwner: boolean): void {
  axios.post(URLs.AddSelfAsOwner, {}, { params: { listingId, setAsOwner } });
}

export function unpublishListing(listingId: number): void {
  axios.post(URLs.UnpublishListing, {}, { params: { listingId } });
}

export function setListingAsFeatured(listingId: number, setAsFeatured: boolean): void {
  axios.post(URLs.SetListingAsFeatured, {}, { params: { listingId, setAsFeatured } });
}

export function getAdminSettings(
  listingId: number,
): AxiosPromise<{ isCurrentOwner: boolean; isFeaturedFlag: boolean }> {
  return axios.get(URLs.GetAdminSettings, { params: { listingId } });
}

export function getDraftListing(
  draftListingId: number | string,
): AxiosPromise<Listings.SavedListingModule> {
  return axios.get(URLs.GetDraftListing, { params: { draftListingId } });
}

export function getDraftListingVersion(
  draftListingVersionId: number | string,
): AxiosPromise<Listings.DraftListingVersion> {
  return axios.get(URLs.GetDraftListingVersion, { params: { draftListingVersionId } });
}

export function deleteDraftListingVersion(draftListingVersionId: number): AxiosPromise<boolean> {
  return axios.delete(URLs.DeleteDraftListingVersion, { params: { draftListingVersionId } });
}

export function deleteDraftListing(draftListingId: number): AxiosPromise<boolean> {
  return axios.delete(URLs.DeleteDraftListing, { params: { draftListingId } });
}

export function discardDraftListingVersion(draftListingVersionId: number): AxiosPromise<boolean> {
  return axios.post(URLs.DiscardDraftListingVersion, {}, { params: { draftListingVersionId } });
}

export function discardDraftListing(draftListingId: number): AxiosPromise<boolean> {
  return axios.post(URLs.DiscardDraftListing, {}, { params: { draftListingId } });
}

export function getRegistrationVersions(
  registrationId: number,
): AxiosPromise<GetRegistrationVersionsResponseBody> {
  return axios.get(URLs.GetRegistrationVersions, { params: { registrationId } });
}

export function updateListingPermissions(
  users: Listings.ListingUser[],
  draftListingId: string,
): AxiosPromise<boolean> {
  return axios.put(URLs.UpdateListingPermissions, users, {
    params: {
      draftListingId,
    },
  });
}

export function saveDraftListing(
  draft: Listings.DraftListingModule,
): AxiosPromise<Listings.DraftListingId> {
  return axios.post(URLs.SaveListingDraft, draft);
}

export function updateDraftListing(
  draft: Listings.DraftListingModule,
  draftListingId: string,
): AxiosPromise<boolean> {
  return axios.put(URLs.UpdateDraftListing, draft, {
    params: {
      draftListingId,
    },
  });
}

export function createDraftListing(
  draftListing: Listings.DraftListingModule,
): AxiosPromise<number> {
  return axios.post(URLs.CreateDraftListing, draftListing);
}

export function createDraftListingVersion(
  draftListing: Listings.DraftListingModule,
  draftListingId: string | number,
): AxiosPromise<number> {
  return axios.post(URLs.CreateDraftListingVersion, draftListing, {
    params: {
      draftListingId,
    },
  });
}

export function publishDraftListing(
  draftListing: Listings.DraftListingModule,
  draftListingId: string | number,
): AxiosPromise<number> {
  return axios.post(URLs.PublishDraftListing, draftListing, {
    params: {
      draftListingId,
    },
  });
}

export function publishDraftListingVersion(
  draftListing: Listings.DraftListingModule,
  draftListingVersionId: string | number,
): AxiosPromise<number> {
  return axios.post(URLs.PublishDraftListingVersion, draftListing, {
    params: {
      draftListingVersionId,
    },
  });
}

export function publishNewDraftListing(
  draftListing: Listings.DraftListingModule,
): AxiosPromise<number> {
  return axios.post(URLs.PublishNewDraftListing, draftListing);
}

export function publishNewDraftListingVersion(
  draftListing: Listings.DraftListingModule,
  draftListingId: string | number,
): AxiosPromise<number> {
  return axios.post(URLs.PublishNewDraftListingVersion, draftListing, {
    params: {
      draftListingId,
    },
  });
}

export function updateDraftListingVersion(
  draft: Listings.DraftListingModule,
  listingVersionId: string | number,
): AxiosPromise<boolean> {
  return axios.put(URLs.UpdateListingDraftVersion, draft, {
    params: {
      listingVersionId,
    },
  });
}

export function getUserGithubRepos(mudId: string): AxiosPromise<GithubRepo[]> {
  return axios.get(URLs.GetUserGithubRepos, {
    params: {
      mudId,
    },
  });
}
