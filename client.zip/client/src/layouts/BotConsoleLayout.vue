<template>
  <div id="layout">
    <portal-target name="appBar" class="pt"></portal-target>
    <gsk-top-app-bar ref="appBar" class="top-app-bar" type="fixed">
      <gsk-icon slot="navigationIcon" class="top-nav__menu" @click="navOpen = !navOpen">
        gsk_menu
      </gsk-icon>
      <router-link slot="title" to="/" class="top-nav__link top-nav__logo">
        <img src="../assets/logo-orange-gradient.png" alt="gsk logo" />
      </router-link>
      <div id="access-management" slot="actionItems" class="header-links item-border">
        <router-link :to="botConsoleAccess" class="menu-link">
          <gsk-list-item>
            <p class="menu-item-text">Access Management</p>
          </gsk-list-item>
        </router-link>
      </div>
      <div id="rpa-console" slot="actionItems" class="header-links item-border">
        <router-link :to="botConsole" class="menu-link">
          <gsk-list-item>
            <p class="menu-item-text">Deployment</p>
          </gsk-list-item>
        </router-link>
      </div>
      <div slot="actionItems">
        <router-link :to="helpDocumentation" class="menu-link help-link">
          <gsk-icon-button icon="question" officon="question"></gsk-icon-button>
        </router-link>
      </div>
      <div
        id="user-mudId"
        ref="menuAnchor"
        slot="actionItems"
        class="header-links item-border"
        @click="showMenu"
      >
        {{ userMudId }}
      </div>
      <gsk-menu ref="menu" slot="actionItems" class="menu">
        <gsk-list>
          <router-link :to="switchAccount" class="menu-link">
            <gsk-list-item>
              <p class="menu-item-text">Switch Account</p>
            </gsk-list-item>
          </router-link>
          <gsk-list-item>
            <p class="menu-item-text" @click="logout">Logout</p>
          </gsk-list-item>
        </gsk-list>
      </gsk-menu>
    </gsk-top-app-bar>
    <gsk-drawer type="modal" :open="navOpen" class="side-nav" v-on="drawerEventHandlers">
      <div class="side-nav__close">
        <gsk-icon @click="navOpen = false">gsk_clear</gsk-icon>
      </div>
      <div class="side-nav__links">
        <div
          v-for="n in navLinks"
          :key="n.link.name"
          :to="n.link"
          class="f-text-button side-nav__link"
        >
          <span v-if="!n.button" class="nowrap">{{ n.mobileText || n.text }}</span>
          <g-button v-else icon="plus">{{ n.mobileText || n.text }}</g-button>
        </div>
      </div>
    </gsk-drawer>
    <main id="layout-main" ref="main">
      <router-view />
      <div class="footer">
        <div class="footer--left">
          <img class="footer__logo" src="@/assets/gsk-logo.svg" alt="GSK Logo" />
          <p class="f-overline footer__copyright">© 2019 GlaxoSmithKline. All rights reserved.</p>
        </div>
        <a
          class="f-text-button footer--right footer__link"
          href="https://one.gsk.com/shared-responsibilities-agreement/#data"
        >
          Shared Responsibilities Agreement
        </a>
      </div>
    </main>
  </div>
</template>

<script lang="ts">
import Vue from 'vue';
import { Component, Watch } from 'vue-property-decorator';
import { TopAppBar } from '@gsk-platforms/gsk-top-app-bar/gsk-top-app-bar';
import { Menu } from '@gsk-platforms/gsk-menu/gsk-menu';
import { Ping, RouteNames } from '@/constants';
import GButton from '@/components/gsk-components/GskButton.vue';
import { RpaModule } from '@/store/modules/rpa.module';
import { UserModule } from '@/store/modules/user.module';
import {RawLocation} from "vue-router";

type GskMenu = Menu;

@Component({
  components: {
    GButton,
  },
  async beforeRouteEnter(to: unknown, from: unknown, next: () => void) {
    const promiseArr = ['dev', 'qa', 'prod'].map(env => {
      return RpaModule.getUserPermissions(env);
    });
    if (!RpaModule.userHasRoles) {
      await Promise.all(promiseArr);
    }
    next();
  },
})
export default class BotConsoleLayout extends Vue {
  private navOpen: boolean = false;

  showMenu(): void {
    const menu = this.$refs.menu as GskMenu;
    const anchor = this.$refs.menuAnchor as Element;
    menu.setAnchorElement(anchor);
    menu.setAnchorCorner(menu.Corner.TOP_LEFT);
    menu.setAnchorMargin({ top: 40, right: 35 });
    menu.open = !menu.open;
  }

  logout() {
    UserModule.logoutUser();
    window.location.assign(Ping.Logout);
  }

  get userMudId(): string {
    return UserModule.user.mudId;
  }

  @Watch('$route')
  onRouteChange() {
    this.navOpen = false;
  }

  get botConsole() {
    return {
      name: RouteNames.BotConsole,
    };
  }

  get botConsoleAccess() {
    return {
      name: RouteNames.BotConsoleAccess,
    };
  }

  get helpDocumentation() {
    return {
      name: 'documentation',
    };
  }

  get switchAccount(): RawLocation {
    return {
      name: RouteNames.SwitchAccount,
    };
  }

  get navLinks() {
    return [
      {
        text: 'Bot Console',
        link: { name: RouteNames.BotConsole },
      },
    ];
  }

  get drawerEventHandlers() {
    return {
      opened: () => {
        this.navOpen = true;
      },
      closed: () => {
        this.navOpen = false;
      },
    };
  }

  mounted() {
    const bar = this.$refs.appBar as TopAppBar;
    const main = this.$refs.main as HTMLElement;
    bar.scrollTarget = main;
  }
}
</script>

<style scoped lang="scss">
@import '~@/styles/breakpoints.scss';
@import '~@/styles/theme.scss';

$header-height: var(--header-height);

#access-management {
  cursor: pointer;
}

#user-mudId {
  cursor: pointer;
}

.menu {
  position: absolute;
  width: 140px;
}

.menu-link {
  text-decoration: none;
}

.help-link {
  padding-right: 9px;
}

.item-border:hover {
  border-bottom: 2px solid #12626d;
}

#layout {
  --gsk-theme-primary: #{$theme-primary};
  .top-app-bar {
    --gsk-theme-primary: #{$theme-on-primary};
  }

  width: 100%;
  height: 100%;
  overflow: hidden;
  display: flex;
  flex-direction: column;
}

#layout-main {
  margin-top: $header-height;
  overflow-y: scroll;
  overflow-x: hidden;
  width: 100%;
  display: flex;
  justify-content: space-between;
  flex-flow: column nowrap;
  flex: 1;
  border-top: 1px solid $theme-lighter;

  /*&::v-deep a {*/
  /*<!--  color: $theme-primary;-->*/
  /*text-decoration: none;*/
  /*}*/
}

.add-icon {
  --gsk-theme-primary: #{$theme-primary};
  --gsk-theme-on-secondary: #{$theme-white};
  transform: rotate(45deg);
}

.side-nav {
  display: block;
  height: auto;
  @include breakpoint($medium) {
    display: none;
  }
  --gsk-theme-surface: #{$theme-on-primary};
  --gsk-theme-on-surface: #{$theme-dark};
  a {
    color: var(--gsk-theme-on-surface);
  }
}
.side-nav__close {
  padding: 1rem;
  text-align: right;
  > gsk-icon {
    font-size: 2rem;
    cursor: pointer;
  }
}
.side-nav__links {
  padding: 1rem;
  display: flex;
  flex-direction: column-reverse;
  margin-top: 6rem;
}
.side-nav__link {
  &:not(:first-child) {
    margin-bottom: 3rem;
  }
}

.menu-icon {
  display: none;
  --gsk-theme-primary: white;
}

.top-nav__logo {
  display: none;
  @include breakpoint($small) {
    display: flex;
  }
  > img {
    height: 100%;
  }
  > span {
    margin-left: 1rem;
    /*display: none;
      @include breakpoint($small) {
        display: inline;
      }*/
  }
}

.top-nav__menu {
  color: var(--theme-primary);
  padding-left: 1rem;
  cursor: pointer;
  @include breakpoint($medium) {
    display: none;
  }
}
.top-nav__link {
  display: flex;
  align-items: center;
  text-decoration: none;
  border-radius: 35px;
  padding: 0.5em;
  color: $theme-dark;
  height: $header-height;
  /*margin-right: 2rem;*/
  margin-bottom: -1px;

  &.f-subtitle--small {
    display: none;
    @include breakpoint($desktop) {
      display: flex;
    }
  }
  &.router-link-active:not(.top-nav__logo) {
    background: linear-gradient(to right, $theme-primary, $theme-primary) no-repeat;
    background-size: 100% 4px;
    background-position: left bottom;
    border-radius: 0;
  }
  // .f-overline {
  //   color: $theme-typography--on-dark;
  // }
}

.header-links {
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: row-reverse;
  height: $header-height;
}

.hamburger {
  margin: 0px;
  font-size: 31px;
  padding-top: 9px;
  color: white;
  text-decoration-line: none;

  @include breakpoint($desktop) {
    display: none;
  }
}

.footer {
  width: 100%;
  margin: 0 auto;
  display: flex;
  flex-direction: column;
  align-content: center;
  align-items: center;
  justify-content: space-between;
  padding: 10px;
  border-top: 1px solid var(--theme-light);
  background: var(--theme-white);

  @include breakpoint($larger-tablet) {
    flex-flow: row nowrap;
    padding: 10px 104px;
  }
  &__logo {
    margin-right: 24px;
  }

  a {
    color: var(--theme-medium);

    &:hover {
      color: var(--theme-primary);
    }
  }

  &--left {
    display: flex;
    flex-flow: row nowrap;
    align-content: center;
    align-items: center;
  }
}
.pt {
  position: absolute;
  top: -17px;
  width: 100%;
  z-index: 1900;
}
</style>
