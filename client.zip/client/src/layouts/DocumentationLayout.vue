<template>
  <gsk-drawer
    class="drawer"
    :type="drawerType"
    :open="drawerOpen"
    @closed="drawerOpen = false"
    @opened="drawerOpen = true"
  >
    <div class="drawer-header">
      <img src="../assets/logo-orange-gradient.png" alt="gsk logo" class="logo" />
      <h2 class="gsk-typography--overline">
        Dev Portal Help
      </h2>
    </div>
    <div class="nav-list">
      <liquor-tree
        v-if="files.length"
        ref="tree"
        class="nav-tree"
        :filter="filter"
        :data="files"
        @node:selected="onNodeSelect"
        @tree:mounted="onTreeMount"
      />
      <gsk-linear-progress v-else />
      <navigation-list class="hide-desktop" :links="navLinks" no-line bold />
    </div>
    <gsk-top-app-bar id="app-bar" slot="appContent" type="fixed">
      <gsk-icon-button slot="navigationIcon" useparentcolor icon="menu" on @click="toggleDrawer" />
      <div slot="title" class="logo-title">
        <router-link v-show="!drawerOpen" to="/" class="logo-title">
          <img src="../assets/logo-orange-gradient.png" alt="gsk logo" class="logo" />
        </router-link>
        <h1 class="gsk-typography--overline">{{ title || 'Documentation' }}</h1>
      </div>
      <top-navigation :links="navLinks" class="hide-phone hide-tablet" />
    </gsk-top-app-bar>
    <div id="app-content" slot="appContent">
      <router-view
        v-if="$route.path.endsWith('.md')"
        :home="defaultLink"
        @update:title="updateTitle"
        @link="selectLink"
      />
    </div>
  </gsk-drawer>
</template>

<script lang="ts">
import Vue from 'vue';
import LiquorTree from 'liquor-tree';
import { HelpModule } from '@/store/modules/help.module';
import { TreeNode } from '@/types/util.types';
import { HELP_REPO_BRANCH, HELP_REPO_NAME, HELP_REPO_OWNER } from '@/constants/help.constants';
import NavigationTabs from '@/components/NavigationTabs.vue';
import { UINavigationItem } from '@/types';
import { RouteNames } from '@/constants';
import NavigationList from '@/components/NavigationList.vue';
import TopNavigation from '@/components/TopNavigation.vue';

export default Vue.extend({
  name: 'HelpLayout',
  components: {
    LiquorTree,
    NavigationList,
    TopNavigation,
  },
  data() {
    return {
      mql: window.matchMedia('(min-width: 850px)'),
      drawerOpen: true,
      drawerType: '',
      filter: '',
      search: '',
      title: '',
    };
  },
  computed: {
    files() {
      return HelpModule.fileTree;
    },
    defaultLink() {
      return HelpModule.defaultFilePath;
    },
    navLinks(): UINavigationItem[] {
      return [
        {
          text: 'My Listings',
          route: { name: RouteNames.MyListings },
          key: 'l',
          props: {
            noripple: true,
          },
        },
        {
          text: 'Projects',
          route: { name: RouteNames.ProjectsList },
          key: 'p',
          props: {
            noripple: true,
          },
        },
        {
          text: 'Product Catalog',
          route: { name: RouteNames.Listings },
          key: 'c',
          props: {
            noripple: true,
          },
        },
      ];
    },
  },
  watch: {
    $route() {
      if (this.drawerType === 'modal') {
        this.drawerOpen = false;
      }
      this.selectLink(this.$route.path);
    },
  },
  beforeDestroy() {
    this.mql.removeListener(this.setDrawerType);
  },
  mounted() {
    this.setDrawerType({ matches: this.mql.matches });
    this.mql.addListener(this.setDrawerType);
    HelpModule.loadFileTree({
      owner: HELP_REPO_OWNER,
      repo: HELP_REPO_NAME,
      // eslint-disable-next-line @typescript-eslint/camelcase
      tree_sha: HELP_REPO_BRANCH,
    });
  },
  methods: {
    selectLink(path: string | void) {
      let sel: any = null;
      const tree = this.$refs.tree as any;
      if (path === undefined) {
        path = HelpModule.defaultFilePath;
      }
      sel = tree.find({
        data: {
          path,
        },
      });
      if (sel && sel.length) {
        sel.select();
        let p = sel[0].parent;
        while (p) {
          p.expand();
          p = p.parent;
        }
      }
    },
    updateTitle(text: string) {
      this.title = text;
    },
    onTreeMount(e: any) {
      const { path } = this.$route;
      this.selectLink(path.endsWith('.md') ? path : undefined);
    },
    onNodeSelect(node: TreeNode) {
      if (!(node.children && node.children.length)) {
        if (!this.$route.path.endsWith('.md')) {
          // to catch the root folder initial navigation
          this.$router.replace(node.data.path).catch(() => {});
        } else {
          this.$router.push(node.data.path).catch(() => {});
        }
        this.title = node.text;
      }
    },
    toggleDrawer() {
      this.drawerOpen = !this.drawerOpen;
    },
    setDrawerType(e: { matches: boolean }) {
      this.drawerType = e.matches ? 'dismissible' : 'modal';
      this.drawerOpen = e.matches;
    },
  },
});
</script>

<style scoped lang="scss">
@import '~@/styles/typography.scss';
@import '~@/styles/breakpoints.scss';
@import '~@/styles/theme.scss';
#app-content {
  height: calc(100vh - var(--header-height));
  overflow-y: scroll;
  margin: var(--header-height) 0 0;
}
#app-bar {
  float: left;
}
.nav-tree {
  ::v-deep {
    .tree-root {
      padding: 0;
      margin-bottom: 0;
      > .tree-node > .tree-content {
        padding-left: 12px !important;
      }
    }
    .tree-arrow:not(.expanded).has-child:after {
      transform: rotate(45deg) translateY(-50%) translateX(-50%);
    }
    .tree-arrow.expanded.has-child:after {
      transform: rotate(45deg + 180deg) translateY(-50%) translateX(-50%);
    }
    .tree-arrow {
      position: absolute;
      right: 12px;
      &:not(.has-child) {
        display: none;
      }
      &.has-child::after {
        left: 50%;
        top: 50%;
        transform-origin: top left;
        border-color: $theme-medium;
        width: 8px;
        height: 8px;
        border-radius: 1px;
      }
    }
    .tree-content {
      position: relative;
      padding-top: 0;
      padding-bottom: 0;
      font-weight: 700;
      border-radius: 2px;
      padding-right: 12px;
      &:not(.has-child) {
        overflow-x: scroll;
        white-space: nowrap;
      }
      &.has-child {
        padding-right: 30px + 12px;
      }
      /*padding-left: 12px !important;*/
    }
    .tree-anchor {
      color: $theme-dark;
      margin-left: 0;
      padding-left: 0;
      padding-top: 12px;
      padding-bottom: 12px;
    }
    .tree-node.selected:not(.has-child) > .tree-content {
      background-color: $theme-lighter;
    }
    .tree-node.selected.has-child > .tree-content {
      background-color: transparent;
    }
    .tree-node > .tree-content:hover {
      background: $theme-lightest !important;
    }
    .tree-arrow {
      &.has-child {
        /*width: 25px;*/
      }
      &:not(.has-child) {
        margin-left: 6px;
      }
    }
  }
}
.drawer-header {
  height: calc(var(--header-height) + 1px);
  border-bottom: 1px solid #eee;
  display: flex;
  align-items: center;
  padding: 0.75rem;
}
.nav-list {
  padding: 0.75rem;
}
.logo-title {
  display: flex;
  text-decoration: none;
  align-items: center;
}
.logo {
  height: 36px;
  padding-right: 1rem;
}
</style>
