<template>
  <div id="layout">
    <portal-target name="appBar" class="pt" />
    <gsk-top-app-bar ref="appBar" class="top-app-bar" type="fixed">
      <gsk-icon-button
        slot="navigationIcon"
        icon="menu"
        on
        useparentcolor
        class="top-nav__menu"
        @click="navOpen = true"
      />
      <router-link slot="title" to="/" class="top-nav__link top-nav__logo">
        <img src="../assets/logo-orange-gradient.png" alt="gsk logo" />
        <span class="f-overline">
          developer portal
        </span>
      </router-link>
      <top-navigation :links="navLinks" />
      <router-link id="help-link" slot="actionItems" :to="helpRoute">
        <gsk-icon-button on icon="question" />
      </router-link>
      <!--      <div-->
      <!--        id="user-mudId"-->
      <!--        ref="menuAnchor"-->
      <!--        slot="actionItems"-->
      <!--        class="header-links item-border"-->
      <!--        @click="showMenu"-->
      <!--      >-->
      <!--        {{ userMudId }}-->
      <!--      </div>-->
      <div slot="actionItems" class="menu-container">
        <user-circle
          id="user-icon"
          ref="menuAnchor"
          :user="user"
          class="circle"
          disable-tooltip
          @click.native="showMenu"
        />
        <gsk-menu ref="menu" class="menu">
          <gsk-list>
            <router-link :to="myTeams" class="menu-link">
              <gsk-list-item>
                <p class="menu-item-text">My Teams</p>
              </gsk-list-item>
            </router-link>
            <router-link :to="switchAccount" class="menu-link">
              <gsk-list-item>
                <p class="menu-item-text">Logout</p>
              </gsk-list-item>
            </router-link>
          </gsk-list>
        </gsk-menu>
      </div>
    </gsk-top-app-bar>
    <gsk-drawer type="modal" :open="navOpen" class="side-nav" v-on="drawerEventHandlers">
      <div class="drawer-header">
        <h2 class="gsk-typography--overline">
          GSK Developer Portal
        </h2>
      </div>
      <div class="side-nav__links">
        <navigation-list :links="navLinks.slice().reverse()" no-line bold />
      </div>
    </gsk-drawer>
    <main id="layout-main" ref="main">
      <router-view />
      <div class="footer">
        <div class="footer--left">
          <img class="footer__logo" src="@/assets/gsk-logo.svg" alt="GSK Logo" />
          <p class="f-overline footer__copyright">© 2019 GlaxoSmithKline. All rights reserved.</p>
        </div>
        <a
          class="f-text-button footer--right footer__link"
          href="https://one.gsk.com/shared-responsibilities-agreement/#data"
        >
          Shared Responsibilities Agreement
        </a>
      </div>
    </main>
  </div>
</template>

<script lang="ts">
import Vue from 'vue';
import { Component, Watch } from 'vue-property-decorator';
import { TopAppBar } from '@gsk-platforms/gsk-top-app-bar/gsk-top-app-bar';
import { Menu } from '@gsk-platforms/gsk-menu/gsk-menu';
import { RawLocation } from 'vue-router';
import { RouteNames } from '@/constants';
import GButton from '@/components/gsk-components/GskButton.vue';
import { HELP_ROOT_PATH } from '@/constants/help.constants';
import { UINavigationItem } from '@/types';
import TopNavigation from '@/components/TopNavigation.vue';
import NavigationList from '@/components/NavigationList.vue';
import { UserModule } from '@/store/modules/user.module';
import UserCircle from '@/components/UserCircle.vue';
import { BaseUser } from '@/types/users.types';

type GskMenu = Menu;

@Component({
  components: {
    GButton,
    TopNavigation,
    NavigationList,
    UserCircle,
  },
})
export default class DefaultLayout extends Vue {
  private navOpen: boolean = false;

  @Watch('$route')
  onRouteChange() {
    this.navOpen = false;
  }

  get navLinks(): UINavigationItem[] {
    return [
      {
        text: 'My Listings',
        key: 'l',
        route: { name: RouteNames.MyListings },
      },
      {
        text: 'Projects',
        key: 'p',
        route: { name: RouteNames.ProjectsList },
      },
      {
        text: 'Product Catalog',
        key: 'c',
        route: { name: RouteNames.Listings },
      },
    ];
  }

  showMenu(): void {
    const menu = this.$refs.menu as GskMenu;
    const anchor = this.$refs.menuAnchor as Vue;
    menu.setAnchorElement(anchor.$el);
    menu.setAnchorCorner(menu.Corner.BOTTOM_LEFT);
    menu.open = !menu.open;
  }

  get myTeams(): RawLocation {
    return {
      name: RouteNames.MyTeams,
    };
  }

  get user(): BaseUser {
    return UserModule.user;
  }

  get switchAccount(): RawLocation {
    return {
      name: RouteNames.SwitchAccount,
    };
  }

  get helpRoute() {
    return `/${HELP_ROOT_PATH}`;
  }

  get drawerEventHandlers() {
    return {
      opened: () => {
        this.navOpen = true;
      },
      closed: () => {
        this.navOpen = false;
      },
    };
  }

  mounted() {
    const bar = this.$refs.appBar as TopAppBar;
    const main = this.$refs.main as HTMLElement;
    bar.scrollTarget = main;
  }
}
</script>

<style scoped lang="scss">
@import '~@/styles/breakpoints.scss';
@import '~@/styles/theme.scss';

$header-height: var(--header-height);

#layout {
  --gsk-theme-primary: #{$theme-primary};
  .top-app-bar {
    --gsk-theme-primary: #{$theme-on-primary};
  }

  width: 100%;
  height: 100%;
  overflow: hidden;
  display: flex;
  flex-direction: column;
}

#layout-main {
  margin-top: $header-height;
  overflow-y: scroll;
  overflow-x: hidden;
  width: 100%;
  display: flex;
  justify-content: space-between;
  flex-flow: column nowrap;
  flex: 1;
  border-top: 1px solid $theme-lighter;

  &::v-deep a {
    color: $theme-primary;
    text-decoration: none;
  }
}

.circle {
  /*margin-left: 29px;*/
}

#user-icon::v-deep * {
  cursor: pointer !important;
}

#help-link {
  margin-left: -12px;
  margin-right: 22px;
}

.menu-container {
  position: relative;
  /*width: 140px;*/
}

.menu-link {
  text-decoration: none;
}

.add-icon {
  --gsk-theme-primary: #{$theme-primary};
  --gsk-theme-on-secondary: #{$theme-white};
  transform: rotate(45deg);
}

.side-nav {
  display: block;
  height: auto;
  @include breakpoint($medium) {
    display: none;
  }
  --gsk-theme-surface: #{$theme-on-primary};
  --gsk-theme-on-surface: #{$theme-dark};
  a {
    color: var(--gsk-theme-on-surface);
  }
}
.side-nav__links {
  padding: 12px;
}

.menu-icon {
  display: none;
  --gsk-theme-primary: white;
}

.top-nav__logo {
  display: none;
  @include breakpoint($small) {
    display: flex;
  }
  > img {
    height: 36px;
  }
  > span {
    margin-left: 1rem;
  }
}

.top-nav__menu {
  padding-left: 1rem;
  @include breakpoint($medium) {
    display: none;
  }
}
.top-nav__link {
  display: flex;
  align-items: center;
  text-decoration: none;
  border-radius: 35px;
  padding: 0.5em;
  color: $theme-dark;
  height: $header-height;
  margin-right: 2rem;
  margin-bottom: -1px;

  &.f-subtitle--small {
    display: none;
    @include breakpoint($desktop) {
      display: flex;
    }
  }
  &.router-link-active:not(.top-nav__logo) {
    background: linear-gradient(to right, $theme-primary, $theme-primary) no-repeat;
    background-size: 100% 4px;
    background-position: left bottom;
    border-radius: 0;
  }
}

.hamburger {
  margin: 0px;
  font-size: 31px;
  padding-top: 9px;
  color: white;
  text-decoration-line: none;

  @include breakpoint($desktop) {
    display: none;
  }
}

.footer {
  width: 100%;
  margin: 0 auto;
  display: flex;
  flex-direction: column;
  align-content: center;
  align-items: center;
  justify-content: space-between;
  padding: 10px;
  border-top: 1px solid var(--theme-light);
  background: var(--theme-white);

  @include breakpoint($larger-tablet) {
    flex-flow: row nowrap;
    padding: 10px 104px;
  }
  &__logo {
    margin-right: 24px;
  }

  a {
    color: var(--theme-medium);

    &:hover {
      color: var(--theme-primary);
    }
  }

  &--left {
    display: flex;
    flex-flow: row nowrap;
    align-content: center;
    align-items: center;
  }
}
.pt {
  position: absolute;
  top: -17px;
  width: 100%;
  z-index: 1900;
}
.drawer-header {
  height: calc(var(--header-height) + 1px);
  border-bottom: 1px solid #eee;
  display: flex;
  align-items: center;
  padding: 0.75rem;
}
</style>
