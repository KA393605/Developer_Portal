import Vue, { VNode } from 'vue';
import { sync } from 'vuex-router-sync';
import App from './App.vue';
import router from './router';
import store from './store';
import './register-globals';

sync(store, router);

new Vue({
  router,
  store,
  render: (h): VNode => h(App),
}).$mount('#app');
