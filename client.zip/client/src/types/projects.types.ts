import { BaseUser } from './users.types';

export interface ProjectEnvironment {
  projectEnvironmentId: number;
  environmentId: number;
  environmentName: string;
  statusId: number;
  statusName: string;
  sequenceNumber: number;
}

export interface ProjectEnvironmentConnectedService {
  // serviceId: number;
  // serviceName: string;
  // projectEnvironmentId: number;
  // serviceEnvironmentId: number;
  // versions: ProjectEnvironmentConnectedServiceVersion[];
  serviceId: number;
  serviceName: string;
  serviceDescription?: string;
  statusId: number;
  statusName: string;
  projectEnvironmentId: number;
  serviceEnvironmentId: number;
  environmentName: string;
  upstreamUrl?: string;
  authenticationType: string;
}

export interface ProjectEnvironmentConnectedServiceVersion {
  serviceDescription?: string;
  statusId: number;
  statusName: string;
  version: string;
  environmentName: string;
  upstreamUrl?: string;
  authenticationType: string;
}

export interface ProjectEnvironmentDetails {
  OAuth: {
    clientId: string;
    secret: string;
    callbackUrls: string[];
  };
  basic: {
    ApiKey: string;
  };
  connectedServices: ProjectEnvironmentConnectedService[];
  status: {
    statusName: string;
    statusId: number;
  };
}

export interface EnvMeta {
  meta: {
    loading: boolean;
    error: boolean;
    initial: boolean;
  };
}
export interface ProjectEnvironmentDetails2 {
  auth: ProjectEnvironmentAuth & EnvMeta;
  services: ProjectEnvironmentServices & EnvMeta;
  status: ProjectEnvironmentStatus & EnvMeta;
}

export type ProjectEnvironmentPart =
  | ProjectEnvironmentAuth
  | ProjectEnvironmentStatus
  | ProjectEnvironmentServices;

export interface ProjectEnvironmentServices {
  connectedServices: ProjectEnvironmentConnectedService[];
}

export interface ProjectEnvironmentAuth {
  OAuth: {
    clientId: string;
    secret: string;
    callbackUrls: string[];
  };
  basic: {
    ApiKey: string;
  };
}

export interface ProjectEnvironmentStatus {
  statusName: string;
  statusId: number;
}

export interface PandoraIdLabel {
  label: string;
  value: string;
}

export interface PandoraApiResponse {
  id: string;
  impact: string;
  itAssetOwner: string;
  itAssetOwnerFullName: string;
  name: string;
  urgency: string;
}

export interface Project {
  projectId: number;
  projectName: string;
  createTimestamp: string;
  projectDescription: string;
  statusId: number;
  statusName: string;
  lastUpdateUser: BaseUser;
  publisherUser: BaseUser;
  billableUser: BaseUser;
  environments: ProjectEnvironment[];
  projectUsers: ProjectUser[];
}

type ProjectPicks = 'projectId' | 'projectName' | 'projectDescription' | 'statusId' | 'statusName';
export type ProjectListProject = Pick<Project, ProjectPicks> & { privilegeList: string[] };

export interface Team {
  teamId: string;
}

export interface ProjectUser extends BaseUser {
  roleId: number;
  roleName: string;
}

export interface ProjectPermissions {
  users: ProjectUser[];
  teams?: Team[];
}

export interface PromoteQuery {
  confirm: boolean;
  projectDescription: string;
  businessJustification: string;
  pandoraId: string;
}

export interface CreateProjectRequestBody
  extends Pick<Project, 'projectName' | 'projectDescription'> {
  requestedServiceId?: number;
}

export interface CreateProjectResponseBody extends Pick<Project, 'projectId'> {}
