import {
  PersonEntryItem,
  PersonEntryItemContent
} from '@gsk-platforms/gsk-people-picker/gsk-people-picker-base';

export interface BaseUser {
  firstName?: string | null;
  lastName?: string | null;
  fullName?: string | null;
  mudId: string;
  email: string;
  userId?: number;
  roleId?: number;
  extra?: PersonEntryItemContent;
}

export interface User extends BaseUser {
  roles: Role[];
  userId: number;
  firstName: string | null;
  lastName: string | null;
  fullName: string | null;
}

export interface Role {
  roleId: number;
  roleName: string;
  privileges?: Privilege[];
}

export interface Privilege {
  privilegeId: number;
  privilegeName: string;
  privilegeDescription?: string;
}
