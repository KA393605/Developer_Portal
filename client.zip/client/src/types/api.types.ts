export interface PaginatedResponseBody<T> {
    count: number;
    data: T[];
}

export interface PaginatedResponseBodyProjects<T> {
    projectsCount: number;
    projects: T[];
}

export interface PaginatedListingsResponseBody<T> {
    count: number;
    types: T[];
}

export interface CreateProjectResponseBody<T> {
    projectId: number;
}

export interface PaginatedResponseBodyRpaBots<T> {
    count: number;
    bots: T[];
}

export interface PaginatedResponseBodyRpaBotDependencies<T> {
    count: number;
    dependencies: T[];
}

export interface PaginatedResponseBodyRpaFolders<T> {
    count: number;
    folders: T[];
}

export interface PaginatedResponseBodyBotPromotion<T> {
    addedOrUpdatedFiles: T[];
    skippedFiles: T[];
}

export interface ResponseBodyBotAAEnv<T> {
    status: T;
}
