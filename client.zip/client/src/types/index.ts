import { Snackbar } from '@gsk-platforms/gsk-snackbar/gsk-snackbar';
import { Omit as StrictOmit } from 'ts-essentials';

export interface FilterableRequest<T> {
  filter?: T;
}

export interface PaginatedRequest {
  resultsPerPage: number;
  pageNumber: number;
}

export interface PaginatedFilterableRequest<T> extends PaginatedRequest, FilterableRequest<T> {}

export interface UITab {
  text: string;
  key: string;
  disabled?: boolean;
  component?: string;
}

export interface UINavigationItem extends UITab {
  route: string | import('vue-router').Location;
  props?: Record<string, unknown>;
  exact?: boolean;
  replace?: boolean; // replace route instead of push
}

export type SnackbarOptions = Partial<
  StrictOmit<Snackbar, keyof HTMLElement> & {
    type: 'information' | 'success' | 'warning' | 'error';
  }
> & {
  labelText: string;
};

export type GskRadioGroupOption = Pick<
  import('@gsk-platforms/gsk-radio/gsk-radio').Radio,
  'value'
> &
  Pick<import('@gsk-platforms/gsk-formfield/gsk-formfield').Formfield, 'label'> & {
    disabled?: boolean;
  };
