

export interface enumType {
  id: number;
  name: string;
  mnemonic: string;
  description: string;
  sequenceNumber: number;
}
