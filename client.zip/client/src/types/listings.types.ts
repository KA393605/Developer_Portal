import { BaseUser } from './users.types';
import { FormField } from '@/components/form/form.types';
import { GithubRepo } from '@/types/publishing.types';

export interface Listing {
  listingId?: number | undefined;
  currentVersionId?: number;
  listingVersionId?: number;
  listingTypeId: number;
  listingTypeName?: string;
  listingName: string;
  listingDescription: string;
  hasImage: boolean;
  iconUrl?: string;
  listingTeamName?: string;
  listingTeamIcon?: string;
  isFeaturedFlag?: boolean;
  isBillableFlag?: boolean;
  createTimestamp?: string;
  updateTimestamp?: string;
  publishTimestamp?: string;
  statusName?: string;
  statusId?: number;
  keywordList?: string[];
  owners: BaseUser[];
  versions: ListingVersion[];
  rnk?: number;
  seq_num?: number;
}

export interface DraftListingId {
  listingId: number;
}

export interface GetRegistrationsResponseData {
  resourceName: string;
  registrationId: number;
  resourceDescription: string;
}

export interface GetRegistrationsResponseBody {
  count: number;
  data: GetRegistrationsResponseData[];
}

export interface ListingType {
  listingTypeId: number;
  name: string;
  template: ListingTypeTemplate;
}

export interface ListingUser extends BaseUser {
  roleId: number;
  roleName: string;
}

export interface ListingVersion {
  listingVersionId: number;
  extendedProperties: any;
  createTimestamp: string;
  updateTimestamp: string;
  publishTimestamp: string;
  registrationVersionId: number;
  statusId: number;
}

export interface ListingSection {
  sectionName: string;
  sectionTemplateType: string;
  sectionTemplateTypeId: number;
  sectionContent: string;
  sectionContentUrl?: string;
}

export type ReposListTagsResponseItemContent = string;

export interface FullListing extends Listing {
  publishedBy: BaseUser;
  extendedProperties: ListingExtendedProperties;
  registrationVersionId?: number;
  registrationId?: number;
  listingUsers?: ListingUser[];
}

export type SavedFullListing = FullListing & {
  extendedProperties: ListingExtendedProperties<true>;
  hasImage?: boolean;
};

export interface DraftListing extends Listing {
  listingUsers: ListingUser[];
  extendedProperties: ListingExtendedProperties;
  registrationVersionId?: number;
  registrationId?: number;
  hasImage: boolean;
}

export interface DraftListingModule {
  listingName: string;
  listingDescription: string;
  listingTypeId: number;
  registrationId: number;
  registrationVersionId: number;
  hasImage: boolean;
  extendedProperties: ListingExtendedProperties;
  listingUsers: ListingUser[];
}


export type SavedDetails = Pick<FormField, 'key' | 'value' | 'type'>[];
export interface ListingExtendedProperties<T extends boolean = false> {
  githubRepo: GithubRepo | null;
  image: string;
  keywords: string[];
  documentationSections: DocumentationSection[];
  details: T extends false ? FormField[] : SavedDetails;
}

export type SavedListingModule = DraftListingModule & {
  extendedProperties: ListingExtendedProperties<true>;
};

export interface DraftListingVersion extends DraftListing {
  listingVersionId: number;
}

export interface Listings<T extends SavedListingModule = SavedListingModule> {
  listingTypeId: number;
  listingTypeName: string;
  sequenceNumber: number;
  count: number;
  listings: T[];
}

export interface DocumentationTemplate {
  canLinkContent: boolean;
  canEditContent: boolean;
  maxSections: number;
  canAddSections: boolean;
  defaultSections: DocumentationSection[];
}

export interface DocumentationSection {
  sectionInfo: ListingSection;
  meta: {
    canDelete: boolean;
    canRename: boolean;
    canReorder: boolean;
    canLinkContent: boolean;
    canEditContent: boolean;
  };
}

export interface ListingGithubRepoTemplate {
  required: boolean;
  canLink: boolean;
  repo: GithubRepo | null;
}

export interface ListingTypeTemplate {
  publishing: {
    content: ListingContentTemplate;
    githubRepo: ListingGithubRepoTemplate;
    info: {
      acceptImage: boolean;
    };
    details: {
      isCustomComponent: boolean;
      form: {
        fields: FormField[];
      };
    };
    documentationSections: DocumentationTemplate;
  };
}

interface OptionalHeadingFields {
  heading?: string;
  subheading?: string;
}
export interface ListingContentTemplate {
  details: OptionalHeadingFields & { edit: OptionalHeadingFields };
  productCard: OptionalHeadingFields;
  documentation: OptionalHeadingFields;
}
