export interface Bot {
  path: string;
  size: number;
  lastModifiedBy: string;
  name: string;
  id: string;
  lastModified: string;
  locked: boolean;
  fileLastModified: string;
}

export interface BotDependency {
  path: string;
  name: string;
  exists: boolean;
  id: string;
  productionVersionApplicable: boolean;
  parentId: string;
}

export interface PromoteBot extends Bot {
  gskId: string;
  text: string;
  loading: boolean;
  timestamp: string;
  error: boolean;
  hasBeenPromoted: string;
}

export interface BotData {
  bots: PromoteBot[];
}

export interface BotChild {
  text: string;
  data: BotData;
}

export interface BotTree {
  text: string;
  data: BotData;
  children: BotChild[];
}

export interface FolderExistsObject {
  folderExists: boolean;
  folderIndex: number;
}

export interface ChildFolderExistsObject {
  childExists: boolean;
  childIndex: number;
}

export interface BotNode {
  children: Bot[];
  data: BotData;
  id: string;
  isBatch: boolean;
  isEditing: boolean;
  parent: any;
  showChildren: boolean;
}

export interface UserPermission {
  action: string;
  bu: string;
  canGrant: string[];
  env: string;
  role: string;
}

export interface MudIDSearchResponse {
  content: string;
  id: string;
  link: string;
  reference: string;
  relevance: string;
  source_key: string;
  startIndex: string;
  summary: string;
  title: string;
  updated: string;
}

export interface UserSearchResponse extends MudIDSearchResponse {}

export interface UserSearchResponse {
  EMAIL: string;
  FIRST_NAME: string;
  LAST_NAME: string;
  MUDID: string;
}

export interface CreateUserRequest {
  username: string;
  email: string;
  fname: string;
  lname: string;
  env: string;
  rolesToGrant: string[];
  licenseFeatures: string[];
}

export interface CreateUserResponse {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  licenseFeatures: string[];
  roles: string[];
  username: string;
}

export interface EditUserRequest {
  env: string;
  username: string;
  rolesToGrant: string[];
  rolesToRevoke: string[];
  licenseFeatures: string[];
}

export interface GetUserRolesResponse extends CreateUserResponse {}

export interface FindRolesResponse {
  email: string;
  username: string;
  firstName: string;
  lastName: string;
  licenseFeatures: string[];
  roles: string[];
  id: number;
  env: string;
  userAcctFound?: boolean;
}

export interface UserEnvPermissions {
  permissions: Permission[];
}

export interface Permission {
  action: string;
  bu: string;
  canGrant: string[];
  env: string;
  role: string;
}

export interface PromoteBotRequest {
  ids: string[];
  source: string;
  target: string;
  approvalEvidence: string;
  productionChecklist: string;
  promotionType: number;
}

export interface BotPromoteArtifact {
  addedOrUpdatedFiles: string[];
  skippedFiles: string[];
}

export interface BotFolders {
  folders: string[];
}

export class BotDir {
  public items: any[] = [];
  public subDirs: Map<string, BotDir> = new Map<string, BotDir>();
}

export type BotDirectory = BotDir[];
