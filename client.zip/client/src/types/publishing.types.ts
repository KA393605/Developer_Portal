import { Listing, ReposListTagsResponseItemContent } from './listings.types';
import { Statuses } from '@/constants';
import { BaseUser } from './users.types';

// import {Team} from "./projects.types";

export interface AdminListing extends Listing {
  hasDraft: boolean;
  publishedBy: BaseUser;
  publishedDate: string;
}

export interface ListingType {
  listingTypeId?: number;
  name: string;
  template: object;
}

export interface ListingUser extends BaseUser {
  roleId: number;
  roleName: string;
}

export interface ListingPermissions {
  users: ListingUser[];
}

export interface ServiceVersion {
  serviceVersionID: number;
  serviceName: string;
  serviceDescription: string;
  serviceVersion: string;
}

export interface MyListing {
  statusId: number;
  versions: MyListingVersion[];
  listingId: number;
  statusName: Statuses;
  listingName: string;
  publishDate: string;
  listingTypeId: number;
  registrationId: number;
  keywords: string[];
  updateTimestamp: string;
  currentVersionId: number;
  listingDescription: string;
  listingUsers: ListingUser[];
}

export interface MyListingVersion {
  versionId: number;
  statusName: Statuses;
  publishDate: string;
  updateTimestamp: string;
  listingVersionId: number;
  registrationVersionId: number;
}

export interface RegistrationVersions {
  versionId: number;
  resourceName: string;
  registrationId: number;
  resourceDescription: string;
  registrationVersionId: number;
}

export interface GetRegistrationVersionsResponseBody {
  count: number;
  versions: RegistrationVersions[] | null;
}

export interface PublishingFlowState {
  edit: boolean;
  addVersion: boolean;
}

export interface PublishingMode {
  edit: boolean;
  version: boolean;
}

export interface GithubRepo {
  name: string;
  full_name: string;
  id: number;
  html_url: string;
  description: string;
  language: string;
  stargazers_count: number;
  default_branch: string;
  releaseTags?: ReposListTagsResponseItemContent[];
}

export interface adminRole {
  checked: boolean;
  content: string;
  radioValue: string;
  title: string;
}
