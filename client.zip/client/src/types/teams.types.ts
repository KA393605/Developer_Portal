import { BaseUser } from '@/types/users.types';

interface UserTeamInfo {
  mudId: string;
  roleId: number;
  roleName: string;
  userId: number;
}

export interface Team {
  teamId: number;
  iconUrl: string;
  teamName: string;
  teamMembers: TeamMember[];
  creatorOfTeam: TeamMember;
  currentUserTeamInfo: UserTeamInfo;
  createTimestamp: string;
  teamDescription: string;
  lastMemberToUpdateTeam: TeamMember;
}

export interface TeamMember extends BaseUser {
  roleName?: string;
  createTimestamp?: string;
  updateTimestamp?: string;
}

export interface UpdateTeamMember {
  roleId: number;
  roleName: string;
  mudId: string;
  teamId: number;
}

export interface DeleteTeamMember {
  mudId: string;
  teamId: number;
  teamMembers: TeamMember[];
}

export interface TeamsResponse {
  count: number;
  teams: Team[];
}

export interface CreateTeamRequest {
  teamName: string;
  teamDescription: string;
  iconUrl: string;
  createUserId?: number;
  teamMembers: TeamMember[];
}

export interface UpdateTeamRequest {
  teamId: number;
  teamName: string;
  teamDescription: string;
  iconUrl: string;
  lastUpdateUserId?: number;
  teamMembers: TeamMember[];
}
