<template>
  <div class="circle-container" :class="{ open, expandable }">
    <user-circle v-for="user in list" :key="user.mudId" :user="user" class="circle" />
    <span v-if="showToggle" class="extra" :class="{ open, expandable }" @click="toggle">
      <template v-if="left > 0">+{{ left }}</template>
      <template v-else>
        <strong class="minus">&mdash;</strong>
      </template>
    </span>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import { BaseUser } from '@/types/users.types';
import UserCircle from '@/components/UserCircle.vue';

@Component({
  components: {
    UserCircle,
  },
})
export default class UserList extends Vue {
  @Prop(Array) readonly users!: BaseUser[];
  @Prop(Boolean) readonly truncate!: boolean;
  @Prop(Boolean) readonly expandable!: boolean;
  @Prop({ type: Number, default: 5 }) readonly limit!: number;

  private open = false;

  toggle() {
    if (!this.expandable) {
      return;
    }
    this.open = !this.open;
  }

  get showToggle() {
    if (!this.truncate) {
      return false;
    }

    return this.users.length > this.limit;
  }

  get left(): number {
    return this.users.length - this.list.length;
  }

  get list(): BaseUser[] {
    if (this.truncate) {
      if (this.open) {
        return this.users;
      }

      return this.users.slice(0, this.limit);
    }

    return this.users;
  }
}
</script>

<style scoped lang="scss">
@import '~@/styles/breakpoints.scss';
@import '~@/styles/theme.scss';
.circle-container {
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
  flex-wrap: nowrap;
  &.open {
    flex-wrap: wrap;
  }
}

.circle {
  margin-left: -4px;
}

.expandable {
  cursor: pointer;
}

.extra {
  width: 2rem;
  text-align: right;
  color: $theme-typography;
  &.open {
    text-align: center;
  }
}
</style>
