import { Component, Prop, Vue } from 'vue-property-decorator';
import { ListingTypes } from '@/constants';
import { SavedFullListing } from '@/types/listings.types';

@Component
export default class ListingDetailsMixin extends Vue {
  @Prop({ type: Object, required: true }) public readonly listing!: SavedFullListing;

  public get isMobileComp(): boolean {
    return this.listing.listingTypeId === ListingTypes.MobileComponent;
  }

  public get isWebComp(): boolean {
    return this.listing.listingTypeId === ListingTypes.WebComponent;
  }

  public get icon(): string {
    return `/img/listing-types/${this.listingTypeId}.svg`;
  }

  public get listingTypeId() {
    return this.listing.listingTypeId;
  }

  public get libs(): string {
    if (!this.listing.extendedProperties) {
      return '';
    }
    const deets = this.listing.extendedProperties.details;
    const lib = deets.find(field => field.key === 'library' || field.key === 'framework');
    if (lib) {
      if (Array.isArray(lib.value)) {
        return lib.value.join(', ');
      }
      if (typeof lib.value === 'string') {
        return lib.value;
      }
    }
    return '';
  }
}
