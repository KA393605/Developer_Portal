<template>
  <tr>
    <td>
      <p>{{ team.teamName }}</p>
    </td>
    <td>
      <user-list :users="team.teamMembers" truncate expandable></user-list>
    </td>
    <td v-if="userIsOwner">
      <router-link :to="editLink">
        <gsk-icon-button
          class="icon-button-edit"
          title="edit"
          icon="pencil"
          officon="pencil"
        ></gsk-icon-button>
      </router-link>
      <gsk-icon-button
        class="icon-button"
        title="delete"
        icon="trash"
        officon="trash"
        @click="del(team)"
      ></gsk-icon-button>
    </td>
    <td v-else>
      <router-link :to="teamDetails">
        <gsk-item-item id="team-details">
          View Details
        </gsk-item-item>
      </router-link>
    </td>
  </tr>
</template>

<script lang="ts">
import { Component, Emit, Vue, Prop } from 'vue-property-decorator';
import { RawLocation } from 'vue-router';
import { MyListing } from '@/types/publishing.types';
import GButton from '@/components/gsk-components/GskButton.vue';
import {Roles, RouteNames} from '@/constants';
import UserCircle from '@/components/UserCircle.vue';
import UserList from '@/components/UserList.vue';
import { Team } from '@/types/teams.types';
import { EnumsModule } from '@/store/modules/enums.module';

@Component({
  components: {
    GButton,
    UserCircle,
    UserList,
  },
})
export default class TeamListings extends Vue {
  @Prop(Object) readonly team!: Team;
  private open: boolean = false;

  get teamDetails(): RawLocation {
    return {
      name: RouteNames.TeamDetails,
      params: {
        teamId: this.team.teamId.toString(),
      },
    };
  }

  get userIsOwner(): boolean {
    const { roleId } = this.team.currentUserTeamInfo;
    return roleId === Roles.TeamOwner;
  }

  ownerRoleEnum(mnemonic: string): number {
    const { role } = EnumsModule.enumTypes;
    let mnemonicRoleId = -1;
    role.forEach(r => {
      if (r.mnemonic === mnemonic) {
        mnemonicRoleId = r.id;
      }
    });
    return mnemonicRoleId;
  }

  get editLink(): RawLocation {
    return {
      name: RouteNames.EditTeam,
      params: {
        teamId: this.team.teamId.toString(),
      },
    };
  }

  @Emit('delete')
  del(team: Team) {}

  @Emit('add')
  add(listing: MyListing) {}
}
</script>

<style lang="scss" scoped>
@import '~@/styles/theme.scss';

.icon-button-edit {
  margin-right: 1rem;
}

.version {
  padding-top: 13px;
  padding-bottom: 13px;
}
</style>
