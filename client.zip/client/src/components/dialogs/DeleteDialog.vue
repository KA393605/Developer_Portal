<template>
  <g-dialog
    class="d"
    :open="open"
    :dismisslabel="cancelText"
    :acceptlabel="buttonText"
    :hideactionbuttons.prop="noAction"
    @update:open="update"
    @accept="confirmDelete"
    @cancel="cancel"
  >
    <slot></slot>
  </g-dialog>
</template>

<script lang="ts">
import { Component, Prop, Emit, Vue } from 'vue-property-decorator';
import GDialog from '@/components/gsk-components/GskDialog.vue';
import GButton from '@/components/gsk-components/GskButton.vue';

@Component({
  components: {
    GDialog,
    GButton,
  },
})
export default class DeleteDialog extends Vue {
  @Prop(Boolean) readonly open!: boolean;
  @Prop(Boolean) readonly noAction!: boolean;
  @Prop({ type: String, default: 'Delete' }) readonly buttonText!: string;
  @Prop({ type: String, default: 'Cancel' }) readonly cancelText!: string;

  @Emit('update:open')
  update(isOpen: boolean): boolean {
    return isOpen;
  }

  @Emit('delete')
  confirmDelete() {}

  cancel() {
    this.update(false);
  }
}
</script>

<style scoped lang="scss">
@import '~@/styles/theme.scss';
.d {
  --gsk-theme-primary: #{$theme-danger};
}
</style>
