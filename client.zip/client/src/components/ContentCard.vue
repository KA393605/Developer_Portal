<template>
  <div class="card"><slot /></div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';

@Component
export default class ContentCard extends Vue {}
</script>

<style scoped lang="scss">
@import '~@/styles/theme.scss';
@import '~@/styles/breakpoints.scss';
.card {
  background-color: #ffffff;
  width: 100%;
  max-width: var(--content-max-width);
  &:not(:last-child) {
    margin-bottom: 40px;
  }
  @include breakpoint($small) {
    padding: 2rem;
  }
}
.initialLoading,
.initialError {
  > *:not(.initial-loader) {
    pointer-events: none;
    user-select: none;
  }
}
.initialError {
  height: 200px;
  overflow: hidden;
  background: white;
  &::v-deep {
    .heading {
      margin: 0;
    }
    .initial-loader {
      color: $theme-danger;
      flex-direction: column;
      * {
        color: inherit;
      }
    }
  }
}
</style>
