<template>
  <gsk-list :activeindex="activeIndex" v-bind="containerProps" class="tab-bar">
    <gsk-list-item
      v-for="link in links"
      :key="link.key"
      class="li"
      :class="mergeClasses(link)"
      :disabled.prop="link.disabled"
      :selected.prop="isActiveItem(link)"
      v-bind="getProps(link)"
      @click="handleClick(link)"
      @update:active-link="handleClick(link)"
    >
      <strong v-if="bold">{{ link.text.trim() }}</strong>
      <template v-else>{{ link.text.trim() }}</template>
    </gsk-list-item>
  </gsk-list>
</template>

<script lang="ts">
import { Component, Prop } from 'vue-property-decorator';
import { mixins } from 'vue-class-component';
import NavigationMixin from '@/components/mixins/navigation.mixin';
import { UINavigationItem } from '@/types';

@Component
export default class NavigationList extends mixins(NavigationMixin) {
  @Prop(Boolean) noLine!: boolean;
  @Prop(Boolean) bold!: boolean;

  mergeClasses(link: UINavigationItem) {
    return { ...this.classes(link), noLine: this.noLine, bold: this.bold };
  }
}
</script>

<style scoped lang="scss">
@import '~@/styles/theme.scss';
.li {
  &:not(.noLine) {
    border-left: 2px solid $theme-lighter;
    &:before {
      content: ' ';
      position: absolute;
      top: 0;
      left: -3px;
      background: var(--theme-primary);
      width: 3px;
      height: 100%;
      z-index: 5;
    }
    &.inactive {
      position: relative;
      &:before {
        background: transparent;
      }
    }
    &.active {
      position: relative;
      &:before {
        background: var(--theme-primary);
      }
    }
  }
}
</style>
