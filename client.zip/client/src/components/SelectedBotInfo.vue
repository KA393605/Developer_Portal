<template>
  <div class="selected-bot">
    <table>
      <thead>
        <td class="f-overline">Name</td>
        <td v-if="notProdEnv" class="f-overline">Action</td>
        <td class="f-overline">Client Last Modified</td>
        <td class="f-overline">Last Modified</td>
        <td class="f-overline">Status</td>
      </thead>

      <template v-if="selectedNode !== undefined">
        <tr :class="{ show }" class="selected-bot__task">
          <td class="f-overline">
            <strong>{{ selectedNode.text }}</strong>
          </td>
          <td></td>
          <td></td>
        </tr>
        <tr
          v-for="child in bots"
          :key="child.id"
          :ref="child.id"
          :class="{ show }"
          class="selected-bot__dependency"
          v-bind="$attrs"
        >
          <td>
            <p class="f-body name">{{ child.text }}</p>
          </td>
          <td v-if="notProdEnv">
            <g-button type="text" @click="updateEnv(child)">
              {{ updateText }} to {{ nextEnv }}
            </g-button>
          </td>
          <td>{{ formatDate(child.fileLastModified) }}</td>
          <td>{{ formatDate(child.lastModified) }}</td>
          <gsk-circular-progress
            v-if="child.loading"
            id="loading-promotion"
            mini
          ></gsk-circular-progress>
          <td v-else-if="child.timestamp" id="promote-text">
            <i>Promoted to {{ nextEnv.toUpperCase() }} at {{ child.timestamp }}</i>
          </td>
          <td v-else-if="child.error" class="api-error"><i>Failed to promote</i></td>
          <td v-else-if="child.hasBeenPromoted">
            {{ child.hasBeenPromoted }}
          </td>
        </tr>
      </template>
    </table>
    <g-dialog
      :open.sync="openUploadChecklist"
      :acceptlabel="'Next'"
      :acceptdisabled="hasNoUpload"
      @accept="chooseDependencies"
      @cancel="closeDialog"
    >
      <div class="promotion-type-info">
        <div class="promotion-choice">
          <section class="promotion-title">
            <strong>Promotion Requirements</strong>
            <p>
              Select which type of bot promotion you'd like to complete and upload the required
              files.
            </p>
          </section>
          <div class="promotion-radio-btns">
            <gsk-radio-group
              name="promotionTypes"
              :value.prop="promotionType"
              :values.prop="promotionTypeOptions"
              inline
              @change="updatePromotionType"
            >
              <template v-for="type in promotionTypeOptions">
                <gsk-formfield :key="type" :label="type">
                  <gsk-radio
                    :name="type"
                    :value="type"
                    :checked.prop="isSelectedType(type)"
                  ></gsk-radio>
                </gsk-formfield>
              </template>
            </gsk-radio-group>
          </div>
        </div>
        <div class="upload-files">
          <span class="upload-label">{{ checklistLabel }}</span>
          <gsk-file-upload
            v-if="openUploadChecklist"
            id="production-checklist"
            ref="checklistFile"
            label="checklistLabel"
            placeholder="Drag and drop files or"
            buttontype="filled"
            condensed
            :accept="acceptFiles"
            @change="uploadChecklist"
          ></gsk-file-upload>
          <span class="upload-label">{{ emailLabel }}</span>
          <gsk-file-upload
            v-if="openUploadChecklist"
            id="evidence-email"
            ref="emailFile"
            label="Approval Evidence Email"
            placeholder="Drag and drop files or"
            buttontype="filled"
            condensed
            :accept="acceptEmailFiles"
            @change="uploadEmail"
          ></gsk-file-upload>
        </div>
      </div>
    </g-dialog>
    <g-dialog
      headerlabel="Do you want to promote any dependencies?"
      :open.sync="openSelectDependencies"
      :acceptlabel="'Promote to ' + nextEnv"
      :acceptdisabled="disablePromote"
      @accept="promoteTo(currentEnv, nextEnv)"
      @cancel="closeDialog"
    >
      <gsk-circular-progress v-if="loadingDependencies"></gsk-circular-progress>
      <g-checkbox-group
        v-else
        :key="key"
        v-model="selectedDependencies"
        name="checkboxes"
        :options="checkboxes"
      ></g-checkbox-group>
    </g-dialog>
  </div>
</template>
<script lang="ts">
import { Component, Vue, Prop, Emit, Watch } from 'vue-property-decorator';
import { format } from 'date-fns';
import { FileDetail } from '@gsk-platforms/gsk-file-upload/gsk-file-upload-base';
import { SelectOption } from '@/components/form/form.types';
import * as API from '@/api/rpa-admin.api';
import GCheckboxGroup from '@/components/gsk-components/GskCheckboxGroup.vue';
import GRadioGroup from '@/components/gsk-components/GskRadioGroup.vue';
import GDialog from '@/components/gsk-components/GskDialog.vue';
import { PromoteBot, BotNode } from '@/types/rpa-admin.types';
import GButton from '@/components/gsk-components/GskButton.vue';

interface FileEvent extends CustomEvent {
  detail: {
    value: FileDetail[];
  };
}

@Component({
  components: {
    GCheckboxGroup,
    GDialog,
    GButton,
    GRadioGroup,
  },
})
export default class SelectedBotInfo extends Vue {
  @Prop() readonly show!: boolean;
  @Prop() readonly folders!: string[];
  @Prop() readonly selectedNode!: BotNode;
  public openSelectDependencies: boolean = false;
  public openUploadChecklist: boolean = false;
  public updateText: string = 'Promote';
  public currentEnv: string = 'dev';
  public nextEnv: string = '';
  public loadingDependencies: boolean = false;
  public selectedDependencies: string[] = [];
  public promotionTypeOptions: readonly string[] = ['New Bot', 'Break-Fix', 'Enhancement'];
  public promotionType: string = this.promotionTypeOptions[1];
  public encodedChecklist: string = '';
  public encodedEmail: string = '';
  public uploadChecklistFile: FileDetail[] = [
    {
      name: '',
      size: '',
      fileContent: '',
      showThumbnail: false,
    },
  ];
  public selectedChildBot: PromoteBot = {
    gskId: '',
    text: '',
    loading: false,
    timestamp: '',
    error: false,
    hasBeenPromoted: '',
    path: '',
    size: 0,
    lastModifiedBy: '',
    name: '',
    id: '',
    lastModified: '',
    locked: false,
    fileLastModified: '',
  };

  private checkboxes: SelectOption[] = [
    {
      value: '',
    },
  ];

  public envStructure: Record<string, string> = {
    dev: 'qa',
    qa: 'prod',
    prod: 'qa',
  };

  get notProdEnv(): boolean {
    return this.currentEnv !== 'prod';
  }

  public updatePromotionType(e: CustomEvent) {
    this.promotionType = e.detail.value;
  }

  isSelectedType(promotionType: string) {
    return this.promotionType === promotionType;
  }

  public formatDate(lastModified: string): string {
    return format(new Date(lastModified), 'MM/dd/yyyy');
  }

  public get key(): string {
    return JSON.stringify(this.checkboxes);
  }

  public get disablePromote(): boolean {
    return this.selectedDependencies.length < 1;
  }

  get checklistLabel(): string {
    if (this.promotionType) {
      if (this.promotionType === 'Break-Fix') {
        return `Bot Details (${this.acceptFiles} files only)`;
      } else {
        return `Production Checklist (${this.acceptFiles} files only)`;
      }
    } else {
      return 'Promotion type not selected';
    }
  }

  get emailLabel(): string {
    if (this.promotionType) {
      return 'Approval Evidence Email (.msg, .eml, .emu files only)';
    } else {
      return 'Promotion type not selected';
    }
  }

  get acceptFiles(): string {
    if (this.promotionType) {
      if (this.promotionType === 'Break-Fix') {
        return '.xls, .xlsx';
      } else {
        return '.doc, .docs, .docx';
      }
    } else {
      return '';
    }
  }

  get acceptEmailFiles(): string {
    return '.msg, .eml, .emu';
  }

  uploadChecklist(e: FileEvent) {
    if (e.detail.value[0]) {
      this.uploadChecklistFile = e.detail.value;
      this.encodedChecklist = e.detail.value[0].fileContent.split(',')[1];
    }
  }

  uploadEmail(e: FileEvent) {
    if (e.detail.value[0]) {
      this.encodedEmail = e.detail.value[0].fileContent.split(',')[1];
    } else {
      this.encodedEmail = '';
    }
  }

  public async updateEnv(child: PromoteBot): Promise<void> {
    this.selectedChildBot = child;
    if (this.currentEnv === 'dev') {
      this.chooseDependencies();
    } else {
      this.openUploadChecklist = true;
    }
  }

  get isNoPromotionType(): boolean {
    return this.promotionType.length < 1;
  }

  get isNoEmailUpload(): boolean {
    return this.encodedEmail.length < 1;
  }

  get isNoChecklistUpload(): boolean {
    return this.encodedChecklist.length < 1;
  }

  get hasNoUpload(): boolean {
    return this.isNoPromotionType || this.isNoChecklistUpload || this.isNoEmailUpload;
  }

  closeDialog(): void {
    this.promotionType = this.promotionTypeOptions[1];
    this.encodedChecklist = '';
    this.encodedEmail = '';
  }

  public async chooseDependencies(): Promise<void> {
    this.openSelectDependencies = true;
    this.loadingDependencies = true;
    this.selectedDependencies = [];

    const child = this.selectedChildBot;
    const botDependencies: API.BotDependenciesAPIResponse = (
      await API.getBotDependencies({
        env: this.currentEnv,
        id: child.gskId,
      })
    ).data;

    this.checkboxes = botDependencies.dependencies.map(dependency => {
      return {
        value: dependency.id,
        label: dependency.name,
        extra: dependency,
      };
    });

    this.checkboxes.forEach(dependency => {
      if (
        dependency.value === child.gskId &&
        !this.selectedDependencies.find(dep => dep === child.gskId)
      ) {
        this.selectedDependencies.push(dependency.value);
      }
    });

    this.loadingDependencies = false;
  }

  get bots(): PromoteBot[] {
    if (!this.selectedNode.data) {
      return [];
    }
    return this.selectedNode.data.bots;
  }

  get time(): string {
    return format(new Date(), 'p');
  }

  async promoteTo(source: string, target: string) {
    this.openSelectDependencies = false;

    // Set Bot state to Loading
    this.updateBot(true, false, []);

    await API.updateBotEnvironment({
      ids: this.selectedDependencies,
      source: source,
      target: target,
      approvalEvidence: this.encodedEmail,
      productionChecklist: this.encodedChecklist,
      promotionType: this.promotionTypeId(this.promotionType),
    })
      .then(res => {
        const { skippedFiles } = res.data;
        this.updateBot(false, true, skippedFiles);
      })
      .catch(() => {
        this.updateBot(false, false, []);
      });
  }

  public promotionTypeId(type: string): number {
    if (type === this.promotionTypeOptions[0]) {
      return 1;
    } else if (type === this.promotionTypeOptions[1]) {
      return 2;
    } else {
      return 3;
    }
  }

  @Emit('promoted')
  updateBot(isLoading: boolean, wasPromoted: boolean, skippedFiles: string[]) {
    let skippedFilesMap: Map<string, boolean> = new Map();
    skippedFiles.forEach((path: string) => {
      const pathArr = path.split('\\');
      const len = pathArr.length;
      const file = pathArr[len - 1];
      skippedFilesMap.set(file, true);
    });
    let dependenciesMap: Map<string, boolean> = new Map();
    this.selectedDependencies.forEach(dependency => {
      dependenciesMap.set(dependency, true);
    });
    this.bots.forEach((bot: PromoteBot) => {
      if (dependenciesMap.get(bot.gskId)) {
        if (wasPromoted) {
          if (skippedFilesMap.get(bot.text)) {
            // bot previously promoted message
            bot.hasBeenPromoted = 'File is already available';
          } else {
            bot.timestamp = this.time;
          }
        } else if (!isLoading) {
          bot.error = true;
        }
        bot.loading = !bot.loading;
      }
    });
  }

  @Watch('$route.params', { immediate: true })
  setComponentState() {
    const { env } = this.$route.params;
    this.currentEnv = env;
    this.nextEnv = this.envStructure[this.currentEnv];
  }
}
</script>
<style scoped lang="scss">
@import '~@/styles/theme.scss';

#loading-promotion {
  margin-top: 11px;
  padding-right: 24px;
}

/*#production-checklist[disabled] {*/
/*  opacity: 0.1; !* not sure about exact value *!*/
/*  pointer-events: none;*/
/*}*/

.promotion-type-info {
  padding: 4.5rem 10rem 5rem;
}

.promotion-choice {
  margin-bottom: 2.5rem;
}

.promotion-title {
  margin-bottom: 1.5rem;
  font-size: 1.5rem;
  font-weight: bold;
  line-height: 1.67;
  text-align: center;
}

.promotion-radio-btns {
  margin-bottom: 0.5rem;
}

.upload-label {
  font-size: 16px;
  line-height: 1.5;
  letter-spacing: 0.25px;
  color: #544f40;
}

.f-body.name {
  word-break: break-word;
}

.api-error {
  color: var(--theme-danger);
}

#promote-text {
  color: var(--theme-medium);
}

.selected-bot {
  display: block;

  thead {
    border-bottom: 1px solid var(--theme-lighter);

    td {
      padding: 4px 0;
    }
  }

  &__task {
    display: none;

    &.show {
      display: table-row;
    }
    td {
      font-size: 1rem;
      padding: 24px 0 8px;
    }
  }

  &__dependency {
    &:hover {
      border-radius: 4px;
      td {
        &:first-child {
          border-top-left-radius: 4px;
          border-bottom-left-radius: 4px;
        }
        &:last-child {
          border-top-right-radius: 4px;
          border-bottom-right-radius: 4px;
        }
      }
    }

    td {
      padding: 4px 0;

      .name {
        padding-left: 24px;
      }
    }
  }

  .promote {
    gsk-checkbox-group {
      text-align: left;
    }
  }

  td {
    border: none;

    p {
      margin: 0;
    }
  }
}
</style>
