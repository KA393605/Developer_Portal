<template>
  <span>
    <gsk-icon :id="id" class="icon" :style="{ cursor }">{{ icon }}</gsk-icon>
    <gsk-tooltip :for="id" :text.prop="text" :placement.prop="placement" delay="1"></gsk-tooltip>
  </span>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import { randId } from '@/utils/components';

@Component
export default class HelpTooltip extends Vue {
  @Prop({ type: String, required: true }) text!: string;
  @Prop({ type: String, default: randId() }) id!: string;
  @Prop({ type: String, default: 'info' }) icon!: string;
  @Prop({ type: String, default: 'above' }) placement!: 'above' | 'below' | 'before' | 'after';
  @Prop({ type: String, default: 'help' }) cursor!: string;
}
</script>

<style lang="scss" scoped>
@import '~@/styles/theme.scss';
.icon {
  color: $theme-primary;
  font-size: 16px;
}
</style>
