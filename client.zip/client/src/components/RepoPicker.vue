<template>
  <Promised :promise="p" class="p">
    <template #pending :pending-delay="0">
      <div style="height: 80px;">
        <div class="f-small-title" style="margin-bottom: 8px;">{{ label }}</div>
        <gsk-linear-progress></gsk-linear-progress>
      </div>
    </template>
    <template #rejected>
      <div class="f-small-title" style="margin-bottom: 8px;">{{ label }}</div>
      <div class="error">Error: could not load GitHub repos</div>
    </template>
    <template>
      <template v-if="userNotFound">
        <g-select
          :value="''"
          :label="label"
          v-bind="$attrs"
          placeholder="No Repos Available"
          :options="[]"
          :required="required"
        ></g-select>
        <div class="no-github-user f-body--small">
          You do not have a
          <a :href="noUserLink" target="_blank">
            GSK Enterprise Github
          </a>
          account. See
          <a
            href="https://cbshelp.gsk.com/Pages/Getting-started-with-GitHub-Enterprise.aspx"
            target="_blank"
          >
            this article
          </a>
          for help gaining access.
        </div>
      </template>
      <template v-else>
        <g-select
          v-model="repoId"
          v-bind="$attrs"
          :label="label"
          :options="options"
          :required="required"
        ></g-select>
        <div v-if="!ghOptions.length" class="no-github-user f-body--small">
          You are not an owner or contributor to any public repositories on
          <a :href="noUserLink" target="_blank">
            GSK Enterprise Github
          </a>
        </div>
      </template>
    </template>
  </Promised>
</template>

<script lang="ts">
import { Component, Prop, Vue, Watch } from 'vue-property-decorator';
import get from 'lodash/get';
import { AxiosError } from 'axios';
import { Promised } from 'vue-promised';
import GSelect from '@/components/gsk-components/GskSelect.vue';
import { GithubRepo } from '@/types/publishing.types';
import { SelectOption } from '@/components/form/form.types';
import { getUserGithubRepos } from '@/api/publishing.api';
import { UserModule } from '@/store/modules/user.module';

const EMPTY = '__empty__';
type Opt = SelectOption<GithubRepo | null>;

@Component({
  components: {
    GSelect,
    Promised,
  },
  inheritAttrs: false,
})
export default class RepoPicker extends Vue {
  @Prop({ required: true, validator: prop => prop === null || typeof prop.name === 'string' })
  value!: GithubRepo | null;
  @Prop({ type: String, default: 'Github Repo' }) label!: string;
  @Prop(Boolean) required!: boolean;
  @Prop(Boolean) noneOption!: boolean;

  p: Promise<any> | null = null;
  ghOptions: Opt[] = [];
  repo: GithubRepo | null = this.value ? this.value : null;
  userNotFound: boolean = false;

  get options(): Opt[] {
    if (this.noneOption) {
      const noneOption: Opt = {
        label: 'No Repo',
        value: EMPTY,
        extra: null,
      };

      return [noneOption].concat(this.ghOptions);
    }

    return this.ghOptions || [];
  }

  get repoId(): string {
    if (this.value === null) {
      if (this.noneOption) {
        return EMPTY;
      }
      return '';
    }

    return this.value.id.toString();
  }

  set repoId(id: string) {
    if (id === EMPTY) {
      this.$emit('input', null);
    }
    const r = (this.options.find(o => o.value === id) || { extra: null }).extra || null;
    this.repo = r;
    this.$emit('input', r);
  }

  get noUserLink() {
    return `https://mygithub.gsk.com/${UserModule.user.mudId}`;
  }

  created() {
    this.p = UserModule.userPromise // ensure we have the real mudId
      .then(() => getUserGithubRepos(UserModule.user.mudId))
      // .then(() => getUserGithubRepos('use this one to simulate no user'))
      .then(r =>
        r.data.map(
          (repo): SelectOption<GithubRepo> => ({
            value: repo.id.toString(),
            label: repo.full_name,
            extra: repo,
          }),
        ),
      )
      .then(options => {
        this.ghOptions = options;
      })
      .catch((e: AxiosError) => {
        const code = get(e, 'response.status');
        if (code === 404) {
          this.userNotFound = true;
          this.$emit('nouser');
        } else {
          throw e;
        }
      });
  }
}
</script>

<style scoped lang="scss">
@import '~@/styles/theme.scss';
.p {
  display: block;
  margin-bottom: 2rem;
}

.no-github-user {
  color: $theme-danger;
  padding: 4px;
  margin-top: 4px;
  a {
    color: $theme-dark;
    text-decoration: underline;
  }
}
.error {
  color: $theme-danger;
  padding: 4px;
  margin-top: 4px;
}
</style>
