<template>
  <div class="outer">
    <div class="code-container">
      <code class="code" :class="{ truncate: !overflow, overflow, isHidden }">{{ dots }}</code>
      <span v-if="secret" class="f-text-button" @click="toggle">
        <template v-if="isHidden">
          show
        </template>
        <template v-else>
          hide
        </template>
      </span>
      <gsk-icon
        :id="id"
        v-clipboard:copy="code"
        v-clipboard:success="copySuccess"
        v-clipboard:error="copyError"
        class="copy-button"
        @mouseenter="setDefaultText"
      >
        copy
      </gsk-icon>
      <gsk-tooltip
        ref="tooltip"
        :open.prop="true"
        :text="text"
        :for="id"
        placement="above"
        delay="1"
        gap="24"
      />
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue, Watch } from 'vue-property-decorator';
import { Tooltip } from '@gsk-platforms/gsk-tooltip/gsk-tooltip';
import { RequiredProp, randId } from '@/utils/components';

const COPY = 'Copy';

@Component
export default class CopyCode extends Vue {
  @RequiredProp(String) code!: string;
  @Prop({ type: String, default: 'Copied!' }) successMessage!: string;
  @Prop({ type: String, default: 'Copy failed!' }) failMessage!: string;
  @Prop(Boolean) overflow!: boolean;
  @Prop(Boolean) secret!: boolean;

  private id = randId();
  private hidden: boolean = this.secret;
  private text: string = COPY;

  setDefaultText() {
    this.text = COPY;
  }

  get isHidden() {
    return this.secret ? this.hidden : false;
  }

  toggle() {
    this.hidden = !this.hidden;
    if (this.isHidden) {
      this.$emit('hide');
    } else {
      this.$emit('show');
    }
  }

  showTooltip() {
    const tooltip = this.$refs.tooltip as Tooltip;
    tooltip.show();
  }

  @Watch('secret')
  onSecretChange() {
    this.hidden = this.secret;
  }

  get dots() {
    return this.isHidden ? '******************' : this.code;
  }

  copySuccess() {
    this.text = this.successMessage;
    setTimeout(() => {
      this.showTooltip();
    });
  }

  copyError() {
    this.text = this.failMessage;
    setTimeout(() => {
      this.showTooltip();
    });
  }
}
</script>

<style scoped lang="scss">
@import '~@/styles/theme.scss';
.outer {
  margin-top: 1rem;
  margin-bottom: 1rem;
}

.code-container {
  display: flex;
  align-items: center;
  background: var(--theme-lighter);
  padding-left: 1rem;
  height: 3rem;
  border-radius: 4px;
  width: 100%;
  max-width: 100%;
}
.code {
  flex: 1;
  color: $theme-dark;
  overflow-x: scroll;
  white-space: nowrap;
  font-size: 12px;
}

.truncate {
  white-space: nowrap;
  overflow-x: hidden;
  overflow-y: hidden;
  text-overflow: ellipsis;
}
.overflow {
  margin-right: 0.5rem;
}

.copy-button {
  color: $theme-dark;
  cursor: pointer;
  font-size: 1rem;
  margin: 1rem;
}

.f-text-button {
  color: $theme-dark;
}

.isHidden {
  user-select: none;
}
</style>
