import { customElement, html, property, TemplateResult } from 'lit-element';
import { classMap } from 'lit-html/directives/class-map';
import { Dialog } from '@gsk-platforms/gsk-dialog/gsk-dialog';
import { ripple } from '@gsk-platforms/mwc-ripple/ripple-directive';

@customElement('gsk-two-dialog')
export class ModifiedDialog extends Dialog {
  @property({ type: Boolean })
  public acceptActionDisabled = false;

  protected _renderButton(label: string, action: string): TemplateResult {
    const classes = {
      'mdc-button': true,
      'mdc-dialog__button': true,
    };

    return html`
      <button
        type="button"
        class="${classMap(classes)}"
        data-mdc-dialog-action="${action}"
        ?data-mdc-dialog-default-action="${this.defaultAction === action}"
        ?disabled="${action === 'accept' ? this.acceptActionDisabled : false}"
        .ripple="${ripple({ unbounded: false })}"
      >
        <span class="mdc-button__label">${label}</span>
      </button>
    `;
  }
}
