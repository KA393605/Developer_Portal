<template>
  <div class="flex-center">
    <svg
      xmlns="http://www.w3.org/2000/svg"
      xmlns:xlink="http://www.w3.org/1999/xlink"
      width="26"
      height="26"
      viewBox="0 0 26 26"
      class="user-circle"
    >
      <defs>
        <circle id="a" cx="12" cy="12" r="12" />
      </defs>
      <g fill="none" fill-rule="evenodd" transform="translate(1 1)">
        <mask id="b" fill="#fff">
          <use xlink:href="#a" />
        </mask>
        <use :fill="color" stroke="#FFF" xlink:href="#a" />
        <text
          fill="#FFF"
          font-family="Arial, sans-serif"
          font-size="10"
          letter-spacing="1"
          text-anchor="middle"
          mask="url(#b)"
        >
          <tspan x="12" y="16">{{ initials.toUpperCase() }}</tspan>
        </text>
      </g>
    </svg>
    <gsk-tooltip v-if="showTooltip" :text="tooltipText" :placement="tooltipPlacement" />
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import { BaseUser } from '@/types/users.types';
import { RequiredProp } from '@/utils/components';

@Component
export default class UserCircle extends Vue {
  @RequiredProp(Object) readonly user!: BaseUser;
  @Prop({ type: String, default: 'below' }) readonly tooltipPlacement!:
    | 'below'
    | 'after'
    | 'before'
    | 'above';

  @Prop(Boolean) readonly disableTooltip!: boolean;

  get colors() {
    return ['#40488d', '#e49b13', '#bc1077', '#f36633', '#008a00'];
  }

  get color() {
    const { mudId } = this.user;
    if (mudId === undefined) return;

    let hash = 0;
    if (mudId.length == 0) {
      return this.colors[0];
    }
    for (let i = 0; i < mudId.length; i++) {
      hash = (hash << 5) - hash + mudId.charCodeAt(i);
      hash = hash & hash;
    }

    return this.colors[Math.abs(hash % this.colors.length)];
  }

  get initials(): string {
    const user = this.user;
    let { firstName, lastName } = user;
    if (user.fullName) {
      const names = user.fullName.split(/\s+/);
      firstName = names[0];
      lastName = names[1];
      if (firstName && lastName) {
        return firstName[0] + lastName[0];
      }
      return user.fullName[0];
    }

    if (user.firstName && user.lastName) {
      return user.firstName[0] + user.lastName[0];
    }
    if (user.firstName) {
      return user.firstName[0];
    }
    if (user.lastName) {
      return user.lastName[0];
    }

    return '?';
  }

  get showTooltip(): boolean {
    return !!this.tooltipText && !this.disableTooltip;
  }

  get tooltipText() {
    const user = this.user;
    const name = user.fullName || `${user.firstName} ${user.lastName}`;
    const email = user.email;
    return `${name} (${email})`;
  }
}
</script>

<style lang="scss" scoped>
gsk-tooltip {
  --gsk-theme-tooltip-max-width: 200px;
  --gsk-theme-secondary: var(--theme-darker);
  --gsk-theme-on-secondary: var(--theme-white);
}
.user-circle {
  cursor: default;
  user-select: none;
}
</style>
