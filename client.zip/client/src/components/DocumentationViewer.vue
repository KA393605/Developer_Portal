<template>
  <Promised :promise="compiledMarkdown">
    <template #pending>
      <gsk-circular-progress class="margin" />
    </template>
    <template v-slot="data">
      <div class="gsk-markdown margin" @click.capture="handleMarkdownClick" v-html="data"></div>
    </template>
    <template #rejected>
      <div class="no-docs margin">
        <h3>Documentation Not Found</h3>
        <img src="@/assets/uh-oh.png" />
        <router-link :to="home">
          <h6>Return to Help Home Page</h6>
        </router-link>
      </div>
    </template>
  </Promised>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import { Promised } from 'vue-promised';
import fm from 'front-matter';
import * as API from '@/api/github.api';
import { createDocument, marked, proxyGithubImages, setVideoAttributes } from '@/utils/markdown';
import { HELP_REPO_BRANCH, HELP_REPO_NAME, HELP_REPO_OWNER } from '@/constants/help.constants';

interface DocAttributes {
  title?: string;
}

@Component({
  components: {
    Promised,
  },
})
export default class HelpDocumentationViewer extends Vue {
  @Prop({ type: String, required: true })
  home!: string;

  get compiledMarkdown(): Promise<string> {
    const owner = HELP_REPO_OWNER;
    const name = HELP_REPO_NAME;
    const file = this.$route.path;
    const args: Parameters<typeof API.getRepoFileContents> = [owner, name, file, HELP_REPO_BRANCH];
    return API.getRepoFileContents(...args)
      .then(r => r.data)
      .then(md => {
        const res = fm<DocAttributes>(md);
        if (res.attributes.title) {
          this.$emit('update:title', res.attributes.title);
        }
        return res.body;
      })
      .then(md => marked(md))
      .then(html => {
        return proxyGithubImages(
          setVideoAttributes(createDocument(html)),
          owner,
          name,
          file,
          HELP_REPO_BRANCH,
        ).body.innerHTML;
      });
  }

  handleMarkdownClick(e: MouseEvent) {
    if (e.target) {
      const a = e.target as HTMLAnchorElement;
      if (a.tagName === 'A') {
        const link = a.getAttribute('href') || '';
        if (!/^http/.test(link)) {
          e.preventDefault();
          this.$router.push(link).then(() => {
            this.$emit('link', this.$route.path);
          });
        }
      }
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/markdown.scss';
@import '~@/styles/breakpoints.scss';
.no-docs {
  text-align: center;
  img {
    width: 500px;
    max-width: 90%;
  }
}
.margin {
  margin: 2rem auto 5rem;
  padding-left: 2rem;
  padding-right: 2rem;

  &:not(gsk-circular-progress) {
    max-width: var(--content-max-width);
  }

  @include breakpoint(1600px) {
    margin: 5rem auto;
    padding-left: 0;
    padding-right: 0;
  }
}
</style>
