<template>
  <a :href="encodedLink" class="f-overline" target="_blank">
    <gsk-icon class="icon">{{ icon }}</gsk-icon>
  </a>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import { HELP_ROOT_PATH } from '@/constants/help.constants';

@Component
export default class HelpLink extends Vue {
  @Prop({ type: String, default: '' }) docPath!: string;
  @Prop({ type: String, default: 'question' }) icon!: string;

  get encodedLink() {
    return encodeURI(`/${HELP_ROOT_PATH}${this.docPath}`);
  }
}
</script>
