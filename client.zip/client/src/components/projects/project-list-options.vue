<template>
  <div class="options gsk-layout-grid__cell--span-12">
    <g-textfield
      class="options__search"
      type="text"
      label="Search projects"
      value
      icon
      placeholder
      outlined
      @input="onSearch"
    ></g-textfield>

    <!--    <gsk-icon-->
    <!--      :class="{ 'is-selected': listMode === 'list' }"-->
    <!--      class="options__mode options__mode&#45;&#45;list"-->
    <!--      @click="onModeChange('list')"-->
    <!--      >gsk-menu</gsk-icon-->
    <!--    >-->
    <!--    <img-->
    <!--      src="~@/assets/squares-grid.svg"-->
    <!--      alt="projects icon"-->
    <!--      :class="{ 'is-selected': listMode === 'cards' }"-->
    <!--      class="options__mode options__mode&#45;&#45;cards"-->
    <!--      @click="onModeChange('cards')"-->
    <!--    />-->
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

interface Textfield extends EventTarget {
  value: string;
}

@Component({})
export default class ProjectListOptions extends Vue {
  @Prop()
  protected listMode!: string;

  protected onModeChange(mode: string) {
    this.$emit('onModeChange', mode);
  }

  protected onSearch(e: Event) {
    if (e.target !== null) {
      this.$emit('onSearch', (e.target as Textfield).value);
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/theme.scss';
.options {
  padding-top: 30px;
  padding-left: 12px;

  &__search {
    max-width: 50%;
  }
  &__mode {
    margin-left: 20px;
    cursor: pointer;

    &.is-selected {
      color: var(--gsk-theme-primary);
    }
  }
}
</style>
