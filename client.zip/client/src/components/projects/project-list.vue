<template>
  <max-width>
    <div class="button-container">
      <router-link :to="newProjectLink" class="button">
        <g-analytics v-slot="{ sendClick }" :click-data="newProjectAnalytics">
          <gsk-fab
            class="button"
            icon="plus"
            primary
            extended
            label="New Project"
            @click="sendClick"
          />
        </g-analytics>
      </router-link>
    </div>
    <div class="projects__container">
      <router-link
        v-for="project in projects"
        :key="project.projectId"
        class="flex-center projects__card-container"
        :to="projectLink(project)"
      >
        <project-card :project-detail="project" class="projects__card" />
      </router-link>
    </div>
  </max-width>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import { Location } from 'vue-router';
import ProjectCard from '@/components/ProjectCard.vue';
import { Project } from '@/types/projects.types';
import MaxWidth from '@/components/MaxWidth.vue';
import GButton from '@/components/gsk-components/GskButton.vue';
import { addAnalyticsRouteParams, ClickData } from '@/analytics';
import { RouteNames } from '@/constants';
import GAnalytics from '@/components/GAnalytics';

@Component({
  components: {
    ProjectCard,
    MaxWidth,
    GButton,
    GAnalytics,
  },
})
export default class ProjectList extends Vue {
  @Prop()
  protected projects!: Project[];

  get newProjectAnalytics(): ClickData {
    return {
      clickTarget: 'project-list-new-project-button',
    };
  }

  get newProjectLink(): Location {
    return {
      name: RouteNames.NewProject,
    };
  }

  projectLink(project: Project): import('vue-router').Location {
    return {
      name: 'project-details',
      params: addAnalyticsRouteParams(
        { id: project.projectId.toString() },
        {
          projectName: project.projectName,
        },
      ),
    };
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/breakpoints.scss';
@import '~@/styles/theme.scss';

.button-container {
  width: 100%;
  text-align: right;

  .button {
    position: relative;
    margin: 0;
    top: -0.9rem;
  }
}

.projects__container {
  padding-top: 1.5rem;
  display: flex;
  flex-wrap: wrap;
  flex-direction: row;
  align-items: stretch;
  justify-content: center;
  @include breakpoint($medium) {
    justify-content: flex-start;
    padding-top: 5.5rem;
    margin-right: -2rem;
  }
}
.projects__card-container {
  margin-right: 0rem;
  margin-bottom: 2rem;
  max-width: 100%;
  @include breakpoint($small) {
    margin-right: 2rem;
    margin-bottom: 2rem;
  }
}

.projects__card {
  width: 280px;
  max-width: 100%;
}
</style>
