<template>
  <div class="max-width__container" :class="{ isForm, fullScreen }" :style="containerStyles">
    <div class="max-width__content" :class="{ isForm }" :style="contentStyles">
      <slot></slot>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component
export default class MaxWidth extends Vue {
  @Prop(Boolean) readonly isForm!: boolean;
  @Prop(Boolean) readonly fullScreen!: boolean;
  @Prop({ type: String, default: '' }) readonly contentPadding!: string;
  @Prop({ type: String, default: '' }) readonly contentBackgroundColor!: string;
  @Prop({ type: Object, default: () => ({}) }) readonly contentStyle!: Record<
    string,
    string | number
  >;

  @Prop({ type: String, default: '' }) readonly containerBackgroundColor!: string;
  @Prop({ type: Object, default: () => ({}) }) readonly containerStyle!: Record<
    string,
    string | number
  >;

  get containerStyles() {
    const out = { ...this.containerStyle };
    if (this.containerBackgroundColor) {
      out.backgroundColor = this.containerBackgroundColor;
    }
    return out;
  }
  get contentStyles() {
    const out = { ...this.contentStyle };
    if (this.contentBackgroundColor) {
      out.backgroundColor = this.contentBackgroundColor;
    }
    if (this.contentPadding) {
      out.padding = this.contentPadding;
    }
    return out;
  }
}
</script>

<style scoped lang="scss">
@import '~@/styles/breakpoints.scss';
@import '~@/styles/theme.scss';

$default-padding: 2rem;
.max-width__container {
  width: 100%;
}

.max-width__content {
  &:not(.isForm) {
    padding-left: $default-padding;
    padding-right: $default-padding;
    @include maxWidth();
    @include breakpoint($content-max-width + $default-padding * 2) {
      padding-left: 0;
      padding-right: 0;
    }
  }
  &.isForm {
    padding-left: $default-padding;
    padding-right: $default-padding;
    @include maxWidthForm();
    @include breakpoint($form-max-width + $default-padding * 2) {
      padding-left: 0;
      padding-right: 0;
    }
  }
}
</style>
