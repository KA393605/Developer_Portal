<template>
  <gsk-people-picker
    class="tf"
    :apitoken.prop="token"
    :choices.prop="derivedUsers"
    :value.prop="usersValue"
    :apiurl="apiUrl"
    :valid.prop="valid"
    v-bind="$attrs"
    @change.self="onChange"
  />
</template>
<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import { Choice } from '@gsk-platforms/gsk-people-picker/gsk-people-picker-base';
import { BaseUser } from '@/types/users.types';
import { UserModule } from '@/store/modules/user.module';

interface PeoplePickerEvent extends CustomEvent {
  detail: {
    value: string;
    selectedChoices: Choice[];
  };
}
@Component({
  inheritAttrs: false,
})
export default class GPeoplePicker extends Vue {
  @Prop(Array) readonly value!: BaseUser[];
  @Prop(Boolean) readonly valid!: boolean;
  get apiUrl(): string {
    const { hostname } = location;
    if (/^localhost|^dev\./.test(hostname)) {
      return 'https://dev.api.gsk.com/tools/search/query';
    } else if (/^uat\./.test(hostname)) {
      return 'https://qa.api.gsk.com/tools/search/query';
    }
    return 'https://api.gsk.com/tools/search/query';
  }
  get token(): string {
    return UserModule.user.accessToken;
  }
  get derivedUsers(): Choice[] {
    return this.value.map(
      (user): Choice => {
        return {
          value: user.mudId,
          label: `${user.firstName} ${user.lastName}`,
          entry: {
            // eslint-disable-next-line @typescript-eslint/camelcase
            source_key: '',
            title: '',
            link: '',
            id: '',
            reference: '',
            updated: '',
            summary: '',
            relevance: '',
            startIndex: '',
            content: {
              EMAIL: user.extra?.EMAIL ?? user.email,
              FIRST_NAME: user.extra?.FIRST_NAME ?? user.firstName ?? '',
              LAST_NAME: user.extra?.LAST_NAME ?? user.lastName ?? '',
              MUDID: user.mudId,
              PICTUREURL: user.extra?.PICTUREURL ?? '',
              JOBTITLE: user.extra?.JOBTITLE ?? '',
              LOCATION: user.extra?.LOCATION ?? '',
            },
          },
        };
      },
    );
  }
  get usersValue() {
    return this.value.map((user: BaseUser) => user.mudId).join(',');
  }
  onChange(e: PeoplePickerEvent) {
    const sc = e.detail.selectedChoices;
    if (!sc) {
      return;
    }
    const people = sc.map(
      (person: Choice): BaseUser => {
        return {
          firstName: person.entry.content.FIRST_NAME,
          lastName: person.entry.content.LAST_NAME,
          fullName: `${person.entry.content.FIRST_NAME} ${person.entry.content.LAST_NAME}`,
          mudId: person.entry.content.MUDID,
          email: person.entry.content.EMAIL,
          extra: person.entry.content,
        };
      },
    );
    this.$emit('input', people);
    return people;
  }
}
</script>
<style scoped lang="scss">
@import '~@/styles/theme.scss';
.tf {
  --gsk-theme-primary: #{$theme-primary};
  --gsk-text-field-ink-color: #{$theme-typography};
  --gsk-text-field-outline-color: #{$theme-typography};
  font-size: 12px;
}
</style>
