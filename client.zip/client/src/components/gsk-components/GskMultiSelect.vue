<template>
  <gsk-select
    :key="key"
    ref="select"
    multiple
    :float-label.prop="false"
    :label="labelAttr"
    :required.prop="required"
    class="tf"
    @change="onChange"
  >
    <gsk-menu>
      <gsk-list>
        <gsk-list-item
          v-for="option in formattedOptions"
          :key="option.key"
          :disabled="option.disabled"
          :value="option.value"
        >
          {{ optionText(option) }}
          <gsk-checkbox slot="graphic" :checked.prop="optionChecked(option)"></gsk-checkbox>
        </gsk-list-item>
      </gsk-list>
    </gsk-menu>
  </gsk-select>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import { isSelectOptions, SelectOption } from '@/components/form/form.types';
import { RequiredProp } from '@/utils/components';

interface SelectCustomEvent extends CustomEvent {
  detail: {
    selectedIndex: number[];
    value: string[]; // this string is useless
  };
}

@Component({})
export default class GskMultiSelect extends Vue {
  @RequiredProp(Array) readonly value!: string[];
  @Prop(String) readonly label!: string;
  @Prop(String) readonly placeholder!: string;
  @Prop(Boolean) readonly required!: boolean;
  @Prop(Array) readonly options!: SelectOption[] | string[];

  get key() {
    return JSON.stringify(this.options);
  }

  get labelAttr() {
    if (!this.label) {
      return '';
    }
    let l = this.label;
    if (this.required && !l.endsWith('*')) {
      // the required star was removed from component but is still in our designs
      l += '*';
    }
    return l;
  }

  get formattedOptions(): SelectOption[] {
    if (!isSelectOptions(this.options)) {
      return this.options.map(option => {
        return {
          key: option,
          value: option,
          label: option,
          disabled: false,
        };
      });
    }

    return this.options.map(option => {
      const out = { ...option };
      if (!out.key) {
        out.key = out.value;
      }
      if (!out.label) {
        out.label = out.value;
      }
      return out;
    });
  }

  onChange(e: SelectCustomEvent) {
    // unwanted change event is emitted sometimes
    if (!e.detail.selectedIndex) {
      return;
    }
    const v = e.detail.selectedIndex.map(i => this.formattedOptions[i].value);
    this.$emit('input', v);
  }

  optionText(option: SelectOption): string {
    if (typeof option.label === 'string') {
      return option.label;
    } else {
      return option.value;
    }
  }

  optionChecked(option: SelectOption): boolean {
    return !!this.value.find(v => v === option.value);
  }
}
</script>

<style scoped lang="scss">
@import '~@/styles/theme.scss';
.tf {
  --gsk-theme-primary: #{$theme-primary};
  --gsk-text-field-ink-color: #{$theme-typography};
  --gsk-text-field-outline-color: #{$theme-typography};
  --gsk-label-text-transform: uppercase;
  font-size: 14px;
  margin-top: 8px;
  width: 100%;
  --gsk-theme-secondary: #{$theme-darker};
  --gsk-theme-on-secondary: #{$theme-white};
}
</style>
