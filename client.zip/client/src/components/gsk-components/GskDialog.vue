<template>
  <gsk-two-dialog ref="dialog" class="gsk-dialog" v-on="dialogEventHandlers">
    <slot></slot>
    <div class="width-hack"></div>
    <slot slot="footer"></slot>
  </gsk-two-dialog>
</template>

<script lang="ts">
import { Component, Prop, Emit, Watch, Vue } from 'vue-property-decorator';
import { Dialog } from '@gsk-platforms/gsk-dialog/gsk-dialog';

// interface Dialog extends Record<string, unknown>, HTMLElement {
//   open: () => void;
//   close: () => void;
//   updateComplete: Promise<boolean>;
// }

interface DialogEvent extends CustomEvent {
  detail: {
    action?: 'cancel' | 'accept' | 'close';
  };
}

@Component
export default class GDialog extends Vue {
  @Prop(Boolean) readonly open!: boolean;
  @Prop(Boolean) readonly centerContent!: boolean;
  @Prop(Boolean) readonly hideHeader!: boolean;

  get dialogEventHandlers() {
    return {
      closed: (e: DialogEvent) => this.handleMdcEvent(false, e),
      opened: (e: DialogEvent) => this.handleMdcEvent(true, e),
    };
  }

  @Watch('open', { immediate: true })
  handleOpen(isOpen: boolean) {
    this.handleDialog(isOpen);
  }

  dialogEl(): Dialog {
    return this.$refs.dialog as Dialog;
  }

  handleDialog(isOpen: boolean) {
    if (!this.dialogEl()) {
      return;
    }
    this.dialogEl().updateComplete.then(() => {
      if (isOpen) {
        this.dialogEl().open();
      } else {
        this.dialogEl().close();
      }
    });
  }

  @Emit('update:open')
  handleMdcEvent(isOpen: boolean, e: DialogEvent): boolean {
    if (!isOpen && e.detail && e.detail.action) {
      if (e.detail.action === 'accept') {
        this.$emit('accept');
      } else {
        this.$emit('cancel');
      }
    }
    return isOpen;
  }
}
</script>

<style scoped lang="scss">
@import '~@/styles/theme.scss';
$margin: 88px;
$h-padding: 24px;
$v-padding: 20px;

.heading-element {
  margin-top: 0;
  margin-bottom: 0;
}

.gsk-dialog {
  --gsk-theme-surface: #{$theme-white};
  &::v-deep gsk-textfield {
    --gsk-theme-surface: #{$theme-lighter};
  }
  /*--gsk-dialog-max-width: 856px; // taken from zeplin*/
  color: $theme-typography;

  > .gsk-dialog__header {
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    color: $theme-typography;
    h3 {
      margin-top: 0;
      margin-right: $margin - $h-padding;
      margin-left: $margin - $h-padding;
      margin-bottom: 1rem;
    }
  }

  .gsk-dialog__close {
    align-self: flex-end;
    img {
      margin-right: -$h-padding;
      user-select: none;
      cursor: pointer;
    }
  }

  > .gsk-dialog__footer {
    margin-bottom: $margin;
    margin-top: $margin / 2 - $v-padding;
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  > .gsk-dialog__content {
    &.centerContent {
      text-align: center;
    }
    color: $theme-typography;
    > *:first-child {
      margin-top: 0;
      padding-top: 0;
    }
    margin-right: $margin - $h-padding;
    margin-left: $margin - $h-padding;
    overflow-x: hidden;
  }
}
.width-hack {
  width: 500px;
  max-width: calc(100vw - 5rem);
}
</style>
