<template>
  <div class="tf">
    <label :for="id" class="f-small-title label">{{ labelAttr }}</label>
    <gsk-file-upload
      :id="id"
      ref="file"
      :label="label"
      v-bind="$attrs"
      @change="input"
    ></gsk-file-upload>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue, Watch } from 'vue-property-decorator';
import FileUpload from '@gsk-platforms/gsk-file-upload/gsk-file-upload';
import { FileDetail } from '@gsk-platforms/gsk-file-upload/gsk-file-upload-base';
import { randId, RequiredProp } from '@/utils/components';

interface FileEvent extends CustomEvent {
  detail: {
    value: FileDetail[];
  };
}

@Component({
  inheritAttrs: false,
})
export default class GImageUpload extends Vue {
  @RequiredProp(Array) readonly value!: string[];
  @Prop({ type: String, default: 'Upload File' }) readonly label!: string;
  @Prop(Boolean) readonly required!: boolean;

  private id: string = randId();

  @Watch('value', { immediate: true })
  onInput() {
    let f = this.$refs.file as FileUpload;
    if (f) {
      f.updateComplete.then(() => {
        f.value = this.fileDetails;
      });
    } else {
      Vue.nextTick(() => {
        f = this.$refs.file as FileUpload;
        f.updateComplete.then(() => {
          f.value = this.fileDetails;
        });
      });
    }
  }

  get labelAttr() {
    let l = this.label;
    if (!l) {
      return '';
    }
    if (this.required && !l.endsWith('*')) {
      l += '*';
    }
    return l;
  }

  get fileDetails(): FileDetail[] {
    return this.value.map(
      (v: string): FileDetail => ({
        fileContent: v,
        showThumbnail: true,
        name: 'Image',
        size: '',
      }),
    );
  }

  input(e: FileEvent) {
    this.$emit(
      'input',
      e.detail.value.map(f => f.fileContent),
    );
  }
}
</script>

<style scoped lang="scss">
@import '~@/styles/theme.scss';

.tf {
  --gsk-theme-primary: #{$theme-medium};
  --gsk-theme-secondary: #{$theme-medium};
  font-size: 14px;
}

.label {
  display: block;
  padding-bottom: 1rem;
}
</style>
