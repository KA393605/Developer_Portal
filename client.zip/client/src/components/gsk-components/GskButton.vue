<template>
  <gsk-button
    class="b nowrap"
    :class="{ danger }"
    v-bind="props"
    :disabled="disabled"
    v-on="$listeners"
  >
    <slot />
  </gsk-button>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import { Button } from '@gsk-platforms/gsk-button/gsk-button';

@Component
export default class GButton extends Vue {
  @Prop(Boolean) readonly danger!: boolean;
  @Prop(Boolean) readonly disabled!: boolean;
  @Prop({ type: String, default: 'flat' })
  readonly type!: 'flat' | 'text' | 'outlined';

  get props(): Partial<Button> {
    if (this.type === 'flat') {
      return {
        unelevated: true,
        raised: true,
      };
    } else if (this.type === 'outlined') {
      return {
        outlined: true,
        unelevated: false,
        raised: false,
      };
    }
    return {};
  }
}
</script>

<style scoped lang="scss">
@import '~@/styles/typography.scss';
@import '~@/styles/theme.scss';
.hide {
  display: none;
}
.b {
  @extend .gsk-typography--button;
  display: inline-block;
  font-size: 12px;
  --gsk-theme-font-family: Arial, sans-serif;
  --gsk-theme-on-primary: #fff;
  --gsk-theme-primary: #{$theme-primary};

  &.danger {
    --gsk-theme-primary: #{$theme-danger};
  }
}
</style>
