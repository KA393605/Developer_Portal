<template>
  <gsk-autocomplete
    ref="ac"
    v-bind="$attrs"
    :floatlabel="false"
    outlined
    borderradius="2"
    class="tf"
    :async.prop="async"
    :choices.prop="choices"
    :get-choices.prop="getChoices"
    :required.prop="required"
    :value.prop="v"
    @change="input"
  ></gsk-autocomplete>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import { AutocompleteBase } from '@gsk-platforms/gsk-autocomplete/gsk-autocomplete-base';

interface AutocompleteEvent extends CustomEvent {
  detail: {
    selectedChoices?: { label: string; value: any }[];
    selectedChoice?: { label: string; value: any };
    value: string;
  };
}

@Component({
  inheritAttrs: false,
})
export default class GAutocomplete extends Vue {
  @Prop(Object) readonly value!: undefined | { label: string; value: string };
  @Prop(Array) readonly choices!: AutocompleteBase['choices'];
  @Prop({ type: Function, required: true }) readonly getChoices!: AutocompleteBase['getChoices'];
  @Prop(Boolean) readonly required!: boolean;
  @Prop(Boolean) readonly async!: boolean;

  get v() {
    return this.value ? this.value.value : '';
  }

  async mounted() {
    if (this.v) {
      Vue.nextTick(async () => {
        const ac = this.$refs.ac as AutocompleteBase;
        ac.choices = this.choices;
        await ac.updateComplete;
        ac.value = this.v;
        // @ts-ignore // needed in order to make initial value work for some reason
        ac.inputValue = this.v;
      });
    }
  }

  input(e: AutocompleteEvent) {
    const keys = new Set(Object.keys(e.detail));
    if (keys.has('selectedChoice')) {
      this.$emit('input', e.detail.selectedChoice);
    } else if (keys.has('selectedChoices')) {
      this.$emit('input', e.detail.selectedChoices?.[0]);
    }
  }
}
</script>

<style scoped lang="scss">
@import '~@/styles/theme.scss';
.tf {
  --gsk-theme-primary: #{$theme-primary};
  --gsk-text-field-ink-color: #{$theme-dark};
  --gsk-text-field-outline-color: #{$theme-dark};
  --gsk-text-field-font-size: 14px;
  font-size: 14px;
  --gsk-theme-secondary: #{$theme-darker};
  --gsk-theme-on-secondary: #{$theme-white};
}
.hide-helper-text {
  --gsk-textfield-helper-display: none;
}
</style>
