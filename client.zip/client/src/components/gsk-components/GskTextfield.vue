<template>
  <gsk-textfield
    v-bind="$attrs"
    :floatlabel="false"
    :value="value"
    :label="label"
    :class="computedClasses"
    :valid.prop="valid"
    :required.prop="required"
    :helpertextcontent="helperTextContent"
    outlined
    borderradius="2"
    @input="input"
  />
</template>

<script lang="ts">
import { Component, Prop, Emit, Vue } from 'vue-property-decorator';
import { TextField } from '@gsk-platforms/gsk-textfield/gsk-textfield';

@Component({
  inheritAttrs: false,
})
export default class GTextfield extends Vue {
  @Prop({ required: true, type: String }) readonly value!: string;
  @Prop(String) readonly helperTextContent!: string | undefined;
  @Prop({ type: String, default: '' }) readonly label!: string;
  @Prop(Boolean) readonly valid!: boolean;
  @Prop(Boolean) readonly required!: boolean;

  get computedClasses() {
    return {
      'hide-helper-text': typeof this.helperTextContent === 'undefined' && !this.$attrs.maxlength,
      tf: true,
    };
  }

  @Emit()
  input(e: Event): string {
    if (e.target !== null) {
      return (e.target as TextField).value;
    }

    return '';
  }
}
</script>

<style scoped lang="scss">
@import '~@/styles/theme.scss';
.tf {
  --gsk-theme-primary: #{$theme-primary};
  --gsk-text-field-ink-color: #{$theme-dark};
  --gsk-text-field-outline-color: #{$theme-dark};
  --gsk-text-field-font-size: 14px;
  --gsk-theme-secondary: #{$theme-darker};
  --gsk-theme-on-secondary: #{$theme-white};
  --gsk-theme-tooltip-max-width: 185px;
  font-size: 14px;
}
.hide-helper-text {
  --gsk-textfield-helper-display: none;
}
</style>
