<template>
  <gsk-radio-group
    :id="name"
    :key="key"
    :name="name"
    :value="value"
    :values="[value]"
    class="r-group"
    :class="{ inline }"
    :inline="inline"
    @change="input"
  >
    <template v-for="option in formattedOptions">
      <gsk-formfield :key="option.key" :label="option.label" class="formfield">
        <gsk-radio
          :name="name"
          :value="option.key"
          :disabled="option.disabled"
          :checked="isChecked(option)"
        ></gsk-radio>
      </gsk-formfield>
    </template>
  </gsk-radio-group>
</template>

<script lang="ts">
import { Component, Vue, Prop } from 'vue-property-decorator';
import { RequiredProp } from '@/utils/components';
import { isSelectOptions, SelectValue, SelectOption } from '@/components/form/form.types';

@Component
export default class GRadioGroup extends Vue {
  @RequiredProp(String) readonly value!: SelectValue;
  @RequiredProp(Array) readonly options!: SelectOption[] | string[];
  @RequiredProp(String) readonly name!: string;
  @Prop(Boolean) readonly inline!: boolean;

  isChecked(option: SelectOption) {
    return option.value === this.value;
  }

  /**
   * workaround for not being able to add options after render
   */
  get key() {
    return JSON.stringify(this.options);
  }

  get formattedOptions(): SelectOption[] {
    if (!isSelectOptions(this.options)) {
      return this.options.map(option => {
        return {
          key: option,
          value: option,
          label: option,
          disabled: false,
        };
      });
    }

    return this.options.map(option => {
      const out = { ...option };
      if (!out.key) {
        out.key = out.value;
      }
      if (!out.label) {
        out.label = out.value;
      }
      return out;
    });
  }

  // currently gsk-radio-group emits 3 "change" events...
  input(e: CustomEvent): void {
    if (e.detail === undefined) {
      // skip the native event that does not have e.detail set
      return;
    }
    let {
      detail: { value },
    } = e;
    if (Array.isArray(value)) {
      value = value[0];
    }
    const opt = this.formattedOptions.find(option => value === option.value);
    if (opt === undefined) {
      const err = new Error(
        'GRadioGroup.options does not contain the value emitted from the radio group',
      );
      this.$log('error', this.options, e.detail);
      throw err;
    }

    this.$emit('input', opt.value);
  }

  created() {
    const opt = this.formattedOptions.find(option => this.value === option.value);
    if (opt === undefined) {
      if (this.formattedOptions.length) {
        this.$emit('input', this.formattedOptions[0].value);
      }
    }
  }
}
</script>

<style scoped lang="scss">
@import '~@/styles/theme.scss';
.r-group {
  --gsk-theme-primary: #{$theme-primary};
  --gsk-formfield-font-size: 14px;
  &.inline {
    .formfield:not(:first-child) {
      margin-left: 1rem;
    }
  }
}
</style>
