<template>
  <gsk-select
    :key="key"
    ref="select"
    :float-label.prop="false"
    :label="labelAttr"
    v-bind="$attrs"
    :required.prop="required"
    :value="nativeValue"
    class="tf"
    @change="handleChange"
  >
    <select>
      <option disabled value="">{{ placeholder || 'Select' }}</option>
      <option
        v-for="option in formattedOptions"
        :key="option.key"
        :value="option.value"
        :disabled="option.disabled"
      >
        {{ optionText(option) }}
      </option>
    </select>
  </gsk-select>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import { isSelectOptions, SelectOption } from '@/components/form/form.types';

@Component({
  inheritAttrs: false,
})
export default class GSelect extends Vue {
  @Prop(String) readonly id!: string;
  @Prop(String) readonly name!: string;
  @Prop([String, Number]) readonly value!: string | number;
  @Prop(String) readonly label!: string;
  @Prop(String) readonly placeholder!: string;
  @Prop(Boolean) readonly required!: boolean;
  @Prop(Array) readonly options!: SelectOption[] | string[];

  get nativeValue(): string {
    return this.value.toString();
  }

  handleChange(e: Event) {
    if (e.target !== null) {
      this.$emit('input', (e.target as HTMLInputElement).value);
    }
  }

  /**
   * workaround for not being able to add options after render
   */
  get key() {
    return JSON.stringify([...this.options]);
  }

  get labelAttr() {
    if (!this.label) {
      return '';
    }
    let l = this.label;
    if (this.required && !l.endsWith('*')) {
      // the required star was removed from component but is still in our designs
      l += '*';
    }
    return l;
  }

  get formattedOptions(): SelectOption[] {
    if (!isSelectOptions(this.options)) {
      return this.options.map(option => {
        return {
          key: option,
          value: option,
          label: option,
          disabled: false,
        };
      });
    }

    return this.options.map(option => {
      const out = { ...option };
      if (!out.key) {
        out.key = out.value;
      }
      if (!out.label) {
        out.label = out.value;
      }
      return out;
    });
  }

  optionText(option: SelectOption): string {
    if (typeof option.label === 'string') {
      return option.label;
    } else {
      return option.value;
    }
  }
}
</script>

<style scoped lang="scss">
@import '~@/styles/theme.scss';
.tf {
  --gsk-theme-primary: #{$theme-primary};
  --gsk-text-field-ink-color: #{$theme-typography};
  --gsk-text-field-outline-color: #{$theme-typography};
  font-size: 14px;
  margin-top: 8px;
  width: 100%;

  --gsk-theme-secondary: #{$theme-darker};
  --gsk-theme-on-secondary: #{$theme-white};
}
</style>
