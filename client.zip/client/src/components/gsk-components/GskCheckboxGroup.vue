<template>
  <gsk-checkbox-group
    :id="name"
    :key="key"
    :name="name"
    :value="value.value"
    :values="value.value"
    class="r-group"
    :class="{ inline }"
    :inline="inline"
    @change="input"
  >
    <template v-for="option in formattedOptions">
      <gsk-formfield :key="option.value" :label="option.label" class="formfield">
        <gsk-checkbox
          :name="name"
          :value="option.value"
          :disabled="option.disabled"
          :checked="isChecked(option)"
        />
      </gsk-formfield>
    </template>
  </gsk-checkbox-group>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import { DeepReadonly } from 'ts-essentials';
import { RequiredProp } from '@/utils/components';
import { isSelectOptions, SelectOption } from '@/components/form/form.types';

@Component
export default class GCheckboxGroup extends Vue {
  @RequiredProp(Array) readonly value!: DeepReadonly<SelectOption['value'][]>;
  @RequiredProp(Array) readonly options!: SelectOption[] | string[];
  @RequiredProp(String) readonly name!: string;
  @Prop(Boolean) readonly inline!: boolean;

  isChecked(option: { value: string }) {
    return this.value.includes(option.value);
  }

  /**
   * workaround for not being able to add options after render
   */
  get key() {
    return JSON.stringify(this.options);
  }

  get formattedOptions(): SelectOption[] {
    if (!isSelectOptions(this.options)) {
      return this.options.map(option => {
        return {
          key: option,
          value: option,
          label: option,
          disabled: false,
        };
      });
    }

    return this.options.map(option => {
      const out = { ...option };
      if (!out.key) {
        out.key = out.value;
      }
      if (!out.label) {
        out.label = out.value;
      }
      return out;
    });
  }

  // currently gsk-radio-group emits 3 "change" events...
  input(e: CustomEvent): void {
    if (e.detail === undefined) {
      // skip the native event that does not have e.detail set
      return;
    }
    let value: string | string[] = e.detail.value;
    if (typeof value === 'string') {
      this.$emit('input', value.split(','));
    } else {
      this.$emit('input', value);
    }
  }
}
</script>

<style scoped lang="scss">
@import '~@/styles/theme.scss';
.r-group {
  --gsk-theme-primary: #{$theme-primary};
  --gsk-formfield-font-size: 14px;
  &.inline {
    .formfield:not(:first-child) {
      margin-left: 1rem;
    }
  }
}
</style>
