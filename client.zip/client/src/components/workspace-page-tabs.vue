<template>
  <div class="workspace-page-tabs">
    <div class="workspace-page-tabs__tab-bar">
      <gsk-tab-bar>
        <!-- eslint-disable vue/attribute-hyphenation -->
        <gsk-tab
          v-for="(button, index) in buttons"
          id="index"
          :key="index"
          class="workspace-page-tabs__buttons"
          minWidth
          @click="handleClick(button)"
        >
          {{ button }}
        </gsk-tab>
      </gsk-tab-bar>
    </div>
    <div class="workspace-page-tabs__content">
      <slot name="content"></slot>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop } from 'vue-property-decorator';
import { slugify } from '@/utils/routing';

@Component({
  components: {},
})
export default class WorkspacePageTabs extends Vue {
  @Prop()
  protected buttons!: string[];

  public buttonClicked = this.buttons[0];

  handleClick(button: string) {
    let currentViewId = slugify(this.buttonClicked);
    let currentEl = document.getElementById(currentViewId);

    const buttonId = slugify(button);
    const el = document.getElementById(buttonId);

    currentEl!.style.display = 'none'; // eslint-disable-line @typescript-eslint/no-non-null-assertion
    el!.style.display = 'block'; // eslint-disable-line @typescript-eslint/no-non-null-assertion
    this.buttonClicked = button;
    currentEl = el;
  }
}
</script>

<style lang="scss" scoped>
.workspace-page-tabs {
  gsk-tab-bar {
    max-width: 400px;
  }
}
</style>
