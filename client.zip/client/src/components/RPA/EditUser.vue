<template>
  <full-screen-form
    class="listing-permissions"
    title="Back"
    :closed="modalClosed"
    @close="$emit('close')"
    @back="$emit('close')"
  >
    <div class="settings">
      <h5 class="settings__heading">Edit {{ userToEdit.firstName }}'s roles</h5>
      <div class="settings__input">
        <template>
          <div class="roles-select">
            <p>
              <strong>Select Roles</strong>
            </p>
            <p>
              Select one or more roles for this user in the
              <b>{{ env.toUpperCase() }}</b>
              environment
            </p>
            <gsk-checkbox-group
              v-model="givenRoles"
              :options="rolesUserCanGrant"
              name="qaOrProdRoles"
            ></gsk-checkbox-group>
            <p v-if="rolesUserCanGrant.length === 0">
              <i class="no-grant">Uh oh, you can't grant roles on this environment</i>
            </p>
          </div>
          <div class="license-form">
            <p>
              <strong>Allocate a Device License to this User?</strong>
            </p>
            <p class="form-info-license">
              Device licenses are only applicable if the user does not have the "Admin" or "BotFarm
              admin" role. A device, or Client UI, cannot connect to the Control Room until the user
              that logs into it has a device license.
              <strong>
                If you change from a Bot runner license to a Bot creator license, any schedules
                associated with this username will be deleted.
              </strong>
            </p>
            <div class="license-info">
              <gsk-radio-group
                v-model="selectedLicense"
                :options="deviceLicenses"
                name="deviceLicenses"
              ></gsk-radio-group>
              <section class="info-section">
                <span class="info-subject">
                  <strong>{{ selectedLicense }}</strong>
                </span>
                <p>
                  {{ licenseInfo }}
                </p>
              </section>
            </div>
          </div>
          <div class="settings__create_button">
            <g-button
              class="create-user-btn"
              :disabled="canNotEdit"
              unelevated
              @click="updateUserRoles"
            >
              Save
            </g-button>
          </div>
        </template>
      </div>
    </div>
  </full-screen-form>
</template>
<script lang="ts">
import { Component, Vue, Prop } from 'vue-property-decorator';
import FullScreenForm from '@/components/FullScreenForm.vue';
import GButton from '@/components/gsk-components/GskButton.vue';
import GPeoplePicker from '@/components/gsk-components/GskPeoplePicker.vue';
import GTextfield from '@/components/gsk-components/GskTextfield.vue';
import GSelect from '@/components/gsk-components/GskSelect.vue';
import GskRadioGroup from '@/components/gsk-components/GskRadioGroup.vue';
import { openSnackbar } from '@/utils/components';
import { SelectOption } from '@/components/form/form.types';
import { RpaModule } from '@/store/modules/rpa.module';
import GskCheckboxGroup from '@/components/gsk-components/GskCheckboxGroup.vue';
import * as API from '@/api/rpa-admin.api';
import { EditUserRequest, FindRolesResponse, UserSearchResponse } from '@/types/rpa-admin.types';

@Component({
  components: {
    GskRadioGroup,
    GskCheckboxGroup,
    FullScreenForm,
    GButton,
    GPeoplePicker,
    GTextfield,
    GSelect,
  },
})
export default class EditUser extends Vue {
  @Prop({ required: true, type: Array }) readonly envOptions!: SelectOption[];
  @Prop({ required: true, type: String }) readonly env!: string;
  @Prop({ required: true, type: Object }) readonly userToEdit!: FindRolesResponse;
  public enteredMudId: string = '';
  public selectedRole: string = '';
  public givenRoles: string[] = this.userToEdit.roles;
  public selectedLicense: string = this.initialLicense;
  public userToCreate: UserSearchResponse[] = [];
  private modalClosed: boolean = false;

  async updateUserRoles(): Promise<void> {
    const { username } = this.userToEdit;
    const editUserRequest: EditUserRequest = {
      env: this.env,
      username,
      rolesToGrant: this.givenRoles,
      rolesToRevoke: this.revokedRoles,
      licenseFeatures: this.assignedLicense,
    };
    await API.updateUserRoles(editUserRequest)
      .then(() => {
        openSnackbar.call(this, 'User Permissions Updated');
      })
      .catch(err => {
        openSnackbar.call(this, err, { type: 'error' });
      })
      .finally(() => {
        this.modalClosed = true;
      });
  }

  cancelCreateUser(): void {
    this.enteredMudId = '';
    this.userToCreate = [];
    this.givenRoles = [];
    this.selectedRole = '';
  }

  get apiUrl(): string {
    const { hostname } = location;
    if (/^localhost|^uat\.|^dev\./.test(hostname)) {
      return 'https://qa.api.gsk.com/tools/search/query';
    }
    return 'https://api.gsk.com/tools/search/query';
  }

  get rolesUserCanGrant(): SelectOption[] {
    return RpaModule.rolesUserCanGrant[this.env];
  }

  get mappedUserRoles(): SelectOption[] {
    return this.userToEdit.roles.map(role => {
      return {
        value: role,
      };
    });
  }

  get canNotEdit(): boolean {
    return false;
  }

  get rolesCanGrantMapped(): string[] {
    return this.rolesUserCanGrant.map(role => {
      return role.value;
    });
  }

  get revokedRoles(): string[] {
    return this.rolesCanGrantMapped.filter(role => {
      return !this.givenRoles.includes(role) && this.userToEdit.roles.includes(role);
    });
  }

  get assignedLicense(): string[] {
    if (this.selectedLicense.endsWith('Creator')) {
      return ['DEVELOPMENT'];
    } else if (this.selectedLicense.endsWith('Runner')) {
      return ['RUNTIME'];
    } else {
      return [];
    }
  }

  get deviceLicenses(): SelectOption[] {
    return [
      { value: 'None' },
      { value: 'Bot Creator' },
      { value: 'Unattended Bot Runner' },
      { value: 'Attended Bot Runner' },
    ];
  }

  get initialLicense(): string {
    if (this.userToEdit.licenseFeatures.length > 0) {
      const { licenseFeatures } = this.userToEdit;
      if (licenseFeatures[0] === 'DEVELOPMENT') {
        return 'Bot Creator';
      } else {
        return 'Unattended Bot Runner';
      }
    } else {
      return 'None';
    }
  }

  get licenseInfo(): string {
    if (this.selectedLicense === 'None') {
      return 'This user will have access to the control room only';
    } else if (this.selectedLicense === 'Bot Creator') {
      return 'Requires a development license, which enables the user AND run Task Bots.';
    } else if (this.selectedLicense === 'Unattended Bot Runner') {
      return (
        'Requires a Run-time license, which enables the user only to run Task Bots. ' +
        'Auto Login is enabled with this license.'
      );
    } else {
      return 'You cannot run or schedule a bot with this license. Auto Login is not enabled.';
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~@/styles/form-modal.scss';
@import '@/styles/theme.scss';

.select-roles {
  /*margin-top: 4rem;*/
  width: 360px;
}

.no-grant {
  color: var(--theme-danger);
}

.license-form {
  padding-top: 46px;
}

#email-textField {
  margin-left: 31px;
}

.check-mudid {
  display: flex;
  flex-direction: row;
  align-items: baseline;
}

.lin-progress {
  width: 269px;
  padding: 0 1px;
}

.check-directory-btn {
  margin-left: 31px;
}

.form-info {
  font-size: small;
  width: 388px;
}

.license-info {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
}

.info-section {
  max-width: 252px;
  margin-top: 20px;
}

.info-subject {
  color: var(--theme-darker);
}

.form-info-license {
  font-size: small;
  width: 720px;
}

.user-textfield {
  width: 320px;
}

.roles-select {
  /*padding-top: 38px;*/
}

.new-user-info {
  display: flex;
  padding-top: 47px;
}

.create-user-btn {
  margin-left: 16px;
}

.bot-console__search-box {
  display: inline-block;
  min-width: 269px;
}

.settings__create_button {
  margin-top: 2rem;
  /*text-align: center;*/
  margin-bottom: 2rem;
}

.listing-permissions {
  height: 100vh;
  width: 100vw;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  position: absolute;
  z-index: 5;
  background: var(--theme-white);
}

.settings__heading {
  text-align: left;
  margin-bottom: 0;
}
.settings {
  /*max-width: 410px;*/
}
.settings__input > p {
  margin-bottom: 40px;
}
</style>
