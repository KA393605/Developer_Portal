<template>
  <full-screen-form
    class="listing-permissions"
    title="Back"
    :closed="modalClosed"
    @close="$emit('close')"
    @back="$emit('close')"
  >
    <div class="settings">
      <h5 class="settings__heading">Create a User</h5>
      <div class="settings__input">
        <p class="f-body--small form-info">
          All users have access to the Control Room. To give the user further permissions, allocate
          the appropriate license below
          <b>(users with Admin role cannot have a license).</b>
        </p>
        <div class="check-mudid">
          <div class="select-acct">
            <g-textfield
              :key="mudIdKey"
              v-model="enteredMudId"
              label="Username"
              class="bot-console__search-box"
              :placeholder="mudIdPlaceholder"
              @keyup.enter.native="validateUserId"
            ></g-textfield>
            <gsk-formfield
              v-if="!checkedDir || userNotInDirectory"
              label="Check if you are searching for a functional account"
            >
              <gsk-checkbox
                :checked="isFuncAcct"
                name="funcAcct"
                value="1"
                @change="setFuncAcctStatus"
              ></gsk-checkbox>
            </gsk-formfield>
          </div>
          <g-button
            class="check-directory-btn"
            :disabled="disableSearchBtn"
            @click="validateUserId"
          >
            Check active directory
          </g-button>
        </div>
        <template v-if="isCheckingDirectory">
          <gsk-circular-progress class="lin-progress"></gsk-circular-progress>
        </template>
        <template v-else-if="userNotInDirectory">
          <p>
            <i class="no-grant">A user with this mudId does not exist in the Active Directory</i>
          </p>
        </template>
        <template v-else-if="userExistsInActiveDirectory">
          <div class="new-user-info">
            <g-textfield
              v-model="usersFullName"
              class="user-textfield"
              label="Name"
              disabled
            ></g-textfield>
            <g-textfield
              id="email-textField"
              v-model="usersEmail"
              class="user-textfield"
              label="Email"
              :disabled="needsManualInput"
              required
            ></g-textfield>
          </div>
          <div class="roles-select">
            <p>
              <strong>Select Roles</strong>
            </p>
            <p>Select one or more roles for this user.</p>
            <g-select
              v-model="selectedEnv"
              class="select-roles"
              label="Select Environment"
              :options="envOptions"
            ></g-select>
            <gsk-radio-group
              v-if="onDevEnv"
              v-model="selectedRole"
              :options="rolesUserCanGrant"
              name="devRoles"
            ></gsk-radio-group>
            <gsk-checkbox-group
              v-else
              v-model="givenRoles"
              :options="rolesUserCanGrant"
              name="qaOrProdRoles"
            ></gsk-checkbox-group>
            <p v-if="!rolesUserCanGrant.length">
              <i class="no-grant">Uh oh, you can't grant roles on this environment</i>
            </p>
          </div>
          <div v-if="rolesUserCanGrant.length" class="license-form">
            <p>
              <strong>Allocate a Device License to this User?</strong>
            </p>
            <p class="form-info-license">
              Device licenses are only applicable if the user does not have the "Admin" or "BotFarm
              admin" role. A device, or Client UI, cannot connect to the Control Room until the user
              that logs into it has a device license.
              <strong>
                If you change from a Bot runner license to a Bot creator license, any schedules
                associated with this username will be deleted.
              </strong>
            </p>
            <div class="license-info">
              <gsk-radio-group
                v-model="selectedLicense"
                :options="deviceLicenses"
                name="deviceLicenses"
              ></gsk-radio-group>
              <section class="info-section">
                <span class="info-subject">
                  <strong>{{ selectedLicense }}</strong>
                </span>
                <p>
                  {{ licenseInfo }}
                </p>
              </section>
            </div>
          </div>
          <div class="settings__create_button">
            <g-button unelevated @click="cancelCreateUser">Cancel</g-button>
            <g-button
              class="create-user-btn"
              :disabled="canNotCreate"
              unelevated
              @click="createNewUser"
            >
              Create
            </g-button>
          </div>
        </template>
      </div>
    </div>
  </full-screen-form>
</template>
<script lang="ts">
import { Component, Vue, Watch, Prop } from 'vue-property-decorator';
import { Checkbox } from '@gsk-platforms/gsk-checkbox/gsk-checkbox';
import FullScreenForm from '@/components/FullScreenForm.vue';
import GButton from '@/components/gsk-components/GskButton.vue';
import GPeoplePicker from '@/components/gsk-components/GskPeoplePicker.vue';
import GTextfield from '@/components/gsk-components/GskTextfield.vue';
import GSelect from '@/components/gsk-components/GskSelect.vue';
import GskRadioGroup from '@/components/gsk-components/GskRadioGroup.vue';
import { openSnackbar } from '@/utils/components';
import { SelectOption } from '@/components/form/form.types';
import { RpaModule } from '@/store/modules/rpa.module';
import GskCheckboxGroup from '@/components/gsk-components/GskCheckboxGroup.vue';
import * as API from '@/api/rpa-admin.api';
import { CreateUserRequest, UserSearchResponse } from '@/types/rpa-admin.types';

@Component({
  components: {
    GskRadioGroup,
    GskCheckboxGroup,
    FullScreenForm,
    GButton,
    GPeoplePicker,
    GTextfield,
    GSelect,
  },
})
export default class CreateNewUser extends Vue {
  @Prop({ required: true, type: Array }) readonly envOptions!: SelectOption[];
  @Prop({ required: true, type: String }) readonly env!: string;
  public enteredMudId: string = '';
  public mudIdPlaceholder: string = 'Enter MudID';
  public selectedEnv: string = this.env;
  public selectedRole: string = '';
  public givenRoles: string[] = [];
  public selectedLicense: string = '';
  public userToCreate: UserSearchResponse[] = [];
  public isCheckingDirectory: boolean = false;
  public checkedDir: boolean = false;
  public serverError: boolean = false;
  public showErrorMessage: boolean = false;
  public isFuncAcct: boolean = false;
  public funcAcctToCreate: CreateUserRequest = {
    username: '',
    email: '',
    fname: '',
    lname: '',
    env: '',
    rolesToGrant: [],
    licenseFeatures: [],
  };
  private modalClosed: boolean = false;
  public mudIdKey: number = 0;

  async createNewUser(): Promise<void> {
    if (this.isFuncAcct) {
      this.createFuncAcctUser().finally(() => (this.modalClosed = true));
    } else {
      this.createNewUserWithMudId().finally(() => (this.modalClosed = true));
    }
  }

  async createNewUserWithMudId(): Promise<void> {
    const newUserRequest = this.createUserRequest;
    await API.createNewUser(newUserRequest)
      .then(() => {
        openSnackbar.call(this, 'New User Created!');
      })
      .catch(err => {
        openSnackbar.call(this, err.message, { type: 'error' });
      });
  }

  async createFuncAcctUser(): Promise<void> {
    const newUserRequest = this.createUserRequest;
    await API.createNewUser(newUserRequest)
      .then(() => {
        openSnackbar.call(this, 'New User Created');
      })
      .catch(err => {
        openSnackbar.call(this, err, { type: 'error' });
      });
  }

  get createUserRequest(): CreateUserRequest {
    if (this.isFuncAcct) {
      const { fname, username } = this.funcAcctToCreate;
      return {
        username,
        email: this.usersEmail,
        fname,
        lname: fname,
        env: this.selectedEnv,
        rolesToGrant: this.assignedRoles,
        licenseFeatures: this.assignedLicense,
      };
    } else {
      return {
        username: this.enteredMudId,
        email: this.usersEmail,
        fname: this.userToCreate[0].FIRST_NAME,
        lname: this.userToCreate[0].LAST_NAME,
        env: this.selectedEnv,
        rolesToGrant: this.assignedRoles,
        licenseFeatures: this.assignedLicense,
      };
    }
  }

  cancelCreateUser(): void {
    this.selectedRole = '';
    this.checkedDir = false;
    this.givenRoles = [];
    if (this.isFuncAcct) {
      this.funcAcctToCreate['username'] = '';
      this.funcAcctToCreate['fname'] = '';
    } else {
      this.userToCreate = [];
    }
    this.enteredMudId = '';
    this.mudIdKey += 1;
  }

  async validateUserId(): Promise<void> {
    this.isCheckingDirectory = true;
    this.showErrorMessage = false;
    if (this.isFuncAcct) {
      await this.validateFuncAcct();
    } else {
      await this.validateMudId();
    }
  }

  async validateFuncAcct(): Promise<void> {
    await API.validateFunctionalAcct(this.enteredMudId)
      .then(res => {
        const { UserId, DisplayName } = res.UserWS;
        this.funcAcctToCreate['username'] = UserId._text;
        this.funcAcctToCreate['fname'] = DisplayName._text;
      })
      .catch(err => {
        this.showErrorMessage = true;
        if (err.status === 500) {
          this.serverError = true;
        } else {
          throw new Error();
        }
      })
      .finally(() => {
        this.isCheckingDirectory = false;
        this.checkedDir = true;
      });
  }

  async validateMudId(): Promise<void> {
    await API.validateUserMudId(this.enteredMudId, this.apiUrl)
      .then(res => {
        this.userToCreate = res;
      })
      .catch(err => {
        this.showErrorMessage = true;
        throw new Error(err);
      })
      .finally(() => {
        this.isCheckingDirectory = false;
        this.checkedDir = true;
      });
  }

  setFuncAcctStatus(e: Event): void {
    if (e.target) {
      this.isFuncAcct = (e.target as Checkbox).checked;
    }
  }

  get userExistsInActiveDirectory(): boolean {
    return this.isFuncAcct ? !!this.funcAcctToCreate.fname : this.userToCreate.length > 0;
  }

  get usersFullName(): string {
    if (this.isFuncAcct) {
      return this.funcAcctToCreate.fname;
    } else {
      const { FIRST_NAME, LAST_NAME } = this.userToCreate[0];
      return FIRST_NAME + ' ' + LAST_NAME;
    }
  }

  get usersEmail(): string {
    if (this.isFuncAcct) {
      return '';
    } else {
      const { EMAIL } = this.userToCreate[0];
      return EMAIL;
    }
  }

  get needsManualInput(): boolean {
    return !this.isFuncAcct;
  }

  get disableSearchBtn(): boolean {
    return this.notValidMudId || this.userExistsInActiveDirectory;
  }

  get userNotInDirectory(): boolean {
    return this.isFuncAcct ? this.notInVsed : this.notInDir;
  }

  get notInDir(): boolean {
    return this.checkedDir && !this.userExistsInActiveDirectory;
  }

  get notInVsed(): boolean {
    return this.checkedDir && !this.funcAcctToCreate.fname;
  }

  @Watch('selectedEnv')
  clearEnvChoices() {
    this.selectedRole = '';
    this.givenRoles = [];
  }

  get apiUrl(): string {
    const { hostname } = location;
    if (/^localhost|^uat\.|^dev\./.test(hostname)) {
      return 'https://qa.api.gsk.com/tools/search/query';
    }
    return 'https://api.gsk.com/tools/search/query';
  }

  get notValidMudId(): boolean {
    return !this.enteredMudId;
  }

  get canNotCreate(): boolean {
    return !this.userExistsInActiveDirectory || !this.hasUserGivenRoles;
  }

  get hasUserGivenRoles(): boolean {
    if (this.selectedEnv === 'dev') {
      return !!this.selectedRole;
    } else {
      return this.givenRoles.length > 0;
    }
  }

  get rolesUserCanGrant(): SelectOption[] {
    return RpaModule.rolesUserCanGrant[this.selectedEnv];
  }

  get onDevEnv(): boolean {
    return this.selectedEnv === 'dev';
  }

  get assignedRoles(): string[] {
    if (this.selectedEnv === 'dev') {
      return [this.selectedRole];
    } else {
      return this.givenRoles;
    }
  }

  get assignedLicense(): string[] {
    if (this.selectedLicense.endsWith('Creator')) {
      return ['DEVELOPMENT'];
    } else if (this.selectedLicense.endsWith('Runner')) {
      return ['RUNTIME'];
    } else {
      return [];
    }
  }

  get deviceLicenses(): SelectOption[] {
    return [
      { value: 'None' },
      { value: 'Bot Creator' },
      { value: 'Unattended Bot Runner' },
      { value: 'Attended Bot Runner' },
    ];
  }

  get licenseInfo(): string {
    if (this.selectedLicense === 'None') {
      return 'This user will have access to the control room only';
    } else if (this.selectedLicense === 'Bot Creator') {
      return 'Requires a development license, which enables the user AND run Task Bots.';
    } else if (this.selectedLicense === 'Unattended Bot Runner') {
      return (
        'Requires a Run-time license, which enables the user only to run Task Bots ' +
        '(not to create them) Auto Login is always enabled with this license.'
      );
    } else {
      return '';
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~@/styles/form-modal.scss';
@import '@/styles/theme.scss';

.select-roles {
  /*margin-top: 4rem;*/
  width: 360px;
}

.no-grant {
  color: var(--theme-danger);
}

.license-form {
  padding-top: 46px;
}

#email-textField {
  margin-left: 31px;
}

.select-acct {
  display: grid;
}

.check-mudid {
  display: flex;
  flex-direction: row;
  align-items: baseline;
}

.lin-progress {
  width: 269px;
  padding: 0 1px;
}

.check-directory-btn {
  margin-left: 31px;
}

.form-info {
  font-size: small;
  width: 388px;
}

.license-info {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
}

.info-section {
  max-width: 252px;
  margin-top: 20px;
}

.info-subject {
  color: var(--theme-darker);
}

.form-info-license {
  font-size: small;
  width: 720px;
}

.user-textfield {
  width: 320px;
}

.roles-select {
  padding-top: 38px;
}

.new-user-info {
  display: flex;
  padding-top: 47px;
}

.create-user-btn {
  margin-left: 16px;
}

.bot-console__search-box {
  display: inline-block;
  min-width: 269px;
}

.settings__create_button {
  margin-top: 2rem;
  /*text-align: center;*/
  margin-bottom: 2rem;
}

.listing-permissions {
  height: 100vh;
  width: 100vw;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  position: absolute;
  z-index: 5;
  background: var(--theme-white);
}

.settings__heading {
  text-align: left;
  margin-bottom: 0;
}
.settings {
  /*max-width: 410px;*/
}
.settings__input > p {
  margin-bottom: 40px;
}
</style>
