<template>
  <div class="gsk-tabs">
    <div class="gsk-tabs__tab-bar">
      <gsk-tab-bar :key="key" :activeindex="activeIndex" v-bind="containerProps" class="tab-bar">
        <gsk-tab
          v-for="link in links"
          :key="link.key"
          :ref="link.key"
          class="gsk-tabs__buttons"
          :class="{ isDisabled: link.disabled }"
          :disabled="link.disabled"
          v-bind="getProps(link)"
          @click="handleClick(link)"
          @update:active-link="handleClick(link)"
        >
          {{ link.text.trim() }}
        </gsk-tab>
      </gsk-tab-bar>
    </div>
  </div>
</template>

<script lang="ts">
import { Component } from 'vue-property-decorator';
import { mixins } from 'vue-class-component';
import NavigationMixin from './mixins/navigation.mixin';

@Component
export default class NavigationTabs extends mixins(NavigationMixin) {}
</script>

<style scoped lang="scss">
@import '~@/styles/theme.scss';

.tab-bar {
  --gsk-theme-primary: #{$theme-primary};
  --gsk-theme-tab-indicator-thickness: 4px;

  .gsk-tabs__buttons {
    --gsk-theme-tab-font-family: Arial Bold, sans-serif;
  }
}
</style>
