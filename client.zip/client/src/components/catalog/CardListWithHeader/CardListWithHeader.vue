<template>
  <max-width :class="{ featured: catalog.typeId === 0 }">
    <div class="card-list">
      <div class="card-list__header-content">
        <span class="card-list__header f-overline">{{ headerText }}</span>
        <router-link :to="goToTab">
          <span v-if="!isOnTab" class="f-overline see-all">see all</span>
        </router-link>
      </div>
      <div class="cards" :class="{ all: showAll, filtered: filters.search }">
        <listing-card
          v-for="listing in listings"
          :key="listing.listingId"
          class="cards__card"
          :listing="listing"
        />
      </div>
    </div>
  </max-width>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import ListingCard from './ListingCard.vue';
import { Listings } from '@/api/listings.api';
import { ListingsPaginated } from '@/store/modules/listings.module';
import MaxWidth from '@/components/MaxWidth.vue';
import { RouteNames } from '@/constants';
import { slugify } from '@/utils/routing';

@Component({
  components: {
    ListingCard,
    MaxWidth,
  },
})
export default class CardListWithHeader extends Vue {
  // data
  slice: number = 4;
  showAll: boolean = false;

  //props
  @Prop() catalog!: ListingsPaginated;
  @Prop(String) header!: string;

  @Prop()
  protected filters!: { search: string };

  get headerText(): string {
    if (this.$route.name === RouteNames.ListingType) {
      return '';
    } else {
      return this.header;
    }
  }

  get goToTab() {
    return {
      name: 'catalog-type',
      params: {
        type: slugify(this.header),
      },
    };
  }

  get isOnTab(): boolean {
    return !!this.$route.params.type || !!this.$route.query.q;
  }

  get listings() {
    return this.catalog.listings;

    // TODO: Keep this here in case we decide to go back to pagination?
    // if (this.showAll) {
    //   return this.catalog.listings;
    // } else if (this.$route.params.type !== undefined) {
    //   return this.catalog.listings;
    // }
    //
    // return this.catalog.listings.slice(0, 4);
  }

  public get $filteredProjects() {
    if (this.listings === undefined) return [];
    const list = this.listings.filter(listing =>
      listing.listingName.toLowerCase().includes(this.filters.search.toLowerCase()),
    );
    return list;
  }

  goToTypePage(cat: Listings.Listings) {
    this.$router.push({
      name: RouteNames.ListingType,
      params: {
        type: slugify(cat.listingTypeName),
      },
    });
  }
}
</script>

<style scoped lang="scss">
@import '@/styles/theme.scss';
@import '@/styles/breakpoints.scss';

.max-width__container.featured {
  background: $theme-lighter;
}

.see-all {
  cursor: pointer;
}

.card-list {
  padding: 2rem 0;
  @include breakpoint($desktop) {
    padding: 2rem 0;
  }

  &__header-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  &__header {
    margin-top: 0;
    margin-bottom: 1.5rem;
    color: $theme-medium;
    text-transform: uppercase;
  }
  &__count {
    color: var(--gsk-theme-primary);
    cursor: pointer;
  }
}
.cards {
  margin: 0;
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  grid-auto-rows: minmax(250px, auto);
  grid-gap: 2rem;
  /*@media screen and (max-width: 750px) {
    justify-content: center;
  }*/

  &.all {
    justify-content: flex-start;

    @media screen and (max-width: 750px) {
      justify-content: center;
    }
  }
  &.filtered {
    justify-content: flex-start;

    @media screen and (max-width: 750px) {
      justify-content: center;
    }
  }
}
.cards__card::v-deep {
  gsk-card {
    height: 100%;
  }
}
</style>
