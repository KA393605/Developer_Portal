<template>
  <router-link :to="listingLink">
    <gsk-card :aspectratio="aspectRatio" :image="img" class="card">
      <div slot="content" class="card__content" :class="{ img: aspectRatio === '16-9' }">
        <div class="card__icon">
          <img :src="icon" :alt="listing.listingTypeName" />
        </div>

        <div class="card__title wba">
          <h3 class="gsk-typography--headline6 card__title-text">{{ listing.listingName }}</h3>
          <p class="gsk-typography--body1 card__version">{{ listing.version }}</p>
        </div>

        <p class="gsk-typography--body2 card__description wba">{{ description }}</p>
      </div>
      <div v-if="isComponent && libs" class="card__bottom f-caption truncate">
        <gsk-icon v-if="isWebComp" class="type-icon">devices</gsk-icon>
        <gsk-icon v-else-if="isMobileComp" class="type-icon">devices_other</gsk-icon>
        {{ libs }}
      </div>
    </gsk-card>
  </router-link>
</template>

<script lang="ts">
import { Component } from 'vue-property-decorator';
import truncate from 'lodash.truncate';
import { mixins } from 'vue-class-component';
import { ListingTypes, listingTypesById, RouteNames } from '@/constants';
import ListingDetailsMixin from '@/components/mixins/listing-details.mixin';
import { addAnalyticsRouteParams } from '@/analytics';

@Component
export default class ListingCard extends mixins(ListingDetailsMixin) {
  get isComponent() {
    return (
      this.listingTypeId === ListingTypes.WebComponent ||
      this.listingTypeId === ListingTypes.MobileComponent
    );
  }

  get img() {
    if (!this.listing.hasImage) {
      return '';
    }
    return `/api/listings/${this.listing.listingId}/image`;
  }

  get aspectRatio(): string {
    return this.img ? '16-9' : '';
  }

  get description(): string {
    return truncate(this.listing.listingDescription, { length: 100 });
  }

  get listingLink() {
    const listingType = listingTypesById[this.listing.listingTypeId];
    return {
      name: RouteNames.ListingDetails,
      params: addAnalyticsRouteParams(
        { listingId: '' + this.listing.listingId },
        {
          listingName: this.listing.listingName,
          listingType,
        },
      ),
    };
  }
}
</script>

<style scoped lang="scss">
@import '@/styles/theme.scss';
.type-icon {
  margin-right: 0.5rem;
  font-size: 1.3rem;
}
.card {
  text-decoration: none;
  z-index: 1;
  // TODO: change border radius once card component supports it
  border-radius: 5px;
  cursor: pointer;
  /* NOTE: grid and max-width are required here for reasons */
  display: grid;
  max-width: 280px;
  width: 100%;
  min-height: 288px;

  &__title {
    display: flex;
    justify-content: flex-start;
    align-items: center;
    margin-bottom: 10px;
  }

  &__title-text,
  &__version,
  &__description,
  &__category {
    margin: 0;
  }

  &__category,
  &__title-text {
    color: var(--gsk-theme-on-secondary);
  }

  &__version {
    color: $theme-light;
    margin-left: 16px;
  }

  &__title-text {
    font-weight: 600;
  }

  &__content {
    padding: 1.5rem;

    &.img {
      margin-top: -45px;
      z-index: 2;
    }
  }

  &__icon {
    width: 30px;
    height: 30px;
    margin-bottom: 1rem;

    img {
      background-color: $theme-white;
      border-radius: 50%;
    }
  }

  &__bottom {
    padding: 0 24px 24px;
    color: #bbb9b4;
    display: flex;
    align-items: center;
    max-width: 280px - 24px;
  }

  &__categories {
    width: 100%;
    min-width: 200px;

    &__icon {
      height: 20px;
      width: 20px;
      color: $theme-medium;
      margin-right: 8px;
    }
  }

  &__category {
    text-transform: none;
    color: $theme-medium;
    margin-right: 3px;
  }
}
</style>
