<template>
  <label ref="label" :for="id">
    <input
      :id="id"
      :name="id"
      type="file"
      style="display: none;"
      :accept="accept"
      @change="loadTextFromFile"
    />
    <g-button type="text" @click.prevent.capture="reclick">{{ title }}</g-button>
  </label>
</template>

<script lang="ts">
import { Component, Vue, Prop } from 'vue-property-decorator';
import GButton from '@/components/gsk-components/GskButton.vue';
import { randId, RequiredProp } from '@/utils/components';

interface HTMLInputEvent extends Event {
  target: HTMLInputElement & EventTarget;
}

@Component({
  components: {
    GButton,
  },
})
export default class FileSelect extends Vue {
  @RequiredProp(String) readonly title!: string;
  @Prop({ default: '', type: String }) readonly accept!: string;
  private id = randId();

  reclick() {
    const l = this.$refs.label as HTMLLabelElement;
    if (l && l.click) {
      l.click();
    }
  }

  public loadTextFromFile(ev: HTMLInputEvent): void {
    if (!ev.target.files) {
      return;
    }
    const file = ev.target.files[0];
    const reader = new FileReader();
    const vm = this;

    reader.onload = function(e: any): void {
      if (e.target) {
        vm.$emit('load', e.target.result || '');
      }
    };
    reader.readAsText(file);
  }
}
</script>

<style lang="scss">
@import '~@/styles/typography.scss';
@import '~@/styles/breakpoints.scss';
@import '~@/styles/theme.scss';
.text-reader {
  margin-right: 16px;
  padding: 10px 18px;
  color: var(--theme-primary);
  background-color: transparent;
  border-radius: 20px;
  text-align: center;
  @extend .gsk-typography--button;
  transition: background-color 250ms;

  &:hover {
    background-color: rgb(243, 102, 51, 0.15);
  }

  input {
    display: none;
  }
}
</style>
