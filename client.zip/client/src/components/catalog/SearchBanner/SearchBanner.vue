<template>
  <div class="search-banner">
    <div class="search-banner__inner">
      <h2 class="gsk-typography--headline4 search-banner__header">{{ header }}</h2>
      <div class="search-banner__search">
        <g-analytics v-slot="{ sendClick }" :click-data="searchAnalytics">
          <g-textfield
            v-model="value"
            class="options__search"
            trailingiconcontent="search"
            trailingiconinteraction
            :placeholder="searchPlaceholder"
            outlined
            helper-text-content=""
            @trailingiconinteraction.native="
              sendClick();
              onSearch(value);
            "
            @keyup.enter.native="
              sendClick();
              onSearch(value);
            "
          />
        </g-analytics>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Emit, Prop, Vue, Watch } from 'vue-property-decorator';
import GTextfield from '@/components/gsk-components/GskTextfield.vue';
import { TextfieldInfo } from '@/constants';
import GAnalytics from '@/components/GAnalytics';
import { ClickData } from '@/analytics';

@Component({
  components: {
    GTextfield,
    GAnalytics,
  },
})
export default class SearchBanner extends Vue {
  @Prop() bannerInfo!: {
    bannerText: string;
    searchInfo: string;
  };

  public searchPlaceholder: string = TextfieldInfo.searchPlaceholder;
  public value: string = '';

  get searchAnalytics(): ClickData {
    return {
      clickTarget: 'product-catalog-search',
      searchQuery: this.value,
    };
  }

  @Watch('$route.query')
  getValue() {
    this.value = Array.isArray(this.$route.query.q)
      ? this.$route.query.q.join(',')
      : this.$route.query.q || '';
  }

  created() {
    this.value = Array.isArray(this.$route.query.q)
      ? this.$route.query.q.join(',')
      : this.$route.query.q || '';
  }
  get header(): string {
    return this.bannerInfo.bannerText;
  }

  @Emit('onSearch')
  protected onSearch(value: string) {
    return value.trim();
  }
}
</script>

<style lang="scss" scoped>
@import '@/styles/theme.scss';

.search-banner {
  --gsk-theme-primary: $theme-primary;
  background-color: var(--theme-accent);

  &__inner {
    padding: 4rem 20px;
    max-width: 720px;
    margin: 0 auto;
  }

  &__header {
    text-align: center;
    color: $theme-white;
    margin-top: 0;
    font-weight: 600;
  }
  &__search {
    background: $theme-white;
    border-radius: 4px;
  }
}
</style>
