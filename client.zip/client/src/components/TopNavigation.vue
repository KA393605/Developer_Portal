<template>
  <div slot="actionItems" class="links">
    <router-link
      v-for="link in links"
      :key="link.key"
      :to="link.route"
      class="link f-subtitle--small"
    >
      <span class="nowrap">{{ link.text.trim() }}</span>
    </router-link>
  </div>
</template>

<script lang="ts">
import { Component } from 'vue-property-decorator';
import { mixins } from 'vue-class-component';
import NavigationMixin from './mixins/navigation.mixin';

@Component
export default class TopNavigation extends mixins(NavigationMixin) {}
</script>

<style scoped lang="scss">
@import '~@/styles/theme.scss';
@import '~@/styles/breakpoints.scss';

.links {
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: row-reverse;
  height: var(--header-height);
}

.link {
  display: flex;
  align-items: center;
  text-decoration: none;
  border-radius: 35px;
  padding: 0.5em;
  color: $theme-dark;
  height: var(--header-height);
  margin-right: 2rem;
  margin-bottom: -1px;

  &.f-subtitle--small {
    display: none;
    @include breakpoint($desktop) {
      display: flex;
    }
  }
  &.router-link-active {
    background: linear-gradient(to right, $theme-primary, $theme-primary) no-repeat left bottom;
    background-size: 100% 4px;
    border-radius: 0;
  }
}
</style>
