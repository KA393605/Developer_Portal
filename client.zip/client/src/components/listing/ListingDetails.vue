<template>
  <section>
    <img :src="icon" alt="" />
    <h5 class="title">
      {{ l.listingName }}
    </h5>
    <div v-if="releaseTags.length" id="github-tag-release" ref="menuContainer" class="f-body">
      {{ currentReleaseTag() }}
      <gsk-icon-button
        icon="caret_down"
        officon="caret_up"
        mini
        :on.prop="isIconOn"
        toggle
        :disabled="draft"
        @click="showMenu"
      />
      <div class="menu-container">
        <gsk-menu
          ref="versionsMenu"
          @MDCMenuSurface:closed="isIconOn = true"
          @MDCMenuSurface:opened="isIconOn = false"
        >
          <gsk-list v-for="tag in releaseTags" :key="tag">
            <gsk-list-item @click="setNewVersion(tag)">
              {{ tag }}
            </gsk-list-item>
          </gsk-list>
        </gsk-menu>
      </div>
    </div>
    <div v-if="isMobileComp || isWebComp" class="mobile-web f-body--small">
      <template v-if="isWebComp">
        <gsk-icon class="type-icon">devices</gsk-icon>
        Web
      </template>
      <template v-else-if="isMobileComp">
        <gsk-icon class="type-icon">devices_other</gsk-icon>
        Mobile
      </template>
    </div>
    <p class="description f-body--small">{{ l.listingDescription }}</p>

    <template v-if="isApi">
      <router-link v-if="!draft" :to="connectLink">
        <g-analytics v-slot="{ sendClick }" :click-data="connectAnalytics">
          <g-button unelevated class="connect-project" @click="sendClick">
            Connect To project
          </g-button>
        </g-analytics>
      </router-link>
      <template v-else>
        <g-button unelevated class="connect-project" :disabled="true">
          Connect To project
        </g-button>
      </template>
    </template>

    <table class="table">
      <tr>
        <td class="f-small-text th">
          Listing Owners
        </td>
        <td class="f-small-text td">
          <user-list :users="l.owners" truncate expandable class="u-list"></user-list>
        </td>
      </tr>
      <tr v-for="d in details" :key="d.key" class="">
        <td class="f-small-text th" :title="d.label">
          {{ d.label }}
        </td>
        <td v-if="isPeople(d.type)" class="f-small-text td">
          <user-list :users="d.value" truncate class="u-list"></user-list>
        </td>
        <td
          v-else
          class="f-small-text td wrap"
          :title="d.value"
          v-html="transformLinks(d.value)"
        ></td>
      </tr>
      <tr v-if="repo && isRepoType">
        <td class="f-small-text th">
          Language
        </td>
        <td class="f-small-text td">
          {{ repo.language }}
        </td>
      </tr>
    </table>

    <div class="links">
      <a v-if="demoLinkField" :href="demoLinkField.value" target="_blank" class="f-overline mt1">
        <strong>
          Demo Link
        </strong>
      </a>
      <a v-if="repo" :href="repoLink" target="_blank" class="f-overline mt1">
        <strong>
          view on github
        </strong>
      </a>
      <router-link v-if="!draft && isOwner" :to="editLink" class="f-overline mt1">
        <strong>
          edit listing
        </strong>
      </router-link>
    </div>
  </section>
</template>

<script lang="ts">
import { RawLocation } from 'vue-router';
import { Component, Prop } from 'vue-property-decorator';
import anchorme from 'anchorme';
import DOMPurify from 'dompurify';
import { Menu } from '@gsk-platforms/gsk-menu/gsk-menu';
import { mixins } from 'vue-class-component';
import GButton from '@/components/gsk-components/GskButton.vue';
import { ReposListTagsResponseItemContent } from '@/types/listings.types';
import { ListingTypes, RouteNames } from '@/constants';
import { FormField } from '@/components/form/form.types';
import { GithubRepo } from '@/types/publishing.types';
import UserList from '@/components/UserList.vue';
import { UserModule } from '@/store/modules/user.module';
import ListingDetailsMixin from '@/components/mixins/listing-details.mixin';
import { addAnalyticsRouteParams, ClickData } from '@/analytics';
import GAnalytics from '@/components/GAnalytics';

function formFieldValueToString(field: FormField): string {
  if (field.type === 'github-repo') {
    if (field.value) {
      return field.value.html_url;
    }
    return '';
  }
  if (field.type === 'people-picker') {
    return field.value.map(u => u.email).join(', ');
  }
  if (Array.isArray(field.value)) {
    return field.value.join(', ');
  }

  return field.value;
}

type GskMenu = Menu;

const DEMO_LINK_KEY = 'demo-link';

@Component({
  components: {
    GButton,
    UserList,
    GAnalytics,
  },
})
export default class ListingDetails extends mixins(ListingDetailsMixin) {
  @Prop(Boolean) draft!: boolean;
  public isIconOn: boolean = true;

  get connectAnalytics(): ClickData {
    return {
      clickTarget: 'listing-details-connect-button',
      listingName: this.listing.listingName,
      listingType: 'API',
    };
  }

  get isOwner(): boolean {
    const u = UserModule.user.mudId;
    return !!this.listing.owners.find(o => o.mudId === u);
  }

  get editLink(): RawLocation {
    const { listingId } = this.listing;
    return {
      name: RouteNames.PublishListing,
      params: {
        listingId: (listingId || '').toString(),
      },
      query: { mode: 'edit' },
    };
  }

  showMenu() {
    if (this.draft) {
      return;
    }
    const menu = this.$refs.versionsMenu as GskMenu;
    menu.setAnchorElement(this.$refs.menuContainer as Element);
    menu.setAnchorCorner(menu.Corner.TOP_LEFT);
    menu.setAnchorMargin({ bottom: 16 });
    menu.open = !menu.open;
  }

  setNewVersion(tag: ReposListTagsResponseItemContent) {
    this.$router.replace({
      name: RouteNames.ListingSection,
      params: this.$route.params,
      query: {
        version: tag,
      },
    });
  }

  get releaseTags(): ReposListTagsResponseItemContent[] {
    const repo = this.l.extendedProperties.githubRepo;
    if (!repo) {
      return [];
    }
    if (!repo.releaseTags) {
      return [repo.default_branch];
    }
    return [repo.default_branch].concat(repo.releaseTags);
  }

  currentReleaseTag(): ReposListTagsResponseItemContent {
    const version = this.$route.query.version;
    if (Array.isArray(version)) {
      return version[0] || '';
    } else if (version) {
      return version;
    }
    // try to get first tag instead of default branch
    const v = this.releaseTags[1] || this.releaseTags[0];
    if (v && !this.draft) {
      this.setNewVersion(v);
    }
    return v;
  }

  get isApi(): boolean {
    return this.listing.listingTypeId === ListingTypes.API;
  }

  get isRepoType(): boolean {
    return this.listingTypeId === ListingTypes.GithubRepo;
  }

  get l() {
    return this.listing;
  }

  get repo(): GithubRepo | null {
    return this.listing.extendedProperties.githubRepo;
  }

  get repoLink() {
    return this.repo ? this.repo.html_url : '';
  }

  get demoLinkField() {
    const demoLink = this.l.extendedProperties.details.find(field => field.key === DEMO_LINK_KEY);
    if (demoLink) {
      return this.formFieldsToDetails(demoLink);
    }
    return undefined;
  }

  get details() {
    return this.listing.extendedProperties.details
      .filter(field => field.key !== DEMO_LINK_KEY)
      .map(this.formFieldsToDetails)
      .filter(field => !!field.value);
  }

  formFieldsToDetails(field: FormField) {
    if (field.type === 'people-picker') {
      return {
        type: field.type,
        label: field.outputLabel || field.label,
        value: field.value.length ? field.value : false,
      };
    }
    return {
      type: field.type,
      label: field.outputLabel || field.label,
      value: formFieldValueToString(field),
    };
  }

  get connectLink(): RawLocation {
    return {
      name: RouteNames.ListingConnect,
      params: addAnalyticsRouteParams(
        {
          listingId: (this.listing.listingId || -1).toString(),
        },
        {
          listingName: this.listing.listingName,
          listingType: this.listing.listingTypeName,
        },
      ),
    };
  }

  isPeople(type: FormField['type']): boolean {
    return type === 'people-picker';
  }

  transformLinks(text: string): string {
    return DOMPurify.sanitize(
      anchorme(text, {
        attributes: [
          {
            name: 'target',
            value: '_blank',
          },
        ],
        // truncate: 50,
      }),
      {
        ADD_ATTR: ['target'],
      },
    );
  }
}
</script>

<style scoped lang="scss">
@import '~@/styles/theme.scss';
@import '~@/styles/breakpoints.scss';

.type-icon {
  margin-right: 0.5rem;
}

.u-list {
  justify-content: flex-end;
}

.links > a:first-child {
  margin-top: 2rem;
}

.mt1 {
  margin-top: 1rem;
  display: block;
}

#github-tag-release {
  margin-top: 4px;
  color: $theme-dark;
}

.menu-container {
  position: relative;
  text-align: right;
  width: 160px;
}

.title {
  margin: 0;
}
.description {
  margin-top: 1rem;
  margin-bottom: 2rem;
  color: $theme-dark;
}
.mobile-web {
  margin-top: 1rem;
  display: flex;
  align-items: center;
  img {
    padding-right: 0.5rem;
  }
}
.table {
  margin-top: 3.5rem;
}

td {
  border-bottom: 1px solid var(--theme-light);
  border-top: 0px solid var(--theme-light);
}
.th {
  /*white-space: nowrap;*/
  /*overflow: hidden;*/
  /*text-overflow: ellipsis;*/
  text-align: left;
  padding: 1rem 0;
  width: 136px;
  max-width: 136px;
  color: $theme-dark;
  font-weight: bold;
  font-size: 14px;
  letter-spacing: 0.25px;
  vertical-align: top;
}
.td {
  font-size: 14px;
  letter-spacing: 0.25px;
  text-align: right;
  padding: 1rem 0 1rem 1rem;
  /*white-space: nowrap;*/
  /*overflow: hidden;*/
  /*text-overflow: ellipsis;*/
  width: 288px - 136px;
  max-width: 288px - 136px;
}

.wrap {
  word-break: break-word;
}
</style>
