<template>
  <content-card class="rel" :class="{ initialLoading, initialError }">
    <div v-if="initialLoading" class="initial-loader flex-center">
      <gsk-circular-progress label="Loading connected services..."></gsk-circular-progress>
    </div>
    <div v-else-if="initialError" class="initial-loader flex-center">
      <h3 class="heading">Error</h3>
      <p>
        <g-button type="text" danger @click="tryAgain">Try Again</g-button>
      </p>
    </div>
    <h6 class="content-heading">
      Connected Services
      <gsk-circular-progress v-if="updating" class="loader" mini />
    </h6>
    <template v-if="hasConnectedServices">
      <div class="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <!--<th>Version</th>-->
              <th>Auth Type</th>
              <th>Environment</th>
              <th>Endpoint</th>
              <th>Status</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="(service, i) in connectedServices"
              :key="service.serviceId"
              :class="{ isDisabled: service.serviceId in removingService }"
            >
              <td>{{ service.serviceName }}</td>
              <!-- TODO: need data -->
              <!--<td><pre>not in data contract</pre></td>-->
              <td>{{ service.authenticationType }}</td>
              <td>{{ service.environmentName }}</td>
              <td>{{ upstreamUrl(service) }}</td>
              <td class="nowrap">
                <!-- TODO: map status to proper icon color -->
                <span class="status-icon" :style="statusColor(service.statusName)"></span>
                {{ service.statusName }}
              </td>
              <td>
                <g-analytics
                  v-slot="{ sendClick }"
                  :click-data="clickAnalytics('project-service-trash-can', service)"
                >
                  <gsk-icon
                    class="trash-icon"
                    title="Remove Service"
                    @click="
                      openDialog(service, i);
                      sendClick();
                    "
                  >
                    gsk_trash
                  </gsk-icon>
                </g-analytics>
              </td>
            </tr>
            <g-analytics
              v-slot="{ sendClick }"
              :click-data="
                clickAnalytics(
                  'remove-service-confirm',
                  selectedService !== undefined ? selectedService : service,
                )
              "
            >
              <delete-dialog
                :open.sync="open"
                center-content
                button-text="Yes, remove service"
                headerlabel="Delete Service?"
                @delete="
                  removeService(selectedService !== undefined ? selectedService : service);
                  sendClick();
                "
              >
                Are you sure you want to delete
                {{ (selectedService !== undefined ? selectedService : service).serviceName }}?
              </delete-dialog>
            </g-analytics>
          </tbody>
        </table>
      </div>
      <div class="connect-link" :style="{ marginTop: '1rem' }">
        <router-link :to="listingsLink">
          <g-analytics v-slot="{ sendClick }" :click-data="connectAnalytics">
            <g-button type="text" @click="sendClick">
              connect an api
            </g-button>
          </g-analytics>
        </router-link>
      </div>
    </template>
    <template v-else>
      <p :style="{ margin: 0 }">
        You don't have any connected services
      </p>
      <div :style="{ marginTop: '2rem' }">
        <router-link :to="listingsLink">
          <g-analytics v-slot="{ sendClick }" :click-data="connectAnalytics">
            <g-button outlined @click="sendClick">
              connect an api
            </g-button>
          </g-analytics>
        </router-link>
      </div>
    </template>
  </content-card>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import { DeepReadonly } from 'ts-essentials';
import { mixins } from 'vue-class-component';
import { APIGatewayURLMapping, Environments, RouteNames, Statuses } from '@/constants';
import * as API from '@/api/projects.api';
import { ProjectDetailsModule } from '@/store/modules/project-details.module';
import ContentCard from '@/components/ContentCard.vue';
import GButton from '@/components/gsk-components/GskButton.vue';
import DeleteDialog from '@/components/dialogs/DeleteDialog.vue';
import { ClickData } from '@/analytics';
import ProjectEnvMetaMixin from '@/components/mixins/project-env-meta.mixin';
import { ProjectEnvironmentConnectedService } from '@/types/projects.types';
import GAnalytics from '@/components/GAnalytics';

@Component({
  components: {
    ContentCard,
    GButton,
    DeleteDialog,
    GAnalytics,
  },
})
export default class ProjectEnvServices extends mixins(ProjectEnvMetaMixin) {
  @Prop({ type: Array, required: true })
  connectedServices!: DeepReadonly<API.Projects.ProjectEnvironmentConnectedService[]>;
  @Prop({ type: String, required: true })
  environmentName!: Environments;
  @Prop({ type: Number, required: true }) projectId!: number;
  @Prop({ type: Number, required: true }) projectEnvId!: number;

  get connectAnalytics(): ClickData {
    return {
      clickTarget: 'project-details-service-connect-button',
      projectName: ProjectDetailsModule.projectDetails.projectName,
      projectId: ProjectDetailsModule.projectDetails.projectId,
    };
  }

  clickAnalytics(
    name: string,
    service: API.Projects.ProjectEnvironmentConnectedService,
  ): ClickData {
    return {
      clickTarget: name,
      serviceName: service.serviceName,
      serviceId: service.serviceId,
      projectEnvironment: this.environmentName,
      projectName: ProjectDetailsModule.projectDetails.projectName,
      projectId: ProjectDetailsModule.projectDetails.projectId,
    };
  }

  tryAgain() {
    const { projectEnvId, projectId } = this;
    ProjectDetailsModule.getProjectEnvironmentPart({
      projectId,
      projectEnvId,
      partName: 'services',
    });
  }

  private removingService: Record<string | number, boolean> = Object.create(null);
  async removeService(service: API.Projects.ProjectEnvironmentConnectedService) {
    const projectId = ProjectDetailsModule.projectDetails.projectId;
    const projectEnvId = service.projectEnvironmentId;
    const serviceEnvId = service.serviceId;
    const vueSetKey = `${projectId}-${projectEnvId}-${serviceEnvId}`;
    Vue.set(this.removingService, vueSetKey, true);
    const rest = this.connectedServices.filter((service, i) => i !== this.selectedServiceIndex);
    await ProjectDetailsModule.removeConnectedService({
      projectId,
      projectEnvId,
      serviceEnvId,
      connectedServices: rest,
    });
    Vue.delete(this.removingService, vueSetKey);
    this.open = false;
  }

  private open: boolean = false;

  selectedService: API.Projects.ProjectEnvironmentConnectedService = {
    authenticationType: '',
    environmentName: '',
    projectEnvironmentId: -1,
    serviceDescription: '',
    serviceEnvironmentId: -1,
    serviceId: -1,
    serviceName: '',
    statusId: -1,
    statusName: '',
    upstreamUrl: '',
  };
  selectedServiceIndex = -1;

  public openDialog(service: API.Projects.ProjectEnvironmentConnectedService, index: number): void {
    this.selectedService = service;
    this.selectedServiceIndex = index;
    this.open = true;
  }

  upstreamUrl(ref: ProjectEnvironmentConnectedService) {
    return (APIGatewayURLMapping.get(ref.environmentName.toUpperCase()) || '') + ref.upstreamUrl;
  }

  get hasConnectedServices() {
    return !!this.connectedServices.length;
  }

  get listingsLink() {
    return {
      name: RouteNames.ListingType,
      params: {
        type: 'api',
      },
    };
  }

  statusColor(status: Statuses): { backgroundColor: string } {
    const statusColorMap = {
      [Statuses.Success.toString()]: 'var(--theme-success)',
      [Statuses.Provisioned.toString()]: 'var(--theme-success)',
      [Statuses.Provisioning.toString()]: 'var(--theme-warning)',
      [Statuses.PendingApproval.toString()]: 'var(--theme-warning)',
    };
    return { backgroundColor: statusColorMap[status] };
  }
}
</script>

<style scoped lang="scss">
@import '~@/styles/theme.scss';
@import '~@/styles/breakpoints.scss';
@import '~@/styles/typography.scss';
/*@import '~@/styles/table.scss';*/

.rel {
  position: relative;
}
.initialLoading {
  pointer-events: none;
  user-select: none;
}
.initial-loader {
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  width: 100%;
  height: 100%;
  user-select: none;
  background: rgba(white, 0.9);
  z-index: 5;
}

.loader {
  display: inline-block;
  margin-left: 1rem;
}

.status-icon {
  width: 12px;
  height: 12px;
  border-radius: 50%;
  display: inline-block;
  margin-right: 0.5rem;
}

.connect-link {
  @include breakpoint($medium) {
    text-align: right;
  }
}
</style>
