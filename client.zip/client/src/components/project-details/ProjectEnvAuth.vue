<template>
  <content-card class="rel" :class="{ initialLoading, initialError }">
    <div v-if="initialLoading" class="initial-loader flex-center">
      <gsk-circular-progress label="Loading authentication details..." />
    </div>
    <div v-else-if="initialError" class="initial-loader flex-center">
      <h3 class="heading">Error</h3>
      <p>
        <g-button type="text" danger @click="tryAgain">Try Again</g-button>
      </p>
    </div>
    <h6 class="content-heading">
      Authentication
      <gsk-circular-progress v-if="updating" class="loader" mini />
    </h6>
    <div class="auth-container">
      <div class="f-subtitle auth-child oauth-container">
        OAuth
        <hr />
        <div class="auth-row">
          <div class="f-overline">CLIENT ID</div>
          <copy-code :code="environmentDetails.OAuth.clientId" overflow />
        </div>
        <div class="auth-row">
          <span class="f-overline">SECRET</span>
          <copy-code
            :code="environmentDetails.OAuth.secret"
            secret
            overflow
            @show="onSecretToggle('oauth')"
          />
        </div>
        <div class="auth-row">
          <div class="f-overline">
            <label for="callback-url">
              callback urls
            </label>
            <help-tooltip
              v-if="callbackTooltipText"
              :text="callbackTooltipText"
              :style="{ textTransform: 'none' }"
            />
          </div>
          <div
            class="callback-input-container"
            :class="{ isDisabled: callbackUrl in disabledCallbackUrls }"
          >
            <g-textfield
              id="callback-url"
              v-model="callbackUrl"
              name="callback-url"
              class="callback-input"
              placeholder="Enter callback URL"
              :helper-text-content="callbackValidationMessage || ' '"
              @keyup.native.enter="addCallbackUrl"
            />
            <gsk-icon class="callback-input-icon flex-center" @click="addCallbackUrl">
              gsk_plus
            </gsk-icon>
          </div>
          <gsk-list>
            <gsk-list-item
              v-for="url in callbackUrls"
              :key="url"
              :disabled.prop="url in disabledCallbackUrls"
              trailinginput
            >
              {{ url }}
              <gsk-icon
                slot="meta"
                class="trash-icon"
                :class="{ isDisabled: url in disabledCallbackUrls || callbackUrls.length < 2 }"
                @click="openDialog(url)"
              >
                gsk_trash
              </gsk-icon>
            </gsk-list-item>
          </gsk-list>
          <delete-dialog
            :open.sync="open"
            center-content
            button-text="Yes, remove url"
            headerlabel="Delete Callback URL?"
            @delete="removeCallbackUrl(selectedUrl)"
          >
            Are you sure you want to delete {{ selectedUrl }}?
          </delete-dialog>
        </div>
      </div>
      <div class="f-subtitle auth-child basic-container">
        Basic
        <hr />
        <div class="auth-row">
          <div class="f-overline">api key</div>
          <copy-code
            :code="environmentDetails.basic.ApiKey"
            secret
            overflow
            class="code-copy"
            @show="onSecretToggle('basic')"
          />
        </div>
      </div>
    </div>
    <div class="auth-row m0">
      <g-button type="text" @click.native="showFederationDialog">
        Federation Info
      </g-button>
      <g-dialog
        :open.sync="federationOpen"
        class="auth-dialog"
        headerlabel="Federation Info"
        hideactionbuttons
      >
        <template>
          <div style="display: flex; align-items: center; margin-bottom: 2rem;">
            <h6 style="margin: 0; margin-right: 0.5rem;">Authorization Code</h6>
            <a
              href="https://www.pingidentity.com/content/developer/en/resources/oauth-2-0-developers-guide.html#authorization_code"
              target="_blank"
            >
              <gsk-icon>question</gsk-icon>
            </a>
          </div>
          <div>
            <div class="code-container">
              <div class="f-overline">Base URL</div>
              <copy-code :code="authBaseUrl" />
            </div>
            <div class="code-container">
              <div class="f-overline">Authorization URL</div>
              <copy-code :code="authUrl" />
            </div>
            <div class="code-container">
              <div class="f-overline">Token URL</div>
              <copy-code :code="tokenUrl" />
            </div>
            <div class="code-container">
              <div class="f-overline">Logout URL</div>
              <copy-code :code="logoutUrl" />
            </div>
            <div class="code-container">
              <div class="f-overline">User Info URL</div>
              <copy-code :code="userInfoUrl" />
            </div>
          </div>
          <h6>Example</h6>
          <div class="f-overline">Authorization Code</div>
          <copy-code :code="authCode" overflow />
          <copy-code :code="authCodeCurl" overflow />

          <div style="display: flex; align-items: center">
            <h6 style="margin-right: 0.5rem;">Client Credentials</h6>
            <a
              href="https://www.pingidentity.com/content/developer/en/resources/oauth-2-0-developers-guide.html#authorization_code"
              target="_blank"
            >
              <gsk-icon>question</gsk-icon>
            </a>
          </div>
          <div>
            <div class="f-overline">Client Credentials</div>
            <copy-code :code="clientCredentials" />
          </div>
        </template>
        <template slot="footer">
          <a href="https://oauth.net/2/grant-types/" target="_blank" class="f-body--small">
            Learn more about OAuth2.0
          </a>
        </template>
      </g-dialog>
    </div>
  </content-card>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import { DeepReadonly } from 'ts-essentials';
import { mixins } from 'vue-class-component';
import * as API from '@/api/projects.api';
import ContentCard from '@/components/ContentCard.vue';
import GButton from '@/components/gsk-components/GskButton.vue';
import GTextfield from '@/components/gsk-components/GskTextfield.vue';
import { openSnackbar } from '@/utils/components';
import DeleteDialog from '@/components/dialogs/DeleteDialog.vue';
import { analyticsClick } from '@/analytics';
import HelpTooltip from '@/components/HelpTooltip.vue';
import GDialog from '@/components/gsk-components/GskDialog.vue';
import CopyCode from '@/components/CopyCode.vue';
import { Environments } from '@/constants';
import ProjectEnvMetaMixin from '@/components/mixins/project-env-meta.mixin';
import { ProjectDetailsModule } from '@/store/modules/project-details.module';

@Component({
  components: {
    ContentCard,
    GButton,
    GTextfield,
    DeleteDialog,
    GDialog,
    HelpTooltip,
    CopyCode,
  },
})
export default class ProjectEnvAuth extends mixins(ProjectEnvMetaMixin) {
  @Prop({ type: Object, required: true })
  environmentDetails!: DeepReadonly<API.Projects.ProjectEnvironmentDetails2['auth']>;
  @Prop({ type: Object, required: true })
  environmentStatus!: DeepReadonly<API.Projects.ProjectEnvironmentDetails2['status']>;
  @Prop({ type: String, required: true }) environmentName!: Environments;
  @Prop({ type: Number, required: true }) projectId!: number;
  @Prop({ type: Number, required: true }) projectEnvId!: number;

  selectedUrl: string = '';
  private open: boolean = false;
  private federationOpen: boolean = false;

  public openDialog(url: string): void {
    this.selectedUrl = url;
    this.open = true;
  }

  tryAgain() {
    const { projectEnvId, projectId } = this;
    ProjectDetailsModule.getProjectEnvironmentPart({
      projectId,
      projectEnvId,
      partName: 'auth',
    });
  }

  get isProduction() {
    return this.environmentName === Environments.Prod;
  }

  protected showFederationDialog() {
    this.federationOpen = true;
  }

  get pingSubdomain() {
    if (this.isProduction) {
      return 'federation';
    }
    return 'federation-qa';
  }

  get authBaseUrl() {
    return `https://${this.pingSubdomain}.gsk.com`;
  }

  get authUrl() {
    return this.authBaseUrl + '/as/authorization.oauth2';
  }

  get authCode() {
    return `${this.authUrl}?response_type=code&client_id=${this.environmentDetails.OAuth.clientId}&redirect_uri=${this.callbackUrlEncoded}`;
  }

  get authCodeCurl() {
    return `curl -X POST ${this.tokenUrl} -d 'client_id=${this.environmentDetails.OAuth.clientId}&client_secret=${this.environmentDetails.OAuth.secret}&grant_type=authorization_code&code={{authorization_code}}&redirect_uri=${this.callbackUrlEncoded}'`;
  }

  get tokenUrl() {
    return this.authBaseUrl + '/as/token.oauth2';
  }

  get logoutUrl() {
    return this.authBaseUrl + '/oidc/token/revocation';
  }

  get userInfoUrl() {
    return this.authBaseUrl + '/idp/userinfo.openid';
  }

  get clientCredentials() {
    return `curl -X POST ${this.tokenUrl} -d 'client_id=${this.environmentDetails.OAuth.clientId}&client_secret=${this.environmentDetails.OAuth.secret}&grant_type=client_credentials'`;
  }

  get callbackUrlEncoded() {
    const { callbackUrls } = this.environmentDetails.OAuth;
    return encodeURI(callbackUrls[callbackUrls.length - 1]);
  }

  private disabledCallbackUrls: Record<string, boolean> = Object.create(null);
  private callbackUrl: string = '';
  protected secretFields = {
    oauth: true,
    basic: true,
  };

  protected onSecretToggle(field: 'oauth' | 'basic'): void {
    analyticsClick({
      clickTarget: 'project-view-auth-secret',
      projectId: this.projectId,
      projectEnvironment: this.environmentName,
      projectName: ProjectDetailsModule.projectDetails.projectName,
      secretType: field,
    });
  }

  get callbackUrls() {
    return this.environmentDetails.OAuth.callbackUrls;
  }

  get callbackTooltipText() {
    if (this.isProduction) {
      return 'https:// is required for production environment';
    }
    return '';
  }

  get callbackValid(): boolean {
    if (this.callbackUrl.trim() === '') {
      // just to simulate `dirty`
      return true;
    }
    return !this.callbackValidationMessage;
  }

  get callbackValidationMessage(): string {
    // no dupes
    if (this.callbackUrls.includes(this.callbackUrl)) {
      return 'URL should not be a duplicate';
    }
    // prod must be https
    if (this.isProduction) {
      if (/https:\/\/.+/.test(this.callbackUrl)) {
        // valid
        return '';
      }
      return 'https:// URL is required for production';
    } else {
      // other must be http/https
      if (/https?:\/\/.+/.test(this.callbackUrl)) {
        // valid
        return '';
      }
      return 'URL should start with http:// or https://';
    }
  }

  async removeCallbackUrl(url: string) {
    this.$log('removing callback url:', url);
    Vue.set(this.disabledCallbackUrls, url, true);
    const urlSet = new Set(this.callbackUrls);
    urlSet.delete(url);
    await ProjectDetailsModule.updateCallbackUrls({
      projectId: Number(this.projectId),
      projectEnvId: Number(this.projectEnvId),
      urls: [...urlSet],
    });
    Vue.delete(this.disabledCallbackUrls, url);
    this.open = false;
  }

  async addCallbackUrl() {
    if (this.callbackUrl.trim() === '') {
      // this.$log('empty input, not adding callback url');
      return;
    }
    if (!this.callbackValid) {
      return;
    }

    const url = this.callbackUrl;
    Vue.set(this.disabledCallbackUrls, url, true);
    ProjectDetailsModule.updateCallbackUrls({
      projectId: Number(this.projectId),
      projectEnvId: Number(this.projectEnvId),
      urls: [...this.callbackUrls, url],
    })
      .then(() => {
        this.callbackUrl = '';
      })
      .catch(() => {
        openSnackbar.call(this, 'Error adding callback URL');
      })
      .finally(() => {
        Vue.delete(this.disabledCallbackUrls, url);
      });
  }
}
</script>

<style scoped lang="scss">
@import '~@/styles/theme.scss';
@import '~@/styles/breakpoints.scss';
@import '~@/styles/typography.scss';

.code-copy {
  max-width: 100%;
}

.rel {
  position: relative;
}
.initial-loader {
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  width: 100%;
  height: 100%;
  user-select: none;
  background: rgba(white, 0.9);
  z-index: 5;
}

.loader {
  display: inline-block;
  margin-left: 1rem;
}

h6 {
  margin: 32px 0 16px;
}

.trash-icon.isDisabled {
  visibility: hidden;
}

.toggle {
  cursor: pointer;
  user-select: none;
  width: 24px;
  color: $theme-primary;
}

.auth-container {
  display: grid;
  align-items: stretch;
  grid-template-columns: 100%;
  grid-column-gap: 1rem;
  @include breakpoint($large) {
    grid-template-columns: repeat(2, 50%);
  }
}
.auth-child {
}

.code-container {
  margin-bottom: 32px;
}
.auth-row {
  --gsk-dialog-max-width: var(--content-max-width);
  display: block;
  align-items: center;
  margin-top: 1.5rem;
  margin-bottom: 1.5rem;

  .icon {
    width: 40px;
    text-align: right;
  }

  > span:first-child {
    width: 104px;
    @include breakpoint($small) {
      width: 185px;
    }
  }
  .auth-token {
    flex: 1;
    word-break: break-all;
  }
}

.callback-input-container {
  display: flex;
  width: 100%;
  margin-top: 1rem;
}
.callback-input {
  flex: 1;
}
.callback-input-icon {
  background: $theme-primary;
  color: white;
  height: 56px;
  width: 56px;
  cursor: pointer;
  margin-left: -3px;
  z-index: 2;
  border-bottom-right-radius: 3px;
  border-top-right-radius: 3px;
  &:hover {
    background: var(--theme-primary--hover);
  }
}
.error-text {
  color: $theme-danger;
}

.m0 {
  margin: 0;
}
</style>
