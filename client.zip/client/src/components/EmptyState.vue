<template>
  <div class="empty">
    <img :src="imageSrc" alt="computer" />
    <h6>{{ title }}</h6>
    <p>{{ subtitle }}</p>
    <div class="button-container">
      <router-link :to="link" class="button">
        <g-button icon="plus" elevation="1" v-on="$listeners">
          {{ buttonText }}
        </g-button>
      </router-link>
    </div>
  </div>
</template>

<script lang="ts">
import { RawLocation } from 'vue-router';
import { Component, Prop, Vue } from 'vue-property-decorator';
import { RequiredProp } from '@/utils/components';
import GButton from '@/components/gsk-components/GskButton.vue';

@Component({
  components: {
    GButton,
  },
})
export default class EmptyState extends Vue {
  @RequiredProp(Object) link!: RawLocation;
  @RequiredProp(String) buttonText!: string;
  @RequiredProp(String) imageSrc!: string;
  @Prop({ type: String, default: '' }) title!: string;
  @Prop({ type: String, default: '' }) subtitle!: string;
}
</script>

<style scoped lang="scss">
@import '~@/styles/theme.scss';
@import '~@/styles/breakpoints.scss';
.empty {
  background-color: $theme-white;
  flex: 1;
  display: flex;
  flex-flow: column nowrap;
  justify-content: center;
  align-items: center;

  h6 {
    margin-top: 42px;
    margin-bottom: 0;
  }

  p {
    margin: 8px 0 32px;
  }
}
</style>
