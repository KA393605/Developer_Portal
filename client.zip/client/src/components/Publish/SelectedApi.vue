<template>
  <section class="api-fields" :class="{ draft: isAddingNewVersion }">
    <div class="mtl">
      <div class="f-subtitle mb1">{{ content.heading }}</div>
      <div class="f-body--small">{{ content.subheading }}</div>
    </div>
    <g-select
      id="select"
      v-model="registrationId"
      class="select-field mtm"
      :label="label"
      :options="availableRegistrations"
      placeholder="Select"
      required
    ></g-select>
    <g-select
      v-if="registrationHasAvailableVersions"
      v-model="registrationVersion"
      :label="labelOfVersion"
      :options="selectedRegistrationVersions"
      placeholder="Select"
      class="second-select__select"
      required
    ></g-select>
    <p v-if="showHelp || showHelpVersion" class="f-body--small">
      To register a new API or API Version in the gateway, reach out to
      <a href="mailto:apigw_admins@gsk.com">
        apigw_admins@gsk.com
      </a>
    </p>
    <g-button class="n-button mtl" :disabled="disabled" @click="next">Next</g-button>
  </section>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import uniqBy from 'lodash/uniqBy';
import GSelect from '../gsk-components/GskSelect.vue';
import GButton from '../gsk-components/GskButton.vue';
import { GetRegistrationsResponseData } from '@/types/listings.types';
import { SelectOption } from '../form/form.types';
import { PublishingModule } from '@/store/modules/publishing.module';
import { RegistrationVersions } from '@/types/publishing.types';

const MISSING = 'missing-api';

@Component({
  components: {
    GSelect,
    GButton,
  },
})
export default class SelectedApi extends Vue {
  public label: string = 'Select API';
  public labelOfVersion: string = 'Select Version';

  showHelp: boolean = false;
  showHelpVersion: boolean = false;

  next() {
    PublishingModule.goToNextComponent();
  }

  get content() {
    return PublishingModule.listingTypeTemplate.publishing.content.details;
  }

  async getRegistrationVersions(id: number) {
    await PublishingModule.getRegistrationVersions(id);
    const versions: RegistrationVersions[] = PublishingModule.registrationVersions.versions || [];
    if (versions.length) {
      this.registrationVersion = versions[0].registrationVersionId.toString();
    }
  }

  public async created(): Promise<void> {
    await PublishingModule.getAvailableRegistrations();
    if (this.registrationOptions.length) {
      if (!this.registrationId) {
        this.registrationId = this.registrationOptions[0].registrationId.toString();
      }
    }
  }

  set registrationId(registrationId) {
    if (registrationId === MISSING) {
      this.showHelp = true;
    } else {
      this.showHelp = false;
      this.registrationVersion = '';
      const id = Number(registrationId);
      PublishingModule.updateRegistrationIdAndProductLabels(id);
      this.getRegistrationVersions(id);
    }
  }

  get registrationId(): string {
    if (this.showHelp) {
      return MISSING;
    }
    const { registrationId } = this.listing;
    const optionObj = this.registrationOptions.find(
      option => option.registrationId === registrationId,
    );
    return optionObj ? optionObj.registrationId.toString() : '';
  }

  set registrationVersion(id: string) {
    if (id === MISSING) {
      this.showHelpVersion = true;
    } else {
      this.showHelpVersion = false;
      PublishingModule.setRegistrationVersionId(Number(id));
    }
  }

  get registrationVersion(): string {
    if (this.showHelpVersion) {
      return MISSING;
    }
    const { registrationVersionId } = PublishingModule.draftListing;
    return registrationVersionId === 0 ? '' : registrationVersionId.toString();
  }

  get registrationOptions(): GetRegistrationsResponseData[] {
    return PublishingModule.registrationOptions;
  }

  get registrationHasAvailableVersions(): boolean {
    return PublishingModule.registrationHasVersions && this.registrationId !== MISSING;
  }

  get registrationVersionId(): number {
    return PublishingModule.draftListing.registrationVersionId;
  }

  get listing() {
    return PublishingModule.draftListing;
  }

  get isAddingNewVersion(): boolean {
    return PublishingModule.statusList[0].key === '3';
  }

  get disabled(): boolean {
    return this.showHelp || this.showHelpVersion || this.registrationVersionId === 0;
  }

  get availableRegistrations(): SelectOption[] {
    const registrations: GetRegistrationsResponseData[] = PublishingModule.registrationOptions;
    return uniqBy(
      registrations.map(reg => {
        let obj: SelectOption = {
          value: reg.registrationId.toString(),
          label: reg.resourceName,
          disabled: false,
        };
        return obj;
      }),
      'value',
    ).concat([
      {
        value: MISSING,
        label: "I don't see what I'm looking for",
        disabled: false,
      },
    ]);
  }

  get selectedRegistrationVersions(): SelectOption[] {
    const versions: RegistrationVersions[] = PublishingModule.registrationVersions.versions || [];
    return versions
      .map(version => {
        let obj: SelectOption = {
          value: version.registrationVersionId.toString(),
          label: 'v' + version.versionId.toString(),
          disabled: false,
        };
        return obj;
      })
      .concat([
        {
          value: MISSING,
          label: "I don't see what I'm looking for",
          disabled: false,
        },
      ]);
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/theme.scss';
.api-fields > * {
  margin-top: 24px;
}
.mtm {
  margin-top: 2rem;
}
.mtl {
  margin-top: 2.5rem;
  color: $theme-dark;
}
.mb1 {
  margin-bottom: 1rem;
}
.n-button {
  float: right;
}
</style>
