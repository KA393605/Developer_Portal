<template>
  <full-screen-form
    class="listing-permissions"
    :closed="modalClosed"
    title="Edit Permissions"
    show-back
    @close="$emit('close')"
  >
    <div class="settings">
      <h5 class="settings__heading">Edit Permissions</h5>
      <div class="settings__input">
        <p class="f-body--small">Who can edit this listing?</p>
        <g-people-picker
          v-model="owners"
          label="add owners"
          outlined
          helper-text-content=""
          validationmessage="Your listing needs at least one owner"
          required
          :valid="lengthValid"
        />
      </div>
      <div class="settings__buttons">
        <g-button :disabled="!canSave" unelevated @click="save">Save</g-button>
      </div>
    </div>
  </full-screen-form>
</template>
<script lang="ts">
import { Component, Vue, Prop } from 'vue-property-decorator';
import FullScreenForm from '@/components/FullScreenForm.vue';
import GButton from '@/components/gsk-components/GskButton.vue';
import GPeoplePicker from '@/components/gsk-components/GskPeoplePicker.vue';
import { RoleNames, Roles, RouteNames } from '@/constants';
import { PublishingModule } from '@/store/modules/publishing.module';
import { ListingUser } from '@/types/publishing.types';
import { UserModule } from '@/store/modules/user.module';
import { openSnackbar } from '@/utils/components';
import { updateListingPermissions } from '@/api/publishing.api';

@Component({
  components: {
    FullScreenForm,
    GButton,
    GPeoplePicker,
  },
})
export default class ListingPermissions extends Vue {
  @Prop(String) listingId?: string;
  private initialState: string = JSON.stringify(PublishingModule.draftListing.listingUsers);
  private owners: ListingUser[] = JSON.parse(this.initialState);
  private modalClosed: boolean = false;

  get mappedOwners(): ListingUser[] {
    return this.owners.map(owner => {
      return {
        roleId: Roles.Owner,
        roleName: RoleNames.Owner,
        ...owner,
      };
    });
  }

  get currentUserIsAnOwner(): boolean {
    const { user } = UserModule;
    const currentUserIsAnOwner = this.mappedOwners.find(owner => owner.mudId === user.mudId);
    return !!currentUserIsAnOwner;
  }

  save() {
    this.savePermissions(this.mappedOwners).then(() => {
      if (this.currentUserIsAnOwner) {
        this.modalClosed = true;
      } else {
        // re-route to my listings page
        this.$router.replace({
          name: RouteNames.MyListings,
        });
      }
    });
  }

  async savePermissions(value: ListingUser[]) {
    let op: Promise<unknown> = Promise.resolve();
    if (this.$route.query.mode === 'edit' && this.listingId) {
      PublishingModule.addUsersWithPermissions(value);
      op = updateListingPermissions(value, this.listingId);
    } else {
      PublishingModule.addUsersWithPermissions(value);
    }

    op.then(() => {
      openSnackbar.call(this, 'Permissions saved!');
    }).catch(e => {
      openSnackbar.call(this, 'Error: could not save permissions!', { type: 'error' });
      this.$log('error', e);
    });
  }

  get lengthValid() {
    return this.owners.length > 0;
  }

  get canSave() {
    return this.lengthValid && this.initialState !== JSON.stringify(this.owners);
  }
}
</script>
<style lang="scss" scoped>
@import '~@/styles/form-modal.scss';

.listing-permissions {
  height: 100vh;
  width: 100vw;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  position: absolute;
  z-index: 5;
  background: var(--theme-white);
}

.settings__heading {
  text-align: left;
  margin-bottom: 0;
}
.settings {
  max-width: 488px;
}
.settings__input > p {
  margin-bottom: 40px;
}
</style>
