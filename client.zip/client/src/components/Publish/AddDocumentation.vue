<template>
  <div id="form">
    <div class="form__title">
      <h6 id="product-type">
        <template v-if="content.heading">
          {{ content.heading }}
        </template>
        <template v-else>
          Add documentation
        </template>
      </h6>
      <g-button
        class="f-text-button--primary form__preview-button"
        label="Preview"
        trailingicon
        icon="link_external"
        type="text"
        @click.native="openPreview"
      ></g-button>
      <portal to="draft-preview">
        <draft-preview-wrapper
          v-if="showPreview"
          :open.sync="showPreview"
          :listing="transformedListing"
          @publish="$emit('publish')"
        />
      </portal>
    </div>
    <g-dialog
      :open.sync="dialogOpen"
      headerlabel="Name new section"
      :acceptactiondisabled="sectionName.trim() === ''"
      @accept="addNewSection"
    >
      <g-textfield
        v-model="sectionName"
        placeholder="Name your section"
        label="Section header"
        maxlength="40"
        required
        @keyup.enter.native="addNewSection"
      ></g-textfield>
    </g-dialog>
    <div id="product-info">
      <p class="f-body--small select-field">
        <template v-if="content.subheading">
          {{ content.subheading }}
        </template>
        <template v-else>
          This documentation will display on your product's listing detail page, where others will
          be able to learn more your product.
        </template>
      </p>
      <upload-component
        v-for="(section, i) in documentationSections"
        :key="section.sectionInfo.sectionName"
        :open="openIndex === i"
        :section="section"
        :flow-state="flowState"
        :index="openIndex"
        :show-arrows="showArrows && section.meta.canReorder"
        :show-up="showUp(i)"
        :show-down="showDown(i)"
        @click.native="open(i)"
        @delete="handleDelete"
      ></upload-component>
      <template v-if="canAddNewSection">
        <hr style="border: 1px solid #efefed; margin-top: 40px" />
        <g-button
          class="f-text-button--primary form__preview-button"
          label="Add New Section"
          icon="plus"
          type="text"
          @click="addNewSectionDialog"
        ></g-button>
      </template>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop } from 'vue-property-decorator';
import GButton from '../gsk-components/GskButton.vue';
import GSelect from '../gsk-components/GskSelect.vue';
import DraftPreviewWrapper from '@/components/Publish/DraftPreviewWrapper.vue';
import { PublishingModule } from '@/store/modules/publishing.module';
import UploadComponent from '@/components/Publish/Upload.vue';
import {
  DocumentationSection,
  FullListing,
  ListingExtendedProperties,
} from '@/types/listings.types';
import {
  ListingSectionTemplateTypeIds,
  ListingSectionTemplateTypes,
  ListingTypes,
} from '@/constants';
import { slugify } from '@/utils/routing';
import { PublishingFlowState } from '@/types/publishing.types';
import GDialog from '@/components/gsk-components/GskDialog.vue';
import GTextfield from '@/components/gsk-components/GskTextfield.vue';

@Component({
  components: {
    GSelect,
    GTextfield,
    GButton,
    UploadComponent,
    DraftPreviewWrapper,
    GDialog,
  },
})
export default class AddDocumentation extends Vue {
  @Prop() readonly flowState!: PublishingFlowState;
  public showPreview: boolean = false;

  private openIndex = 0;
  private dialogOpen = false;
  private sectionName = '';

  open(i: number) {
    this.openIndex = i;
  }
  handleDelete(i: number) {
    // set timeout schedules open after native click event open handler
    setTimeout(() => {
      this.open(Math.max(0, i - 1));
    });
  }

  public get pm(): typeof PublishingModule {
    return PublishingModule;
  }

  get content() {
    return PublishingModule.listingTypeTemplate.publishing.content.documentation;
  }

  public get canAddNewSection() {
    const numSections =
      PublishingModule.draftListing.extendedProperties.documentationSections.length;
    const maxSections = PublishingModule.documentationSectionsMeta.maxSections;

    return numSections < maxSections;
  }

  public get currentDraftListing() {
    return PublishingModule.draftListing;
  }

  public get transformedListing(): FullListing {
    const $ = this.currentDraftListing;
    return {
      ...$,
      listingId: $.registrationId,
      iconUrl: '',
      listingTypeName: ListingTypes[$.listingTypeId],
      keywordList: [],
      owners: $.listingUsers,
      publishedBy: { mudId: '', email: '' },
      versions: [],
    };
  }

  openPreview() {
    // TODO: figure out if this call was actually needed
    // PublishingModule.setDraftListing(this.currentDraftListing);
    this.showPreview = true;
  }

  addNewSectionDialog() {
    this.dialogOpen = true;
  }
  get newSectionMeta(): DocumentationSection['meta'] {
    const ds = PublishingModule.listingTypeTemplate.publishing.documentationSections;
    return {
      canDelete: true,
      canRename: true,
      canReorder: true,
      canEditContent: ds.canEditContent,
      canLinkContent: ds.canLinkContent,
    };
  }
  addNewSection() {
    if (this.sectionName.trim() === '') {
      return;
    }
    PublishingModule.addDocumentationSection({
      // TODO: derive meta info from top level template type settings
      sectionInfo: {
        sectionName: this.sectionName,
        sectionContent: '',
        sectionTemplateTypeId: ListingSectionTemplateTypeIds[ListingSectionTemplateTypes.Markdown],
        sectionTemplateType: ListingSectionTemplateTypes.Markdown,
      },
      meta: this.newSectionMeta,
    });
    this.dialogOpen = false;
    this.sectionName = '';
    this.openIndex = PublishingModule.documentationSections.length - 1;
  }

  showUp(i: number) {
    if (this.documentationSections[i]) {
      if (!this.documentationSections[i].meta.canReorder) {
        return false;
      }
    }
    if (this.showArrows) {
      if (i === 0) {
        return false;
      }
      const prev = this.documentationSections[i - 1];
      if (prev) {
        return prev.meta.canReorder;
      }
      return false;
    }
    return false;
  }

  showDown(i: number) {
    if (this.documentationSections[i]) {
      if (!this.documentationSections[i].meta.canReorder) {
        return false;
      }
    }
    if (this.showArrows) {
      if (i === this.documentationSections.length - 1) {
        return false;
      }
      const next = this.documentationSections[i + 1];
      if (next) {
        return next.meta.canReorder;
      }
      return false;
    }
    return false;
  }

  get showArrows() {
    return this.documentationSections.length > 1;
  }

  get documentationSections() {
    return PublishingModule.documentationSections;
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/breakpoints.scss';

#form {
  max-width: 600px;
  margin: 0 auto;
  @include breakpoint($desktop) {
    margin: 0 auto 0 0;
  }
}

.form {
  &__title {
    display: flex;
    justify-content: space-between;
    align-items: center;
    align-content: center;
    margin-bottom: 1rem;
  }
}

#product-type {
  margin: 0;
}

.select-field {
  margin-top: 0;
  margin-bottom: 40px;
}
</style>
