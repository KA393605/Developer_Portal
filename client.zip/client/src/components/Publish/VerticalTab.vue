<template>
  <ul id="vertical-list-style">
    <li
      v-for="tab in tabs"
      :key="tab.key"
      :class="classes(tab)"
      class="list-item f-body--small bold"
      @click="update(tab)"
    >
      {{ tab.text }}
    </li>
  </ul>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { UITab } from '@/types';
import { RequiredProp } from '@/utils/components';

@Component
export default class VerticalTab extends Vue {
  @RequiredProp(Array) readonly tabs!: UITab[];
  @RequiredProp(Object) readonly activeTab!: UITab;

  update(tab: UITab) {
    this.$emit('update:activeTab', tab);
  }

  classes(tab: UITab) {
    return {
      active: tab.key === this.activeTab.key,
      inactive: tab.key !== this.activeTab.key && tab.disabled,
      normal: !tab.disabled && tab.key !== this.activeTab.key,
      isDisabled: tab.disabled,
    };
  }
}
</script>

<style lang="scss" scoped>
#vertical-list-style {
  list-style: none;
  cursor: pointer;
  border-left: solid 1.5px #efefed;
  padding: 0;
  max-width: 200px;
  display: inline-block;
}

.list-item {
  width: 200px;
  margin-top: 5px;
  margin-bottom: 12px;
  margin-left: -3px;
  padding-bottom: 5px;
  padding-top: 5px;
  white-space: nowrap;
  &:first-child {
    margin-top: 0;
  }
  &:last-child {
    margin-bottom: 0;
  }
}

.active {
  color: #4a4a4a;
  border-left: solid 5px var(--theme-primary);
  padding-left: 15px;
}

.normal {
  color: #858585;
  padding-left: 20px;
}

.inactive {
  color: #d5d1ce;
  padding-left: 20px;
}
</style>
