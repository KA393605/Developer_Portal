<template>
  <div class="editor link" :class="{ show: open }">
    <gsk-top-app-bar class="link__top-bar">
      <div slot="title" class="link__top-bar__title">
        <div class="link__top-bar__left">
          <gsk-icon-button
            slot="navigationIcon"
            officon="close"
            icon="close"
            class="close-icon"
            @click="cancel"
          ></gsk-icon-button>
        </div>
        <span class="f-overline text link__right" style="margin-left: 1rem;">
          Specify URL to link external documentation
        </span>
      </div>
      <div slot="actionItems" class="link__top-bar__buttons">
        <g-button unelevated :disabled="disabled" @click="save">
          Save documentation
        </g-button>
      </div>
    </gsk-top-app-bar>
    <div class="link__url-input">
      <g-textfield
        v-if="!githubRepo"
        :value="userURL"
        placeholder="Enter link to markdown file"
        outlined
        :float-label="false"
        @input="inputChange"
      ></g-textfield>
      <div v-else class="repo-search">
        {{ githubRepo.full_name }}/
        <g-autocomplete
          v-if="fileCache && fileCache.length"
          :key="filesKey"
          v-model="fileChoice"
          :choices="fileCache || []"
          :get-choices="getFiles"
          async
        />
      </div>
    </div>
    <div class="link__editor-viewer">
      <max-width>
        <article class="markdown" v-html="renderedMarkdown"></article>
      </max-width>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Emit, Prop } from 'vue-property-decorator';
// Link Viewer
import 'tui-editor/dist/tui-editor-contents.css';
// eslint-disable-next-line import/no-extraneous-dependencies
import 'highlight.js/styles/github.css';
import Viewer from '@toast-ui/vue-editor/src/Viewer.vue';
import { marked, replaceLinkedRepoRelativeLinks } from '@/utils/markdown';

import GTextfield from '@/components/gsk-components/GskTextfield.vue';
import { RequiredProp } from '@/utils/components';
import { PublishingModule } from '@/store/modules/publishing.module';
import MaxWidth from '@/components/MaxWidth.vue';

import * as API from '@/api/github.api';
import { ListingSectionTemplateTypeIds, ListingSectionTemplateTypes } from '@/constants';
import { ListingSection } from '@/types/listings.types';
import GAutocomplete from '@/components/gsk-components/GskAutocomplete.vue';
import GButton from '@/components/gsk-components/GskButton.vue';

interface HTMLInputEvent extends Event {
  target: HTMLInputElement & EventTarget;
}

@Component({
  components: {
    Viewer,
    GTextfield,
    MaxWidth,
    GAutocomplete,
    GButton,
  },
})
export default class LinkEditor extends Vue {
  @Prop() readonly title!: string;
  @Prop() readonly open!: boolean;
  @Prop() readonly link!: string;
  @RequiredProp(Number) readonly index!: number;

  public userURL: string = '';
  public displayText: string = '';

  public get renderedMarkdown(): string {
    if (this.githubRepo) {
      return replaceLinkedRepoRelativeLinks(
        marked(this.displayText),
        this.githubRepo,
        this.userURL,
      );
    } else {
      return marked(this.displayText, { baseUrl: this.userURL });
    }
  }

  @Emit('update:open')
  public update(isOpen: boolean): boolean {
    return isOpen;
  }

  get disabled() {
    return this.userURL === '';
  }

  get githubRepo() {
    return PublishingModule.draftListing.extendedProperties.githubRepo;
  }

  get fileChoice() {
    return this.userURL ? { label: this.userURL, value: this.userURL } : null;
  }
  set fileChoice(fc: { label: string; value: string } | null) {
    this.inputChange(fc ? fc.value : '');
  }

  private fileCache: { label: string; value: string }[] | null = null;
  filterFiles(v: string) {
    return (this.fileCache || []).filter(f => new RegExp(v, 'i').test(f.label));
  }
  get filesKey() {
    return JSON.stringify(this.fileCache);
  }

  get hasMarkdownFiles(): boolean {
    if (this.fileCache === null) {
      return true; // not loaded yet, pretend it does
    }

    return !!this.fileCache.length;
  }

  async getFiles(v: string) {
    if (this.githubRepo) {
      const [owner, repo] = this.githubRepo.full_name.split('/');
      this.$log('owner, repo', owner, repo);
      if (this.fileCache) {
        return this.filterFiles(v);
      }
      return API.getRepoFiles(owner, repo)
        .then(r => r.data)
        .then(files => files.filter(f => f.endsWith('.md')))
        .then(files => (this.fileCache = files.map(f => ({ label: f, value: f }))))
        .then(() => this.filterFiles(v))
        .finally(() => {
          if (!this.hasMarkdownFiles) {
            this.displayText = '## Your GitHub repo does not contain any markdown files';
          }
        });
    }
    return [];
  }
  get forceGithub() {
    return PublishingModule.listingTypeTemplate.publishing.githubRepo.canLink;
  }

  async created() {
    this.userURL = this.link;
    if (this.forceGithub) {
      this.getFiles('.');
      this.inputChange(this.userURL);
    }
  }

  public async inputChange(val: string): Promise<void> {
    this.$log('input change', val);
    this.userURL = val.trim();
    if (!this.userURL) {
      this.displayText = '## Please enter a link to a markdown file';
      return;
    }
    if (this.forceGithub) {
      if (this.githubRepo) {
        const [owner, repo] = this.githubRepo.full_name.split('/');
        this.displayText = (await API.getRepoFileContents(owner, repo, val)).data;
      }
      return;
    }
    try {
      this.displayText = (await API.getExternalDocumentation(this.userURL)).data;
    } catch (e) {
      this.displayText = `
## Error loading content

##### please verify that the url you have entered is accessible and is a direct link to a markdown file
      `;
    }
  }

  public cancel(): void {
    this.update(false);
  }

  public get pageTitle(): string {
    return this.title;
  }

  public close(): void {
    this.update(false);
  }

  public save(): void {
    const listingSection: ListingSection = {
      sectionName: this.title,
      sectionTemplateType: ListingSectionTemplateTypes.Markdown,
      sectionContent: '',
      sectionContentUrl: this.userURL,
      sectionTemplateTypeId: ListingSectionTemplateTypeIds[ListingSectionTemplateTypes.Markdown],
    };

    this.$emit('save', listingSection);
    this.close();
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/typography.scss';
@import '~@/styles/breakpoints.scss';
@import '~@/styles/markdown.scss';
@import '~@/styles/theme.scss';
.close-icon {
  --gsk-theme-secondary: #{$theme-darker};
}

.markdown::v-deep {
  @extend .gsk-markdown;
  .anchor {
    display: none;
  }
}

.editor::v-deep {
  // .full-screen-form {
  height: auto;
  flex: 1;
  &__content {
    flex-direction: column;
    align-items: center;

    @include breakpoint($desktop) {
      flex-direction: row;
    }
  }

  + .footer {
    display: none;
  }
}

.link {
  height: 100vh;
  width: 100vw;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  position: relative;
  display: none;

  &.show {
    display: block;
    z-index: 5;
    position: absolute;
    background: var(--theme-white);
  }

  &__top-bar {
    --gsk-theme-primary: white;
    position: absolute;
    top: 0;
    right: 0;
    left: 0;
    height: 64px;

    &__left {
      display: flex;
      align-items: center;
    }

    &__title {
      display: flex;
      flex-direction: column;

      @include breakpoint($desktop) {
        flex-direction: row;
        justify-content: flex-start;
        align-content: center;
        align-items: center;
      }

      gsk-icon,
      .title {
        color: var(--theme-dark);
      }

      .text {
        display: none;
        color: var(--theme-medium);
        @include breakpoint($desktop) {
          display: block;
        }
      }

      .title {
        margin-left: 24px;
        text-transform: capitalize;
        @include breakpoint($desktop) {
          margin-left: 40px;
        }
      }

      .divider {
        height: 30px;
        width: 1px;
        background-color: var(--theme-lighter);
        margin: 0 16px;
        display: none;
        @include breakpoint($desktop) {
          display: block;
        }
      }
    }

    &__buttons {
      --gsk-theme-primary: var(--theme-primary);
      margin-right: 40px;
      display: flex;
      align-items: center;
      align-content: center;
    }
  }

  &__url-input {
    margin-top: 64px;
    padding: 24px 40px;
    text-align: right;
    border-top: 1px solid var(--theme-lighter);

    gsk-textfield,
    gsk-autocomplete {
      max-width: 328px;
      margin-left: auto;
    }
  }

  &__editor-viewer {
    width: 100%;
    height: calc(100vh - 64px - 105px);
    overflow-x: scroll;
    padding-top: 3rem;
    padding-bottom: 3rem;
    border-top: 1px solid var(--theme-lighter);
    &::v-deep {
      .tui-editor-contents {
        max-width: 800px;
        margin: 0 auto;
        @extend .gsk-markdown;
      }
    }
  }
}

.repo-search {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  text-align: right;
  gsk-textfield,
  gsk-autocomplete {
    margin: initial;
  }
}
</style>
