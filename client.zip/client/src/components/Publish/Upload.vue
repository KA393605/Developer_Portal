<template>
  <div class="upload-outer">
    <div class="upload" :class="{ open, 'docs-added': done }">
      <div class="upload__visible">
        <p class="f-overline upload__title">
          <gsk-icon v-if="done" class="upload__success">
            check_circle
          </gsk-icon>
          {{ sectionInfo.sectionName }}
          <span v-if="!meta.canDelete">*</span>
        </p>
        <gsk-icon-button
          v-if="showUp || showDown || meta.canRename || meta.canDelete"
          icon="more_vertical"
          officon="more_vertical"
          class="upload__caret"
          primary
          @click="showMenu"
        >
          more_vertical
        </gsk-icon-button>
        <div ref="menuContainer" class="menu-container">
          <gsk-menu ref="settingsMenu">
            <gsk-list class="settings-list">
              <gsk-list-item v-if="showUp" @click="up">
                <p class="f-body--small">Move Up</p>
              </gsk-list-item>
              <gsk-list-item v-if="showDown" @click="down">
                <p class="f-body--small">Move Down</p>
              </gsk-list-item>
              <gsk-list-item v-if="meta.canRename" @click="editClick">
                <p class="f-body--small">Rename Section</p>
              </gsk-list-item>
              <gsk-list-item v-if="meta.canDelete" class="menu-delete" @click="deleteOpen = true">
                <p class="f-body--small menu-delete">Delete Section</p>
              </gsk-list-item>
            </gsk-list>
          </gsk-menu>
        </div>
      </div>
      <div class="upload__hidden">
        <div
          v-if="canEditContent"
          id="markdown"
          class="upload__cell"
          :class="{ selected: isLocal }"
          @click="isLocal = true"
        >
          <div id="markdown-inner" class="upload__cell--left">
            <div class="flex-center">
              <div class="upload__cell__icon">
                <gsk-radio :checked="isLocal" primary :name="sectionInfo.sectionName"></gsk-radio>
              </div>
              <p class="f-body--small upload__cell__text">Import or add documentation</p>
            </div>
            <div v-if="done && isLocal" class="upload__cell__confirmation">
              <span class="f-caption">Documentation Added</span>
              <span class="f-caption clear" @click="clearSectionContent">Clear</span>
            </div>
          </div>
          <p v-if="isLocal" class="f-text-button--primary upload__cell__link" @click="clickedEdit">
            {{ uploadText }}
          </p>
          <portal to="publish-new">
            <markdown-editor
              v-if="isMarkdown && showEdit"
              :title="sectionInfo.sectionName"
              :text="editorText"
              :open.sync="showEdit"
              :index="index"
              @save="editorSave"
            ></markdown-editor>
            <open-api-spec-link
              v-if="isOpenApi && showEdit"
              :open.sync="showEdit"
              :doc-section="sectionInfo"
              :title="sectionInfo.sectionName"
              :link="link"
              :index="index"
              edit
              @save="editorSave"
            />
          </portal>
        </div>
        <div
          v-if="canLinkContent"
          id="link"
          class="upload__cell"
          :class="{ selected: !isLocal }"
          @click="isLocal = false"
        >
          <div id="link-inner" class="upload__cell--left">
            <div class="flex-center">
              <div class="upload__cell__icon">
                <gsk-radio
                  :checked.prop="!isLocal"
                  primary
                  :name="sectionInfo.sectionName"
                ></gsk-radio>
              </div>
              <p class="f-body--small upload__cell__text">
                <template v-if="forceGithub">
                  Add MyGithub URL to link to existing documentation
                </template>
                <template v-else>
                  Add URL to link to existing documentation
                </template>
              </p>
            </div>
            <div v-if="done && !isLocal" class="upload__cell__confirmation">
              <span class="f-caption">Documentation Added</span>
              <span class="f-caption clear" @click="clearSectionContent">Clear</span>
            </div>
          </div>
          <p v-if="!isLocal" class="f-text-button--primary upload__cell__link" @click="clickedLink">
            {{ uploadText }}
          </p>
          <portal to="publish-new">
            <open-api-spec-link
              v-if="isOpenApi && showLink"
              :open.sync="showLink"
              :title="sectionInfo.sectionName"
              :doc-section="sectionInfo"
              :link="link"
              :index="index"
              @save="editorSave"
            />
            <link-editor
              v-else-if="isMarkdown && showLink"
              :title="sectionInfo.sectionName"
              :open.sync="showLink"
              :link="link"
              :index="index"
              @save="editorSave"
            ></link-editor>
          </portal>
        </div>
      </div>
      <g-dialog
        v-if="meta.canRename || meta.canDelete"
        v-show="!deleteOpen"
        :open="dialogOpen"
        :acceptactiondisabled="modalVal.trim() === ''"
        headerlabel="Rename Section"
        acceptlabel="save"
        declinelabel="dismiss"
        @update:open="handleDialogOpen"
        @accept="editName"
      >
        <g-textfield
          v-model="modalVal"
          placeholder="Name your section"
          label="Section header"
          maxlength="40"
          required
          :disabled.prop="!meta.canRename"
          @keyup.enter.native="editName"
        ></g-textfield>
      </g-dialog>
      <delete-dialog
        v-if="meta.canDelete"
        :open.sync="deleteOpen"
        button-text="yes, delete section"
        headerlabel="Are you sure you want to delete?"
        @delete="deleteSection"
      >
        Deleting this section will also delete any attached documentation once your changes are
        published. This action cannot be reversed.
      </delete-dialog>
      <!-- my-github dialog -->
      <g-dialog
        v-if="forceGithub"
        :open.sync="githubDialogOpen"
        headerlabel="GitHub URL Required"
        declinelabel="dismiss"
        @accept="githubDialogOpen = false"
      >
        <p style="margin-bottom: 2rem;">
          To link to documentation for this listing type, you need to associate your listing with a
          repository on GSK Enterprise Github. If you don't have that information, you can import or
          manually add documentation through the text editor.
        </p>
        <github-repo-link></github-repo-link>
      </g-dialog>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop } from 'vue-property-decorator';
import { Menu } from '@gsk-platforms/gsk-menu/gsk-menu';
import { PublishingModule } from '@/store/modules/publishing.module';
import MarkdownEditor from '@/components/Publish/MarkdownEditor.vue';
import LinkEditor from '@/components/Publish/LinkEditor.vue';
import OpenApiSpecLink from '@/components/Publish/OpenApiSpecLink.vue';
import { DocumentationSection, ListingSection } from '@/types/listings.types';
import { GithubRepo, PublishingMode } from '@/types/publishing.types';
import { RequiredProp } from '@/utils/components';
import GButton from '@/components/gsk-components/GskButton.vue';
import GDialog from '@/components/gsk-components/GskDialog.vue';
import GTextfield from '@/components/gsk-components/GskTextfield.vue';
import DeleteDialog from '@/components/dialogs/DeleteDialog.vue';
import { ListingSectionTemplateTypes } from '@/constants';
import RepoPicker from '@/components/RepoPicker.vue';
import GithubRepoLink from '@/components/Publish/GithubRepoLink.vue';

@Component({
  components: {
    MarkdownEditor,
    LinkEditor,
    OpenApiSpecLink,
    GButton,
    GDialog,
    GTextfield,
    DeleteDialog,
    RepoPicker,
    GithubRepoLink,
  },
})
export default class UploadComponent extends Vue {
  @RequiredProp(Object) section!: DocumentationSection;
  @Prop(Boolean) open!: boolean;
  @Prop(Boolean) showArrows!: boolean;
  @Prop(Boolean) showUp!: boolean;
  @Prop(Boolean) showDown!: boolean;
  @Prop(Object) readonly flowState!: PublishingMode;
  @RequiredProp(Number) readonly index!: number;

  private dialogOpen: boolean = false;
  private deleteOpen: boolean = false;
  private modalVal: string = this.section.sectionInfo.sectionName;
  public initialMarkdown: string = PublishingModule.sampleMarkdown;
  public showEdit: boolean = false;
  public showLink: boolean = false;
  public isLocal: boolean = true;
  private githubDialogOpen: boolean = false;

  showMenu() {
    const menu = this.$refs.settingsMenu as Menu;
    menu.setAnchorCorner(menu.Corner.BOTTOM_START);
    menu.setAnchorElement(this.$refs.menuContainer as Element);
    menu.setAnchorMargin({ bottom: 16 });
    menu.open = !menu.open;
  }

  created() {
    if (this.done) {
      this.$log('created::done');
      this.isLocal = !this.link;
    } else {
      this.isLocal = this.canEditContent;
    }
  }

  get sectionInfo() {
    return this.section.sectionInfo;
  }

  get forceGithub(): boolean {
    return PublishingModule.listingTypeTemplate.publishing.githubRepo.canLink;
  }

  get githubLinked(): boolean {
    return !!PublishingModule.draftListing.extendedProperties.githubRepo;
  }

  get meta() {
    return this.section.meta;
  }

  get canEditContent(): boolean {
    // default section metadata can override overall template settings
    return PublishingModule.documentationSectionsMeta.canEditContent && this.meta.canEditContent;
  }

  get canLinkContent(): boolean {
    return PublishingModule.documentationSectionsMeta.canLinkContent && this.meta.canLinkContent;
  }

  get isOpenApi() {
    return this.sectionInfo.sectionTemplateType === ListingSectionTemplateTypes.OpenApi;
  }

  get isMarkdown() {
    return this.sectionInfo.sectionTemplateType === ListingSectionTemplateTypes.Markdown;
  }

  get done() {
    return !!this.sectionInfo.sectionContent || !!this.sectionInfo.sectionContentUrl;
  }

  get editorText() {
    if (!this.flowState.edit) {
      return this.sectionInfo.sectionContent || this.initialMarkdown;
    }
    return this.sectionInfo.sectionContent || '';
  }

  get link() {
    return this.sectionInfo.sectionContentUrl || '';
  }

  editClick(): void {
    this.dialogOpen = true;
  }

  editorSave(listingSection: ListingSection): void {
    PublishingModule.setDocumentationSection({
      documentationSection: {
        sectionInfo: listingSection,
        meta: this.meta,
      },
      index: this.index,
    });
  }

  handleDialogOpen(isOpen: boolean): void {
    this.modalVal = this.sectionInfo.sectionName;
    this.dialogOpen = isOpen;
  }

  editName(): void {
    if (!this.meta.canRename) {
      return;
    }
    if (this.modalVal.trim() === '') {
      return;
    }
    const documentationSection: DocumentationSection = {
      ...this.section,
      sectionInfo: {
        ...this.section.sectionInfo,
        sectionName: this.modalVal,
      },
    };
    PublishingModule.setDocumentationSection({ documentationSection, index: this.index });
    this.dialogOpen = false;
  }

  clearSectionContent(): void {
    const documentationSection: DocumentationSection = {
      ...this.section,
      sectionInfo: {
        ...this.section.sectionInfo,
        sectionContent: '',
      },
    };
    delete documentationSection.sectionInfo.sectionContentUrl;

    PublishingModule.setDocumentationSection({
      documentationSection,
      index: this.index,
    });
  }

  deleteSection(): void {
    PublishingModule.removeDocumentationSection(this.index);
    this.$emit('delete', this.index);
  }

  public clickedEdit(): void {
    this.showLink = false;
    this.showEdit = true;
  }

  public clickedLink(): void {
    if (this.forceGithub && !this.githubLinked) {
      this.githubDialogOpen = true;
    } else {
      this.showLink = true;
      this.showEdit = false;
    }
  }

  get uploadText(): string {
    return this.done ? 'Edit' : 'Add';
  }

  up() {
    PublishingModule.moveDocumentationSection({
      index: this.index,
      direction: 'up',
    });
  }

  down() {
    PublishingModule.moveDocumentationSection({
      index: this.index,
      direction: 'down',
    });
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/typography.scss';
@import '~@/styles/breakpoints.scss';
@import '~@/styles/theme.scss';

.github-input {
  display: flex;
  > * {
    flex: 1;
    &:first-child {
      margin-right: 1rem;
    }
    &:last-child {
      margin-left: 1rem;
    }
  }
}

.upload-outer {
  position: relative;
}
.arrows {
  display: flex;
  flex-direction: column;
  align-items: center;
  position: absolute;
  left: -1.5rem;

  > gsk-icon {
    cursor: pointer;
    color: $theme-primary;
  }
}

.upload {
  margin-bottom: 16px;
  border: 1px solid var(--theme-lighter);
  border-radius: 2px;
  padding: 19px 24px;
  cursor: pointer;
  box-shadow: 0 4px 10px 1px rgba(84, 79, 64, 0.14);

  &__visible,
  &__cell {
    position: relative;
    display: flex;
    justify-content: space-between;
    align-content: center;
    align-items: center;
  }

  &__title {
    margin: 0;
    color: var(--theme-medium);
    cursor: default;
    display: flex;
    align-content: center;
    align-items: center;
    /*user-select: none;*/
    /*pointer-events: none;*/

    .edit-icon {
      color: $theme-dark;
      font-size: 1rem;
      margin-left: 0.5rem;
      cursor: pointer;
    }
  }
  &__success {
    margin-right: 16px;
    font-size: 1rem;
    color: var(--theme-success);
  }

  &__caret {
    color: var(--theme-primary);
    position: absolute;
    right: -1rem;
    top: -0.6rem;
  }

  &__separator {
    background: var(--theme-white);
    position: absolute;
    top: 62px;
    left: calc(50% - 9px);
    padding: 0 1px 0 3px;
    color: var(--theme-medium);
    user-select: none;
    z-index: 2;
    + .upload__cell {
      border-top: 1px solid var(--theme-lighter);
    }
  }

  &__hidden {
    position: relative;
    display: none;
    padding-right: 2rem;
  }

  &.docs-added {
    .upload__cell:not(.selected) {
      pointer-events: none;
      color: var(--theme-light);
      gsk-radio {
        opacity: 0.3;
      }

      .upload__cell__text {
        color: var(--theme-light);
      }
    }
    /*
    .upload__caret {
      top: -20px;
    }
    */
  }

  &__cell {
    margin: 10px 0;

    &:last-child {
      padding-bottom: 0;
    }

    &__icon,
    &__text {
      display: inline-block;
      pointer-events: none;
      user-select: none;
    }

    &__icon {
      margin-right: 16px;
    }

    &__confirmation {
      margin-left: 56px;
      margin-top: -1rem;

      .clear {
        color: var(--theme-primary);
        margin-left: 8px;
      }
    }

    &--left {
    }

    &.selected {
      .upload__cell {
        &__text {
          color: var(--theme-dark);
        }
      }
    }

    &.uploaded {
      padding-bottom: 34px;

      + .upload__separator {
        top: 87px;
      }
    }
  }

  &.open {
    .upload {
      &__hidden {
        display: block;
      }

      &__caret {
        transform: rotate(180deg);
      }

      &__title {
        color: var(--theme-dark);
      }
    }
  }
}

.menu-container {
  position: relative;
  text-align: right;
  width: 160px;
}

.menu-delete {
  color: $theme-danger;
}
</style>
