<template>
  <div class="preview" :class="{ show: update(open) }">
    <gsk-top-app-bar class="preview__top-bar">
      <div slot="title" class="preview__top-bar__title">
        <div class="preview__top-bar__left">
          <gsk-icon-button
            slot="navigationIcon"
            icon="close"
            officon="close"
            class="close-icon"
            @click="cancel"
          />
          <span class="f-body title">
            Preview
          </span>
        </div>
      </div>
      <div slot="actionItems" class="preview__top-bar__buttons">
        <g-button unelevated :disabled="disabled" @click="save">
          Publish
        </g-button>
      </div>
    </gsk-top-app-bar>
    <div class="preview__pane">
      <listing-detail :listing="listing" :draft="true"></listing-detail>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Emit, Prop } from 'vue-property-decorator';
import ListingDetail from '@/views/ListingDetail.vue';
import { FullListing, DraftListingModule, ListingUser } from '@/types/listings.types';
import { Roles, RoleNames } from '@/constants';
import { PublishingModule } from '@/store/modules/publishing.module';
import GButton from '@/components/gsk-components/GskButton.vue';

@Component({
  components: {
    ListingDetail,
    GButton,
  },
})
export default class DraftPreviewWrapper extends Vue {
  @Prop() readonly open!: boolean;
  @Prop() readonly listing!: FullListing;

  public editorMode: string = 'preview';
  public file: string | null = null;

  public editorHeight: string = '';
  public defaultOptions: { hideModeSwitch: boolean } = { hideModeSwitch: false };

  @Emit('update:open')
  public update(isOpen: boolean): boolean {
    // this.$log('emitting open update', isOpen);
    if (isOpen) {
      // Need to get the height of the page, because with the preview editor,
      // you can't just put 'auto' or '100%' in height for some reason.
      if (document !== undefined && document.getElementById('app')) {
        this.$nextTick(() => {
          // @ts-ignore
          this.editorHeight = document.getElementById('app').clientHeight - 90 + 'px';
        });
      }
    }
    return isOpen;
  }

  public cancel(): void {
    this.update(false);
  }

  @Emit()
  public close(): void {
    this.update(false);
  }

  public get currentDraftListing(): FullListing {
    return this.listing;
  }

  public get disabled() {
    return !PublishingModule.publishEnabled;
  }

  get getOwners(): ListingUser[] {
    return this.currentDraftListing.listingUsers
      ? this.currentDraftListing.listingUsers
      : this.currentDraftListing.owners.map(user => {
          return {
            ...user,
            roleId: user.roleId ? user.roleId : Roles.Owner,
            roleName: RoleNames.Owner,
          };
        });
  }

  get transformedListing(): DraftListingModule {
    const $: FullListing = this.currentDraftListing;
    return {
      listingName: $.listingName,
      listingDescription: $.listingDescription,
      listingTypeId: $.listingTypeId,
      hasImage: !!($.extendedProperties && $.extendedProperties.image),
      registrationId: $.registrationId ? $.registrationId : 1,
      registrationVersionId: $.registrationVersionId ? $.registrationVersionId : 1,
      extendedProperties: $.extendedProperties,
      listingUsers: this.getOwners,
    };
  }

  async save() {
    this.$emit('publish');
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/typography.scss';
@import '~@/styles/breakpoints.scss';
@import '~@/styles/theme.scss';

.close-icon {
  --gsk-theme-secondary: #{$theme-darker};
}

.preview::v-deep {
  + .footer {
    display: none;
  }
}

.preview {
  height: 100vh;
  width: 100vw;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  position: relative;
  display: none;

  &.show {
    display: block;
    z-index: 5;
    position: absolute;
    background: var(--theme-white);
  }

  &__top-bar {
    --gsk-theme-primary: white;
    position: absolute;
    top: 0;
    right: 0;
    left: 0;
    height: 65px;
    border-bottom: 1px solid var(--theme-lighter);

    &__left {
      display: flex;
      align-items: center;
    }

    &__title {
      display: flex;
      flex-direction: column;

      @include breakpoint($desktop) {
        flex-direction: row;
        justify-content: flex-start;
        align-content: center;
        align-items: center;
      }

      gsk-icon,
      .title {
        color: var(--theme-dark);
      }

      .text {
        display: none;
        color: var(--theme-medium);
        @include breakpoint($desktop) {
          display: block;
        }
      }

      .title {
        margin-left: 24px;
        text-transform: capitalize;
        @include breakpoint($desktop) {
          margin-left: 40px;
        }
      }

      .divider {
        height: 30px;
        width: 1px;
        background-color: var(--theme-lighter);
        margin: 0 16px;
        display: none;
        @include breakpoint($desktop) {
          display: block;
        }
      }
    }

    &__buttons {
      --gsk-theme-primary: var(--theme-primary);
      margin-right: 40px;
      display: flex;
      align-items: center;
      align-content: center;
    }
  }

  &__mobile-save {
    display: block;
    margin: 64px auto 16px;
    text-align: center;

    @include breakpoint($desktop) {
      display: none;
    }
  }

  &__pane {
    margin-top: 65px;
    padding-bottom: 65px;
    height: calc(100% - 65px);
    overflow-y: scroll;
  }
}
</style>
