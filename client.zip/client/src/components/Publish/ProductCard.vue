<template>
  <form id="form" class="row">
    <div id="product-info">
      <div class="product-container">
        <h6 id="product-type">
          <template v-if="content.heading">
            {{ content.heading }}
          </template>
          <template v-else>
            Build your product card
          </template>
        </h6>
        <p class="f-body--small product-description">
          <template v-if="content.details">
            {{ content.details }}
          </template>
          <template v-else>
            This information will be surfaced on the card that will appear in the product catalog.
            Edit the fields below to build the card to the right.
          </template>
        </p>
        <g-textfield
          v-model="listingName"
          label="Name"
          class="select-field t-name"
          maxlength="50"
          required
        ></g-textfield>
        <g-textfield
          v-model="listingDescription"
          class="select-field t-description"
          type="textarea"
          label="Short Description"
          maxlength="500"
          required
        ></g-textfield>
        <gsk-image-upload
          v-if="needsImage"
          v-model="file"
          required
          label="Upload Image"
          accept="image/*"
          class="select-field"
          condensed
        ></gsk-image-upload>
        <gsk-input-chips
          class="select-field input-chip t-keywords"
          label="ADD KEYWORDS"
          breakchar=" "
          labeltooltiptext="Add keywords to enhance search results. Keywords will not appear in the listing."
          :value.prop="publishKeywords"
          @blur="addKeywords"
          @removal="addKeywords"
        ></gsk-input-chips>
        <g-button id="button" :disabled="disabled" @click.native="clicked">Next</g-button>
      </div>
    </div>
    <div class="card" @click.capture.prevent>
      <p class="f-overline card__title">PRODUCT CARD</p>
      <card class="one-card" :listing="draftListingCard"></card>
    </div>
  </form>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { InputChips } from '@gsk-platforms/gsk-input-chips/gsk-input-chips';
import GTextfield from '../gsk-components/GskTextfield.vue';
import GButton from '../gsk-components/GskButton.vue';
import Card from '../catalog/CardListWithHeader/ListingCard.vue';
import { PublishingModule } from '@/store/modules/publishing.module';
import GSelect from '@/components/gsk-components/GskSelect.vue';
import GImageUpload from '@/components/gsk-components/GskImageUpload.vue';
import { DraftListing } from '@/types/listings.types';

@Component({
  components: {
    GTextfield,
    GSelect,
    GButton,
    GskImageUpload: GImageUpload,
    Card,
  },
})
export default class ProductCard extends Vue {
  get content() {
    return PublishingModule.listingTypeTemplate.publishing.content.productCard;
  }

  get file(): string[] {
    return [PublishingModule.draftListing.extendedProperties.image].filter(i => i);
  }

  set file(f: string[]) {
    PublishingModule.setListingImage(f[0]);
  }

  get img() {
    return this.file[0] || 'no-image';
  }

  clicked() {
    PublishingModule.goToNextComponent();
  }

  get draftListingCard(): DraftListing {
    const d = PublishingModule.draftListing;
    return {
      ...d,
      listingId: -1,
      listingName: d.listingName || '<name>',
      listingDescription: d.listingDescription || '<description>',
      iconUrl: this.needsImage ? this.img : '',
      owners: [],
      versions: [],
    };
  }

  get listingName(): string {
    return PublishingModule.draftListing.listingName;
  }

  set listingName(name: string) {
    PublishingModule.updateListingName(name);
  }

  get listingDescription(): string {
    return PublishingModule.draftListing.listingDescription;
  }

  set listingDescription(words: string) {
    PublishingModule.updateListingDescription(words);
  }

  get needsImage() {
    return PublishingModule.listingTypeTemplate.publishing.info.acceptImage;
  }

  get disabled(): boolean {
    const conds = [this.listingName === '', this.listingDescription === ''];
    if (this.needsImage) {
      conds.push(this.file[0] === '');
    }
    return conds.some(b => b);
  }

  get listingTypeId(): number {
    return PublishingModule.draftListing.listingTypeId;
  }

  get publishKeywords(): string {
    return PublishingModule.draftListing.extendedProperties.keywords.join(' ');
  }

  async addKeywords(value: CustomEvent) {
    const updated = (value.target as InputChips).updateComplete;
    let i = 0;
    while (!(await updated)) {
      // wait for the updates to complete
      if (++i > 4) {
        // don't wait forever
        break;
      }
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const keywords: string[] = (value.target as any).chipSet.chips.map(
      (chip: { label: { toLowerCase: () => string } }) => chip.label.toLowerCase().trim(),
    );
    PublishingModule.updateKeywords(keywords.flatMap(v => v.split(/,/g)).filter(w => !!w));
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/breakpoints.scss';
@import '~@/styles/theme.scss';

@media only screen and (max-width: 1205px) {
  #form {
    display: grid;
    grid-template-columns: 1fr;
    grid-template-rows: 1fr 1fr;
    grid-auto-rows: minmax(100px, auto);
    grid-auto-columns: minmax(100px, auto);
    grid-row: 1 / 3;
    max-width: 488px;
    margin: 0 auto;
  }
}

.row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  grid-auto-columns: minmax(100px, auto);
}

.card {
  align-self: flex-start;
  justify-self: center;
  max-width: 280px;
  width: 100%;

  &__title {
    margin: 0 0 24px 0;
    color: var(--theme-medium);
  }
}

.product-container {
  max-width: 488px;
}

.col {
  margin-left: 30px;
}

hr {
  width: 1px;
  transform: rotate(90deg);
  color: #efefed;
}

.select-title {
  display: block;
  margin-top: 25px;
}

.input-chip {
  --gsk-theme-secondary: #{$theme-darker};
  --gsk-theme-on-secondary: #{$theme-white};
}

#product-type {
  margin: 0 0 16px 0;
}

.product-description {
  margin-bottom: 0;
  padding-bottom: 8px;
}

.select-field {
  border-radius: 2px;
  margin-top: 24px;

  &.t-name,
  &.t-description {
    margin-top: 16px;
  }

  &[maxlength]:not([type='textarea']) + .select-field {
    margin-top: 24px - 19px;
  }
}

#select {
  text-transform: capitalize;
}

#button {
  float: right;
  margin-top: 32px;
  margin-bottom: 10px;
}
</style>
