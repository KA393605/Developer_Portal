<template>
  <div ref="markdownContainer" class="editor markdown" :class="{ show: update(open) }">
    <gsk-top-app-bar class="markdown__top-bar">
      <div slot="title" class="markdown__top-bar__title">
        <div class="markdown__top-bar__left">
          <gsk-icon-button
            slot="navigationIcon"
            icon="close"
            officon="close"
            class="close-icon"
            @click="close"
          />
        </div>
        <span class="f-overline text link__right" style="margin-left: 1rem;">
          Import or add documentation
        </span>
      </div>
      <div slot="actionItems" class="markdown__top-bar__buttons">
        <file-select
          title="Import Markdown"
          accept=".md"
          @load="displayText = $event"
        ></file-select>
        <g-button unelevated style="margin-left: 1rem;" @click="save">
          Save documentation
        </g-button>
      </div>
    </gsk-top-app-bar>
    <div class="markdown__editor-viewer">
      <editor
        ref="editor"
        v-model="displayText"
        :options="defaultOptions"
        :height="editorHeight"
        :mode="editorMode"
        preview-style="vertical"
      />
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Emit, Prop } from 'vue-property-decorator';

// Markdown Editor
import 'tui-editor/dist/tui-editor.css';
// eslint-disable-next-line import/no-extraneous-dependencies
import 'codemirror/lib/codemirror.css';

import FullScreenForm from '@/components/FullScreenForm.vue';
import FileSelect from '@/components/catalog/FileSelect/FileSelect.vue';
import { RequiredProp } from '@/utils/components';
import { ListingSectionTemplateTypeIds, ListingSectionTemplateTypes } from '@/constants';
import { ListingSection } from '@/types/listings.types';
import GButton from '@/components/gsk-components/GskButton.vue';

@Component({
  components: {
    FullScreenForm,
    Editor: () => import('@toast-ui/vue-editor/src/Editor.vue'),
    FileSelect,
    GButton,
  },
})
export default class MarkdownEditor extends Vue {
  @Prop() readonly title!: string;
  @Prop() readonly open!: boolean;
  @Prop() text!: string;
  @RequiredProp(Number) readonly index!: number;

  public disabled: boolean = true;
  public displayText: string = this.text || '';
  public editorMode: string = 'wysiwyg';
  public file: string = '';

  public editorHeight: string = '';
  public defaultOptions = { hideModeSwitch: false, minHeight: '590px' };

  @Emit('update:open')
  update(isOpen: boolean): boolean {
    // this.$log('emitting open update', isOpen);
    if (isOpen) {
      // Need to get the height of the page, because with the markdown editor,
      // you can't just put 'auto' or '100%' in height for some reason. But
      // it does cause the markdown editor to not show until you click into it.
      if (document !== undefined && document.getElementById('app')) {
        this.$nextTick(() => {
          // @ts-ignore
          this.editorHeight = document.getElementById('app').clientHeight - 95 + 'px';
        });
      }
    }
    return isOpen;
  }

  public cancel(): void {
    this.update(false);
  }

  public get pageTitle(): string {
    return this.title;
  }

  public close(): void {
    this.update(false);
  }

  public save(): void {
    const listingSection: ListingSection = {
      sectionName: this.title,
      sectionTemplateType: ListingSectionTemplateTypes.Markdown,
      sectionContent: this.displayText,
      sectionTemplateTypeId: ListingSectionTemplateTypeIds[ListingSectionTemplateTypes.Markdown],
    };

    this.$emit('save', listingSection);
    this.close();
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/typography.scss';
@import '~@/styles/breakpoints.scss';
@import '~@/styles/markdown.scss';
@import '~@/styles/table.scss';
@import '~@/styles/theme.scss';

.close-icon {
  --gsk-theme-secondary: #{$theme-darker};
}

.editor::v-deep {
  height: auto;
  flex: 1;
  &__content {
    flex-direction: column;
    align-items: center;

    @include breakpoint($desktop) {
      flex-direction: row;
    }
  }

  .max-width__content {
    max-width: 100%;
    padding: 0;
  }

  + .footer {
    display: none;
  }
}

.markdown {
  height: 100vh;
  width: 100vw;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  position: relative;
  display: none;

  &.show {
    display: block;
    z-index: 5;
    position: absolute;
    background: var(--theme-white);
  }

  &__top-bar {
    --gsk-theme-primary: white;
    position: absolute;
    top: 0;
    right: 0;
    left: 0;
    height: 64px;
    border-bottom: 1px solid var(--theme-lighter);

    &__left {
      display: flex;
      align-items: center;
    }

    &__title {
      display: flex;
      flex-direction: column;

      @include breakpoint($desktop) {
        flex-direction: row;
        justify-content: flex-start;
        align-content: center;
        align-items: center;
      }

      gsk-icon,
      .title {
        color: var(--theme-dark);
      }

      .text {
        display: none;
        color: var(--theme-medium);
        @include breakpoint($desktop) {
          display: block;
        }
      }

      .title {
        margin-left: 24px;
        text-transform: capitalize;
        @include breakpoint($desktop) {
          margin-left: 40px;
        }
      }

      .divider {
        height: 30px;
        width: 1px;
        background-color: var(--theme-lighter);
        margin: 0 16px;
        display: none;
        @include breakpoint($desktop) {
          display: block;
        }
      }
    }

    &__buttons {
      --gsk-theme-primary: var(--theme-primary);
      margin-right: 40px;
      display: flex;
      align-items: center;
      align-content: center;
    }
  }

  &__editor-viewer {
    width: 100%;
    margin-top: 64px;
    &::v-deep {
      .tui-editor-defaultUI {
        border: none;

        &-toolbar {
          height: auto;
          overflow: auto;
          padding: 8px 16px;
        }

        .CodeMirror-line {
          padding-left: 16px;
          padding-right: 25px;
          @include breakpoint($desktop) {
            padding: 0;
          }
        }

        .te-preview {
          padding-top: 24px;
          padding-right: 16px;
          word-break: break-word;
          * {
            padding-top: 0;
            margin-top: 0;
          }
        }

        .CodeMirror-lines,
        .te-preview {
          @include breakpoint($desktop) {
            padding: 64px 64px 0;
          }
        }
        .tui-editor-contents {
          @extend .gsk-markdown;
          * {
            font-family: 'Arial', sans-serif;
          }
          table {
            @extend .gsk-table;
          }
          th {
            @extend .gsk-th;
          }
          td {
            @extend .gsk-td;
          }
          pre,
          code {
            font-family: 'Source Code Pro', monospace;
          }
          a {
            code {
              color: $theme-primary;
              font-family: 'Source Code Pro', monospace;
            }
            color: $theme-primary;
          }
        }
        .te-ww-mode {
          .tui-editor-contents {
            max-width: 800px;
            width: 100%;
            margin: 0 auto;
          }
        }
      }
      .te-toolbar-section {
        height: auto;
        border-bottom: 1px solid var(--theme-lighter);
        border-top: 1px solid var(--theme-lighter);

        // this section does not like top and bottom padding. and disappears if
        @include breakpoint($desktop) {
          padding-left: 64px;
        }
      }
      .te-mode-switch-section {
        background-color: var(--theme-white);
        padding: 16px 40px;
        .te-mode-switch {
          button {
            @extend .f-body--small;
            position: relative;

            &:first-child::after {
              content: '';
              position: absolute;
              height: 16px;
              width: 1px;
              background: var(--theme-lighter);
              top: 5px;
              bottom: 0;
              right: -5px;
            }

            &.active {
              color: var(--theme-primary);
            }
          }
        }
      }
    }
  }
}
</style>
