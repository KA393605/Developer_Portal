<template>
  <div>
    <gsk-list-item id="one-list-item">
      <gsk-chip :label="user.fullName" :avatar="userInitials(user.fullName)"></gsk-chip>
      <gsk-label id="one-label" slot="meta">
        {{ user.roleName.charAt(0).toUpperCase() + user.roleName.substr(1) }}
      </gsk-label>
      <gsk-icon-button
        v-if="user.roleId > 1"
        slot="meta"
        icon="keyboard_arrow_up"
        officon="keyboard_arrow_down"
        noripple
        @click="showMenu"
      ></gsk-icon-button>
    </gsk-list-item>
    <gsk-menu slot="meta" ref="removeUserMenu" class="removeUserMenu">
      <gsk-list>
        <gsk-list-item ref="itemMenuAnchor" :value="user.mudId" @click="removeFromListing">
          Remove from listing
        </gsk-list-item>
      </gsk-list>
    </gsk-menu>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import { Menu } from '@gsk-platforms/gsk-menu/gsk-menu';
import { BaseUser } from '@/types/users.types';

type GskMenu = Menu;

@Component({
  components: {},
})
export default class PermissionList extends Vue {
  @Prop() readonly user!: BaseUser;

  showMenu() {
    const menu = this.$refs.removeUserMenu as GskMenu;
    menu.setAnchorElement(this.$refs.itemMenuAnchor as Element);
    menu.setAnchorCorner(menu.Corner.TOP_LEFT);
    menu.setAnchorMargin({ left: 254 });
    menu.open = !menu.open;
  }

  userInitials(userFullName: string): string {
    const userNameArr = userFullName.split(' ');
    return userNameArr[0].slice(0, 1) + userNameArr[1].slice(0, 1);
  }

  removeFromListing() {
    this.$emit('remove', this.user.mudId);
  }
}
</script>

<style lang="scss" scoped>
.removeUserMenu {
  position: relative;
  text-align: right;
  width: 168px;
  object-fit: contain;
}

#product-type {
  font-size: 24px;
  font-weight: bold;
  line-height: 1.67;
  color: #4a4a4a;
  display: block;
}

#one-list-item {
  border-bottom: 5px solid black;
}

.owner-list {
  list-style: none;
  margin-left: -40px;
}

.select-field {
  border-radius: 2px;
  margin-top: 10px;
}

.label-field {
  display: block;
  margin-top: 25px;
}

#list-wrapper {
  margin-top: 35px;
}

#select {
  text-transform: capitalize;
}

#button {
  margin-top: 32px;
  margin-bottom: 10px;
}

#button-div {
  justify-self: center;
}

.button-class {
  width: 128px;
}
</style>
