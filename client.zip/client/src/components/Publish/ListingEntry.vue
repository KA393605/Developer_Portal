<template>
  <tbody>
    <template v-if="listing.versions.length">
      <listing-table-row
        v-for="(lv, i) in listing.versions"
        :key="lv.listingVersionId"
        :listing="listing"
        :listing-version="listing"
        :is-admin-mode="isAdminMode"
        :first="i === 0"
        :open.sync="open"
        v-on="$listeners"
      />
      <tr v-if="open">
        <td colspan="8" style="text-align: right" class="version">
          <g-button icon="plus" type="text" @click.native="add(listing)">
            add new version
          </g-button>
        </td>
      </tr>
    </template>
    <template v-else>
      <listing-table-row
        :listing="listing"
        :listing-version="listing"
        :is-admin-mode="isAdminMode"
        :first="true"
        :open="false"
        v-on="$listeners"
      ></listing-table-row>
    </template>
  </tbody>
</template>

<script lang="ts">
import { Component, Emit, Vue, Prop } from 'vue-property-decorator';
import { RequiredProp } from '@/utils/components';
import { MyListing } from '@/types/publishing.types';
import GButton from '@/components/gsk-components/GskButton.vue';
import ListingTableRow from '@/components/Publish/ListingTableRow.vue';

@Component({
  components: {
    GButton,
    ListingTableRow,
  },
})
export default class ListingEntry extends Vue {
  @RequiredProp(Object) readonly listing!: MyListing;
  @Prop(Boolean) readonly isAdminMode!: boolean;
  private open: boolean = false;

  @Emit('add')
  add(listing: MyListing) {}
}
</script>

<style lang="scss" scoped>
@import '~@/styles/theme.scss';
.version {
  padding-top: 13px;
  padding-bottom: 13px;
}
</style>
