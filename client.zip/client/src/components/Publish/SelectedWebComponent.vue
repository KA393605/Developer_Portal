<template>
  <section>
    <g-textfield label="library"></g-textfield>
    <g-button class="button" :disabled="disabled" style="margin-top: 2rem;" @click="next">
      Next
    </g-button>
  </section>
</template>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import GButton from '../gsk-components/GskButton.vue';
import { PublishingModule } from '@/store/modules/publishing.module';
import { GithubRepo } from '@/types/publishing.types';
import RepoPicker from '@/components/RepoPicker.vue';

@Component({
  components: {
    GButton,
    RepoPicker,
  },
})
export default class SelectedWebComponent extends Vue {
  repo: GithubRepo | null = null;

  next() {
    PublishingModule.goToNextComponent();
  }
  get disabled() {
    return false;
  }
}
</script>
<style scoped>
.button {
  float: right;
  margin-bottom: 10px;
}
</style>
