<template>
  <div class="editor markdown" :class="{ show: open, edit }">
    <gsk-top-app-bar class="markdown__top-bar">
      <div slot="title" class="markdown__top-bar__title">
        <div class="markdown__top-bar__left">
          <gsk-icon-button
            slot="navigationIcon"
            icon="close"
            officon="close"
            class="close-icon"
            @click="close"
          />
          <span class="f-body title">
            {{ title }}
          </span>
        </div>
        <span class="divider"></span>
        <span class="f-overline text markdown__right">
          <template v-if="edit">
            import or add documentation
          </template>
          <template v-else>
            Specify url to link open api spec
          </template>
        </span>
      </div>
      <div slot="actionItems" class="markdown__top-bar__buttons">
        <file-select
          v-if="edit"
          class="file-button"
          title="Import API Spec"
          accept=".json, .yml, .yaml"
          @load="loadCode"
        ></file-select>
        <g-button unelevated :disabled="isDisabled" @click="saveDoc">
          Save documentation
        </g-button>
      </div>
    </gsk-top-app-bar>
    <div id="editors-wrapper" class="full-height">
      <div v-if="!edit" id="textbox-wrapper">
        <g-textfield
          id="textfield"
          :value="userURL"
          placeholder="Enter link to API Spec"
          outlined
          :float-label="false"
          @input="handleUrlUpdate"
        ></g-textfield>
      </div>
      <div id="box" class="gsk-layout-grid rest-height" :class="{ edit }">
        <div class="gsk-layout-grid__inner full-height">
          <div id="monaco-container" class="gsk-layout-grid__cell--span-6 full-height">
            <monaco-editor
              id="monaco-editor"
              v-model="code"
              class="full-height"
              :language="editorLanguage"
              :options="monacoOptions"
              @editorDidMount="editorDidMount"
            ></monaco-editor>
          </div>
          <div id="rapi-container" class="gsk-layout-grid__cell--span-6 full-height overflowY">
            <rapi-doc
              v-show="!!code"
              :spec-url="specUrl"
              class="rapidoc"
              theme="light"
              show-header="false"
              show-info
              allow-authentication="false"
              allow-spec-file-load="false"
              layout="column"
              allow-try="false"
              primary-color="#f36633"
              regular-font="Arial"
              mono-font="Source Code Pro"
            ></rapi-doc>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Emit, Watch, Prop } from 'vue-property-decorator';
import debounce from 'lodash/debounce';
import * as API from '@/api/github.api';
import GTextfield from '@/components/gsk-components/GskTextfield.vue';
import { RequiredProp } from '@/utils/components';
import { getProxyUrl } from '@/api/service/urls';
import { ListingSectionTemplateTypeIds, ListingSectionTemplateTypes } from '@/constants';
import GButton from '@/components/gsk-components/GskButton.vue';
import FileSelect from '@/components/catalog/FileSelect/FileSelect.vue';
import { ListingSection } from '@/types/listings.types';

@Component({
  components: {
    'monaco-editor': () => import('vue-monaco'),
    GTextfield,
    GButton,
    FileSelect,
  },
})
export default class OpenApiSpecLink extends Vue {
  @Prop() readonly open!: boolean;
  @Prop() readonly title!: string;
  @Prop() readonly link!: string;
  @RequiredProp(Object) readonly docSection!: ListingSection;
  @RequiredProp(Number) readonly index!: number;
  @Prop(Boolean) readonly edit!: boolean;

  // private editor: import('monaco-editor').editor.IEditor | null = null;
  private editor: any = null;

  public userURL: string = '';

  public repoName: string = '';
  public code: string = '';
  public specUrl: string = '';

  public onResize = debounce(this.resizeEditor.bind(this), 200);

  created() {
    this.$log('created');
    window.addEventListener('resize', this.onResize);
    if (!this.edit) {
      this.handleUrlUpdate(this.link);
    } else {
      this.code = this.docSection.sectionContent;
    }
  }

  beforeDestroy() {
    window.removeEventListener('resize', this.onResize);
  }

  get editorLanguage() {
    try {
      JSON.parse(this.code);
      return 'json';
    } catch (e) {
      return 'yaml';
    }
  }

  get monacoOptions(): import('monaco-editor').editor.IEditorConstructionOptions {
    return {
      readOnly: !this.edit,
      formatOnPaste: true,
      formatOnType: true,
      minimap: {
        enabled: false,
      },
    };
  }

  loadCode(fileCode: string): void {
    this.code = fileCode;
  }

  @Watch('code')
  public handleResize() {
    if (this.edit) {
      this.specUrl = this.makeFileUrl(this.code);
    }
    this.resizeEditor();
  }

  public makeFileUrl(str: string): string {
    URL.revokeObjectURL(this.specUrl);
    return URL.createObjectURL(new Blob([str], { type: 'text/json' }));
  }

  public resizeEditor() {
    if (this.editor) {
      this.editor.layout();
    }
  }

  get isDisabled(): boolean {
    if (this.edit) {
      return !this.code;
    }
    return !this.userURL;
  }

  @Emit('update:open')
  public update(isOpen: boolean): boolean {
    return isOpen;
  }

  handleUrlUpdate(value: string) {
    this.userURL = value.trim();
    this.getExternalLink();
  }

  async getExternalLink() {
    if (this.userURL) {
      this.specUrl = getProxyUrl(this.userURL);
      const result = (await API.getExternalDocumentation(this.userURL)).data;
      this.code = typeof result === 'string' ? result : JSON.stringify(result, null, 2);
    }
  }

  saveDoc() {
    const sectionTemplateType = ListingSectionTemplateTypes.OpenApi;
    const listingSection = {
      sectionName: this.title,
      sectionTemplateType,
      sectionContentUrl: this.userURL,
      sectionContent: '',
      sectionTemplateTypeId: ListingSectionTemplateTypeIds[sectionTemplateType],
    };
    if (this.edit) {
      delete listingSection.sectionContentUrl;
      listingSection.sectionContent = this.code;
    }

    this.$emit('save', listingSection);
    this.close();
  }

  public close(): void {
    this.update(false);
  }

  editorDidMount(editor: import('monaco-editor').editor.ICodeEditor) {
    editor.onDidChangeModelLanguageConfiguration(() => {
      this.$log('editor lang change');
      editor.getAction('editor.action.formatDocument').run();
    });
    this.editor = editor;
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/typography.scss';
@import '~@/styles/breakpoints.scss';
@import '~@/styles/theme.scss';

$textbox-wrapper-height: 105px;
$header-height: 64px;

.file-button {
  margin-right: 1rem;
}
#textbox-wrapper {
  width: 100vw;
  border-bottom: 1px solid #efefed;
  display: flex;
  justify-content: flex-end;
  align-items: center;
  padding: 24px 40px;
  height: $textbox-wrapper-height;

  .tf {
    min-width: 328px;
  }
}

.rest-height {
  height: calc(100% - #{$header-height} - #{$textbox-wrapper-height});
  &.edit {
    height: calc(100% - #{$header-height});
  }
}

.overflowY {
  overflow-y: scroll;
}

#textfield {
  max-width: 328px;
}

#editors-block {
  display: block;
}

#box {
  max-width: 100%;
  width: 100%;
  padding: 0;
}
.gsk-layout-grid__inner {
  grid-gap: 0;
}
#editors-wrapper {
  margin-top: $header-height;
  border-top: 1px solid var(--theme-lighter);
  height: 100%;
}
#monaco-container,
#rapi-container {
  padding: 0;
}
#monaco-editor {
  width: 100%;
  padding-top: 15px;
}

.close-icon {
  --gsk-theme-secondary: #{$theme-darker};
}

.rapidoc {
  min-width: 800px;
}

.editor {
  height: 100vh;
  width: 100vw;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  position: relative;
  display: none;

  &.show {
    display: block;
    z-index: 5;
    position: absolute;
    background: var(--theme-white);
  }
}
.editor::v-deep {
  // .full-screen-form {
  height: auto;
  flex: 1;
  &__content {
    flex-direction: column;
    align-items: center;

    @include breakpoint($desktop) {
      flex-direction: row;
    }
  }
  // }

  .max-width__content {
    max-width: 100%;
    padding: 0;
  }

  + .footer {
    display: none;
  }
}

.markdown {
  position: relative;

  &__top-bar {
    --gsk-theme-primary: white;
    position: absolute;
    top: 0;
    right: 0;
    left: 0;
    border-bottom: 1px solid var(--theme-lighter);

    &__left {
      display: flex;
      align-items: center;
    }

    &__title {
      display: flex;
      flex-direction: column;

      @include breakpoint($desktop) {
        flex-direction: row;
        justify-content: flex-start;
        align-content: center;
        align-items: center;
      }

      gsk-icon,
      .title {
        color: var(--theme-dark);
      }

      .text {
        display: none;
        color: var(--theme-medium);
        @include breakpoint($desktop) {
          display: block;
        }
      }

      .title {
        margin-left: 24px;
        text-transform: capitalize;
        @include breakpoint($desktop) {
          margin-left: 40px;
        }
      }

      .divider {
        height: 30px;
        width: 1px;
        background-color: var(--theme-lighter);
        margin: 0 16px;
        display: none;
        @include breakpoint($desktop) {
          display: block;
        }
      }
    }

    &__buttons {
      --gsk-theme-primary: var(--theme-primary);
      margin-right: 40px;
      display: flex;
      align-items: center;
      align-content: center;
    }
  }

  &__editor-viewer {
    width: 100%;
    padding-top: 8px;

    &::v-deep {
      .tui-editor-defaultUI {
        border: none;

        &-toolbar {
          height: auto;
          overflow: auto;
          padding: 8px 16px;

          @include breakpoint($desktop) {
            padding-top: 32px;
            padding-bottom: 32px;
            padding-left: 64px;
          }
        }

        .CodeMirror-line {
          padding-left: 16px;
          padding-right: 25px;
          @include breakpoint($desktop) {
            padding: 0;
          }
        }

        .te-preview {
          padding-top: 24px;
          padding-right: 16px;
          word-break: break-word;
          * {
            padding-top: 0;
            margin-top: 0;
          }
        }

        .CodeMirror-lines,
        .te-preview {
          @include breakpoint($desktop) {
            padding: 64px 64px 0;
          }
        }
      }
      .te-toolbar-section {
        border: none;
        height: auto;
        border-bottom: 1px solid var(--theme-lighter);
      }
      .te-mode-switch-section {
        background-color: var(--theme-white);
        padding: 16px 40px;
        .te-mode-switch {
          button {
            @extend .f-body--small;
            position: relative;

            &:first-child::after {
              content: '';
              position: absolute;
              height: 16px;
              width: 1px;
              background: var(--theme-lighter);
              top: 5px;
              bottom: 0;
              right: -5px;
            }

            &.active {
              color: var(--theme-primary);
            }
          }
        }
      }
    }
  }
}
</style>
