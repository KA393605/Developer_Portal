<template>
  <section id="product-details">
    <template v-if="!isEdit">
      <h6 class="heading top">Select Product Type</h6>
      <p class="description">Select which type of product you’d like to publish to the catalog.</p>
      <g-select
        v-if="options.length"
        v-model="listingType"
        class="select-field"
        label="Select Product Type"
        :options="options"
        placeholder="Select"
        required
      ></g-select>
    </template>
    <template v-if="isCustomComponent">
      <component :is="productDetailsComponent">
        <template v-if="!isEdit">
          <h6 v-if="content.heading" class="f-subtitle heading">{{ content.heading }}</h6>
          <p v-if="content.subheading" class="description f-body--small">
            {{ content.subheading }}
          </p>
        </template>
        <template v-else>
          <h6 v-if="content.heading" class="heading top">{{ content.heading }}</h6>
          <p v-if="content.subheading" class="description">
            {{ content.subheading }}
          </p>
        </template>
        <template v-slot:repo>
          <github-repo-link></github-repo-link>
        </template>
      </component>
    </template>
    <template v-else>
      <template v-if="!isEdit">
        <h6 v-if="content.heading" class="f-subtitle heading">{{ content.heading }}</h6>
        <p v-if="content.subheading" class="description f-body--small">
          {{ content.subheading }}
        </p>
      </template>
      <template v-else>
        <h6 v-if="content.heading" class="heading top">{{ content.heading }}</h6>
        <p v-if="content.subheading" class="description">
          {{ content.subheading }}
        </p>
      </template>
      <github-repo-link></github-repo-link>
      <generated-form v-model="productDetails" @valid="valid = $event"></generated-form>
      <g-button v-if="listingType" class="next-button" :disabled="!ghValid" @click="next">
        Next
      </g-button>
    </template>
  </section>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import GSelect from '@/components/gsk-components/GskSelect.vue';
import { PublishingModule } from '@/store/modules/publishing.module';
import GButton from '@/components/gsk-components/GskButton.vue';
import { FormField, SelectOption } from '@/components/form/form.types';
import GeneratedForm from '@/components/form/GeneratedForm.vue';
import SelectedApi from '@/components/Publish/SelectedApi.vue';
import SelectedMobileComponent from '@/components/Publish/SelectedMobileComponent.vue';
import GithubRepoLink from '@/components/Publish/GithubRepoLink.vue';

@Component({
  components: {
    GSelect,
    GButton,
    GeneratedForm,
    SelectedApi,
    SelectedMobileComponent,
    GithubRepoLink,
  },
})
export default class ProductDetails extends Vue {
  public label: string = 'Select Product*';
  public ready: boolean = false;
  public valid: boolean = false;

  get isEdit() {
    return PublishingModule.mode.edit;
  }

  get content() {
    const d = PublishingModule.listingTypeTemplate.publishing.content.details;
    if (this.isEdit) {
      return d.edit;
    }
    return d;
  }

  get ghValid(): boolean {
    if (this.valid) {
      return PublishingModule.linkedGithubRepoValid;
    }
    return false;
  }

  get options(): SelectOption[] {
    return PublishingModule.listingTypes.map(o => ({
      value: o.listingTypeId.toString(),
      label: o.name,
      extra: o.template,
    }));
  }

  set listingType(listingTypeId) {
    PublishingModule.setListingTypeId(listingTypeId);
    const opt = this.options.find(o => o.value === listingTypeId);
    if (opt) {
      PublishingModule.createExtendedPropertiesFromTemplate(opt.extra);
    }
  }

  get listingType(): string {
    const id = PublishingModule.draftListing.listingTypeId;
    if (id) {
      return id.toString();
    }
    return '';
  }

  get productDetails(): FormField[] {
    return PublishingModule.draftListing.extendedProperties.details;
  }

  set productDetails(form: FormField[]) {
    PublishingModule.setDetailsForm(form);
  }

  next() {
    PublishingModule.goToNextComponent();
  }

  get listingTypeId() {
    return PublishingModule.draftListing.listingTypeId;
  }

  get isCustomComponent() {
    return PublishingModule.listingTypeTemplate.publishing.details.isCustomComponent;
  }

  get productDetailsComponent() {
    // this is bad and i know it
    return [null, SelectedApi, null, SelectedMobileComponent, null, null][this.listingTypeId];
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/breakpoints.scss';

.heading {
  margin-bottom: 1rem;
  &.top {
    margin-top: 0;
    margin-bottom: 1rem;
  }
}

.select-field {
  margin-bottom: 2rem;
}

.description {
  margin-bottom: 2rem;
  margin-top: 0;
}

.next-button {
  float: right;
}

#product-details {
  &::v-deep {
    p.f-body--small {
      margin-bottom: 2rem;
      margin-top: 0;
    }
  }

  max-width: 488px;
  margin: 0 auto;
  @include breakpoint($desktop) {
    margin: 0 auto 0 0;
  }
}
</style>
