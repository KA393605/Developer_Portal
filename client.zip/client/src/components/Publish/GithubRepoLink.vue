<template>
  <repo-picker
    v-if="repoInfo.canLink"
    v-model="repo"
    :required="repoInfo.required"
    none-option
    class="picker"
    labeltooltiptext="To see your repo in the list below, you need to be the owner or added as a 'Collaborator' due to limitations of the GitHub API"
  ></repo-picker>
</template>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { PublishingModule } from '@/store/modules/publishing.module';
import { GithubRepo } from '@/types/publishing.types';
import RepoPicker from '@/components/RepoPicker.vue';

@Component({
  components: {
    RepoPicker,
  },
})
export default class GithubRepoLink extends Vue {
  get repo() {
    return PublishingModule.draftListing.extendedProperties.githubRepo;
  }

  set repo(repo: GithubRepo | null) {
    PublishingModule.linkGithubRepo(repo);
  }

  get disabled() {
    return false;
  }

  get repoInfo() {
    return PublishingModule.listingTypeTemplate.publishing.githubRepo;
  }
}
</script>
<style scoped>
.picker {
  margin-bottom: 2rem;
}
</style>
