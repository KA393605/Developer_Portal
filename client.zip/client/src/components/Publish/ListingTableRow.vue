<template>
  <tr :class="{ open }">
    <td v-if="false" @click="toggle">
      <gsk-icon v-if="first" class="toggle" :class="{ open }">
        gsk_keyboard_arrow_down
      </gsk-icon>
    </td>
    <td colspan="2">
      <router-link v-if="first && lv.publishDate" :to="listingVersionLink">
        <span v-if="first" class="name f-body--small">
          {{ listing.listingName }}
        </span>
      </router-link>
      <span v-else-if="first" class="name f-body--small">
        {{ listing.listingName }}
      </span>
    </td>
    <td>
      <span v-if="first" class="f-body--small">{{ listingType }}</span>
    </td>
    <!--    <td>v{{ lv.versionId }}</td>-->
    <td>
      <user-list :users="listing.listingUsers" truncate expandable></user-list>
    </td>
    <td v-if="isPublished">
      <p class="f-body--small status">{{ lv.statusName }}</p>
      <div class="publish-date f-caption" :title="publishDateLong">
        Last Published {{ publishDateRelative }}
      </div>
    </td>
    <td v-else>
      <p class="f-body--small">{{ lv.statusName }}</p>
    </td>
    <td :title="updateDateLong" class="f-body--small">{{ updateDateRelative }}</td>
    <td class="text-right menu-anchor">
      <div class="flex-center icon-buttons">
        <gsk-icon-button
          v-if="isAdminMode"
          class="icon-button"
          title="settings"
          icon="cog"
          officon="cog"
          @click="openDialog(listing, lv)"
        ></gsk-icon-button>
        <router-link v-if="userIsOwner" :to="editLink">
          <gsk-icon-button
            class="icon-button"
            title="edit"
            icon="pencil"
            officon="pencil"
          ></gsk-icon-button>
        </router-link>
        <gsk-icon-button
          v-else
          class="icon-button"
          title="edit"
          icon="pencil"
          officon="pencil"
          disabled
        ></gsk-icon-button>
        <gsk-icon-button
          class="icon-button"
          title="menu"
          icon="more_horizontal"
          officon="more_horizontal"
          @click="showMenu"
        ></gsk-icon-button>
      </div>
      <gsk-menu ref="menu" class="menu">
        <gsk-list class="settings-list">
          <router-link v-if="lv.publishDate" :to="listingVersionLink">
            <gsk-list-item><p class="f-body--small">View Listing</p></gsk-list-item>
          </router-link>
          <gsk-list-item class="menu-delete" @click="del(listing, lv)">
            <template v-if="isPublished">
              <p class="f-body--small">Delete Listing</p>
            </template>
            <template v-else>
              <p class="f-body--small">Discard Draft</p>
            </template>
          </gsk-list-item>
          <gsk-list-item v-if="isPublished && userIsOwner" @click="unpublish(listing, lv)">
            <p class="f-body--small">Unpublish Listing</p>
          </gsk-list-item>
        </gsk-list>
      </gsk-menu>
    </td>
  </tr>
</template>

<script lang="ts">
import { Component, Emit, Vue, Prop } from 'vue-property-decorator';
import formatDistanceToNow from 'date-fns/formatDistanceToNow';
import { Menu } from '@gsk-platforms/gsk-menu/gsk-menu';
import { RawLocation } from 'vue-router';
import { RequiredProp } from '@/utils/components';
import { MyListing, MyListingVersion } from '@/types/publishing.types';
import { ListingTypes, RouteNames, Statuses } from '@/constants';
import GButton from '@/components/gsk-components/GskButton.vue';
import UserList from '@/components/UserList.vue';
import { UserModule } from '@/store/modules/user.module';
import { User } from '@/types/users.types';
import * as API from '@/api/publishing.api';

@Component({
  components: {
    GButton,
    UserList,
  },
})
export default class ListingTableRow extends Vue {
  @RequiredProp(Object) readonly listing!: MyListing;
  @RequiredProp(Object) readonly listingVersion!: MyListingVersion;
  @RequiredProp(Boolean) readonly first!: boolean;
  @RequiredProp(Boolean) readonly open!: boolean;
  @Prop(Boolean) readonly isAdminMode!: boolean;

  get lv() {
    return this.listingVersion;
  }

  nameClick() {
    if (this.isPublished) {
      this.$router.push(this.listingVersionLink);
    }
  }

  longDate(ds: string) {
    const date = new Date(ds);
    return `${date.toLocaleDateString()} ${date.toLocaleTimeString()}`;
  }

  relativeDate(ds: string) {
    return formatDistanceToNow(new Date(ds), { addSuffix: true });
  }

  get publishDateLong() {
    return this.longDate(this.listingVersion.publishDate);
  }
  get publishDateRelative() {
    return this.relativeDate(this.listingVersion.publishDate);
  }

  get updateDateLong() {
    return this.longDate(this.listingVersion.updateTimestamp);
  }
  get updateDateRelative() {
    return this.relativeDate(this.listingVersion.updateTimestamp);
  }

  get currentUser(): User {
    return UserModule.user;
  }

  get userIsOwner(): boolean {
    return this.listing.listingUsers.some(user => {
      return user.mudId === this.currentUser.mudId;
    });
  }

  @Emit('update:open')
  toggle() {
    return !this.open;
  }

  showMenu() {
    // refs are an array because they are used in v-for
    const menu = this.$refs.menu as Menu;
    const anchor = this.$refs.menuAnchor as Element;
    menu.setAnchorCorner(menu.Corner.BOTTOM_RIGHT);
    menu.setAnchorElement(anchor);
    menu.setAnchorMargin({ bottom: 16, right: this.getDistance });
    menu.open = !menu.open;
  }

  @Emit('admin')
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  openDialog(listing: MyListing, listingVersion: MyListingVersion) {}

  @Emit('delete')
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  del(listing: MyListing, listingVersion: MyListingVersion) {}

  @Emit('unpublish')
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  unpublish(listing: MyListing, listingVersion: MyListingVersion): void {
    API.unpublishListing(listing.listingId);
  }

  // TODO: Versioning for this
  get listingVersionLink(): RawLocation {
    return {
      name: RouteNames.ListingDetails,
      params: {
        listingId: this.listing.listingId.toString(),
      },
    };
  }

  get editLink() {
    return {
      name: RouteNames.PublishListing,
      params: {
        listingId: this.listing.listingId.toString(),
      },
      query: { mode: 'edit' },
    };
  }

  get isPublished() {
    return this.listing.statusName === Statuses.Published;
  }

  get getDistance() {
    return this.isPublished && !this.isAdminMode ? -35 : -95;
  }

  get listingType(): string | undefined {
    return {
      [ListingTypes.API.toString()]: 'API',
      [ListingTypes.WebComponent.toString()]: 'Web Component',
      [ListingTypes.MobileComponent.toString()]: 'Mobile Component',
      [ListingTypes.RPA.toString()]: 'RPA',
      [ListingTypes.GithubRepo.toString()]: 'Github',
    }[this.listing.listingTypeId];
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/theme.scss';
tr {
  user-select: none;
  cursor: default;
  /*td:nth-child(1) {*/
  /*  cursor: pointer;*/
  /*}*/
  &.open {
    td:nth-child(1),
    td:nth-child(2) {
      border-bottom: none;
    }
  }
  .status {
    margin: 0;
  }
}
.toggle {
  cursor: pointer;
  &.open {
    transform: rotateX(180deg);
  }
}

.icon-button {
  color: $theme-dark;
  --gsk-theme-secondary: #{$theme-dark};
}

.icon-buttons > *:not(:last-child) {
  margin-right: 1rem;
}

.publish-date {
  color: $theme-dark;
  font-size: 10px;
}

.menu {
  position: absolute;
  width: 140px;
}

.menu-anchor {
  position: relative;
  gsk-list a {
    color: $theme-dark;
  }
}

.menu-delete {
  color: $theme-danger;
}
</style>
