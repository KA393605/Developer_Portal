<template>
  <section>
    <div
      v-for="field in filteredValue"
      :key="field.key"
      class="field-container"
      :class="{ ht: !!field.helperText }"
    >
      <div v-if="field.leadingText" class="f-body--small leading-text">
        {{ field.leadingText }}
      </div>
      <g-select
        v-if="field.type === 'select'"
        :options="field.options"
        :label="field.label"
        :value="field.value"
        :helpertextcontent="field.helpText"
        :required="field.required"
        placeholder="Select"
        v-bind="field.attrs"
        @input="onChange(field, $event)"
      ></g-select>
      <g-radio
        v-else-if="field.type === 'radio'"
        :name="field.key"
        :options="field.options"
        :label="field.label"
        :value="field.value"
        :helpertext="field.helpText"
        :required="field.required"
        persistenthelpertext
        inline
        v-bind="field.attrs"
        @input="onChange(field, $event)"
      ></g-radio>
      <g-checkbox
        v-else-if="field.type === 'checkbox'"
        :name="field.key"
        :options="field.options"
        :label="field.label"
        :value="field.value"
        :helpertext="field.helpText"
        :required="field.required"
        persistenthelpertext
        v-bind="field.attrs"
        @input="onChange(field, $event)"
      ></g-checkbox>
      <g-text-field
        v-else-if="field.type === 'text' || field.type === 'long-text'"
        :label="field.label"
        :value="field.value"
        :type="field.type === 'long-text' ? 'textarea' : 'text'"
        :helper-text-content="field.helpText"
        :required="field.required"
        v-bind="field.attrs"
        @input="onChange(field, $event)"
      ></g-text-field>
      <g-people-picker
        v-else-if="field.type === 'people-picker'"
        :value="field.value"
        :label="field.label"
        :helpertextcontent="field.helpText"
        :required="field.required"
        v-bind="field.attrs"
        @input="onChange(field, $event)"
      />
      <g-multi-select
        v-else-if="field.type === 'multi-select'"
        :options="field.options"
        :label="field.label"
        :value="field.value"
        :helpertextcontent="field.helpText"
        :required="field.required"
        placeholder="Select"
        v-bind="field.attrs"
        @input="onChange(field, $event)"
      ></g-multi-select>
      <repo-picker
        v-else-if="field.type === 'github-repo'"
        :value="field.value"
        v-bind="field.attrs"
        @input="onChange(field, $event)"
      ></repo-picker>
      <div v-else-if="isDev" class="unknown">
        unknown input type:
        <code>{{ field.type }}</code>
      </div>
    </div>
  </section>
</template>

<script lang="ts">
import { Component, Emit, Vue, Watch } from 'vue-property-decorator';
import cloneDeep from 'lodash/cloneDeep';
import * as types from './form.types';
import { RequiredProp } from '@/utils/components';
import { isValid } from '@/components/form/utils';

const components = {
  'g-select': () => import('@/components/gsk-components/GskSelect.vue'),
  'g-multi-select': () => import('@/components/gsk-components/GskMultiSelect.vue'),
  'g-radio': () => import('@/components/gsk-components/GskRadioGroup.vue'),
  'g-checkbox': () => import('@/components/gsk-components/GskCheckboxGroup.vue'),
  'g-text-field': () => import('@/components/gsk-components/GskTextfield.vue'),
  'g-people-picker': () => import('@/components/gsk-components/GskPeoplePicker.vue'),
  'repo-picker': () => import('@/components/RepoPicker.vue'),
};

@Component({
  components,
})
export default class GeneratedForm extends Vue {
  @RequiredProp(Array) value!: types.FormField[];

  get filteredValue() {
    return this.value.filter(v => !v.hide);
  }

  get isDev() {
    return process.env.NODE_ENV === 'development';
  }

  @Watch('value', { immediate: true })
  valueWatcher() {
    this.$nextTick(() => {
      this.checkValidity(this.value);
    });
  }

  @Emit('input')
  onChange(field: types.FormField, value: types.FormField['value']) {
    const model = cloneDeep(this.value);
    const mf = model.find(modelField => modelField.key === field.key);
    if (mf) {
      mf.value = value;
    }
    return model;
  }

  checkValidity(form: types.FormField[]): void {
    const v = isValid(form);
    this.$emit('valid', v);
  }
}
</script>

<style scoped lang="scss">
@import '~@/styles/theme.scss';
@import '~@/styles/breakpoints.scss';

.field-container {
  margin-bottom: 1.5rem;
  &.ht {
    margin-bottom: 1rem;
  }
}
.leading-text {
  margin-bottom: 1rem;
  padding-top: 1rem; // not using margin so distances will stack
}

.unknown {
  background: $theme-lightest;
  color: $theme-dark;
  padding: 1rem;
  border-radius: 4px;
  code {
    color: $theme-danger;
    padding: 0.5rem;
  }
}
</style>
