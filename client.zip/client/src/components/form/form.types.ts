import { BaseUser } from '@/types/users.types';
import { GithubRepo } from '@/types/publishing.types';

export interface FormFieldBase<T> {
  type: FieldType;
  label: string;
  outputLabel?: string; // for when you want to display `label`: `value` later and `label` is stupid
  value: T;
  key: string;
  required?: boolean;
  hide?: boolean; // removes field from render and validation
  helpText?: string;
  leadingText?: string;
  attrs?: Record<string, string>;
}
export type FieldType =
  | 'text'
  | 'long-text'
  | 'select'
  | 'multi-select'
  | 'radio'
  | 'checkbox'
  | 'people-picker'
  | 'github-repo';

export interface SelectOption<T = any> {
  value: string;
  label?: string;
  key?: string;
  disabled?: boolean;
  extra?: T;
}
export type SelectValue = SelectOption['value']
export interface SelectField extends FormFieldBase<SelectValue> {
  type: 'select';
  options: SelectOption[] | string[];
}
export interface MultiSelectField extends FormFieldBase<SelectValue[]> {
  type: 'multi-select';
  options: SelectOption[] | string[];
}
export interface PeoplePickerField extends FormFieldBase<BaseUser[]> {
  type: 'people-picker';
  single?: boolean;
}
export interface RadioField extends FormFieldBase<SelectValue> {
  type: 'radio';
  options: SelectOption[] | string[];
}
export interface CheckboxField extends FormFieldBase<SelectValue[]> {
  type: 'checkbox';
  options: SelectOption[] | string[];
}

export interface TextField extends FormFieldBase<string> {
  type: 'text' | 'long-text';
}

export interface GithubRepoField extends FormFieldBase<GithubRepo | null> {
  type: 'github-repo';
}

export type FormField =
  | TextField
  | SelectField
  | MultiSelectField
  | PeoplePickerField
  | RadioField
  | CheckboxField
  | GithubRepoField;

export interface ExtendedPropertiesDetails {
  fields: FormField[];
}

export function isSelectOptions(options: SelectOption[] | string[]): options is SelectOption[] {
  return !(typeof options[0] === 'string');
}
