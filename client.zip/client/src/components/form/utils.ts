import { FormField } from '@/components/form/form.types';

export function isValid(form: FormField[]) {
  return form.reduce((isValid: boolean, field) => {
    if (isValid) {
      if (field.required && !field.hide) {
        if (Array.isArray(field.value)) {
          return !!field.value.length;
        }

        return !!field.value;
      }
    }
    return isValid;
  }, true);
}
