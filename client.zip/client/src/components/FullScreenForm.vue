<template>
  <div id="fs-layout">
    <gsk-top-app-bar id="fs-app-bar" class="full-screen-form__top-bar" type="fixed">
      <div slot="navigationIcon">
        <gsk-icon-button
          icon="arrow_left"
          officon="arrow_left"
          class="icon back-button"
          :class="{ disabled: hideBack }"
          :aria-disabled="hideBack"
          :aria-hidden="hideBack"
          @click="back"
        ></gsk-icon-button>
      </div>
      <div slot="title" class="f-body">{{ title }}</div>
      <div slot="actionItems">
        <gsk-icon-button icon="close" officon="close" @click="close"></gsk-icon-button>
      </div>
    </gsk-top-app-bar>

    <main id="fs-layout-main">
      <div class="full-screen-form">
        <max-width is-form full-screen class="bt">
          <div class="full-screen-form__content">
            <slot></slot>
          </div>
        </max-width>
      </div>
    </main>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Emit, Watch, Vue } from 'vue-property-decorator';
import { RawLocation } from 'vue-router';
import { TopAppBar } from '@gsk-platforms/gsk-top-app-bar/gsk-top-app-bar';
import MaxWidth from '@/components/MaxWidth.vue';

@Component({
  components: {
    MaxWidth,
  },
})
export default class FullScreenForm extends Vue {
  @Prop(Object) readonly closeRoute!: RawLocation;
  @Prop(Boolean) readonly hideBack!: boolean;
  @Prop(Boolean) readonly closed!: boolean;
  @Prop(Boolean) readonly hideControls!: boolean;
  @Prop({ type: String, default: '' }) readonly title!: string;

  mounted() {
    Vue.nextTick(() => {
      const bar = document.querySelector('#fs-app-bar') as TopAppBar;
      bar.scrollTarget = document.querySelector('#fs-layout-main') as HTMLElement;
    });
  }

  @Watch('closed')
  onClose(isClosed: boolean) {
    if (isClosed) {
      this.close();
    }
  }

  @Emit()
  close() {
    if (this.closeRoute) {
      this.$router.safeBack(this.closeRoute);
    }
  }

  @Emit()
  back() {
    if (this.closeRoute) {
      this.$router.safeBack(this.closeRoute);
    }
  }
}
</script>

<style scoped lang="scss">
@import '~@/styles/breakpoints.scss';
@import '~@/styles/theme.scss';

#fs-layout {
  --gsk-theme-primary: #{$theme-primary};
  width: 100%;
  height: 100%;
  overflow: hidden;
  display: flex;
}

#fs-layout-main {
  height: calc(100% - var(--header-height));
  overflow-y: scroll;
  overflow-x: hidden;
  width: 100%;
  display: flex;
  flex: 1;
  margin-top: var(--header-height);
  border-top: 1px solid $theme-lighter;

  &::v-deep a {
    color: $theme-primary;
    text-decoration: none;
  }
}

.back-button.disabled {
  user-select: none;
  user-focus: none;
  visibility: hidden;
}

.full-screen-form {
  display: flex;
  flex-direction: column;
  position: relative;
  height: 100%;
  width: 100%;

  &__content {
    flex: 1;
    display: flex;
    align-items: flex-start;
    justify-content: center;

    @include breakpoint($medium) {
      // padding-top: 140px;
      align-items: center;
    }
  }

  &__top-bar {
    color: $theme-dark;
    > * {
      color: $theme-dark;
    }
  }
}

.back-button {
  margin-right: 1rem;
}
</style>
