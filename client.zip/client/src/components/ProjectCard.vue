<template>
  <div class="project">
    <div class="project__top">
      <h6 class="project__title">{{ name }}</h6>
      <p class="project__description f-body--small">
        {{ truncatedDetails }}
      </p>
    </div>
    <div class="project__bottom">
      <div class="card__users">
        <user-list :users="users" truncate />
      </div>
      <div class="f-overline project__env">{{ env }}</div>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import truncate from 'lodash.truncate';
import { Project, ProjectUser, ProjectEnvironment } from '@/types/projects.types';
import UserList from '@/components/UserList.vue';

@Component({
  components: {
    UserList,
  },
})
export default class ProjectCard extends Vue {
  @Prop() readonly projectDetail!: Project;
  get truncatedDetails() {
    return truncate(this.projectDetail.projectDescription, { length: 160 });
  }

  get environments(): ProjectEnvironment[] {
    return this.projectDetail.environments;
  }

  get env(): string {
    return this.environments[0].environmentName;
  }

  get name(): string {
    return this.projectDetail.projectName;
  }

  get users(): ProjectUser[] {
    return this.projectDetail.projectUsers;
  }
}
</script>

<style scoped lang="scss">
@import '~@/styles/theme.scss';
.project {
  padding: 24px;
  height: 100%;
  min-height: 275px;
  border-radius: 4px;
  box-shadow: 4px 4px 10px 0 #d7d7d725;
  transition: box-shadow 250ms;
  border: solid 1px $theme-lighter;
  background-color: #ffffff;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-content: center;

  &:hover {
    box-shadow: 6px 6px 20px -5px #c1c1c150;
  }

  &__bottom {
    display: flex;
    justify-content: space-between;
    align-content: center;
    align-items: center;

    &::v-deep {
      .user-circle {
        cursor: pointer;
      }
    }
  }

  &__title {
    color: var(--theme-dark);
    margin-top: 0;
    margin-bottom: 1rem;
    word-break: break-word;
  }
  &__link {
    font-size: 24px;
  }
  &__description {
    word-break: break-word;
  }

  .ripple {
    --gsk-theme-primary: #{$theme-light};
  }
}
</style>
