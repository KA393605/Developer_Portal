<template>
  <gsk-snackbar ref="snack" class="snackbar" v-bind="snackbarOptions">
    <gsk-icon-button
      id="iconButton"
      slot="dismiss"
      icon="gsk_clear"
      officon="gsk_clear"
    ></gsk-icon-button>
  </gsk-snackbar>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { Snackbar } from '@gsk-platforms/gsk-snackbar/gsk-snackbar';
import { Events } from '@/constants';
import { SnackbarOptions } from '@/types';

@Component
export default class GlobalSnackbar extends Vue {
  public snackbarOptions: SnackbarOptions = { labelText: '' };

  showSnackbar(options: SnackbarOptions): void {
    this.snackbarOptions = options;
    Vue.nextTick(() => {
      const snack = this.$refs.snack as Snackbar | undefined;
      if (snack) {
        snack.open();
      }
    });
  }
  created() {
    this.$root.$on(Events.ShowSnackbar, (options: SnackbarOptions) => this.showSnackbar(options));
  }
}
</script>

<style lang="scss">
// global snackbar settings in main.scss
</style>
