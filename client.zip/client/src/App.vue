<template>
  <div id="app">
    <template>
      <gsk-linear-progress id="top-progress" indeterminate progress="0.5" closed />
      <portal-target name="modal" />
      <router-view v-if="userLoaded" />
      <global-snackbar />
    </template>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import GlobalSnackbar from '@/components/GlobalSnackbar.vue';
import { UserModule } from '@/store/modules/user.module';
import {
  analyticsPageView,
  analyticsUserLogin,
  extractAnalyticsFromRouteParams,
} from '@/analytics';

@Component({
  components: {
    GlobalSnackbar,
  },
})
export default class App extends Vue {
  beforeCreate() {
    UserModule.getUserInfo().then(() => {
      if (UserModule.user.mudId) {
        analyticsUserLogin();
      }
    });
  }

  get userLoaded() {
    return UserModule.user.mudId;
  }

  private destroyBeforeEach: Function = () => {};
  private lastPageViewTime = Date.now();
  async created() {
    await UserModule.userPromise;

    setInterval(() => {
      UserModule.getUserInfo();
    }, 1000 * 60 * 30);

    this.destroyBeforeEach = this.$router.beforeEach((to, from, next) => {
      // analytics registers first page view itself
      const data = extractAnalyticsFromRouteParams(to.params);
      const now = Date.now();
      const timeSpent = Math.round((now - this.lastPageViewTime) / 1000);
      this.lastPageViewTime = now;
      analyticsPageView({ timeSpent, ...data }, { to, from });
      next();
    });
  }

  beforeDestroy() {
    this.destroyBeforeEach();
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/theme.scss';
#app {
  width: 100%;
  height: 100%;
  overflow: hidden;
  background: #fff;
}
#top-progress {
  width: 100%;
  position: fixed;
  z-index: 10;

  --gsk-theme-primary: #{$theme-primary};
  --gsk-theme-surface: transparent;
  --gsk-linear-progress-buffering-dots-image: '';
}
</style>
