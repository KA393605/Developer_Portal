import { Location, Route } from 'vue-router';
import mapKeys from 'lodash/mapKeys';
import {
  AnalyticsEventNames,
  AnalyticsUser,
  ClickData,
  PageViewData,
} from '@/analytics/analytics.types';
import { UserModule } from '@/store/modules/user.module';
import store from '@/store';

export * from '@/analytics/analytics.types';

function getRouteData(override?: { to: Route; from: Route }) {
  const routeState = store.state.route;
  return {
    current: {
      name: override?.to.name ?? routeState.name,
      path: override?.to.fullPath ?? routeState.fullPath,
    },
    previous: {
      name: override?.from.name ?? routeState.from?.name ?? null,
      path: override?.from.fullPath ?? routeState.from?.fullPath ?? null,
    },
  };
}

function getUserData(): AnalyticsUser {
  return {
    mudId: UserModule.user.mudId,
    email: UserModule.user.email,
  };
}

// never change this, unless the analytics team asks us to
const ANALYTICS_EVENT_NAME = 'analytics';
const ANALYTICS_QUERY_PREFIX = '__analytics__:';

function getAnalyticsData<T>(
  name: AnalyticsEventNames,
  data: T,
  routeOverride?: { to: Route; from: Route },
) {
  return {
    detail: {
      name,
      user: getUserData(),
      page: getRouteData(routeOverride),
      data,
    },
  };
}

function evt(data: ReturnType<typeof getAnalyticsData>) {
  document.dispatchEvent(new CustomEvent(ANALYTICS_EVENT_NAME, data));
}

export function analyticsClick(data: ClickData) {
  evt(getAnalyticsData(AnalyticsEventNames.Click, data));
}

export function analyticsUserLogin() {
  evt(getAnalyticsData(AnalyticsEventNames.UserLogin, {}));
}

export function analyticsPageView(data: PageViewData, routeOverride?: { to: Route; from: Route }) {
  evt(getAnalyticsData(AnalyticsEventNames.PageView, data, routeOverride));
}

/**
 * this is kind of dumb but vue-router doesn't have a way to
 * pass arbitrary metadata through route objects
 */
export function addAnalyticsRouteParams(
  params: Location['params'],
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  data: Record<string, any>,
): Location['params'] {
  return {
    ...params,
    ...mapKeys(data, (value, key) => {
      return ANALYTICS_QUERY_PREFIX + key;
    }),
  };
}

export function extractAnalyticsFromRouteParams(
  params: Location['params'],
): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  if (params) {
    Object.keys(params).forEach(key => {
      if (key.startsWith(ANALYTICS_QUERY_PREFIX)) {
        out[key.replace(ANALYTICS_QUERY_PREFIX, '')] = params[key];
        delete params[key];
      }
    });
  }
  return out;
}
