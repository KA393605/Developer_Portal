import Vue from 'vue';
import Router from 'vue-router';
import DefaultLayout from '@/layouts/DefaultLayout.vue';
import FullScreenModalLayout from '@/layouts/FullScreenFormLayout.vue';
import { RouteNames } from '@/constants';
import ListingCatalog from '@/views/ListingCatalog.vue';
import ListingDetailInfo from '@/views/ListingDetailInfo.vue';
import PublishNew from '@/views/PublishNew.vue';
import Permissions from '@/components/Publish/Permissions.vue';
import MyListingsView from '@/views/MyListings.vue';
import BotConsoleLayout from '@/layouts/BotConsoleLayout.vue';
import DocumentationLayout from '@/layouts/DocumentationLayout.vue';
import HelpDocumentationViewer from '@/components/DocumentationViewer.vue';
import { HELP_ROOT_PATH } from '@/constants/help.constants';
import MyTeams from '@/views/MyTeams.vue';

Vue.use(Router);

export default new Router({
  mode: 'history',
  base: process.env.BASE_URL,
  /* eslint-disable @typescript-eslint/explicit-function-return-type */
  scrollBehavior(to, from, savedPosition) {
    if (savedPosition) {
      return savedPosition;
    } else {
      return { selector: '#layout-main', x: 0, y: 0 };
    }
  },
  routes: [
    {
      path: '/test-form',
      component: DefaultLayout,
      children: [
        {
          path: '/',
          component: () => import('./views/TestForm.vue'),
        },
      ],
    },
    {
      path: '/projects/new',
      component: FullScreenModalLayout,
      children: [
        {
          path: '/',
          name: RouteNames.NewProject,
          component: () => import(/* webpackChunkName: "projectNew" */ './views/ProjectNew.vue'),
        },
      ],
    },
    {
      path: '/listings/:listingId/connect',
      component: FullScreenModalLayout,
      children: [
        {
          path: '/',
          name: RouteNames.ListingConnect,
          component: () =>
            import(/* webpackChunkName: "projectConnect" */ './views/ProjectConnect.vue'),
        },
      ],
    },
    {
      path: '/projects/:id/env/:env/promote-to-prod',
      component: FullScreenModalLayout,
      children: [
        {
          path: '/',
          name: RouteNames.PromoteToProd,
          component: () =>
            import(/* webpackChunkName: "promoteToProd" */ './views/PromoteToProd.vue'),
        },
      ],
    },
    {
      path: '/projects/:id/settings',
      component: FullScreenModalLayout,
      children: [
        {
          path: '/',
          name: RouteNames.ProjectSettings,
          component: () =>
            import(/* webpackChunkName: "projectSettings" */ './views/ProjectDetailsSettings.vue'),
        },
        {
          path: 'permissions',
          name: RouteNames.ProjectPermissions,
          component: () =>
            import(
              /* webpackChunkName: "projectSettings" */ './views/ProjectPermissionsSettings.vue'
            ),
        },
      ],
    },
    {
      path: '/projects',
      component: DefaultLayout,
      children: [
        {
          path: '/',
          name: RouteNames.ProjectsList,
          component: () => import(/* webpackChunkName: "projects" */ './views/ProjectsList.vue'),
        },
        {
          path: ':id',
          name: RouteNames.ProjectDetails,
          component: () =>
            import(/* webpackChunkName: "projectDetails" */ './views/ProjectDetails.vue'),
          children: [
            {
              name: RouteNames.ProjectEnvDetails,
              component: () =>
                import(/* webpackChunkName: "projectDetails" */ './views/ProjectEnv.vue'),
              path: 'env/:env/:section?',
              props: true,
            },
          ],
        },
      ],
    },
    {
      path: '/rpa-console',
      component: BotConsoleLayout,
      children: [
        {
          path: '/',
          redirect: '/rpa-console/dev',
          name: RouteNames.BotConsole,
          component: () => import(/* webpackChunkName: "console"*/ './views/BotConsole.vue'),
        },
        {
          path: ':env',
          props: true,
          name: RouteNames.BotEnv,
          component: () => import(/* webpackChunkName: "console"*/ './views/BotConsole.vue'),
          children: [
            {
              path: ':type',
              props: true,
              name: RouteNames.BotType,
              component: () => import(/* webpackChunkName: "console"*/ './views/BotConsole.vue'),
            },
          ],
        },
        // {
        //   path: '/switch',
        //   name: RouteNames.SwitchAccount,
        //   component: () => import(/* webpackChunkName: "console"*/ './views/SelectAccount.vue'),
        // },
      ],
    },
    {
      path: '/access/management',
      component: BotConsoleLayout,
      children: [
        {
          path: '/',
          name: RouteNames.BotConsoleAccess,
          component: () => import(/* webpackChunkName: "console"*/ './views/AccessManagement.vue'),
        },
      ],
    },
    {
      path: '/switch',
      component: DefaultLayout,
      children: [
        {
          path: '/',
          name: RouteNames.SwitchAccount,
          component: () => import(/* webpackChunkName: "console"*/ './views/SelectAccount.vue'),
        },
      ],
    },
    {
      path: '/product-catalog',
      component: DefaultLayout,
      children: [
        {
          path: '/',
          props: true,
          name: RouteNames.Listings,
          component: ListingCatalog,
        },
        {
          path: ':type',
          props: true,
          name: RouteNames.ListingType,
          component: ListingCatalog,
        },
      ],
    },
    {
      path: '/listings/:listingId',
      component: DefaultLayout,
      children: [
        {
          path: '/',
          name: RouteNames.ListingDetails,
          props: true,
          component: () => import(/* webpackChunkName: "products" */ './views/ListingDetail.vue'),
          children: [
            {
              name: RouteNames.ListingSection,
              component: ListingDetailInfo,
              path: ':info',
            },
          ],
        },
      ],
    },
    {
      path: '/my-listings',
      component: DefaultLayout,
      children: [
        {
          path: '/',
          name: RouteNames.MyListings,
          component: MyListingsView,
        },
        {
          path: 'publish/:listingId?',
          name: RouteNames.PublishListing,
          props: true,
          component: PublishNew,
        },
        {
          path: 'permissions',
          name: RouteNames.ListingPermissions,
          component: Permissions,
        },
      ],
    },
    {
      path: '/my-teams',
      component: DefaultLayout,
      children: [
        {
          path: '/',
          name: RouteNames.MyTeams,
          component: MyTeams,
        },
      ],
    },
    {
      path: '/my-teams/new',
      component: FullScreenModalLayout,
      children: [
        {
          path: '/',
          name: RouteNames.NewTeam,
          component: () => import('./views/NewTeam.vue'),
        },
      ],
    },
    {
      path: '/my-teams/edit/:teamId',
      component: FullScreenModalLayout,
      children: [
        {
          path: '/',
          name: RouteNames.EditTeam,
          component: () => import('./views/EditTeam.vue'),
        },
      ],
    },
    {
      path: '/my-teams/details/:teamId',
      component: FullScreenModalLayout,
      children: [
        {
          path: '/',
          name: RouteNames.TeamDetails,
          component: () => import('./views/TeamDetails.vue'),
        },
      ],
    },
    {
      path: `/${HELP_ROOT_PATH}`,
      component: DocumentationLayout,
      children: [
        {
          path: '*',
          name: 'documentation',
          component: HelpDocumentationViewer,
        },
      ],
    },
    {
      path: '/',
      redirect: '/product-catalog',
    },
    {
      path: '*',
      alias: '/404',
      name: RouteNames.NotFound,
      component: () => import(/* webpackChunkName: "notfound" */ './views/NotFound.vue'),
    },
  ],
});
