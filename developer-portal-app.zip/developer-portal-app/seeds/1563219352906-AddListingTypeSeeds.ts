import { MigrationInterface, QueryRunner } from 'typeorm';
import { ListingType } from '../src/types/entities';

export class AddListingTypeSeeds1563219352906 implements MigrationInterface {
  private listingTypeName = 'API';
  private listingTypeDescription = 'API';
  private listingTypeTemplate = JSON.parse('{1: "overview"}');

  public async up(queryRunner: QueryRunner): Promise<any> {
    let listingType = ListingType.create();
    listingType.listingTypeName = this.listingTypeName;
    listingType.listingTemplate = this.listingTypeTemplate;
    listingType = await listingType.save();
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    const listingType = await ListingType.findOne({
      where: {
        listingTypeName: this.listingTypeName,
        listingTypeDescription: this.listingTypeDescription,
      },
    });
    listingType.remove();
  }
}
