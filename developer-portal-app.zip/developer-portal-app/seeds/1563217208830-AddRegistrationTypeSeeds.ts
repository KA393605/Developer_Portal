import { MigrationInterface, QueryRunner } from 'typeorm';
import { RegistrationType } from '../src/services/entities/registration-type.entity';

export class AddRegistrationTypeSeeds1563217208830
  implements MigrationInterface {
  private registrationTypeName = 'API';
  private registrationTypeDescription = 'API';

  public async up(queryRunner: QueryRunner): Promise<any> {
    let registrationType = RegistrationType.create();
    registrationType.registrationTypeName = this.registrationTypeName;
    registrationType.registrationTypeDescription = this.registrationTypeDescription;
    registrationType = await registrationType.save();
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    const registrationType = await RegistrationType.findOne({
      where: {
        registrationTypeName: this.registrationTypeName,
        registrationTypeDescription: this.registrationTypeDescription,
      },
    });
    registrationType.remove();
  }
}
