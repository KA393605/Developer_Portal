import { MigrationInterface, QueryRunner } from 'typeorm';
import { Privilege } from '../src/core/entities';

export class AddPrivilegeSeeds1563222154806 implements MigrationInterface {
  private readProjectPrivilegeName = 'canReadProject';
  private readProjectPrivilegeDescription = 'canReadProject';

  private editProjectMembersPrivilegeName = 'canReadProject';
  private editProjectMembersPrivilegeDescription = 'canReadProject';

  public async up(queryRunner: QueryRunner): Promise<any> {
    const readPrivilege = Privilege.create();
    readPrivilege.privilegeName = this.readProjectPrivilegeName;
    readPrivilege.privilegeDescription = this.readProjectPrivilegeDescription;
    await readPrivilege.save();

    const editPrivilege = Privilege.create();
    editPrivilege.privilegeName = this.editProjectMembersPrivilegeName;
    editPrivilege.privilegeDescription = this.editProjectMembersPrivilegeDescription;
    await editPrivilege.save();
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    const readPrivilege = await Privilege.findOne({
      where: {
        privilegeName: this.readProjectPrivilegeName,
        privilegeDescription: this.readProjectPrivilegeDescription,
      },
    });
    await readPrivilege.remove();

    const editPrivilege = await Privilege.findOne({
      where: {
        privilegeName: this.editProjectMembersPrivilegeName,
        privilegeDescription: this.editProjectMembersPrivilegeDescription,
      },
    });
    await editPrivilege.remove();
  }
}
