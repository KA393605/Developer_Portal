import { MigrationInterface, QueryRunner } from 'typeorm';
import { Status } from '../src/core/entities';
import { StatusType } from '../src/core/value-objects/status-type.vo';

export class AddStatusSeeds15612746180000 implements MigrationInterface {
  private activeStatusTypeName = 'active';
  private activestatusTypeDescription = 'active';

  private activeStatusName = 'active';
  private activeStatusDescription = 'active';

  private pendingStatusTypeName = 'pending';
  private pendingStatusTypeDescription = 'pending';

  private pendingStatusName = 'pending';
  private pendingStatusDescription = 'pending';

  public async up(queryRunner: QueryRunner): Promise<any> {
    const activeStatusType = await StatusType.findOne({
      where: {
        statusTypeName: this.activeStatusTypeName,
        statusTypeDescription: this.activestatusTypeDescription,
      },
    });
    const activeStatus = Status.create();
    activeStatus.statusType = activeStatusType;
    activeStatus.statusName = this.activeStatusName;
    activeStatus.statusDescription = this.activeStatusDescription;
    activeStatus.sequenceNumber = 1;
    await activeStatus.save();

    const pendingStatusType = await StatusType.findOne({
      where: {
        statusTypeName: this.pendingStatusTypeName,
        statusTypeDescription: this.pendingStatusTypeDescription,
      },
    });
    const pendingStatus = Status.create();
    pendingStatus.statusType = pendingStatusType;
    pendingStatus.statusName = this.pendingStatusName;
    pendingStatus.statusDescription = this.pendingStatusDescription;
    pendingStatus.sequenceNumber = 2;
    await pendingStatus.save();
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    const activeStatus = await Status.findOne({
      where: {
        statusName: this.activeStatusName,
        statusDescription: this.activeStatusDescription,
      },
    });
    await activeStatus.remove();
    const pendingStatus = await Status.findOne({
      where: {
        statusName: this.pendingStatusName,
        statusDescription: this.pendingStatusDescription,
      },
    });
    await pendingStatus.remove();
  }
}
