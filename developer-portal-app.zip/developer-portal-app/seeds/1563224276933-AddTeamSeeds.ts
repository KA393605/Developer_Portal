import { MigrationInterface, QueryRunner } from 'typeorm';
import { Team } from '../src/core/entities/team.entity';

export class AddTeamSeeds1563224276933 implements MigrationInterface {
  private teamName: string = 'KRAKEN';
  private teamDescription: string = 'KRAKEN';

  public async up(queryRunner: QueryRunner): Promise<any> {
    const team = Team.create();
    team.teamName = this.teamName;
    team.teamDescription = this.teamDescription;
    await team.save();
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    const team = await Team.findOne({
      where: {
        teamName: this.teamName,
        teamDescription: this.teamDescription,
      },
    });
    await team.remove();
  }
}
