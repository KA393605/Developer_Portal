import { MigrationInterface, QueryRunner } from 'typeorm';
import { User } from '../src/users/entities/user.entity';

export class AddUserSeeds1563223728966 implements MigrationInterface {
  private mudId: string = 'yyz1234';
  private email: string = 'neil.x.peart@gsk.com';
  private firstName: string = 'Neil';
  private lastName: string = 'Peart';
  private fullName: string = 'Neil Peart';

  public async up(queryRunner: QueryRunner): Promise<any> {
    const user = User.create();
    user.mudId = this.mudId;
    user.email = this.email;
    user.firstName = this.firstName;
    user.lastName = this.lastName;
    user.fullName = this.fullName;
    await user.save();
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    const user = await User.findOne({
      where: {
        mudId: this.mudId,
        email: this.email,
        firstName: this.firstName,
        lastName: this.lastName,
        fullName: this.fullName,
      },
    });
    await user.remove();
  }
}
