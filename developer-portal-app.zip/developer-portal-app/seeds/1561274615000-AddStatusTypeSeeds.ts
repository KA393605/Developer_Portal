import { MigrationInterface, QueryRunner } from 'typeorm';
import { StatusType } from '../src/core/value-objects/status-type.vo';

export class AddStatusTypeSeeds15612746150000 implements MigrationInterface {
  private activeStatusTypeName = 'active';
  private activestatusTypeDescription = 'active';
  private activeStatusTypeSequenceNumber = 1;

  private pendingStatusTypeName = 'pending';
  private pendingStatusTypeDescription = 'pending';
  private pendingStatusTypeSequenceNumber = 2;

  public async up(queryRunner: QueryRunner): Promise<any> {
    let activeStatusType = StatusType.create();
    activeStatusType.statusTypeName = this.activeStatusTypeName;
    activeStatusType.statusTypeDescription = this.activestatusTypeDescription;
    activeStatusType.sequenceNumber = this.activeStatusTypeSequenceNumber;
    activeStatusType = await activeStatusType.save();

    let pendingStatusType = StatusType.create();
    pendingStatusType.statusTypeName = this.pendingStatusTypeName;
    pendingStatusType.statusTypeDescription = this.pendingStatusTypeDescription;
    pendingStatusType.sequenceNumber = this.pendingStatusTypeSequenceNumber;
    pendingStatusType = await pendingStatusType.save();
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    const activeStatusType = await StatusType.findOne({
      where: {
        statusTypeName: this.activeStatusTypeName,
        statusTypeDescription: this.activestatusTypeDescription,
        sequenceNumber: this.activeStatusTypeSequenceNumber,
      },
    });
    activeStatusType.remove();
    const pendingStatusType = await StatusType.findOne({
      where: {
        statusTypeName: this.pendingStatusTypeName,
        statusTypeDescription: this.pendingStatusTypeDescription,
        sequenceNumber: this.pendingStatusTypeSequenceNumber,
      },
    });
    pendingStatusType.remove();
  }
}
