import { MigrationInterface, QueryRunner } from 'typeorm';
import { RoleGroup } from '../src/core/value-objects/role-group.vo';

export class AddRoleGroupSeeds1563221125469 implements MigrationInterface {
  private roleGroupName = 'PROJECT';
  private roleGroupDescription = 'PROJECT';

  public async up(queryRunner: QueryRunner): Promise<any> {
    const role = RoleGroup.create();
    role.roleGroupName = this.roleGroupName;
    role.roleGroupDescription = this.roleGroupDescription;
    await role.save();
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    const role = await RoleGroup.findOne({
      where: {
        roleGroupName: this.roleGroupName,
        roleGroupDescription: this.roleGroupDescription,
      },
    });
    await role.remove();
  }
}
