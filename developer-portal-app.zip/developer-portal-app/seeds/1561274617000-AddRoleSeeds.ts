import { MigrationInterface, QueryRunner } from 'typeorm';
import { Role } from '../src/core/entities';
import { RoleGroup } from '../src/core/value-objects/role-group.vo';

export class AddRoleSeeds15612746170000 implements MigrationInterface {
  private roleName = 'owner';
  private roleDescription = 'owner';

  private roleGroupName = 'PROJECT';
  private roleGroupDescription = 'PROJECT';

  public async up(queryRunner: QueryRunner): Promise<any> {
    const roleGroup = await RoleGroup.findOne({
      where: {
        roleGroupName: this.roleGroupName,
        roleGroupDescription: this.roleGroupDescription,
      },
    });

    const ownerRole = Role.create();
    ownerRole.roleName = this.roleName;
    ownerRole.roleDescription = this.roleDescription;
    ownerRole.roleGroup = roleGroup;
    await ownerRole.save();
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    const ownerRole = await Role.findOne({
      where: {
        roleName: this.roleName,
        roleDescription: this.roleDescription,
      },
    });
    await ownerRole.remove();
  }
}
