import { MigrationInterface, QueryRunner } from 'typeorm';
import { Environment } from '../src/core/entities';
import { ENVIRONMENTS } from '../src/core/environments.constants';

export class AddEnvironmentSeeds1561275746142 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<any> {
    const devEnvironment = Environment.create();
    devEnvironment.environmentName = ENVIRONMENTS.DEV;
    devEnvironment.environmentDescription = ENVIRONMENTS.DEV;
    devEnvironment.sequenceNumber = 1;
    await devEnvironment.save();
    const qaEnvironment = Environment.create();
    qaEnvironment.environmentName = ENVIRONMENTS.QA;
    qaEnvironment.environmentDescription = ENVIRONMENTS.QA;
    qaEnvironment.sequenceNumber = 2;
    await qaEnvironment.save();
    const prodEnvironment = Environment.create();
    prodEnvironment.environmentName = ENVIRONMENTS.PROD;
    prodEnvironment.environmentDescription = ENVIRONMENTS.PROD;
    prodEnvironment.sequenceNumber = 3;
    await prodEnvironment.save();
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    await Environment.clear();
  }
}
