import { MigrationInterface, QueryRunner } from 'typeorm';
import { ConnectionType } from '../src/projects/project-environment/entities/connection-type.entity';

export class AddConnectionType1561276117830 implements MigrationInterface {
  private connectionTypeName = 'OAUTH';
  private connectionTypeDescription = 'OAUTH';

  public async up(queryRunner: QueryRunner): Promise<any> {
    const connectionType = ConnectionType.create();
    connectionType.connectionTypeName = this.connectionTypeName;
    connectionType.connectionTypeDescription = this.connectionTypeDescription;
    connectionType.sequenceNumber = 1;
    await connectionType.save();
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    const connectionType = await ConnectionType.findOne({
      where: {
        connectionName: this.connectionTypeName,
        connectionDescription: this.connectionTypeDescription,
      },
    });
    await connectionType.remove();
  }
}
