import { Module } from '@nestjs/common';

import { RpaAdminController } from '../rpa-admin/rpa-admin.controller';
import { RpaAdminService } from '../rpa-admin/rpa-admin.service';
@Module({
  controllers: [RpaAdminController],
  providers: [RpaAdminService],
})
export class BotConsoleModule {}
