import {
  BaseEntity,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { IProjectUser } from '../interfaces';
import { User } from '../../../users/entities/user.entity';
import { Role } from '../../../core/entities';
import { Project } from '../../entities/project.entity';

@Entity({ name: 'UserProjectRole' })
export class ProjectUser extends BaseEntity implements IProjectUser {
  @PrimaryGeneratedColumn('uuid')
  uniqueKey: string;

  @ManyToOne(type => Project, project => project.projectId)
  @JoinColumn({
    name: 'projectId',
    referencedColumnName: 'projectId',
  })
  project: Promise<Project>;

  @ManyToOne(type => User, user => user.projectUsers)
  @JoinColumn({
    name: 'userId',
    referencedColumnName: 'userId',
  })
  user: Promise<User>;

  @OneToOne(type => Role)
  @JoinColumn({
    name: 'roleId',
    referencedColumnName: 'roleId',
  })
  role: Promise<Role>;

  @ManyToOne(type => User)
  @JoinColumn({
    name: 'createUserId',
    referencedColumnName: 'userId',
  })
  createUser: Promise<User>;

  @ManyToOne(type => User)
  @JoinColumn({
    name: 'lastUpdateUserId',
    referencedColumnName: 'userId',
  })
  lastUpdateUser: Promise<User>;
}
