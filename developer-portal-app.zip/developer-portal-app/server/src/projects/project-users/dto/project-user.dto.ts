import { IsNotEmpty, IsNumber } from 'class-validator';
import { UsersCreateRequestDTO } from '../../../users/dto/users-create-request.dto';
import { IProjectUsersDTO } from '../interfaces';

export class ProjectUserDTO extends UsersCreateRequestDTO
  implements IProjectUsersDTO {
  @IsNotEmpty()
  @IsNumber()
  roleId: number;
}
