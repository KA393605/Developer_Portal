import { Injectable, Inject } from '@nestjs/common';
import { IProjectUsersAppService } from './interfaces/project-users-app-service.interface';
import { IProjectUsersDomainService } from './interfaces/project-users-domain-service.interface';
import { IProjectUsersDTO } from './interfaces';

@Injectable()
export class ProjectUsersAppService implements IProjectUsersAppService {
  constructor(
    @Inject('ProjectUsersDomainService')
    private readonly projectUsersDomainService: IProjectUsersDomainService,
  ) {}

  updateProjectUsers(projectId, data: IProjectUsersDTO[]) {
    return this.projectUsersDomainService.updateProjectUsers(projectId, data);
  }
}
