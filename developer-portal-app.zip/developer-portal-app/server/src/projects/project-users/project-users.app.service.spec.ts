import { ProjectUsersAppService } from './project-users.app.service';
import { IProjectUsersDomainService } from './interfaces';
import { IProjectUsersDTO } from './interfaces';
import { GoodProjectUsersDTO, MockProjectUsersDomain } from './mocks';

describe('ProjectUsersAppService', () => {
  let appService: ProjectUsersAppService;

  const projectUsers: IProjectUsersDTO[] = [
    GoodProjectUsersDTO,
    GoodProjectUsersDTO,
    GoodProjectUsersDTO,
  ];

  const MockProjectUsersDomainService = jest.fn<IProjectUsersDomainService, []>(
    () => MockProjectUsersDomain,
  );
  const mockProjectUsersDomainService = new MockProjectUsersDomainService();
  beforeEach(() => {
    appService = new ProjectUsersAppService(mockProjectUsersDomainService);
  });
  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(appService).toBeDefined();
  });

  it('should update project users', () => {
    appService.updateProjectUsers(123, projectUsers);
    expect(mockProjectUsersDomainService.updateProjectUsers).toBeCalledTimes(1);
  });
});
