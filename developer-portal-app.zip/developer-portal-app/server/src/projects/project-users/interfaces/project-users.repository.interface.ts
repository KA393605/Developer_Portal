import { IProjectUsersDTO } from '../interfaces';
import { IProjectUser } from './project-user.interface';
import { IUser } from '../../../users/interfaces';

export interface IProjectUsersRepository {
  findOne(projectId: number, userId: number): Promise<IProjectUser>;
  updateProjectUsers: (projectId: number, data: IProjectUsersDTO[]) => void;
  findUserByRegistrationAndRole(
    registrationId: number,
    roleName: string,
  ): Promise<IUser>;
}
