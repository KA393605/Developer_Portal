import { IProjectUsersDTO } from '../interfaces';
import { IProjectUser } from './project-user.interface';

export interface IProjectUsersDomainService {
  findOne(projectId: number, userId: number): Promise<IProjectUser>;
  updateProjectUsers(projectId: number, data: IProjectUsersDTO[]): any;
}
