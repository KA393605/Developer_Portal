import { IUserCreateRequest } from '../../../users/interfaces/user-create-request.interface';
export interface IProjectUsersDTO extends IUserCreateRequest {
  roleId: number;
}
