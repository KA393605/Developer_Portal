import { IProjectUsersDTO } from '../interfaces';

export interface IProjectUsersAppService {
  updateProjectUsers(projectId: number, data: IProjectUsersDTO[]): any;
}
