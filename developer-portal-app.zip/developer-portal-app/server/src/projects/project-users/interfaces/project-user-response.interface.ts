export interface IProjectUserResponse {
  userId: number;
  fullName: string;
  firstName: string;
  lastName: string;
  mudId: string;
  email: string;
  roleId?: number;
  roleName?: string;
}
