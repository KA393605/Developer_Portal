import { IProject } from '../../interfaces/';
import { IRole } from '../../../core/interfaces';
import { IUser } from '../../../users/interfaces/user.interface';

export interface IProjectUser {
  uniqueKey: string;
  project: Promise<IProject>;
  user: Promise<IUser>;
  role: Promise<IRole>;
}
