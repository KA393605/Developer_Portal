import { IProjectUsersDTO } from '../interfaces';

export const GoodProjectUsersDTO: IProjectUsersDTO = {
  mudId: 'foobar',
  email: 'foo@bar.com',
  fullName: 'Foo Bar',
  roleId: 123,
};
