import { IProjectUsersRepository } from '../interfaces';
import { GoodProjectUser } from './project-user.mock';
import { GoodUser } from '../../../users/mocks';
export const MockProjectUsersRepository: IProjectUsersRepository = {
  updateProjectUsers: jest.fn((projectId, data) => {
    return 'Success';
  }),
  findOne: jest.fn(() => {
    return Promise.resolve(GoodProjectUser);
  }),
  findUserByRegistrationAndRole: jest.fn(() => Promise.resolve(GoodUser)),
};
