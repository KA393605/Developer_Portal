import { GoodProject } from '../../mocks/project.mock';
import { GoodRole } from '../../../core/mocks/role.mock';
import { GoodUser } from '../../../users/mocks/user.mock';

import { IProjectUser } from '../../project-users/interfaces';

export const GoodProjectUser: IProjectUser = {
  project: Promise.resolve(GoodProject),
  role: Promise.resolve(GoodRole),
  uniqueKey: 'Good Unique Key',
  user: Promise.resolve(GoodUser),
};
