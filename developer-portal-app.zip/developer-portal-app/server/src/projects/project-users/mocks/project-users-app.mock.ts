import { IProjectUsersAppService, IProjectUsersDTO } from '../interfaces';

export const MockProjectUsersApp: IProjectUsersAppService = {
  updateProjectUsers: jest.fn((projectId: number, data: IProjectUsersDTO[]) => {
    return 'Success';
  }),
};
