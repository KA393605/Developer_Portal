import { IProjectUsersDomainService, IProjectUsersDTO } from '../interfaces';
import { GoodProjectUser } from './project-user.mock';

export const MockProjectUsersDomain: IProjectUsersDomainService = {
  updateProjectUsers: jest.fn(
    (projectId: number, data: IProjectUsersDTO[]) => 'Success',
  ),
  findOne: jest.fn(() => Promise.resolve(GoodProjectUser)),
};
