import { IProjectUserResponse } from '../interfaces';

export const GoodProjectUserResponse: IProjectUserResponse = {
  email: 'Good',
  firstName: 'Good',
  fullName: 'Good',
  lastName: 'Good',
  mudId: 'Good',
  userId: 1,
};
