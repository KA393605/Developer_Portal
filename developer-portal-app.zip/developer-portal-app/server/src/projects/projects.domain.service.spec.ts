// ENV VAR SETUP
// This has to happen before any imports
if (!process.env.AIR_APP_SECONDARY_CONTACT_JSON) {
  process.env.AIR_APP_SECONDARY_CONTACT_JSON = '{"default":"default"}';
}
if (!process.env.AIR_APP_TERTIARY_CONTACT_JSON) {
  process.env.AIR_APP_TERTIARY_CONTACT_JSON = '{"default":"default"}';
}

// Imports
import { ProjectsDomainService } from './projects.domain.service';
import { IProjectRepository } from './interfaces';
import {
  IProjectEnvironmentRepository,
  IProjectEnvironmentServiceRepository,
  IProjectEnvironmentConnectionRepository,
} from './project-environment/interfaces';
import { IServiceRepository } from '../services/interfaces';
import { IRequestsRepository } from '../requests/interfaces';
import {
  IIntegrifyDomainService,
  ICryptService,
  IAzureServiceBusBase,
} from '../core/interfaces';
import {
  MockProjectRepository,
  GoodProjectsPatchRequest,
  GoodProject,
  GoodCreateProjectRequest,
} from './mocks';
import { MockServiceRepository } from '../services/mocks';
import {
  MockProjectEnvironmentRepository,
  GoodProjectEnvironmentConnection,
  GoodPutCallbackUrlrequest,
  MockProjectServiceRepository,
  GoodProjectEnvironmentWithProject,
  GoodProjectEnvironmentWithProjectAndService,
  GoodCreateProjectEnvironmentWithProject,
} from './project-environment/mocks';
import { MockRequestsRepository } from '../requests/mocks/requests-repository.mock';
import {
  MockIntegrifyDomainService,
  MockCryptService,
  MockAzureServiceBus,
  GoodStatus,
  GoodEnvironment,
} from '../core/mocks';
import { ENVIRONMENTS } from '../core/environments.constants';
import { IAirDomainService } from '../air/interfaces';
import { IKongDomainService } from '../kong/interfaces';
import { IGatewayCredentialsDomainService } from '../gateway-credentials/interfaces';
import { MockKongDomainService } from '../kong/mock';
import { MockAirDomainService } from '../air/mock';
import { GatewayCredentialsDomainService } from '../gateway-credentials/gateway-credentials.domain.service';
import { MockGatewayCredentialsDomainService } from '../gateway-credentials/mock';
import { IProjectUsersRepository } from './project-users/interfaces';
import { MockProjectUsersRepository } from './project-users/mocks';
import { AIR_SERVICEBUS_ACTION } from '../air/air.constants';
import {
  PROJECTS_CREATE_DEFAULT_CONNECTION_TYPE,
  // PROJECT_SERVICEBUS_ACTION,
} from './projects.constants';
import { GoodUser } from '../users/mocks';
import { KongOnboardingServiceBus } from './utilities';

describe('Projects Domain Service', () => {
  const kongOnboardingServiceBus = new KongOnboardingServiceBus();
  let domainService: ProjectsDomainService;
  let mockProjectRepo: IProjectRepository;
  let mockProjectEnvironmentRepo: IProjectEnvironmentRepository;
  let mockProjectServiceRepo: IProjectEnvironmentServiceRepository;
  let mockServiceRepo: IServiceRepository;
  let mockRequestsRepo: IRequestsRepository;
  let mockProjectConnectionRepo: IProjectEnvironmentConnectionRepository;
  let mockAirDomainService: IAirDomainService;
  let mockKongDomainService: IKongDomainService;
  let mockGatewayCredentialsDomainService: IGatewayCredentialsDomainService;
  let mockIntegrifyDomainService: IIntegrifyDomainService;
  let mockCryptService: ICryptService;
  let mockProjectUsersRepository: IProjectUsersRepository;
  let mockProjectsServiceBusSender: IAzureServiceBusBase;
  let mockProjectsServiceBusReceiver: IAzureServiceBusBase;
  let mockAirServiceBusSender: IAzureServiceBusBase;

  beforeEach(() => {
    const MockProjectRepo = jest.fn<IProjectRepository, []>(
      () => MockProjectRepository,
    );
    const MockServiceRepo = jest.fn<IServiceRepository, []>(
      () => MockServiceRepository,
    );
    const MockProjectServiceRepo = jest.fn<
      IProjectEnvironmentServiceRepository,
      []
    >(() => MockProjectServiceRepository);
    const MockProjectEnvRepo = jest.fn<IProjectEnvironmentRepository, []>(
      () => MockProjectEnvironmentRepository,
    );
    const MockRequestRepo = jest.fn<IRequestsRepository, []>(
      () => MockRequestsRepository,
    );
    const AirDomainServiceMock = jest.fn<IAirDomainService, []>(
      () => MockAirDomainService,
    );
    const MockKongDomainServ = jest.fn<IKongDomainService, []>(
      () => MockKongDomainService,
    );

    const MockProjectConnectionRepo = jest.fn<
      IProjectEnvironmentConnectionRepository,
      []
    >(() => ({
      putCallbackUrls: jest.fn(req => {
        return Promise.resolve(GoodProjectEnvironmentConnection);
      }),
    }));

    const MockGatewayCredentialsDomainServ = jest.fn<
      GatewayCredentialsDomainService,
      []
    >(() => MockGatewayCredentialsDomainService);

    const MockIntegrifyDomainServ = jest.fn<IIntegrifyDomainService, []>(
      () => MockIntegrifyDomainService,
    );

    const ProjectUsersRepositoryMock = jest.fn<IProjectUsersRepository, []>(
      () => MockProjectUsersRepository,
    );

    const CryptServiceMock = jest.fn<ICryptService, []>(() => MockCryptService);

    const AzureProjectsServiceBusBaseMock = jest.fn<IAzureServiceBusBase, []>(
      () => MockAzureServiceBus,
    );

    const AzureAirServiceBusBaseMock = jest.fn<IAzureServiceBusBase, []>(
      () => MockAzureServiceBus,
    );

    mockProjectRepo = new MockProjectRepo();
    mockServiceRepo = new MockServiceRepo();
    mockProjectServiceRepo = new MockProjectServiceRepo();
    mockProjectEnvironmentRepo = new MockProjectEnvRepo();
    mockRequestsRepo = new MockRequestRepo();
    mockProjectConnectionRepo = new MockProjectConnectionRepo();
    mockAirDomainService = new AirDomainServiceMock();
    mockKongDomainService = new MockKongDomainServ();
    mockGatewayCredentialsDomainService = new MockGatewayCredentialsDomainServ();
    mockIntegrifyDomainService = new MockIntegrifyDomainServ();
    mockCryptService = new CryptServiceMock();
    mockProjectUsersRepository = new ProjectUsersRepositoryMock();
    mockProjectsServiceBusSender = new AzureProjectsServiceBusBaseMock();
    mockProjectsServiceBusReceiver = new AzureProjectsServiceBusBaseMock();
    mockAirServiceBusSender = new AzureAirServiceBusBaseMock();

    domainService = new ProjectsDomainService(
      mockProjectRepo,
      mockProjectEnvironmentRepo,
      mockProjectServiceRepo,
      mockServiceRepo,
      mockAirDomainService,
      mockKongDomainService,
      mockGatewayCredentialsDomainService,
      mockRequestsRepo,
      mockProjectConnectionRepo,
      mockIntegrifyDomainService,
      mockCryptService,
      mockProjectUsersRepository,
      mockProjectsServiceBusReceiver,
      mockProjectsServiceBusSender,
      mockAirServiceBusSender,
    );
  });

  it('should be defined', () => {
    expect(domainService).toBeDefined();
  });

  describe('Patch', () => {
    it('Should hit repo', () => {
      domainService.patch(1, GoodProjectsPatchRequest, 1);
      expect(mockProjectRepo.patchProject).toBeCalledTimes(1);
    });

    it('Should return value on good call', async () => {
      const res = await domainService.patch(1, GoodProjectsPatchRequest, 1);
      expect(mockProjectRepo.patchProject).toBeCalledWith(
        1,
        GoodProjectsPatchRequest,
        1,
      );
      expect(res).toEqual(GoodProject);
    });
  });

  describe('Get', () => {
    it('Should hit repo', () => {
      domainService.findOne(1);
      expect(mockProjectRepo.getProjectById).toBeCalledTimes(1);
    });

    it('Should return value on good call', async () => {
      const res = await domainService.findOne(1);
      expect(mockProjectRepo.getProjectById).toBeCalledWith(1);
      expect(res).toEqual(GoodProject);
    });
  });

  describe('Create', () => {
    it('Should hit repo', () => {
      domainService.create(GoodCreateProjectRequest, 1);
      expect(mockProjectRepo.create).toBeCalledTimes(1);
    });

    it('Should return value on good call', async () => {
      const res = await domainService.create(GoodCreateProjectRequest, 1);
      expect(mockProjectRepo.create).toBeCalledWith(
        GoodCreateProjectRequest,
        1,
      );
      expect(res).toEqual(GoodProject);
    });
  });

  describe('Put callbackUrls', () => {
    it('Should return value on good call', async () => {
      const res = await domainService.putCallbackUrls(
        0,
        GoodPutCallbackUrlrequest,
      );
      expect(mockProjectConnectionRepo.putCallbackUrls).toBeCalledTimes(1);
      expect(res).toEqual(GoodProjectEnvironmentConnection);
    });
  });

  describe('Add Service To Project', () => {
    it('Should hit service', async () => {
      await domainService.addServiceById(1, 1, 1, 1);
      expect(mockProjectServiceRepo.create).toBeCalledTimes(3);
    });
  });

  describe('Remove Service From Environment', () => {
    it('Should hit repo', () => {
      domainService.removeServiceFromProjectEnvironment(1, 1, 1);
      expect(mockProjectServiceRepo.remove).toBeCalledTimes(1);
      expect(mockProjectServiceRepo.remove).toBeCalledWith(1, 1, 1);
    });
  });

  describe('Send service bus message request', () => {
    it('Should send message', () => {
      domainService.publishServiceRequestMessage(1, 1, 1, 1);
    });
  });

  describe('Promote Environment', () => {
    describe('Dev to QA - New - With Attached Service', () => {
      let getPromotionEnvironmentName;
      let removeServiceFromProjectEnvironment;
      let response;
      beforeAll(async () => {
        jest.clearAllMocks();
        // Return QA environment
        getPromotionEnvironmentName = domainService.getPromotionEnvironmentName = jest.fn(
          () => {
            return ENVIRONMENTS.QA;
          },
        );
        kongOnboardingServiceBus.onboardKongConnection = jest.fn(() =>
          Promise.resolve(null),
        );
        removeServiceFromProjectEnvironment = domainService.removeServiceFromProjectEnvironment = jest.fn(
          () => {
            return;
          },
        );
        // Return null (no project-environment found for that environment)
        mockProjectEnvironmentRepo.findOneByEnvNameAndProjectId = jest.fn(
          () => {
            return null;
          },
        );

        response = await domainService.promoteProjectEnvironment(1, 1);
      });
      it('Should hit project environment repo findOne with correct data', () => {
        expect(mockProjectEnvironmentRepo.findOne).toBeCalledTimes(2);
        expect(mockProjectEnvironmentRepo.findOne).toBeCalledWith(1);
      });
      it('Should get promotion env name', () => {
        expect(getPromotionEnvironmentName).toBeCalledTimes(1);
        expect(getPromotionEnvironmentName).toBeCalledWith(
          'Good Environment Name',
        );
      });
      it('Should get project-environment-service by environment', () => {
        expect(
          mockProjectServiceRepo.getProjectEnvironmentServiceByEnvironment,
        ).toBeCalledTimes(1);
        expect(
          mockProjectServiceRepo.getProjectEnvironmentServiceByEnvironment,
        ).toBeCalledWith(1);
      });
      it('Should check if we already have environment', () => {
        expect(
          mockProjectEnvironmentRepo.findOneByEnvNameAndProjectId,
        ).toBeCalledTimes(1);
        expect(
          mockProjectEnvironmentRepo.findOneByEnvNameAndProjectId,
        ).toBeCalledWith(ENVIRONMENTS.QA, 1);
      });
      it('Should hit project environment repo create with correct data', () => {
        expect(mockProjectEnvironmentRepo.create).toBeCalledTimes(1);
        expect(mockProjectEnvironmentRepo.create).toBeCalledWith(
          GoodProject,
          ENVIRONMENTS.QA,
          PROJECTS_CREATE_DEFAULT_CONNECTION_TYPE,
          1,
        );
      });
      it('Should loop through services and find correct versions for ENV', () => {
        expect(
          mockServiceRepo.getServiceByRegistrationVersionEnvId,
        ).toBeCalledTimes(1);
        expect(
          mockServiceRepo.getServiceByRegistrationVersionEnvId,
        ).toBeCalledWith(1, ENVIRONMENTS.QA);
      });
      it('Should not try to remove any services', () => {
        expect(removeServiceFromProjectEnvironment).toBeCalledTimes(0);
      });
      it('Should send AIR service bus request', () => {
        expect(mockAirServiceBusSender.publish).toBeCalledTimes(1);
        expect(mockAirServiceBusSender.publish).toBeCalledWith(
          {
            eventType: AIR_SERVICEBUS_ACTION.CREATE_APP_INSTANCE,
            request: {
              airAppId: 'Good Air Application Id',
              env: ENVIRONMENTS.QA,
              projectEnvId: 1,
              projectId: 1,
              userId: 1,
              request: undefined,
              serviceIds: [1],
            },
          },
          { sessionId: undefined },
        );
      });
      it('Response should be correct', () => {
        expect(response).toEqual(GoodCreateProjectEnvironmentWithProject);
      });
      afterAll(() => {
        jest.clearAllMocks();
      });
    });
    describe('Dev to QA - Existing - With Attached Service', () => {
      let getPromotionEnvironmentName;
      let removeServiceFromProjectEnvironment;
      let response;
      let findOneByEnvNameAndProjectId;
      let findOne;
      beforeAll(async () => {
        jest.clearAllMocks();
        // Return QA environment
        getPromotionEnvironmentName = domainService.getPromotionEnvironmentName = jest.fn(
          () => {
            return ENVIRONMENTS.QA;
          },
        );
        kongOnboardingServiceBus.onboardKongConnection = jest.fn(() =>
          Promise.resolve(null),
        );
        removeServiceFromProjectEnvironment = domainService.removeServiceFromProjectEnvironment = jest.fn(
          () => {
            return;
          },
        );
        findOneByEnvNameAndProjectId = mockProjectEnvironmentRepo.findOneByEnvNameAndProjectId = jest.fn(
          () => {
            const res = GoodProjectEnvironmentWithProject;
            res.projectEnvironmentServices = Promise.resolve([
              {
                projectEnvironment: Promise.resolve({
                  projectEnvironmentId: 1,
                  project: Promise.resolve(GoodProject),
                  environment: Promise.resolve(GoodEnvironment),
                  status: Promise.resolve(GoodStatus),
                  airInstanceId: 'good id',
                  createUser: Promise.resolve(GoodUser),
                  lastUpdateUser: Promise.resolve(GoodUser),
                  connections: Promise.resolve([]),
                  projectEnvironmentServices: Promise.resolve([]),
                }),
                projectEnvironmentServiceId: 2,
                service: Promise.resolve({
                  serviceId: 2,
                  registrationVersion: Promise.resolve(null),
                  environment: Promise.resolve(null),
                  projectEnvironment: Promise.resolve(null),
                  serviceProperties: {},
                  requiresApproval: false,
                  requiresNotification: false,
                  status: Promise.resolve(null),
                  createUser: Promise.resolve(null),
                  lastUpdateUser: Promise.resolve(null),
                  createTimestamp: 'good',
                  updateTimestamp: 'good',
                  deleteTimestamp: 'good',
                }),
                status: Promise.resolve(GoodStatus),
                createTimestamp: 'Good Create Timestamp',
                updateTimestamp: 'Good Update Timestamp',
                deleteTimestamp: 'Good Delete Timestamp',
              },
            ]);
            return Promise.resolve(res);
          },
        );
        findOne = mockProjectEnvironmentRepo.findOne = findOne = jest.fn(() =>
          Promise.resolve(GoodProjectEnvironmentWithProjectAndService),
        );
        mockProjectEnvironmentRepo.findOneByEnvNameAndProjectId = findOneByEnvNameAndProjectId;
        response = await domainService.promoteProjectEnvironment(1, 1);
      });
      it('Should hit project environment repo findOne with correct data', () => {
        expect(findOne).toBeCalledTimes(2);
        expect(findOne).toBeCalledWith(1);
      });
      it('Should get promotion env name', () => {
        expect(getPromotionEnvironmentName).toBeCalledTimes(1);
        expect(getPromotionEnvironmentName).toBeCalledWith(
          'Good Environment Name',
        );
      });
      it('Should get project-environment-service by environment', () => {
        expect(
          mockProjectServiceRepo.getProjectEnvironmentServiceByEnvironment,
        ).toBeCalledTimes(1);
        expect(
          mockProjectServiceRepo.getProjectEnvironmentServiceByEnvironment,
        ).toBeCalledWith(1);
      });
      it('Should check if we already have environment', () => {
        expect(findOneByEnvNameAndProjectId).toBeCalledTimes(1);
        expect(findOneByEnvNameAndProjectId).toBeCalledWith(ENVIRONMENTS.QA, 1);
      });
      it('Should not hit project environment repo create with correct data', () => {
        expect(mockProjectEnvironmentRepo.create).toBeCalledTimes(0);
      });
      it('Should loop through services and find correct versions for ENV', () => {
        expect(
          mockServiceRepo.getServiceByRegistrationVersionEnvId,
        ).toBeCalledTimes(1);
        expect(
          mockServiceRepo.getServiceByRegistrationVersionEnvId,
        ).toBeCalledWith(1, ENVIRONMENTS.QA);
      });
      it('Should try to remove additional services', () => {
        expect(removeServiceFromProjectEnvironment).toBeCalledTimes(1);
        expect(removeServiceFromProjectEnvironment).toBeCalledWith(
          1,
          1,
          undefined,
        );
      });
      // it('Should send project service, service bus request', () => {
      //   expect(mockProjectsServiceBusSender.publish).toBeCalledTimes(1);
      //   expect(mockProjectsServiceBusSender.publish).toBeCalledWith(
      //     {
      //       eventType: PROJECT_SERVICEBUS_ACTION.ADD_SERVICE,
      //       request: {
      //         projectEnvironmentId: 1,
      //         projectId: 1,
      //         projectEnvironmentServiceId: 1,
      //         request: undefined,
      //         serviceId: 1,
      //         userId: 1,
      //       },
      //     },
      //     { sessionId: undefined },
      //   );
      // });
      it('Response should be correct', () => {
        expect(response).toEqual(GoodProjectEnvironmentWithProject);
      });
      afterAll(() => {
        jest.clearAllMocks();
      });
    });
  });
});
