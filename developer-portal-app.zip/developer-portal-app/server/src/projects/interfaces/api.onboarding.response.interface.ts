import { uuid4 } from 'rhea/typings/util';
import { IKongOnboardingRequest } from '.';

export interface IEventGridMessage {
  id: uuid4;
  subject: string;
  eventType: string;
  data: IKongOnboardingRequest;
  eventTime: any;
  dataVersion: string;
  metadataVersion: string;
  topic: string;
}
