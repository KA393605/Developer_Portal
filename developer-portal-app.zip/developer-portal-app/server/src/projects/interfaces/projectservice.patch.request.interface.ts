export interface IProjectServicePatchRequest {
  statusId?: string;
}
