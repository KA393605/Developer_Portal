import { IProject } from './project.interface';

export interface IProjectsResponse {
  projectsCount: number;
  projects: IProject[];
}
