import { IProjectPermissionsTeamGetResponse } from './project-team-response-interface';
import { IProjectUserResponse } from '../project-users/interfaces';

export interface IProjectPermissionsGetResponse {
  users: IProjectUserResponse[];
  teams: IProjectPermissionsTeamGetResponse[];
}
