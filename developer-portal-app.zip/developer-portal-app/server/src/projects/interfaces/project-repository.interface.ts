import { IProjectsPostRequest, IProject, IProjectsPatchRequest } from '.';

export interface IProjectRepository {
  create: (data: IProjectsPostRequest, userId: number) => Promise<IProject>;
  patchProject: (
    id: number,
    data: IProjectsPatchRequest,
    userId: number,
  ) => Promise<IProject>;
  getProjectById: (id: number) => Promise<IProject>;
  remove: (id: number) => Promise<IProject>;
  getProjectAndTeams: (id: number) => Promise<IProject>;
  exists(projectId: number): Promise<boolean>;
}
