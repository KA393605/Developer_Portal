export interface IProjectsRequest {
  userId: number;
  filter?: object;
  results?: number;
  pageNumber?: number;
}
