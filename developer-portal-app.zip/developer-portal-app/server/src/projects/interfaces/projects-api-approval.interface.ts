export interface IProjectAPIApproval {
  name: string;
  mudID: string;
  email: string;
  businessOwner: string;
  serviceName: string;
  serviceVersion: string;
  serviceEnvironment: string;
  API: string;
  projectName: string;
  projectDescription: string;
  businessJustification: string;
  businessUnit: string;
}
