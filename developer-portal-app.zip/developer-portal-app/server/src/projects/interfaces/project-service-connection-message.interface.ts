import { IProjectsPromoteToProdRequest } from '../project-environment/interfaces';

export interface IProjectServiceConnectionMessage {
  eventType: string;
  request: {
    projectId: number;
    projectEnvironmentId: number;
    serviceId: number;
    userId: number;
    projectEnvironmentServiceId?: number;
    request?: IProjectsPromoteToProdRequest;
  };
}
