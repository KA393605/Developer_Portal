import { IUser } from '../../users/interfaces';
import { IStatus } from '../../core/interfaces';
import { IProjectEnvironment } from '../project-environment/interfaces';
import { ITeamProjectRole } from '.';
import { IProjectUser } from '../project-users/interfaces';

export interface IProject {
  uniqueKey: string;
  projectId: number;
  projectName: string;
  projectDescription: string;
  billableUser: Promise<IUser>;
  airApplicationId: string;
  status: Promise<IStatus>;
  createUser: Promise<IUser>;
  lastUpdateUser: Promise<IUser>;
  createTimestamp: string;
  updateTimestamp: string;
  deleteTimestamp: string;
  environments: Promise<IProjectEnvironment[]>;
  teams: Promise<ITeamProjectRole[]>;
  projectUsers: Promise<IProjectUser[]>;
}
