import { IProjectUserResponse } from '../project-users/interfaces';
import { IProjectEnvironment } from '../project-environment/interfaces';

export interface IProjectGetResponse {
  projectId: number;
  projectName: string;
  projectDescription: string;
  publisherUser: IProjectUserResponse;
  billableUser: IProjectUserResponse;
  lastUpdateUser: IProjectUserResponse;
  airApplicationId: string;
  statusId: number;
  statusName: string;
  createTimestamp: string;
  updateTimestamp: string;
  environments: IProjectEnvironment[];
  projectUsers: IProjectUserResponse[];
}
