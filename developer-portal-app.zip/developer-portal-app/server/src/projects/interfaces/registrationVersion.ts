import { IRegistration } from './registration';

export interface IRegistrationVersion extends IRegistration {
  registrationVersonId?: number;
  versionId: number;
  registrationVersionProperties: {};
}
