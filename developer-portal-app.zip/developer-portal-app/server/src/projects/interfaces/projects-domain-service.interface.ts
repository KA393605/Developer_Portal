import { IProjectsPostRequest, IProject, IProjectsPatchRequest } from '.';
import {
  IProjectsPromoteToProdRequest,
  IProjectEnvironment,
  IProjectEnvironmentPatchRequest,
  IProjectEnvironmentService,
  IProjectEnvironmentConnectionCallbackUrlPutRequest,
  IProjectEnvironmentConnection,
} from '../project-environment/interfaces';
import { IService } from '../../services/interfaces';

export interface IProjectsDomainService {
  create: (data: IProjectsPostRequest, userId: number) => Promise<IProject>;
  patch: (
    id: number,
    data: IProjectsPatchRequest,
    userId: number,
  ) => Promise<IProject>;
  findOne: (id: number) => Promise<IProject>;
  remove: (id: number) => Promise<IProject>;
  findOneWithTeams: (id: number) => Promise<IProject>;
  promoteProjectEnvironment: (
    envId: number,
    userId: number,
    request?: IProjectsPromoteToProdRequest,
  ) => Promise<IProjectEnvironment>;
  getEnvironmentServices: (
    projectId: number,
    projEnvId: number,
    userId: number,
  ) => Promise<unknown>;
  getEnvironmentStatus: (
    projectId: number,
    projEnvId: number,
    userId: number,
  ) => Promise<unknown>;
  getEnvironmentAuth: (
    projectId: number,
    projEnvId: number,
    userId: number,
  ) => Promise<unknown>;
  getProjectServiceByEnvironment: (
    projEnvId: number,
  ) => Promise<IProjectEnvironmentService[]>;
  getServiceById: (id: number) => Promise<IService>;
  patchEnvironment: (
    envId: number,
    patchRequest: IProjectEnvironmentPatchRequest,
  ) => Promise<IProjectEnvironment>;
  findAll(query, data, userId: number, filterProducerProjects?: boolean);
  putCallbackUrls(
    projectEnvironmentId: number,
    data: IProjectEnvironmentConnectionCallbackUrlPutRequest,
  ): Promise<IProjectEnvironmentConnection>;
  addServiceById(
    projectId: number,
    projectEnvironmentId: number,
    serviceId: number,
    userId: number,
    request?: IProjectsPromoteToProdRequest,
  );
  removeServiceFromProjectEnvironment: (
    projectId: number,
    projectEnvironmentId: number,
    serviceId: number,
  ) => void;
  getPromotionEnvironmentName(env: string): string;
  exists(projectId: number): Promise<boolean>;
  publishServiceRequestMessage(
    projectId: number,
    projectEnvId: number,
    serviceId: number,
    userId: number,
    projectEnvironmentServiceId?: number,
    request?: IProjectsPromoteToProdRequest,
  );
}
