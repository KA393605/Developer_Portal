export interface IProjectsPostResponse {
  projectId: number;
}
