export interface ITeamProjectRole {
  projectId: number;
  teamId: number;
  roleId: number;
}
