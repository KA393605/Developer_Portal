export interface IRoleResponse {
  roleId: number;
  roleName: string;
  privileges: object[];
}
