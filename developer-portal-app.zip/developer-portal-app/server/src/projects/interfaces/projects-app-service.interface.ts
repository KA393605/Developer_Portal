import {
  IProjectsPostRequest,
  IProjectsPostResponse,
  IProjectGetResponse,
  IProjectsPatchRequest,
  IProjectsPatchResponse,
} from '.';
import {
  IProjectsPromoteToProdRequest,
  IProjectsPromoteResponse,
  IProjectEnvironmentPatchRequest,
  IProjectEnvironmentPostServiceResponse,
  IProjectEnvironmentConnectionCallbackUrlPutRequest,
  ICallbackUrlPutResponse,
} from '../project-environment/interfaces';

export interface IProjectsAppService {
  create: (
    data: IProjectsPostRequest,
    userId: number,
  ) => Promise<IProjectsPostResponse>;
  getPermissions: (id: number, userId: number) => void;
  promoteProjectEnvironment(
    projectEnvironmentId: number,
    userId: number,
    request?: IProjectsPromoteToProdRequest,
  ): Promise<IProjectsPromoteResponse>;
  putCallbackUrls: (
    projectEnvironmentId: number,
    data: IProjectEnvironmentConnectionCallbackUrlPutRequest,
    userId: number,
  ) => Promise<ICallbackUrlPutResponse>;
  patchEnvironment: (
    projectEnvironmentId: number,
    patchRequest: IProjectEnvironmentPatchRequest,
    userId: number,
  ) => any;
  addServiceToProjectEnvironment: (
    projectId: number,
    projectEnvironmentId: number,
    serviceId: number,
    userId: number,
  ) => Promise<IProjectEnvironmentPostServiceResponse>;
  getProdServiceApprovalCheck: (projectEnvironmentId: number) => Promise<any[]>;
  removeServiceFromProjectEnvironment: (
    projectId: number,
    projectEnvironmentId: number,
    serviceId: number,
    userId: number,
  ) => void;
  remove(id: number, userId: number);
  findAll(query, data, userId: number, filterProducerProjects?: boolean);
  findOne(id: number, userId: number): Promise<IProjectGetResponse>;
  patch(
    id: number,
    data: IProjectsPatchRequest,
    userId: number,
  ): Promise<IProjectsPatchResponse>;
}
