// interface IWhiteListGroup {
//   whiteListGroup: string;
// }

export interface IKongOnboardingRequest {
  clientId: string;
  whiteListGroupName: string;
  environment: string;
  requestTrackingId: string;
}
