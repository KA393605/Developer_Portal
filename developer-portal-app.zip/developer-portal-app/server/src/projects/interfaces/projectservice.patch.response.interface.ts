export interface IProjectEnvironmentServicePatchResponse {
  projectEnvironmentServiceId: number;
  projectEnvironmentId: number;
  serviceId: number;
  status: string;
  createTimestamp: string;
  updateTimestamp: string;
}
