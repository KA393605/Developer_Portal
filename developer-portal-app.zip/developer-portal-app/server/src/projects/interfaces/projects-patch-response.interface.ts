export interface IProjectsPatchResponse {
  projectId: number;
  projectName: string;
  projectDescription: string;
  airApplicationId: string;
  createTimestamp: string;
  updateTimestamp: string;
  createUser: string;
  status: string;
}
