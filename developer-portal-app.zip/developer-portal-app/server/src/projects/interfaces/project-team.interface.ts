export interface IProjectTeam {
  projectId: number;
  teamId: number;
  roleId: number;
}
