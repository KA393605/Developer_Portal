export interface IRegistration {
  registrationId: number;
  resourceName: string;
  resourceDescription: string;
  registrationTypeId: number;
  projectId: number;
  registrationProperties: object;
  statusId: number;
}
