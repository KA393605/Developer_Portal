import { IProject } from './project.interface';
import {
  ProjectsPostResponseDTO,
  ProjectsPatchResponseDTO,
  ProjectGetResponseDTO,
  ProjectPermissionsGetResponseDTO,
} from '../dto';

export interface IProjectAssembler {
  buildProjectPostResponseDTO: (
    project: IProject,
  ) => Promise<ProjectsPostResponseDTO>;
  buildProjectPatchResponseDTO: (
    project: IProject,
  ) => Promise<ProjectsPatchResponseDTO>;
  buildGetByIdResponse: (project: IProject) => Promise<ProjectGetResponseDTO>;
  buildGetPermissionsResponseDTO: (
    project: IProject,
  ) => Promise<ProjectPermissionsGetResponseDTO>;
}
