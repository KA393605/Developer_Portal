export interface IProjectsPostRequest {
  projectName: string;
  projectDescription: string;
  requestedServiceId?: number;
}
