export interface IProjectsPatchRequest {
  projectName?: string;
  projectDescription?: string;
  lastUpdateUserId?: number;
  airApplicationId?: string;
  statusId?: number;
}
