export interface IProjectPermissionsTeamGetResponse {
  teamId: number;
}
