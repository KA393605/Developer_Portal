import { IAzureServiceBusBase } from 'src/core/interfaces';

export interface IProjectServiceBusReceiver extends IAzureServiceBusBase {
  createProjectReceiver(onMessageHandler: any): void;
}
