// import { IRegistration } from './registration';
import { IRegistrationVersion } from './registrationVersion';

export interface IService extends IRegistrationVersion {
  serviceId: number;
  projectEnvironmentId: number;
  serviceProperties: object;
  requiresApproval: boolean;
  requiresNotification: boolean;
}

export interface IServiceToPromote {
  serviceId: number;
  requiresApproval: boolean;
  requiresNotification: boolean;
  upstreamUrl: string;
}

export interface IPendingService {
  pendingServiceId: number;
}
