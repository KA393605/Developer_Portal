import {
  Injectable,
  OnModuleInit,
  OnModuleDestroy,
  Inject,
  ServiceUnavailableException,
  NotFoundException,
  Logger,
  BadRequestException,
} from '@nestjs/common';
import { getRepository } from 'typeorm';
import {
  IProject,
  IProjectsDomainService,
  IProjectRepository,
  IProjectsPostRequest,
  IProjectsPatchRequest,
  IProjectServiceConnectionMessage,
} from './interfaces';
import {
  IProjectEnvironment,
  IProjectEnvironmentRepository,
  IProjectEnvironmentServiceRepository,
  IProjectEnvironmentConnectionDetails,
  IProjectEnvironmentConnectionRepository,
  IProjectEnvironmentPatchRequest,
  IProjectsPromoteToProdRequest,
  IProjectEnvironmentService,
} from './project-environment/interfaces';
import { IRequestsRepository } from '../requests/interfaces';
import { IService, IServiceRepository } from '../services/interfaces';
import {
  IIntegrifyDomainService,
  IAzureServiceBusBase,
} from '../core/interfaces';
import {
  ServiceBusReceiver,
  KongOnboardingServiceBus,
  KongOnboardingEventGrid,
} from './utilities';
import { ProjectEnvironmentConnectionCallbackUrlPutRequestDTO } from './project-environment/dto';
import { ProjectsEntity } from './entities';
import { ProjectEnvironmentConnection } from './project-environment/entities';
import { CryptService } from '../core/utilities/crypt.service';
import { PROJECTS_ERROR_INVALID_PROMOTION_ENVIRONMENT } from './projects-error.constants';
import {
  PROJECTS_LIST_VIEW,
  PROJECTS_CREATE_DEFAULT_CONNECTION_TYPE,
  SERVICEBUS_SESSION_ID,
  PROJECT_SERVICEBUS_ACTION,
  PROJECT_SERVICE_SERVICEBUS_HANDLER_OPTIONS,
} from './projects.constants';
import { STATUS_NAMES } from '../core/status.constants';
import { ENVIRONMENTS } from '../core/environments.constants';
import { ROLES } from '../core/role.constants';
import { KongDomainService } from '../kong/kong.domain.service';
import {
  IGatewayCredentialsDomainService,
  IProjectGatewayCredentials,
} from '../gateway-credentials/interfaces';
import {
  IAirApplicationInstanceResponse,
  IAirDomainService,
  IAirCreateAppInstanceMessage,
  IAirCreateAppMessage,
} from '../air/interfaces';
import { GatewayCredentialsRequestDTO } from '../gateway-credentials/dto';
import { KONG_ENVIRONMENT_VARIABLES } from '../kong/kong.constants';
import { GATEWAY_CREDENTIALS_ENVIRONMENT } from '../gateway-credentials/gateway-credentials.constants';
import { IKongEnvironmentVariableInstance } from '../kong/interfaces';
import { AIR_ENVIRONMENT, AIR_SERVICEBUS_ACTION } from '../air/air.constants';
import { IProjectUsersRepository } from './project-users/interfaces';
import { OnMessage } from '@azure/service-bus';
import { INTEGRIFY_ALLOWED_STATUS } from '../core/integrify.status.constants';
import { executeQuery } from '../core/utilities';

// const delay = <T = unknown>(x: T, n?: number): Promise<T> =>
//   new Promise(r => setTimeout(() => r(x), n || Math.random() * 3000));

@Injectable()
export class ProjectsDomainService
  implements IProjectsDomainService, OnModuleInit, OnModuleDestroy {
  private serviceBusReceiver: ServiceBusReceiver;
  private kongOnboardingBus: KongOnboardingServiceBus;
  private kongOnboardingEventGrid: KongOnboardingEventGrid;
  private readonly logger: Logger = new Logger(ProjectsDomainService.name);
  constructor(
    @Inject('ProjectRepository')
    private readonly projectRepo: IProjectRepository,
    @Inject('ProjectEnvironmentRepository')
    private readonly projectEnvironmentRepo: IProjectEnvironmentRepository,
    @Inject('ProjectServiceRepository')
    private readonly projectServiceRepo: IProjectEnvironmentServiceRepository,
    @Inject('ServiceRepository')
    private readonly serviceRepo: IServiceRepository,
    @Inject('AirDomainService')
    private readonly airDomainService: IAirDomainService,
    @Inject('KongDomainService')
    private kongService: KongDomainService,
    @Inject('GatewayCredentialsDomainService')
    private readonly gatewayCredentialsDomainService: IGatewayCredentialsDomainService,
    @Inject('RequestsRepository')
    private readonly requestsRepository: IRequestsRepository,
    @Inject('ProjectConnectionRepository')
    private readonly projectConnectionRepo: IProjectEnvironmentConnectionRepository,
    @Inject('IntegrifyDomainService')
    private readonly integrifyDomainService: IIntegrifyDomainService,
    @Inject('CryptService')
    private readonly cryptService: CryptService,
    @Inject('ProjectUsersRepository')
    private readonly projectUserRepository: IProjectUsersRepository,
    @Inject('ProjectsServiceBusReceiver')
    private readonly projectsServiceBusReceiver: IAzureServiceBusBase,
    @Inject('ProjectsServiceBusSender')
    private readonly projectsServiceBusSender: IAzureServiceBusBase,
    @Inject('AirServiceBusSender')
    private readonly airServiceBusSender: IAzureServiceBusBase,
  ) {}

  onModuleInit() {
    this.logger.log('Creating module');
    // Create a connection to the Kong receiver
    this.airServiceBusSender.connect();
    const serviceBusReceiver = new ServiceBusReceiver(this.projectServiceRepo);
    this.serviceBusReceiver = serviceBusReceiver;
    this.serviceBusReceiver.connect();
    this.serviceBusReceiver.createKongReceiver();

    // Create connection to KongOnboarding EventGrid
    this.kongOnboardingEventGrid = new KongOnboardingEventGrid();
    this.kongOnboardingEventGrid.connectEventGridSubscription();

    // Create connection to KongOnboarding ServiceBus
    const kongOnboardingBus = new KongOnboardingServiceBus();
    this.kongOnboardingBus = kongOnboardingBus;
    this.kongOnboardingBus.connect();

    // Project Service Init
    this.projectsServiceBusSender.connect();
    this.projectsServiceBusReceiver.awaitReceiver(
      this.ProjectServiceBusMessageHandler,
      { sessionId: SERVICEBUS_SESSION_ID },
      PROJECT_SERVICE_SERVICEBUS_HANDLER_OPTIONS,
    );
    this.logger.log('Connected Service Bus Clients');
  }

  onModuleDestroy() {
    this.logger.log('Destroying module');
    this.serviceBusReceiver.disconnect();
    this.projectsServiceBusReceiver.disconnect();
    this.logger.log('Disconnecting Service Bus Clients');
  }

  /**
   * Creates Projects
   * Orchestrates the creation of AIR applicationId
   * Orchestrates the creation of AIR app instanceId
   * @param data Projects Create DTO
   * @param userId User Id
   * @returns Project
   */
  async create(data: IProjectsPostRequest, userId: number): Promise<IProject> {
    const project = await this.projectRepo.create(data, userId);
    const user = await project.createUser;

    // async portion, publish a message for air interaction
    const msg: IAirCreateAppMessage = {
      eventType: AIR_SERVICEBUS_ACTION.CREATE_APP,
      request: {
        description: data.projectDescription,
        env: ENVIRONMENTS.DEV,
        projectId: project.projectId,
        projectTitle: project.projectName.trim(),
        submitterEmail: user.email,
        submitterMudId: user.mudId,
        userId,
      },
    };
    // conditionally add requested service
    if (data.requestedServiceId) {
      const projectEnv = await this.projectEnvironmentRepo.findOneByEnvNameAndProjectId(
        ENVIRONMENTS.DEV,
        project.projectId,
      );

      await this.addServiceById(
        project.projectId,
        projectEnv.projectEnvironmentId,
        data.requestedServiceId,
        userId,
      );
      msg.request.serviceId = data.requestedServiceId;
      // msg.request.projectEnvironmentService = projectEnvService;
    }
    this.logger.log('Requesting Air Creation: ' + JSON.stringify(msg));
    await this.airServiceBusSender.publish(msg, {
      sessionId: SERVICEBUS_SESSION_ID,
    });
    return project;
  }

  async patch(
    id: number,
    data: IProjectsPatchRequest,
    userId: number,
  ): Promise<IProject> {
    return this.projectRepo.patchProject(id, data, userId);
  }

  async patchEnvironment(
    envId: number,
    patchRequest: IProjectEnvironmentPatchRequest,
  ): Promise<IProjectEnvironment> {
    return this.projectEnvironmentRepo.patch(envId, patchRequest);
  }

  async findAll(
    query,
    data,
    userId: number,
    filterProducerProjects: boolean = false,
  ) {
    try {
      const page = query.page || 1;
      const limit = query.results || 100;

      const qb = await getRepository(ProjectsEntity).createQueryBuilder(
        PROJECTS_LIST_VIEW,
      );
      qb.where('user_projects_vw."userId" = :userId', {
        userId,
      });
      if (filterProducerProjects) {
        // if projects have an associated registration, they are "producer" projects
        qb.andWhere(`
          ${PROJECTS_LIST_VIEW}."projectId" NOT IN (
            SELECT p."projectId" FROM catalog."Registration" r
                JOIN catalog."Project" p USING ("projectId")
              WHERE r."deleteTimestamp" IS NULL AND p."deleteTimestamp" IS NULL
            )
        `);
      }
      qb.orderBy('"updateTimestamp"', 'DESC');
      qb.take(limit);
      qb.skip((page - 1) * limit);

      const projects = await qb.getMany();
      const projectsCount = await qb.getCount();

      return { projectsCount, projects };
    } catch (error) {
      throw error;
    }
  }

  async findOne(id: number): Promise<IProject> {
    return this.projectRepo.getProjectById(id);
  }

  async remove(id: number): Promise<IProject> {
    return this.projectRepo.remove(id);
  }

  findOneWithTeams(id: number): Promise<IProject> {
    return this.projectRepo.getProjectAndTeams(id);
  }

  async createAndUpdateGatewayCredentials(
    airAppInstance: IAirApplicationInstanceResponse,
    newEnvironment: string,
  ) {
    /* Here is the entry point for keyvault logic */
    const apiKey: string = this.cryptService.generateSecret(true);
    const gatewayCreds: GatewayCredentialsRequestDTO = {
      apiKey,
      clientId: airAppInstance.identifier,
      clientSecret: airAppInstance.ssoSettings[0].clientSecret,
      env: newEnvironment,
    };
    // Gets kong credentials for whichever gateway environment we are working with
    const gateWayVars = KONG_ENVIRONMENT_VARIABLES[
      GATEWAY_CREDENTIALS_ENVIRONMENT
    ] as IKongEnvironmentVariableInstance;
    const gateWayToken = await this.kongService.getKongToken(
      gateWayVars.clientId,
      gateWayVars.secret,
      gateWayVars.tokenUrl,
    );
    await this.gatewayCredentialsDomainService.saveGatewayCredentials(
      gatewayCreds,
      gateWayToken,
    );
  }

  /**
   * Creates new project environment.
   * Hits AIR and creates new AIR instance ID and patches environment.
   * Retrieves all Project Environment - Service Environment connections.
   * Pulls back Services and finds the Service Environments for each service.
   * Creates new Project Environment - Service Environment records for new Environment.
   * Pulls back the Services and figures out which one of those require approval.
   * Send request to integrify and set to pending status.
   * For the ones that need approval, create an integrifyRequest record.
   * Send request to kong to whitelist new air clientId for requested service environment.
   * Return newly created project environment.
   * @param projectEnvironmentId Environment Id
   * @param request Request (optional)
   * @returns IProjectEnvironment
   */
  async promoteProjectEnvironment(
    projectEnvironmentId: number,
    userId: number,
    request?: IProjectsPromoteToProdRequest,
  ): Promise<IProjectEnvironment> {
    // Get current Environment.
    const currentEnvironment: IProjectEnvironment = await this.projectEnvironmentRepo.findOne(
      projectEnvironmentId,
    );

    // Check which environment we are trying to promote to.
    const environment = await currentEnvironment.environment;
    const newEnvironmentName = this.getPromotionEnvironmentName(
      environment.environmentName,
    );

    // Get Project.
    const project = await currentEnvironment.project;

    // Get environment service connections.
    const projectEnvServices = await this.projectServiceRepo.getProjectEnvironmentServiceByEnvironment(
      currentEnvironment.projectEnvironmentId,
    );

    // Check if we already have the new environment.
    let projectEnv = await this.projectEnvironmentRepo.findOneByEnvNameAndProjectId(
      newEnvironmentName,
      project.projectId,
    );
    let existingServiceIds: number[] = [];
    if (projectEnv) {
      const projectEnvironmentServices = await projectEnv.projectEnvironmentServices;
      existingServiceIds = await Promise.all(
        projectEnvironmentServices.map(async projEnvServ => {
          if (!projEnvServ.deleteTimestamp) {
            const service = await projEnvServ.service;
            return service.serviceId;
          }
        }),
      );
    } else {
      // Create if it doesn't exist
      projectEnv = await this.projectEnvironmentRepo.create(
        project,
        newEnvironmentName,
        PROJECTS_CREATE_DEFAULT_CONNECTION_TYPE,
        userId,
      );
    }

    // Loop through project env services and find version we want to add to new one.
    let serviceIds: number[] = [];
    for (const projectEnvService of projectEnvServices) {
      const service = await projectEnvService.service;
      const registrationVersion = await service.registrationVersion;
      const newServiceEnv = await this.serviceRepo.getServiceByRegistrationVersionEnvId(
        registrationVersion.registrationVersionId,
        newEnvironmentName,
      );
      serviceIds = [...serviceIds, newServiceEnv.serviceId];
    }

    // Remove services that existed in previously promoted project environment,
    // but have been removed in the new promotion
    const removeIds = existingServiceIds.filter(
      serviceId => !serviceIds.includes(serviceId),
    );
    removeIds.forEach(serviceId =>
      this.removeServiceFromProjectEnvironment(
        project.projectId,
        projectEnv.projectEnvironmentId,
        serviceId,
      ),
    );

    // Only add services that do not exist for promotion environment.
    const addIds = serviceIds.filter(
      serviceId => !existingServiceIds.includes(serviceId),
    );

    if (addIds.length !== 0) {
      for (const serviceId of addIds) {
        await this.addServiceById(
          project.projectId,
          projectEnv.projectEnvironmentId,
          serviceId,
          userId,
        );
      }
    }

    if (projectEnv.airInstanceId === '') {
      // Create Event
      const createEnvEvent: IAirCreateAppInstanceMessage = {
        eventType: AIR_SERVICEBUS_ACTION.CREATE_APP_INSTANCE,
        request: {
          airAppId: project.airApplicationId,
          env: newEnvironmentName,
          projectEnvId: projectEnv.projectEnvironmentId,
          projectId: project.projectId,
          userId,
          request,
          serviceIds: addIds,
        },
      };

      this.logger.log(
        `Requesting Air Promotion for Project: ${
          project.projectId
        } request: ${JSON.stringify(createEnvEvent)}`,
      );
      this.airServiceBusSender.publish(createEnvEvent, {
        sessionId: SERVICEBUS_SESSION_ID,
      });
    } else {
      for (const serviceId of addIds) {
        this.publishServiceRequestMessage(
          project.projectId,
          projectEnv.projectEnvironmentId,
          serviceId,
          userId,
          null,
          request,
        );
      }
    }
    return projectEnv;
  }

  async getEnvironmentStatus(
    projectId: number,
    projectEnvId: number,
    userId: number,
  ): Promise<{ statusName: string; statusId: number }> {
    const n = 'status';
    const sql = `
      SELECT
        json_build_object(
          'statusId', s."statusId",
          'statusName', s."statusName"
        ) ${n}
      FROM
        catalog."Status" s
        JOIN catalog."ProjectEnvironment" pe ON s."statusId" = pe."statusId"
        JOIN catalog."UserProjectRole" upr ON upr."projectId" = pe."projectId"
      WHERE
        pe."projectEnvironmentId" = $1
        AND upr."userId" = $2
        AND upr."deleteTimestamp" IS NULL
        AND pe."deleteTimestamp" IS NULL
        AND s."deleteTimestamp" IS NULL
      LIMIT 1;`;

    const res = await executeQuery(sql, [projectEnvId, userId]);
    if (res.rows.length) {
      return res.rows[0][n];
    }
    throw new BadRequestException();
  }

  async getEnvironmentAuth(
    projectId: number,
    projectEnvId: number,
    userId: number,
  ) {
    const projEnv = await this.projectEnvironmentRepo.findOne(projectEnvId);
    const projConnection = await ProjectEnvironmentConnection.findOneOrFail({
      where: { projectEnvironmentId: projectEnvId },
    });

    // Gets kong credentials for whichever gateway environment we are working with
    const gateWayVars = KONG_ENVIRONMENT_VARIABLES[
      GATEWAY_CREDENTIALS_ENVIRONMENT.toUpperCase()
    ] as IKongEnvironmentVariableInstance;
    const gateWayToken = await this.kongService.getKongToken(
      gateWayVars.clientId,
      gateWayVars.secret,
      gateWayVars.tokenUrl,
    );
    // keyvault logic
    const environment = await projEnv.environment;
    const connectionDetails = projConnection.connectionDetails as IProjectGatewayCredentials;
    const callbackUrls = (projConnection.connectionDetails as IProjectEnvironmentConnectionDetails)
      .callbackUrls;
    const projCreds = await this.gatewayCredentialsDomainService.getGatewayCredentials(
      connectionDetails.clientId,
      environment.environmentName,
      gateWayToken,
    );
    connectionDetails.clientSecret = projCreds.clientSecret;
    connectionDetails.apiKey = projCreds.apiKey;

    return {
      basic: {
        ApiKey: projCreds.apiKey,
      },
      OAuth: {
        clientId: connectionDetails.clientId,
        callbackUrls,
        secret: projCreds.clientSecret,
      },
    };
  }

  async getEnvironmentServices(
    projectId: number,
    projectEnvId: number,
    userId: number,
  ) {
    const pEnv = await this.projectEnvironmentRepo.findOne(projectEnvId);
    const projectEnvironmentServices = await this.getProjectServiceByEnvironment(
      projectEnvId,
    );

    const connectedServices = [];
    for (const projectEnvService of projectEnvironmentServices) {
      const status = await projectEnvService.status;
      const service = await projectEnvService.service;
      const registrationVersion = await service.registrationVersion;
      const environment = await service.environment;
      const registration = await registrationVersion.registration;

      const serveDTO = {
        registrationVersionId: registrationVersion.registrationVersionId,
        serviceName: registration.resourceName,
        serviceDescription: registration.resourceDescription,
        statusId: status.statusId,
        statusName: status.statusName,
        projectEnvironmentId: pEnv.projectEnvironmentId,
        serviceId: service.serviceId,
        environmentName: environment.environmentName,
        // apparently there can be more than 1 kong proxy path, but ui does not account for it
        // and i haven't seen it any of the data so far
        upstreamUrl: (service.serviceProperties.kong_proxy_path || [])[0] || '',
        authenticationType: service.serviceProperties
          .enabled_oidc_plugin_instead_of_keyauth
          ? 'OAuth'
          : 'Basic',
      };
      connectedServices.push(serveDTO);
    }
    return { connectedServices };
  }

  async getProjectServiceByEnvironment(projEnvId: number) {
    return this.projectServiceRepo.getProjectEnvironmentServiceByEnvironment(
      projEnvId,
    );
  }

  async getServiceById(id: number): Promise<IService> {
    return this.serviceRepo.getServiceById(id);
  }

  async patchProjectServiceEnvironment(
    projectServiceEnvId: number,
    statusName: string,
  ) {
    return this.projectServiceRepo.patch(projectServiceEnvId, statusName);
  }

  async putCallbackUrls(
    projectEnvId: number,
    data: ProjectEnvironmentConnectionCallbackUrlPutRequestDTO,
  ) {
    const env: IProjectEnvironment = await this.projectEnvironmentRepo.findOne(
      projectEnvId,
    );

    const airAppId = env.airInstanceId;

    await this.airDomainService.putCallbackUrls(
      airAppId,
      data.urls,
      AIR_ENVIRONMENT,
    );

    return await this.projectConnectionRepo.putCallbackUrls(projectEnvId, data);
  }

  async addServiceById(
    projectId: number,
    projectEnvironmentId: number,
    serviceId: number,
    userId: number,
  ): Promise<IProjectEnvironmentService> {
    const projectEnv = await this.projectEnvironmentRepo.findOne(
      projectEnvironmentId,
    );

    const service = await this.getServiceById(serviceId);

    const projectEnvService = await this.projectServiceRepo.create(
      projectEnv,
      service,
      service.requiresApproval
        ? STATUS_NAMES.PENDINGAPPROVAL
        : STATUS_NAMES.PROVISIONING,
      userId,
    );

    return projectEnvService;
  }

  async publishServiceRequestMessage(
    projectId: number,
    projectEnvId: number,
    serviceId: number,
    userId: number,
    projectEnvironmentServiceId?: number,
    request?: IProjectsPromoteToProdRequest,
  ) {
    // Create a message to send to event hub
    const projectServiceMessage: IProjectServiceConnectionMessage = {
      eventType: PROJECT_SERVICEBUS_ACTION.ADD_SERVICE,
      request: {
        projectEnvironmentId: projectEnvId,
        projectId,
        serviceId,
        userId,
      },
    };

    if (projectEnvironmentServiceId) {
      projectServiceMessage.request.projectEnvironmentServiceId = projectEnvironmentServiceId;
    } else if (request) {
      projectServiceMessage.request.request = request;
    }

    this.logger.log(
      'Requesting Project Service Connection. Msg: ' +
        JSON.stringify(projectServiceMessage),
    );
    this.projectsServiceBusSender.publish(projectServiceMessage, {
      sessionId: SERVICEBUS_SESSION_ID,
    });
  }

  /**
   * Routes Project Service Bus Messages
   */
  ProjectServiceBusMessageHandler: OnMessage = async brokeredMessage => {
    this.logger.log(
      'Received Message: ' + JSON.stringify(brokeredMessage.body),
    );
    const messageStatus = brokeredMessage.body.eventType;

    switch (messageStatus) {
      case PROJECT_SERVICEBUS_ACTION.ADD_SERVICE:
        try {
          const connectServiceMsg = brokeredMessage.body as IProjectServiceConnectionMessage;
          const project = await this.findOne(
            connectServiceMsg.request.projectId,
          );
          const projectEnvironment = await this.projectEnvironmentRepo.findOne(
            connectServiceMsg.request.projectEnvironmentId,
          );
          const service = await this.getServiceById(
            connectServiceMsg.request.serviceId,
          );
          const registrationVersion = await service.registrationVersion;
          const registration = await registrationVersion.registration;
          const projectPublisher = await project.createUser;
          const environment = await projectEnvironment.environment;
          const connectionEntities = await projectEnvironment.connections;

          const request = connectServiceMsg.request.request;
          const userId = connectServiceMsg.request.userId;

          const projectEnvironmentService = await this.projectServiceRepo.getProjectEnvironmentServiceByIds(
            connectServiceMsg.request.projectEnvironmentId,
            connectServiceMsg.request.serviceId,
          );

          const status = await projectEnvironmentService.status;

          if (
            (service.requiresApproval || service.requiresNotification) &&
            status.statusName !== INTEGRIFY_ALLOWED_STATUS.APPROVED
          ) {
            const businessOwner = await this.projectUserRepository.findUserByRegistrationAndRole(
              registration.registrationId,
              ROLES.OWNER,
            );
            const integrifyResponse = await this.integrifyDomainService.promoteProjectRequest(
              project,
              service,
              businessOwner,
              projectPublisher,
              environment.environmentName,
              registration,
              registrationVersion,
              request,
            );
            // Create request record.
            await this.requestsRepository.create(
              projectEnvironmentService,
              integrifyResponse.message,
              userId,
            );
          }

          if (!service.requiresApproval) {
            const environmentName = this.kongService.translateEnvironment(
              environment.environmentName,
            );
            for (const connectionEntity of connectionEntities) {
              const connectionDetails = connectionEntity.connectionDetails as IProjectEnvironmentConnectionDetails;
              const cId = connectionDetails.clientId;
              if (!cId) {
                continue;
              }
              const event = {
                clientId: cId,
                whiteListGroupName:
                  service.serviceProperties.whiteListGroupName,
                environment: environmentName,
                requestTrackingId: projectEnvironmentService.projectEnvironmentServiceId.toString(),
              };
              await this.kongOnboardingBus.onboardKongConnection(event);
            }
          }

          if (
            !service.requiresApproval ||
            status.statusName === INTEGRIFY_ALLOWED_STATUS.APPROVED
          ) {
            const environmentName = this.kongService.translateEnvironment(
              environment.environmentName,
            );
            for (const connectionEntity of connectionEntities) {
              const connectionDetails = connectionEntity.connectionDetails as IProjectEnvironmentConnectionDetails;
              const cId = connectionDetails.clientId;
              if (!cId) {
                continue;
              }
              const event = {
                clientId: cId,
                whiteListGroupName:
                  service.serviceProperties.whiteListGroupName,
                environment: environmentName,
                requestTrackingId: projectEnvironmentService.projectEnvironmentServiceId.toString(),
              };
              await this.kongOnboardingBus.onboardKongConnection(event);
            }
          }
          this.logger.log(
            'Completed request: ' + JSON.stringify(brokeredMessage.body),
          );
          brokeredMessage.complete();
        } catch (error) {
          brokeredMessage.abandon();
          this.logger.log(error);
        }
        break;
      default:
        brokeredMessage.deadLetter({
          deadletterReason: brokeredMessage.body.eventType,
          deadLetterErrorDescription: 'Message eventType not recognized.',
        });
        this.logger.error(
          new NotFoundException(JSON.stringify(brokeredMessage)),
        );
    }
  };

  removeServiceFromProjectEnvironment(
    projectId: number,
    projectEnvironmentId: number,
    serviceId: number,
  ) {
    this.projectServiceRepo.remove(projectId, projectEnvironmentId, serviceId);
  }

  getPromotionEnvironmentName(env: string): string {
    switch (env) {
      case ENVIRONMENTS.DEV:
        return ENVIRONMENTS.QA;
      case ENVIRONMENTS.QA:
        return ENVIRONMENTS.PROD;
      default:
        throw new ServiceUnavailableException(
          PROJECTS_ERROR_INVALID_PROMOTION_ENVIRONMENT,
        );
    }
  }

  exists(projectId: number): Promise<boolean> {
    return this.projectRepo.exists(projectId);
  }
}
