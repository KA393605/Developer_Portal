import { IProjectsPostResponse } from '../interfaces';

export const GoodProjectsPostResponse: IProjectsPostResponse = {
  projectId: 1,
};
