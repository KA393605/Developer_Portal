import { Connection } from 'typeorm';

export const conn: Connection = new Connection({
  type: 'postgres',
  host: 'localhost',
});
