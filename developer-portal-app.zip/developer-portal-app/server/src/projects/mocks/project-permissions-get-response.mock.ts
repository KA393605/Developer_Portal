import { IProjectPermissionsGetResponse } from '../interfaces';

export const GoodProjectPermissionsGetResponse: IProjectPermissionsGetResponse = {
  teams: [],
  users: [],
};
