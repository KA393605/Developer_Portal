import { IProjectsAppService, IProjectsPostRequest } from '../interfaces';
import {
  GoodProjectsPostResponse,
  GoodProjectsPatchResponse,
  GoodProjectGetResponse,
} from '.';
import {
  GoodProjectsPromoteResponse,
  GoodProjectEnvironmentPostServiceResponse,
  GoodCallbackUrlPutResponse,
} from '../project-environment/mocks';

export const MockProjectsAppService: IProjectsAppService = {
  // Needs to be fixed to use DTOs and repos
  findAll: jest.fn(req => {
    return req;
  }),
  create: jest.fn((data: IProjectsPostRequest) =>
    Promise.resolve(GoodProjectsPostResponse),
  ),
  patch: jest.fn(() => Promise.resolve(GoodProjectsPatchResponse)),
  findOne: jest.fn(() => Promise.resolve(GoodProjectGetResponse)),
  remove: jest.fn(() => 'Success'),
  getPermissions: jest.fn(() => 'Success'),
  promoteProjectEnvironment: jest.fn(() =>
    Promise.resolve(GoodProjectsPromoteResponse),
  ),
  addServiceToProjectEnvironment: jest.fn(() =>
    Promise.resolve(GoodProjectEnvironmentPostServiceResponse),
  ),
  patchEnvironment: jest.fn(() => 'Success'),
  putCallbackUrls: jest.fn(() => Promise.resolve(GoodCallbackUrlPutResponse)),
  removeServiceFromProjectEnvironment: jest.fn(() => Promise.resolve()),
  getProdServiceApprovalCheck: jest.fn(() => Promise.resolve([])),
};
