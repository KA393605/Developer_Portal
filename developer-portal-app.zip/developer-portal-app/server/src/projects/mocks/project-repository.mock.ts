import { IProjectRepository } from '../interfaces';
import { GoodProject } from '.';

export const MockProjectRepository: IProjectRepository = {
  patchProject: jest.fn(() => Promise.resolve(GoodProject)),
  getProjectById: jest.fn(() => Promise.resolve(GoodProject)),
  create: jest.fn(() => Promise.resolve(GoodProject)),
  getProjectAndTeams: jest.fn(() => Promise.resolve(GoodProject)),
  remove: jest.fn(() => Promise.resolve(GoodProject)),
  exists: jest.fn(() => Promise.resolve(true)),
};
