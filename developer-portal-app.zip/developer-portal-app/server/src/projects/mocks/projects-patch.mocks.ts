import { IProjectsPatchRequest, IProjectsPatchResponse } from '../interfaces';

export const GoodProjectsPatchRequest: IProjectsPatchRequest = {
  airApplicationId: 'good',
  projectDescription: 'good',
  projectName: 'good',
  lastUpdateUserId: 1,
  statusId: 1,
};

export const GoodProjectsPatchResponse: IProjectsPatchResponse = {
  projectId: 1,
  projectName: 'good',
  projectDescription: 'good',
  airApplicationId: 'good',
  createTimestamp: 'good',
  updateTimestamp: 'good',
  createUser: 'good',
  status: 'good',
};
