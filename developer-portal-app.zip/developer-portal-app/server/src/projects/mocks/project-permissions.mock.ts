export const GoodGetPermissionsResponse = {
  users: [],
  teams: [],
};
