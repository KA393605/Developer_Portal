import { IProject } from '../interfaces';
import { GoodUser } from '../../users/mocks';
import { GoodProjectEnvironment } from '../project-environment/mocks';

export const GoodProject: IProject = {
  uniqueKey: 'foo',
  projectId: 1,
  projectName: 'mockName',
  projectDescription: 'mockDescription',
  billableUser: Promise.resolve(GoodUser),
  airApplicationId: 'Good Air Application Id',
  status: Promise.resolve(null),
  createUser: Promise.resolve(GoodUser),
  lastUpdateUser: Promise.resolve(GoodUser),
  environments: Promise.resolve([GoodProjectEnvironment]),
  teams: Promise.resolve(null),
  projectUsers: Promise.resolve([]),
  createTimestamp: 'foo',
  updateTimestamp: 'bar',
  deleteTimestamp: null,
};

export const GoodProjectClean: IProject = {
  deleteTimestamp: null,
  uniqueKey: 'foo',
  airApplicationId: 'Good Air Application Id',
  billableUser: Promise.resolve(null),
  createUser: Promise.resolve(null),
  lastUpdateUser: Promise.resolve(null),
  environments: Promise.resolve([GoodProjectEnvironment]),
  createTimestamp: 'foo',
  projectDescription: 'mockDescription',
  projectId: 1,
  projectName: 'mockName',
  status: Promise.resolve(null),
  teams: Promise.resolve(null),
  updateTimestamp: 'bar',
  projectUsers: Promise.resolve(null),
};
