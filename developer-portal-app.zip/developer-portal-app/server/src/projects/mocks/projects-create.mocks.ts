import { IProjectsPostRequest } from '../interfaces';

export const GoodCreateProjectRequest: IProjectsPostRequest = {
  projectName: 'foo',
  projectDescription: 'bar',
  requestedServiceId: 1,
};
