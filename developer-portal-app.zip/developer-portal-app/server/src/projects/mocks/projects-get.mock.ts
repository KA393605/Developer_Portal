import { IProjectsRequest } from '../interfaces';

export const GoodGetAllRequest: IProjectsRequest = {
  userId: 1,
  filter: {},
  results: 100,
  pageNumber: 1,
};

export const GoodGetAllResponse = {
  projects: [
    {
      projectId: 1,
      projectName: 'Success',
      projectDescription: 'Success',
      statusId: 1,
      statusName: 'Success',
      privilegeList: ['canDeleteTeamUsers', 'canEditTeam', 'canDeleteAppData'],
    },
  ],
  projectsCount: 1,
};
