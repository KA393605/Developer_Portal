import { IProjectGetResponse } from '../interfaces';
import { GoodProjectUserResponse } from '../project-users/mocks';
import { GoodProjectEnvironment } from '../project-environment/mocks';

export const GoodProjectGetResponse: IProjectGetResponse = {
  airApplicationId: 'good',
  billableUser: GoodProjectUserResponse,
  createTimestamp: 'good',
  environments: [GoodProjectEnvironment],
  lastUpdateUser: GoodProjectUserResponse,
  projectDescription: 'good',
  projectId: 1,
  projectName: 'good',
  publisherUser: GoodProjectUserResponse,
  projectUsers: [GoodProjectUserResponse],
  statusId: 1,
  statusName: 'good',
  updateTimestamp: 'good',
};
