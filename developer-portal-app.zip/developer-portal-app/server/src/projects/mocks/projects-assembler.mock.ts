import { IProjectAssembler } from '../interfaces';
import {
  GoodProjectGetResponse,
  GoodGetPermissionsResponse,
  GoodProjectsPatchResponse,
  GoodProjectsPostResponse,
} from '.';

export const MockProjectsAssembler: IProjectAssembler = {
  buildGetByIdResponse: jest.fn(id => Promise.resolve(GoodProjectGetResponse)),
  buildGetPermissionsResponseDTO: jest.fn(id =>
    Promise.resolve(GoodGetPermissionsResponse),
  ),
  buildProjectPatchResponseDTO: jest.fn(id =>
    Promise.resolve(GoodProjectsPatchResponse),
  ),
  buildProjectPostResponseDTO: jest.fn(id =>
    Promise.resolve(GoodProjectsPostResponse),
  ),
};
