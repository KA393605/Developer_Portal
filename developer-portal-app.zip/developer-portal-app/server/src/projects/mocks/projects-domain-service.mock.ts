import { IProjectsDomainService } from '../interfaces';
import { GoodProject } from '.';
import {
  GoodProjectEnvironment,
  GoodProjectEnvironmentService,
  GoodProjectEnvironmentConnection,
} from '../project-environment/mocks';
import { GoodService } from '../../services/mocks';

export const MockProjectsDomainService: IProjectsDomainService = {
  addServiceById: jest.fn(() => Promise.resolve(null)),
  create: jest.fn(() => Promise.resolve(GoodProject)),
  findAll: jest.fn(() => Promise.resolve('Success')),
  findOne: jest.fn(() => Promise.resolve(GoodProject)),
  findOneWithTeams: jest.fn(() => Promise.resolve(GoodProject)),
  getEnvironmentStatus: jest.fn(() => Promise.resolve()),
  getEnvironmentServices: jest.fn(() => Promise.resolve()),
  getEnvironmentAuth: jest.fn(() => Promise.resolve()),
  getProjectServiceByEnvironment: jest.fn(id =>
    Promise.resolve([GoodProjectEnvironmentService]),
  ),
  getServiceById: jest.fn(() => Promise.resolve(GoodService)),
  patch: jest.fn(() => Promise.resolve(GoodProject)),
  patchEnvironment: jest.fn(() => Promise.resolve(GoodProjectEnvironment)),
  promoteProjectEnvironment: jest.fn(() =>
    Promise.resolve(GoodProjectEnvironment),
  ),
  remove: jest.fn(id => Promise.resolve(GoodProject)),
  removeServiceFromProjectEnvironment: jest.fn(
    (projectId: number, projectEnvironmentId: number, serviceId: number) => {
      return;
    },
  ),
  putCallbackUrls: jest.fn(req =>
    Promise.resolve(GoodProjectEnvironmentConnection),
  ),
  getPromotionEnvironmentName: jest.fn(
    (env: string) => 'Good Environment Name',
  ),
  exists: jest.fn(() => Promise.resolve(true)),
  publishServiceRequestMessage: jest.fn(
    (
      projectId: number,
      projectEnvironmentId: number,
      serviceId: number,
      userId: number,
    ) => {
      return undefined;
    },
  ),
};
