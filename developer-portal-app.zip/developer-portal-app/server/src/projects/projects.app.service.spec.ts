import { ProjectsAppService } from './projects.app.service';
import {
  IProjectsDomainService,
  IProjectAssembler,
  IProjectsPatchResponse,
  IProject,
} from './interfaces';
import {
  IProjectEnvironmentAssembler,
  IProjectEnvironmentDomainService,
  IProjectEnvironmentPostServiceResponse,
  IProjectsPromoteResponse,
  ICallbackUrlPutResponse,
  IProjectEnvironmentServiceRepository,
} from './project-environment/interfaces';
import {
  MockProjectsDomainService,
  MockProjectsAssembler,
  GoodGetAllRequest,
  GoodProjectsPatchRequest,
  GoodProject,
  GoodProjectsPatchResponse,
  GoodGetPermissionsResponse,
} from './mocks';
import {
  MockProjectEnvironmentDomainService,
  GoodProjectsPromoteRequest,
  GoodProjectsPromoteResponse,
  GoodPutCallbackUrlrequest,
  GoodCallbackUrlPutResponse,
  GoodProjectEnvironmentAssembler,
  MockProjectServiceRepository,
  GoodProjectEnvironmentPostServiceResponse,
} from './project-environment/mocks';
import { IProjectUsersDomainService } from './project-users/interfaces';
import { MockProjectUsersDomain } from './project-users/mocks';
import { NotFoundException } from '@nestjs/common';
import { IAirDomainService } from '../air/interfaces';
import { MockAirDomainService } from '../air/mock';

describe('Projects App Service', () => {
  let appService: ProjectsAppService;
  let mockDomainService: IProjectsDomainService;
  let mockProjectAssembler: IProjectAssembler;
  let mockProjectEnvironmentAssembler: IProjectEnvironmentAssembler;
  let mockProjectEnvironmentDomainService: IProjectEnvironmentDomainService;
  let mockProjectUsersDomainService: IProjectUsersDomainService;
  let mockProjectServiceRepository: IProjectEnvironmentServiceRepository;
  let mockAirDomainService: IAirDomainService;

  beforeEach(async () => {
    const ProjectDomainServiceMock = jest.fn<IProjectsDomainService, []>(
      () => MockProjectsDomainService,
    );

    const ProjectAssemblerMock = jest.fn<IProjectAssembler, []>(
      () => MockProjectsAssembler,
    );

    const ProjectEnvironmentAssembler = jest.fn<
      IProjectEnvironmentAssembler,
      []
    >(() => GoodProjectEnvironmentAssembler);

    const ProjectEnvironmentDomainServiceMock = jest.fn<
      IProjectEnvironmentDomainService,
      []
    >(() => MockProjectEnvironmentDomainService);

    const ProjectUsersDomainServiceMock = jest.fn<
      IProjectUsersDomainService,
      []
    >(() => MockProjectUsersDomain);

    const ProjectServiceRepositoryMock = jest.fn<
      IProjectEnvironmentServiceRepository,
      []
    >(() => MockProjectServiceRepository);

    const AirDomainServiceMock = jest.fn<IAirDomainService, []>(
      () => MockAirDomainService,
    );

    mockDomainService = new ProjectDomainServiceMock();
    mockProjectAssembler = new ProjectAssemblerMock();
    mockProjectEnvironmentAssembler = new ProjectEnvironmentAssembler();
    mockProjectEnvironmentDomainService = new ProjectEnvironmentDomainServiceMock();
    mockProjectUsersDomainService = new ProjectUsersDomainServiceMock();
    mockProjectServiceRepository = new ProjectServiceRepositoryMock();
    mockAirDomainService = new AirDomainServiceMock();

    appService = new ProjectsAppService(
      mockDomainService,
      mockProjectAssembler,
      mockProjectEnvironmentAssembler,
      mockProjectUsersDomainService,
      mockProjectEnvironmentDomainService,
      mockProjectServiceRepository,
      mockAirDomainService,
    );
  });

  it('should be defined', () => {
    expect(appService).toBeDefined();
  });

  describe('Find All', () => {
    let res: any;
    beforeAll(async () => {
      res = await mockDomainService.findAll(1, GoodGetAllRequest, 1);
    });
    it('Should hit service', () => {
      expect(mockDomainService.findAll).toBeCalledTimes(1);
      expect(mockDomainService.findAll).toBeCalledWith(1, GoodGetAllRequest, 1);
    });
    it('Should return value on good call', () => {
      expect(res).toEqual('Success');
    });
  });

  describe('Patch', () => {
    let res: IProjectsPatchResponse;
    beforeAll(async () => {
      res = await appService.patch(1, GoodProjectsPatchRequest, 1);
    });
    it('Should hit service', () => {
      expect(mockDomainService.patch).toBeCalledTimes(1);
      expect(mockDomainService.patch).toBeCalledWith(
        1,
        GoodProjectsPatchRequest,
        1,
      );
    });
    it('Patch should return value on good call', () => {
      expect(mockProjectAssembler.buildProjectPatchResponseDTO).toBeCalledWith(
        GoodProject,
      );
      expect(res).toEqual(GoodProjectsPatchResponse);
    });
  });

  describe('Find One', () => {
    let res: IProject;
    beforeAll(async () => {
      res = await mockDomainService.findOne(1);
    });
    it('Should hit service', () => {
      expect(mockDomainService.findOne).toBeCalledTimes(1);
      expect(mockDomainService.findOne).toBeCalledWith(1);
    });
    it('Should return value on good call', () => {
      expect(res).toEqual(GoodProject);
    });
  });

  describe('Remove', () => {
    let res: IProject;
    beforeAll(async () => {
      res = await mockDomainService.remove(1);
    });
    it('Should hit service', () => {
      expect(mockDomainService.remove).toBeCalledTimes(1);
      expect(mockDomainService.remove).toBeCalledWith(1);
    });
    it('Should return value on good call', () => {
      expect(res).toEqual(GoodProject);
    });
  });

  describe('Get permissions', () => {
    let res: any;
    beforeAll(async () => {
      res = await appService.getPermissions(1, 1);
    });
    it('Should hit service', async () => {
      expect(mockDomainService.findOneWithTeams).toBeCalledTimes(1);
      expect(mockDomainService.findOneWithTeams).toBeCalledWith(1);
    });
    it('Should return a value on a good call', () => {
      expect(res).toEqual(GoodGetPermissionsResponse);
    });
  });

  describe('Add Service To Project', () => {
    let res: IProjectEnvironmentPostServiceResponse;
    beforeAll(async () => {
      res = await appService.addServiceToProjectEnvironment(1, 1, 1, 1);
    });
    it('Should hit service', () => {
      expect(mockDomainService.addServiceById).toBeCalledTimes(1);
      expect(mockDomainService.addServiceById).toBeCalledWith(1, 1, 1, 1);
    });
    it('Should send servicebus message', () => {
      expect(mockDomainService.publishServiceRequestMessage).toBeCalledTimes(1);
      expect(mockDomainService.publishServiceRequestMessage).toBeCalledWith(
        1,
        1,
        1,
        1,
      );
    });

    it('Should return value on good call', () => {
      expect(res).toEqual(GoodProjectEnvironmentPostServiceResponse);
    });
  });

  describe('Remove Service From Environment', () => {
    beforeAll(async () => {
      mockProjectServiceRepository.exists = jest.fn(() =>
        Promise.resolve(true),
      );
      await appService.removeServiceFromProjectEnvironment(1, 1, 1, 1);
    });
    it('Should hit service', async () => {
      expect(
        mockDomainService.removeServiceFromProjectEnvironment,
      ).toBeCalledTimes(1);
      expect(
        mockDomainService.removeServiceFromProjectEnvironment,
      ).toBeCalledWith(1, 1, 1);
    });
    it('Should hit repo', async () => {
      expect(mockProjectServiceRepository.exists).toBeCalledTimes(1);
      expect(mockProjectServiceRepository.exists).toBeCalledWith(1, 1);
    });
    it('Should throw if project environment service does not exist', async () => {
      mockProjectServiceRepository.exists = jest.fn(() =>
        Promise.resolve(false),
      );
      try {
        await appService.removeServiceFromProjectEnvironment(1, 1, 1, 1);
        // should never run
        expect(false).toBe(true);
      } catch (e) {
        expect(e).toBeInstanceOf(NotFoundException);
      }
    });
  });

  describe('Put Callback URLs', () => {
    let res: ICallbackUrlPutResponse;
    beforeAll(async () => {
      res = await appService.putCallbackUrls(1, GoodPutCallbackUrlrequest, 1);
    });
    it('PUT callbackurls should hit service', () => {
      expect(mockDomainService.putCallbackUrls).toBeCalledTimes(1);
    });

    it('PUT callbackrls should return a value on a good call', () => {
      expect(res).toEqual(GoodCallbackUrlPutResponse);
    });
  });

  describe('Promote Project Environment', () => {
    let res: IProjectsPromoteResponse;
    beforeAll(async () => {
      res = await appService.promoteProjectEnvironment(
        1,
        1,
        GoodProjectsPromoteRequest,
      );
    });
    it('Should hit service', () => {
      expect(mockDomainService.promoteProjectEnvironment).toBeCalledTimes(1);
      expect(mockDomainService.promoteProjectEnvironment).toBeCalledWith(
        1,
        1,
        GoodProjectsPromoteRequest,
      );
    });
    it('Should return correct dto', () => {
      expect(res).toEqual(GoodProjectsPromoteResponse);
    });
  });
});
