import { ProjectsController } from './projects.controller';
import {
  IProjectsAppService,
  IProjectsRequest,
  IProjectsPostResponse,
  IProjectsPatchResponse,
  IProjectGetResponse,
} from './interfaces';
import { IAuthService } from '../core/interfaces';
import {
  MockProjectsAppService,
  GoodGetAllRequest,
  GoodCreateProjectRequest,
  GoodProjectsPostResponse,
  GoodProjectsPatchRequest,
  GoodProjectsPatchResponse,
  GoodProjectGetResponse,
} from './mocks';
import {
  GoodProjectEnvironmentPatchRequest,
  GoodProjectEnvironmentPostServiceResponse,
  GoodPutCallbackUrlrequest,
  GoodCallbackUrlPutResponse,
} from './project-environment/mocks';
import {
  IProjectEnvironmentPostServiceResponse,
  ICallbackUrlPutResponse,
} from './project-environment/interfaces';
import { MockAuthService } from '../core/mocks/auth-service.mock';

describe('Projects Controller', () => {
  let controller: ProjectsController;
  let mockProjectsAppService: IProjectsAppService;
  let mockAuthService: IAuthService;
  beforeEach(async () => {
    const ProjectsAppServiceMock = jest.fn<IProjectsAppService, []>(
      () => MockProjectsAppService,
    );
    mockProjectsAppService = new ProjectsAppServiceMock();
    const AuthServiceMock = jest.fn<IAuthService, []>(() => MockAuthService);
    mockAuthService = new AuthServiceMock();

    controller = new ProjectsController(
      mockProjectsAppService,
      null,
      mockAuthService,
    );
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  describe('Get Projects', () => {
    let res: IProjectsRequest;
    beforeAll(async () => {
      res = await controller.getProjects(GoodGetAllRequest, 1, '1');
    });
    it('Should hit service', () => {
      expect(mockProjectsAppService.findAll).toBeCalledTimes(1);
      expect(mockProjectsAppService.findAll).toBeCalledWith(
        GoodGetAllRequest,
        1,
        1,
        true,
      );
    });

    it('Should return value on good call', async () => {
      expect(res).toEqual(GoodGetAllRequest);
    });
  });

  describe('Create', () => {
    let res: IProjectsPostResponse;
    beforeAll(async () => {
      res = await controller.createProject(GoodCreateProjectRequest, '1');
    });
    it('Should hit service', () => {
      expect(mockProjectsAppService.create).toBeCalledTimes(1);
      expect(mockProjectsAppService.create).toBeCalledWith(
        GoodCreateProjectRequest,
        1,
      );
    });

    it('Should return value on good call', async () => {
      expect(res).toEqual(GoodProjectsPostResponse);
    });
  });

  describe('Patch', () => {
    let res: IProjectsPatchResponse;
    beforeAll(async () => {
      res = await controller.patchProject(1, GoodProjectsPatchRequest, '1');
    });
    it('Should hit service', () => {
      expect(mockProjectsAppService.patch).toBeCalledTimes(1);
      expect(mockProjectsAppService.patch).toBeCalledWith(
        1,
        GoodProjectsPatchRequest,
        1,
      );
    });
    it('Should return value on good call', () => {
      expect(res).toEqual(GoodProjectsPatchResponse);
    });
  });

  describe('Find One', () => {
    let res: IProjectGetResponse;
    beforeAll(async () => {
      res = await controller.getProjectById(1, '1');
    });
    it('Should hit service', () => {
      expect(mockProjectsAppService.findOne).toBeCalledTimes(1);
      expect(mockProjectsAppService.findOne).toBeCalledWith(1, 1);
    });
    it('Should return value on good call', () => {
      expect(res).toEqual(GoodProjectGetResponse);
    });
  });

  describe('Delete', () => {
    let res: string;
    beforeAll(async () => {
      res = await controller.removeProject(1, '1');
    });
    it('Should hit service', () => {
      expect(mockProjectsAppService.remove).toBeCalledTimes(1);
      expect(mockProjectsAppService.remove).toBeCalledWith(1, 1);
    });
    it('Should return value on good call', () => {
      expect(res).toEqual('Success');
    });
  });

  describe('Put Callback URLs', () => {
    let res: ICallbackUrlPutResponse;
    beforeAll(async () => {
      res = await controller.putCallBackUrls(
        0,
        0,
        GoodPutCallbackUrlrequest,
        '1',
      );
    });
    it('PUT callback Urls should hit service', () => {
      expect(mockProjectsAppService.putCallbackUrls).toBeCalledTimes(1);
      expect(mockProjectsAppService.putCallbackUrls).toBeCalledWith(
        0,
        GoodPutCallbackUrlrequest,
        1,
      );
    });
    it('PUT callbackUrls should return value on good call', () => {
      expect(res).toEqual(GoodCallbackUrlPutResponse);
    });
  });

  describe('Patch Environment', () => {
    let res: any;
    beforeAll(async () => {
      res = await controller.patchProjectEnvironment(
        1,
        GoodProjectEnvironmentPatchRequest,
        '1',
      );
    });
    it('Should hit service', () => {
      expect(mockProjectsAppService.patchEnvironment).toBeCalledTimes(1);
      expect(mockProjectsAppService.patchEnvironment).toBeCalledWith(
        1,
        GoodProjectEnvironmentPatchRequest,
        1,
      );
    });
    it('Should return a good response', () => {
      expect(res).toEqual('Success');
    });
  });

  describe('Add Service', () => {
    let res: IProjectEnvironmentPostServiceResponse;
    beforeAll(async () => {
      res = await controller.attachService(1, 1, 1, '1');
    });
    it('Should hit service', () => {
      expect(
        mockProjectsAppService.addServiceToProjectEnvironment,
      ).toBeCalledTimes(1);
      expect(
        mockProjectsAppService.addServiceToProjectEnvironment,
      ).toBeCalledWith(1, 1, 1, 1);
    });
    it('Should return value on good call', () => {
      expect(res).toEqual(GoodProjectEnvironmentPostServiceResponse);
    });
  });
});
