import { Module } from '@nestjs/common';
import { ProjectsAppService } from './projects.app.service';
import { ProjectsDomainService } from './projects.domain.service';
import { ProjectRepositoryProvider } from './repositories/project.repository';
import {
  ProjectEnvironmentRepositoryProvider,
  ProjectEnvironmentServiceRepositoryProvider,
  ProjectEnvironmentConnectionRepositoryProvider,
} from './project-environment/repositories';
import { ProjectAssembler } from './assemblers';
import { ProjectEnvironmentAssembler } from './project-environment/assemblers';
import { GatewayCredentialsDomainService } from '../gateway-credentials/gateway-credentials.domain.service';
import { UsersDomainService } from '../users/users.domain.service';
import { KongDomainService } from '../kong/kong.domain.service';
import { RequestsRepositoryProvider } from '../requests/repositories';
import { IntegrifyDomainService } from '../core/integrify.domain.service';
import { AuthService } from '../core/auth.service';
import { ProjectsController } from './projects.controller';
import {
  RegistrationVersionRepositoryProvider,
  ServiceRepositoryProvider,
} from '../services/repositories';
import { UserRepositoryProvider } from '../users/repositories';
import { ProjectUsersDomainService } from './project-users/project-users.domain.service';
import { ProjectEnvironmentDomainService } from './project-environment/project-environment.domain.service';
import { ProjectUsersRepositoryProvider } from './project-users/repositories/project-users.repository';
import { RegistrationUserRoleRepositoryProvider } from '../services/repositories/registration-user-role.repository';
import { ProjectUsersModule } from './project-users/project-users.module';
import { AirModule } from '../air/air.module';
import { ProjectsServiceBusReceiver } from './projects-service-bus-receiver';
import { ProjectsServiceBusSender } from './projects-service-bus-sender';
import { RegistrationController } from './registration/registration.controller';
import { KongCreateServiceBusSender } from './registration/kong-create-service-bus-sender';
import { RegistrationService } from './registration/registration.service';

const ProjectAppServiceProvider = {
  provide: 'ProjectsAppService',
  useClass: ProjectsAppService,
};

const ProjectDomainServiceProvider = {
  provide: 'ProjectsDomainService',
  useClass: ProjectsDomainService,
};

const UsersDomainServiceProvider = {
  provide: 'UsersDomainService',
  useClass: UsersDomainService,
};

const KongDomainServiceProvider = {
  provide: 'KongDomainService',
  useClass: KongDomainService,
};

const IntegrifyDomainServiceProvider = {
  provide: 'IntegrifyDomainService',
  useClass: IntegrifyDomainService,
};

const AuthServiceProvider = {
  provide: 'AuthService',
  useClass: AuthService,
};

const ProjectUsersDomainServiceProvider = {
  provide: 'ProjectUsersDomainService',
  useClass: ProjectUsersDomainService,
};

const ProjectEnvironmentDomainServiceProvider = {
  provide: 'ProjectEnvironmentDomainService',
  useClass: ProjectEnvironmentDomainService,
};

const ProjectsServiceBusReceiverProvider = {
  provide: 'ProjectsServiceBusReceiver',
  useClass: ProjectsServiceBusReceiver,
};

const ProjectsServiceBusSenderProvider = {
  provide: 'ProjectsServiceBusSender',
  useClass: ProjectsServiceBusSender,
};

const KongCreateSericeBusSenderProvider = {
  provide: 'KongCreateServiceBusSender',
  useClass: KongCreateServiceBusSender,
};

const ProjectEnvironmentAssemblerProvider = {
  provide: 'ProjectEnvironmentAssembler',
  useClass: ProjectEnvironmentAssembler,
};

const RegistrationServiceProvider = {
  provide: 'RegistrationService',
  useClass: RegistrationService,
};

@Module({
  imports: [ProjectUsersModule, AirModule],
  controllers: [ProjectsController, RegistrationController],
  providers: [
    ProjectAppServiceProvider,
    ProjectDomainServiceProvider,
    ProjectRepositoryProvider,
    ProjectAssembler,
    ProjectEnvironmentAssemblerProvider,
    ProjectEnvironmentDomainServiceProvider,
    ProjectEnvironmentRepositoryProvider,
    ProjectEnvironmentServiceRepositoryProvider,
    ProjectEnvironmentConnectionRepositoryProvider,
    ServiceRepositoryProvider,
    RegistrationVersionRepositoryProvider,
    UserRepositoryProvider,
    UsersDomainServiceProvider,
    KongDomainServiceProvider,
    RequestsRepositoryProvider,
    GatewayCredentialsDomainService,
    IntegrifyDomainServiceProvider,
    AuthServiceProvider,
    ProjectUsersDomainServiceProvider,
    ProjectUsersRepositoryProvider,
    RegistrationUserRoleRepositoryProvider,
    ProjectsServiceBusReceiverProvider,
    ProjectsServiceBusSenderProvider,
    KongCreateSericeBusSenderProvider,
    RegistrationServiceProvider,
  ],
  exports: [ProjectDomainServiceProvider],
})
export class ProjectsModule {}
