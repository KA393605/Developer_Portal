import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';
import { Length } from 'class-validator';

@Entity({ name: 'user_projects_vw', schema: 'catalog' })
export class ProjectsEntity {
  @PrimaryGeneratedColumn({ type: 'int4' })
  projectId: number;

  @Length(1, 20)
  @Column({ type: 'varchar' })
  projectName: string;

  @Length(0, 500)
  @Column({ type: 'varchar' })
  projectDescription: string;

  @Column({ type: 'int' })
  statusId: number;

  @Length(1, 20)
  @Column({ type: 'varchar' })
  statusName: string;

  @Column({ type: 'varchar' })
  privilegeList: string;
}
