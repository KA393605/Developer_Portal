import {
  Entity,
  PrimaryGeneratedColumn,
  Generated,
  Column,
  OneToOne,
  JoinColumn,
  ManyToOne,
  OneToMany,
  BaseEntity,
} from 'typeorm';
import { User } from '../../users/entities/user.entity';
import { Status } from '../../core/entities/status.entity';
import { TeamProjectRole } from '../value-objects/project-team-role.vo';
import { ProjectEnvironment } from '../project-environment/entities';
import { ProjectUser } from '../project-users/entities';
import { IProject } from '../interfaces';

@Entity({ name: 'Project' })
export class Project extends BaseEntity implements IProject {
  @PrimaryGeneratedColumn('uuid')
  uniqueKey: string;

  @Column()
  @Generated()
  projectId: number;

  @Column()
  projectName: string;

  @Column()
  projectDescription: string;

  @OneToOne(type => User)
  @JoinColumn({
    name: 'billableUserId',
    referencedColumnName: 'userId',
  })
  billableUser!: Promise<User>;

  @Column()
  airApplicationId: string;

  @ManyToOne(type => Status, status => status.statusId)
  @JoinColumn({
    name: 'statusId',
    referencedColumnName: 'statusId',
  })
  status: Promise<Status>;

  @OneToOne(type => User)
  @JoinColumn({
    name: 'createUserId',
    referencedColumnName: 'userId',
  })
  createUser: Promise<User>;

  @OneToOne(type => User)
  @JoinColumn({
    name: 'lastUpdateUserId',
    referencedColumnName: 'userId',
  })
  lastUpdateUser: Promise<User>;

  @OneToMany(type => TeamProjectRole, pteam => pteam.project)
  teams: Promise<TeamProjectRole[]>;

  @Column()
  updateTimestamp: string;

  @Column()
  createTimestamp: string;

  @Column()
  deleteTimestamp: string;

  @OneToMany(
    type => ProjectEnvironment,
    projectEnvironment => projectEnvironment.project,
  )
  environments: Promise<ProjectEnvironment[]>;

  @OneToMany(type => ProjectUser, projectUser => projectUser.project)
  projectUsers: Promise<ProjectUser[]>;
}
