import { Injectable } from '@nestjs/common';
import {
  IProjectAssembler,
  IProject,
  IProjectPermissionsTeamGetResponse,
} from '../interfaces';
import {
  ProjectsPostResponseDTO,
  ProjectsPatchResponseDTO,
  ProjectGetResponseDTO,
  ProjectPermissionsGetResponseDTO,
} from '../dto';
import { IProjectUserResponse } from '../project-users/interfaces';
import { IProjectEnvironmentResponse } from '../project-environment/interfaces';

@Injectable()
export class ProjectAssembler implements IProjectAssembler {
  public buildProjectPostResponseDTO = async (
    project: IProject,
  ): Promise<ProjectsPostResponseDTO> => {
    const ret = new ProjectsPostResponseDTO();
    project = await project;
    ret.projectId = project.projectId;
    return ret;
  };

  public buildProjectPatchResponseDTO = async (
    project: IProject,
  ): Promise<ProjectsPatchResponseDTO> => {
    const createUser = await project.createUser;
    const status = await project.status;

    const dto = new ProjectsPatchResponseDTO();
    dto.projectId = project.projectId;
    dto.projectName = project.projectName;
    dto.projectDescription = project.projectDescription;
    dto.airApplicationId = project.airApplicationId;
    dto.createTimestamp = project.createTimestamp;
    dto.updateTimestamp = project.updateTimestamp;
    dto.createUser = createUser.mudId;
    dto.status = status.statusName;
    return dto;
  };

  public buildGetByIdResponse = async (
    project: IProject,
  ): Promise<ProjectGetResponseDTO> => {
    const res = new ProjectGetResponseDTO();
    const status = await project.status;
    const createUser = await project.createUser;
    const billableUser = await project.billableUser;
    const lastUpdateUser = await project.lastUpdateUser;

    const publisherResponse: IProjectUserResponse = {
      userId: createUser.userId,
      email: createUser.email,
      firstName: createUser.firstName,
      fullName: createUser.fullName,
      lastName: createUser.lastName,
      mudId: createUser.mudId,
    };
    const billableUserResponse: IProjectUserResponse | null = billableUser
      ? {
          userId: billableUser.userId,
          email: billableUser.email,
          firstName: billableUser.firstName,
          fullName: billableUser.fullName,
          lastName: billableUser.lastName,
          mudId: billableUser.mudId,
        }
      : null;
    const lastUpdateUserResponse: IProjectUserResponse = {
      userId: lastUpdateUser.userId,
      email: lastUpdateUser.email,
      firstName: lastUpdateUser.firstName,
      fullName: lastUpdateUser.fullName,
      lastName: lastUpdateUser.lastName,
      mudId: lastUpdateUser.mudId,
    };

    res.projectId = project.projectId;
    res.projectName = project.projectName;
    res.projectDescription = project.projectDescription;
    res.statusId = status.statusId;
    res.statusName = status.statusName;
    res.lastUpdateUser = lastUpdateUserResponse;
    res.billableUser = billableUserResponse;
    res.publisherUser = publisherResponse;

    const projectEnvironments = await project.environments;
    const environments = [];

    for (const projectEnvironment of projectEnvironments) {
      const environment = await projectEnvironment.environment;
      const envStatus = await projectEnvironment.status;

      const environmentResponse: IProjectEnvironmentResponse = {
        environmentId: environment.environmentId,
        environmentName: environment.environmentName,
        projectEnvironmentId: projectEnvironment.projectEnvironmentId,
        statusId: envStatus.statusId,
        statusName: envStatus.statusName,
      };
      environments.push(environmentResponse);
    }
    res.environments = environments;

    const users = [];
    const projectUsers = await project.projectUsers;
    for (const projectUser of projectUsers) {
      const role = await projectUser.role;
      const user = await projectUser.user;
      users.push({
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        fullName: user.fullName,
        mudId: user.mudId,
        roleId: role.roleId,
        roleName: role.roleName,
        userId: user.userId,
      });
    }
    res.projectUsers = users;
    return res;
  };

  public buildGetPermissionsResponseDTO = async (
    project: IProject,
  ): Promise<ProjectPermissionsGetResponseDTO> => {
    const res = new ProjectPermissionsGetResponseDTO();

    const users = [];
    const projectUsers = await project.projectUsers;
    for (const projectUser of projectUsers) {
      const user = await projectUser.user;
      users.push({
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        fullName: user.fullName,
        mudId: user.mudId,
        userId: user.userId,
      });
    }
    res.users = users;

    res.teams = [];
    const teams = await project.teams;
    for (const team of teams) {
      const teamRes: IProjectPermissionsTeamGetResponse = {
        teamId: team.teamId,
      };
      res.teams.push(teamRes);
    }

    return res;
  };
}
