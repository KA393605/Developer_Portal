import { ROLES } from '../core/role.constants';
import { STATUS_NAMES } from '../core/status.constants';

export const PROJECTS_PATH = 'api/projects';
export const PROJECTS_LIST_VIEW = 'user_projects_vw';

// Azure Service Bus / Event Grid
export const SERVICEBUS_SESSION_ID = process.env.SERVICEBUS_SESSION_ID;
export const KONG_SERVICEBUS_SESSION_ID =
  process.env.KONG_SERVICEBUS_SESSION_ID;

// Creation Defaults
export const PROJECTS_CREATE_DEFAULT_STATUS = STATUS_NAMES.PROVISIONED;
export const PROJECTS_CREATE_DEFAULT_ENVIRONMENT_STATUS =
  STATUS_NAMES.PROVISIONING;
export const PROJECTS_CREATE_DEFAULT_CONNECTION_STATUS =
  STATUS_NAMES.PROVISIONING;
export const PROJECTS_CREATE_DEFAULT_ACTIVE = true;
export const PROJECTS_CREATE_DEFAULT_ROLE = ROLES.OWNER;
export const PROJECTS_CREATE_DEFAULT_CONNECTION_TYPE = 'API';

// AZURE ACCESS
export const AZURE_TENANT_ID = process.env.AZURE_TENANT_ID;
export const AZURE_SUBSCRIPTION_ID = process.env.AZURE_SUBSCRIPTION_ID;
export const AZURE_RESOURCE_GROUP = process.env.AZURE_RESOURCE_GROUP;
export const AZURE_CLIENT_ID = process.env.AZURE_CLIENT_ID;
export const AZURE_CLIENT_SECRET = process.env.AZURE_CLIENT_SECRET;

// KongOnboarding ServiceBus & EventGrid
export const KONG_ONBOARDING_SERVICEBUS_CONN_STRING =
  process.env.KONG_ONBOARDING_SERVICEBUS_CONN_STRING;
export const KONG_ONBOARDING_EVENTGRID_TOPIC_ENDPOINT =
  process.env.KONG_ONBOARDING_EVENTGRID_TOPIC_ENDPOINT;
export const KONG_ONBOARDING_EVENTGRID_TOPIC_SCOPE =
  process.env.KONG_ONBOARDING_EVENTGRID_TOPIC_SCOPE;
export const KONG_ONBOARDING_SENDER_QUEUE_NAME =
  process.env.KONG_ONBOARDING_SENDER_QUEUE_NAME;
export const KONG_ENVIRONMENTS = {
  DEV: 'DEV',
  QA: 'UAT',
  PROD: 'PROD',
};

// Service Bus Receiver for Kong
export const KONG_SERVICEBUS_CONN_STRING =
  process.env.KONG_SERVICEBUS_CONN_STRING;
export const KONG_SERVICEBUS_QUEUE_ID = process.env.KONG_SERVICEBUS_QUEUE_ID;
export const KONG_SERVICEBUS_RECEIVER_QUEUE_NAME =
  process.env.KONG_SERVICEBUS_RECEIVER_QUEUE_NAME;
export const KONG_SERVICEBUS_RECEIVER_HANDLER_OPTIONS = {
  autoComplete:
    process.env.KONG_SERVICEBUS_RECEIVER_HANDLER_AUTOCOMPLETE === 'true',
  maxMessageAutoRenewLockDurationInSeconds: parseInt(
    process.env.KONG_SERVICEBUS_RECEIVER_HANDLER_RENEW_LOCK_DURATION,
    10,
  ),
  maxConcurrentCalls: parseInt(
    process.env.KONG_SERVICEBUS_RECEIVER_HANDLER_MAX_CONCURRENT_CALLS,
    10,
  ),
};

// Service Bus Receiver for async internal flows.
export const PROJECT_SERVICE_SERVICEBUS_CONN_STRING =
  process.env.PROJECT_SERVICE_SERVICEBUS_CONN_STRING;
export const PROJECT_SERVICE_SERVICEBUS_QUEUE_NAME =
  process.env.PROJECT_SERVICE_SERVICEBUS_QUEUE_NAME;

export enum PROJECT_SERVICEBUS_ACTION {
  ADD_SERVICE = 'ADD_SERVICE',
  CONNECT_SERVICE = 'CONNECT_SERVICE',
}

export const PROJECT_SERVICE_SERVICEBUS_HANDLER_OPTIONS = {
  autoComplete:
    process.env.PROJECT_SERVICE_SERVICEBUS_HANDLER_AUTOCOMPLETE === 'true',
  maxMessageAutoRenewLockDurationInSeconds: parseInt(
    process.env.PROJECT_SERVICE_SERVICEBUS_RECEIVER_HANDLER_RENEW_LOCK_DURATION,
    10,
  ),
  maxConcurrentCalls: parseInt(
    process.env
      .PROJECT_SERVICE_SERVICEBUS_RECEIVER_HANDLER_MAX_CONCURRENT_CALLS,
    10,
  ),
};
