import {
  Controller,
  Inject,
  Get,
  UsePipes,
  ValidationPipe,
  Body,
  Post,
  Patch,
  Param,
  Delete,
  Put,
  Query,
  Headers,
} from '@nestjs/common';
import { PROJECTS_PATH } from './projects.constants';
import { IProjectsAppService, IProjectsDomainService } from './interfaces';
import { IAuthService } from '../core/interfaces';
import { ProjectsPostRequestDTO, ProjectsPatchRequestDTO } from './dto';
import {
  ProjectsPromoteToProdRequestDTO,
  ProjectEnvironmentPatchRequestDTO,
  ProjectEnvironmentConnectionCallbackUrlPutRequestDTO,
} from './project-environment/dto';

@Controller(PROJECTS_PATH)
export class ProjectsController {
  constructor(
    @Inject('ProjectsAppService')
    private readonly projectsAppService: IProjectsAppService,
    @Inject('ProjectsDomainService')
    private readonly projectsDomainService: IProjectsDomainService,
    @Inject('AuthService')
    private readonly authService: IAuthService,
  ) {}

  @Get()
  @UsePipes(new ValidationPipe())
  getProjects(
    @Query() query,
    @Body() data,
    @Headers('platforms-userid') userId?: string,
  ) {
    this.authService.validateUserId(userId);
    return this.projectsAppService.findAll(
      query,
      data,
      parseInt(userId, 10),
      true,
    );
  }

  @Post()
  @UsePipes(new ValidationPipe())
  createProject(
    @Body() data: ProjectsPostRequestDTO,
    @Headers('platforms-userid') userId?: string,
  ) {
    this.authService.validateUserId(userId);
    return this.projectsAppService.create(data, parseInt(userId, 10));
  }

  @Patch(':id')
  @UsePipes(new ValidationPipe())
  patchProject(
    @Param('id') id: number,
    @Body() data: ProjectsPatchRequestDTO,
    @Headers('platforms-userid') userId?: string,
  ) {
    this.authService.validateUserId(userId);
    return this.projectsAppService.patch(id, data, parseInt(userId, 10));
  }

  @Delete(':id')
  @UsePipes(new ValidationPipe())
  removeProject(
    @Param('id') id: number,
    @Headers('platforms-userid') userId?: string,
  ) {
    this.authService.validateUserId(userId);
    return this.projectsAppService.remove(id, parseInt(userId, 10));
  }

  @Get(':id')
  @UsePipes(new ValidationPipe())
  getProjectById(
    @Param('id') id: number,
    @Headers('platforms-userid') userId?: string,
  ) {
    this.authService.validateUserId(userId);
    return this.projectsAppService.findOne(id, parseInt(userId, 10));
  }

  @Get(':id/permissions')
  getPermissions(
    @Param('id') id: number,
    @Headers('platforms-userid') userId?: string,
  ) {
    this.authService.validateUserId(userId);
    return this.projectsAppService.getPermissions(id, parseInt(userId, 10));
  }

  @Post('environments/:projectEnvId/promotetoprod')
  @UsePipes(new ValidationPipe())
  promoteToProd(
    @Param('projectEnvId') envId: number,
    @Body() data: ProjectsPromoteToProdRequestDTO,
    @Headers('platforms-userid') userId?: string,
  ) {
    this.authService.validateUserId(userId);
    return this.projectsAppService.promoteProjectEnvironment(
      envId,
      parseInt(userId, 10),
      data,
    );
  }

  @Post('environments/:projectEnvId/promotetoqa')
  @UsePipes(new ValidationPipe())
  promoteToQA(
    @Param('projectEnvId') envId: number,
    @Headers('platforms-userid') userId?: string,
  ) {
    this.authService.validateUserId(userId);
    return this.projectsAppService.promoteProjectEnvironment(
      envId,
      parseInt(userId, 10),
    );
  }

  @Patch('environments/:projectEnvId')
  @UsePipes(new ValidationPipe())
  patchProjectEnvironment(
    @Param('projectEnvId') envId: number,
    @Body() patchRequest: ProjectEnvironmentPatchRequestDTO,
    @Headers('platforms-userid') userId?: string,
  ) {
    this.authService.validateUserId(userId);
    return this.projectsAppService.patchEnvironment(
      envId,
      patchRequest,
      parseInt(userId, 10),
    );
  }

  @Get(':id/environments/:envId/status')
  getProjectEnvironmentStatus(
    @Param('id') id: number,
    @Param('envId') envId: number,
    @Headers('platforms-userid') userId?: string,
  ) {
    this.authService.validateUserId(userId);
    return this.projectsDomainService.getEnvironmentStatus(
      id,
      envId,
      parseInt(userId, 10),
    );
  }

  @Get(':id/environments/:envId/auth')
  getProjectEnvironmentAuth(
    @Param('id') id: number,
    @Param('envId') envId: number,
    @Headers('platforms-userid') userId?: string,
  ) {
    this.authService.validateUserId(userId);
    return this.projectsDomainService.getEnvironmentAuth(
      id,
      envId,
      parseInt(userId, 10),
    );
  }

  @Get(':id/environments/:envId/services')
  getProjectEnvironmentServices(
    @Param('id') id: number,
    @Param('envId') envId: number,
    @Headers('platforms-userid') userId?: string,
  ) {
    this.authService.validateUserId(userId);
    return this.projectsDomainService.getEnvironmentServices(
      id,
      envId,
      parseInt(userId, 10),
    );
  }

  /*
      Workaround for prod approval workaround non-functional
   */
  @Get('environments/:projectEnvId/prodServiceCheck')
  getProdServiceApprovalCheck(
    @Param('projectEnvId') envId: number,
    @Headers('platforms-userid') userId?: string,
  ) {
    this.authService.validateUserId(userId);

    return this.projectsAppService.getProdServiceApprovalCheck(envId);
  }

  @Post(':id/environments/:projectEnvId/services/:serviceId')
  @UsePipes(new ValidationPipe())
  attachService(
    @Param('id') projectId: number,
    @Param('projectEnvId') projectEnvironmentId: number,
    @Param('serviceId') serviceId: number,
    @Headers('platforms-userid') userId?: string,
  ) {
    this.authService.validateUserId(userId);
    return this.projectsAppService.addServiceToProjectEnvironment(
      projectId,
      projectEnvironmentId,
      serviceId,
      parseInt(userId, 10),
    );
  }

  @Delete(':id/environments/:projectEnvId/services/:serviceId')
  @UsePipes(new ValidationPipe())
  removeServiceFromProjectEnvironment(
    @Param('id') projectId: number,
    @Param('projectEnvId') projectEnvironmentId: number,
    @Param('serviceId') serviceId: number,
    @Headers('platforms-userid') userId?: string,
  ) {
    this.authService.validateUserId(userId);
    return this.projectsAppService.removeServiceFromProjectEnvironment(
      projectId,
      projectEnvironmentId,
      serviceId,
      parseInt(userId, 10),
    );
  }

  @Put('/environments/:envId/connections/callbackUrls')
  @UsePipes(new ValidationPipe({}))
  putCallBackUrls(
    @Param('envId') projectEnvironmentId: number,
    @Param('connId') connId: number,
    @Body() data: ProjectEnvironmentConnectionCallbackUrlPutRequestDTO,
    @Headers('platforms-userid') userId?: string,
  ) {
    this.authService.validateUserId(userId);
    return this.projectsAppService.putCallbackUrls(
      projectEnvironmentId,
      data,
      parseInt(userId, 10),
    );
  }
}
