import {
  Injectable,
  Inject,
  NotFoundException,
  ForbiddenException,
  ConflictException,
} from '@nestjs/common';
import {
  IProjectsAppService,
  IProjectsDomainService,
  IProjectsPatchResponse,
} from './interfaces';
import { ProjectAssembler } from './assemblers';
import { IProjectUsersDomainService } from './project-users/interfaces';
import {
  IProjectEnvironmentDomainService,
  IProjectEnvironmentAssembler,
  IProjectEnvironmentServiceRepository,
} from './project-environment/interfaces';
import {
  ProjectsPostRequestDTO,
  ProjectsPostResponseDTO,
  ProjectsPatchRequestDTO,
  ProjectGetResponseDTO,
} from './dto';
import {
  ProjectEnvironmentPatchRequestDTO,
  ProjectsPromoteToProdRequestDTO,
  ProjectEnvironmentConnectionCallbackUrlPutRequestDTO,
  ProjectsPromoteResponseDTO,
} from './project-environment/dto';
import { IAirDomainService } from '../air/interfaces';
import { executeQuery } from '../core/utilities';
import { BaseDBService } from '../core/base.service';

@Injectable()
export class ProjectsAppService extends BaseDBService
  implements IProjectsAppService {
  constructor(
    @Inject('ProjectsDomainService')
    private readonly projectsDomainService: IProjectsDomainService,
    private readonly projectAssembler: ProjectAssembler,
    @Inject('ProjectEnvironmentAssembler')
    private readonly projectEnvironmentAssembler: IProjectEnvironmentAssembler,
    @Inject('ProjectUsersDomainService')
    private readonly projectUsersDomainService: IProjectUsersDomainService,
    @Inject('ProjectEnvironmentDomainService')
    private readonly projectEnvironmentDomainService: IProjectEnvironmentDomainService,
    @Inject('ProjectServiceRepository')
    private readonly projectEnvironmentServiceRepository: IProjectEnvironmentServiceRepository,
    @Inject('AirDomainService')
    private readonly airDomainService: IAirDomainService,
  ) {
    super();
  }

  async findAll(
    query,
    data,
    userId: number,
    filterProduceProjects: boolean = false,
  ) {
    return await this.executeFunction('getUserProjects', 'catalog', [userId]);
  }

  async create(
    data: ProjectsPostRequestDTO,
    userId: number,
  ): Promise<ProjectsPostResponseDTO> {
    const res = await this.projectsDomainService.create(data, userId);
    return this.projectAssembler.buildProjectPostResponseDTO(res);
  }

  async patch(
    id: number,
    data: ProjectsPatchRequestDTO,
    userId: number,
  ): Promise<IProjectsPatchResponse> {
    if (!(await this.projectsDomainService.exists(id))) {
      throw new NotFoundException();
    }
    if (!(await this.projectUsersDomainService.findOne(id, userId))) {
      throw new ForbiddenException();
    }
    const entityResponse = await this.projectsDomainService.patch(
      id,
      data,
      userId,
    );
    return this.projectAssembler.buildProjectPatchResponseDTO(entityResponse);
  }

  async findOne(id: number, userId: number): Promise<ProjectGetResponseDTO> {
    if (!(await this.projectsDomainService.exists(id))) {
      throw new NotFoundException();
    }
    if (!(await this.projectUsersDomainService.findOne(id, userId))) {
      throw new ForbiddenException();
    }
    const res = await this.projectsDomainService.findOne(id);
    return this.projectAssembler.buildGetByIdResponse(res);
  }

  async remove(id: number, userId: number) {
    if (!(await this.projectsDomainService.exists(id))) {
      throw new NotFoundException();
    }
    if (!(await this.projectUsersDomainService.findOne(id, userId))) {
      throw new ForbiddenException();
    }
    return this.projectsDomainService.remove(id);
  }

  async getPermissions(id: number, userId: number) {
    if (!(await this.projectsDomainService.exists(id))) {
      throw new NotFoundException();
    }
    if (!(await this.projectUsersDomainService.findOne(id, userId))) {
      throw new ForbiddenException();
    }
    const project = await this.projectsDomainService.findOneWithTeams(id);
    return this.projectAssembler.buildGetPermissionsResponseDTO(project);
  }

  async patchEnvironment(
    projectEnvironmentId: number,
    patchRequest: ProjectEnvironmentPatchRequestDTO,
    userId: number,
  ) {
    if (
      !(await this.projectEnvironmentDomainService.exists(projectEnvironmentId))
    ) {
      throw new NotFoundException();
    }
    // This is why we should have made this /project/{id}/environments/{envId}
    const env = await this.projectEnvironmentDomainService.findOne(
      projectEnvironmentId,
    );
    const projectId = (await env.project).projectId;
    if (!(await this.projectUsersDomainService.findOne(projectId, userId))) {
      throw new ForbiddenException();
    }

    const res = await this.projectsDomainService.patchEnvironment(
      projectEnvironmentId,
      patchRequest,
    );
    return this.projectEnvironmentAssembler.buildPatchResponse(res);
  }

  async promoteProjectEnvironment(
    projectEnvironmentId: number,
    userId: number,
    request?: ProjectsPromoteToProdRequestDTO,
  ): Promise<ProjectsPromoteResponseDTO> {
    if (
      !(await this.projectEnvironmentDomainService.exists(projectEnvironmentId))
    ) {
      throw new NotFoundException();
    }
    if (request) {
      await this.airDomainService.getPandora(request.pandoraId);
    }
    // This is why we should have made this /project/{id}/environments/{envId}
    const env = await this.projectEnvironmentDomainService.findOne(
      projectEnvironmentId,
    );
    const projectId = (await env.project).projectId;
    if (!(await this.projectUsersDomainService.findOne(projectId, userId))) {
      throw new ForbiddenException();
    }

    const projectEnvironment = await this.projectsDomainService.promoteProjectEnvironment(
      projectEnvironmentId,
      userId,
      request,
    );
    return this.projectEnvironmentAssembler.buildPromoteResponse(
      projectEnvironment,
    );
  }

  async addServiceToProjectEnvironment(
    projectId: number,
    projectEnvironmentId: number,
    serviceId: number,
    userId: number,
  ) {
    if (
      !(await this.projectEnvironmentDomainService.exists(projectEnvironmentId))
    ) {
      throw new NotFoundException('Project Environment Not Found');
    }
    if (
      await this.projectEnvironmentServiceRepository.exists(
        projectEnvironmentId,
        serviceId,
      )
    ) {
      throw new ConflictException(
        'Service already added to this project environment',
      );
    }
    if (!(await this.projectUsersDomainService.findOne(projectId, userId))) {
      throw new ForbiddenException();
    }
    const res = await this.projectsDomainService.addServiceById(
      projectId,
      projectEnvironmentId,
      serviceId,
      userId,
    );

    this.projectsDomainService.publishServiceRequestMessage(
      projectId,
      projectEnvironmentId,
      serviceId,
      userId,
    );

    return this.projectEnvironmentAssembler.buildServiceEnvironmentResponse(
      res,
    );
  }

  async removeServiceFromProjectEnvironment(
    projectId: number,
    projectEnvironmentId: number,
    serviceId: number,
    userId: number,
  ) {
    if (
      !(await this.projectEnvironmentDomainService.exists(projectEnvironmentId))
    ) {
      throw new NotFoundException();
    }

    if (
      !(await this.projectEnvironmentServiceRepository.exists(
        projectEnvironmentId,
        serviceId,
      ))
    ) {
      throw new NotFoundException(
        'This service is not connected to this project environment',
      );
    }

    if (!(await this.projectUsersDomainService.findOne(projectId, userId))) {
      throw new ForbiddenException();
    }
    await this.projectsDomainService.removeServiceFromProjectEnvironment(
      projectId,
      projectEnvironmentId,
      serviceId,
    );
  }

  async putCallbackUrls(
    projectEnvironmentId: number,
    data: ProjectEnvironmentConnectionCallbackUrlPutRequestDTO,
    userId: number,
  ) {
    if (
      !(await this.projectEnvironmentDomainService.exists(projectEnvironmentId))
    ) {
      throw new NotFoundException();
    }
    // This is why we should have made this /project/{id}/environments/{envId}
    const projectEnv = await this.projectEnvironmentDomainService.findOne(
      projectEnvironmentId,
    );
    const projectId = (await projectEnv.project).projectId;
    if (!(await this.projectUsersDomainService.findOne(projectId, userId))) {
      throw new ForbiddenException();
    }
    const patchedConnection = await this.projectsDomainService.putCallbackUrls(
      projectEnvironmentId,
      data,
    );

    return this.projectEnvironmentAssembler.buildCallbackUrlPatchResponse(
      patchedConnection,
    );
  }

  async getProdServiceApprovalCheck(
    projectEnvironmentId: number,
  ): Promise<any[]> {
    const sql = `With connectedQARegistrations as (
            select r."resourceName", r."registrationId"
            from catalog."ProjectEnvironmentService" pes 
            inner join catalog."Service" s on pes."serviceId" = s."serviceId"
            inner join catalog."RegistrationVersion" rv on s."registrationVersionId" = rv."registrationVersionId"
            inner join catalog."Registration" r on rv."registrationId" = r."registrationId"
            where pes."projectEnvironmentId" = $1 and pes."deleteTimestamp" is null
            ),
            relatedProdServices as (
            select r.*
            from connectedQARegistrations r
            inner join catalog."RegistrationVersion" rv  on r."registrationId" = rv."registrationId"
            inner join catalog."Service" s on rv."registrationVersionId" = s."registrationVersionId"
            where s."environmentId" = 3 and s."requiresApproval" = true -- prod
            and s."deleteTimestamp" is null
            )
            
            select row_to_json(rows) as rows from
            (
              select * from relatedProdServices
            ) rows;
            `;

    const res = await executeQuery(sql, [projectEnvironmentId]);

    if (res.rows.length) {
      return res.rows[0].rows;
    } else {
      return null;
    }
  }
}
