import { IsNotEmpty, IsNumber, IsString, IsOptional } from 'class-validator';
import { IProjectsPostRequest } from '../interfaces';

export class ProjectsPostRequestDTO implements IProjectsPostRequest {
  @IsNotEmpty()
  @IsString()
  projectName: string;
  @IsNotEmpty()
  @IsString()
  projectDescription: string;
  @IsOptional()
  @IsNumber()
  requestedServiceId?: number;
}
