import {
  IProjectPermissionsGetResponse,
  IProjectPermissionsTeamGetResponse,
} from '../interfaces';

import { IProjectUserResponse } from '../project-users/interfaces';

export class ProjectPermissionsGetResponseDTO
  implements IProjectPermissionsGetResponse {
  users: IProjectUserResponse[];
  teams: IProjectPermissionsTeamGetResponse[];
}
