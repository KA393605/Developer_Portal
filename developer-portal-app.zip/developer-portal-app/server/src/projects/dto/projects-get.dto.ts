import { IsNotEmpty, IsNumber, IsOptional } from 'class-validator';
import { IProjectsRequest } from '../interfaces';

export class ProjectsGetDTO implements IProjectsRequest {
  @IsNotEmpty()
  @IsNumber()
  userId: number;
  @IsOptional()
  filter?: object;
  @IsOptional()
  @IsNumber()
  results?: number;
  @IsOptional()
  @IsNumber()
  pageNumber?: number;
}
