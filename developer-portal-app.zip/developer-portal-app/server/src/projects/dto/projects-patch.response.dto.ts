import { IProjectsPatchResponse } from '../interfaces';

export class ProjectsPatchResponseDTO implements IProjectsPatchResponse {
  projectId: number;
  projectName: string;
  projectDescription: string;
  airApplicationId: string;
  createTimestamp: string;
  updateTimestamp: string;
  createUser: string;
  status: string;
}
