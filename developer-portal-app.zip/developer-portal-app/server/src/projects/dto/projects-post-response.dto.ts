import { IProjectsPostResponse } from '../interfaces';

export class ProjectsPostResponseDTO implements IProjectsPostResponse {
  projectId: number;
}
