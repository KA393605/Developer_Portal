import { IProjectsPatchRequest } from '../interfaces';

export class ProjectsPatchRequestDTO implements IProjectsPatchRequest {
  projectName?: string;
  projectDescription?: string;
  lastUpdateUserId?: number;
  airApplicationId?: string;
  statusId?: number;
}
