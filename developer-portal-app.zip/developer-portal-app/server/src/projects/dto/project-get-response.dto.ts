import { IProjectUserResponse } from '../project-users/interfaces';
import { IProjectGetResponse } from '../interfaces';
import { IProjectEnvironment } from '../project-environment/interfaces';
// import { IRole } from '../../core/interfaces';

export class ProjectGetResponseDTO implements IProjectGetResponse {
  projectId: number;
  projectName: string;
  projectDescription: string;
  lastUpdateUser: IProjectUserResponse;
  publisherUser: IProjectUserResponse;
  billableUser: IProjectUserResponse;
  airApplicationId: string;
  statusId: number;
  statusName: string;
  createTimestamp: string;
  updateTimestamp: string;
  environments: IProjectEnvironment[];
  projectUsers: IProjectUserResponse[];
  // roles: IRole[];
}
