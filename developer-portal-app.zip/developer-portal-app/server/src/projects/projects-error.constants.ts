export const PROJECTS_ERROR_INVALID_PROMOTION_ENVIRONMENT =
  'Invalid Promotion Environment';
