import { Injectable } from '@nestjs/common';
import { AzureServiceBusBase } from '../core/utilities/service-bus.base';
import {
  PROJECT_SERVICE_SERVICEBUS_CONN_STRING,
  PROJECT_SERVICE_SERVICEBUS_QUEUE_NAME,
} from './projects.constants';

@Injectable()
export class ProjectsServiceBusReceiver extends AzureServiceBusBase {
  constructor() {
    super(
      PROJECT_SERVICE_SERVICEBUS_CONN_STRING,
      PROJECT_SERVICE_SERVICEBUS_QUEUE_NAME,
    );
  }
}
