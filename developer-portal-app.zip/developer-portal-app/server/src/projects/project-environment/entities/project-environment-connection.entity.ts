import {
  BaseEntity,
  ManyToOne,
  JoinColumn,
  Entity,
  PrimaryGeneratedColumn,
  Column,
  OneToOne,
} from 'typeorm';
import { ProjectEnvironment } from '.';
import {
  IProjectEnvironmentConnectionDetails,
  IProjectEnvironmentConnection,
} from '../interfaces';
import { ConnectionType } from './connection-type.entity';
import { Status } from '../../../core/entities';
import { User } from '../../../users/entities/user.entity';

@Entity({ name: 'ProjectEnvironmentConnection' })
export class ProjectEnvironmentConnection extends BaseEntity
  implements IProjectEnvironmentConnection {
  @PrimaryGeneratedColumn()
  projectEnvironmentConnectionId: number;

  @Column()
  projectEnvironmentId: number;

  @Column({ type: 'json' })
  connectionDetails: IProjectEnvironmentConnectionDetails | {};

  @ManyToOne(type => ProjectEnvironment, projectEnv => projectEnv.connections)
  @JoinColumn({
    name: 'projectEnvironmentId',
    referencedColumnName: 'projectEnvironmentId',
  })
  projectEnvironment: ProjectEnvironment;

  @ManyToOne(
    type => ConnectionType,
    connectionType => connectionType.projectConnections,
  )
  @JoinColumn({
    name: 'connectionTypeId',
    referencedColumnName: 'connectionTypeId',
  })
  connectionType: ConnectionType;

  @OneToOne(type => Status)
  @JoinColumn({
    name: 'statusId',
    referencedColumnName: 'statusId',
  })
  status: Status;

  @ManyToOne(type => User)
  @JoinColumn({
    name: 'createUserId',
    referencedColumnName: 'userId',
  })
  createUser: Promise<User>;

  @ManyToOne(type => User)
  @JoinColumn({
    name: 'lastUpdateUserId',
    referencedColumnName: 'userId',
  })
  lastUpdateUser: Promise<User>;
}
