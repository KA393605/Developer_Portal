import {
  BaseEntity,
  PrimaryGeneratedColumn,
  Entity,
  Column,
  JoinColumn,
  ManyToOne,
  OneToMany,
} from 'typeorm';
import { IProjectEnvironment } from '../interfaces';
import { Environment } from '../../../core/entities';
import { Project } from '../../entities/project.entity';
import { Status } from '../../../core/entities';
import { ProjectEnvironmentConnection } from '.';
import { User } from '../../../users/entities/user.entity';
import { ProjectEnvironmentService } from './project-environnment-service.entity';

@Entity({ name: 'ProjectEnvironment' })
export class ProjectEnvironment extends BaseEntity
  implements IProjectEnvironment {
  @PrimaryGeneratedColumn()
  projectEnvironmentId: number;

  @ManyToOne(Type => Project, project => project.environments)
  @JoinColumn({
    name: 'projectId',
    referencedColumnName: 'projectId',
  })
  project: Promise<Project>;

  @Column()
  projectId: number;

  @ManyToOne(Type => Environment, environment => environment.environmentId)
  @JoinColumn({
    name: 'environmentId',
    referencedColumnName: 'environmentId',
  })
  environment: Promise<Environment>;

  @Column()
  environmentId: number;

  @Column()
  statusId: number;

  @ManyToOne(Type => Status, status => status.statusId)
  @JoinColumn({
    name: 'statusId',
    referencedColumnName: 'statusId',
  })
  status: Promise<Status>;

  @Column()
  airInstanceId: string;

  @ManyToOne(type => User)
  @JoinColumn({
    name: 'createUserId',
    referencedColumnName: 'userId',
  })
  createUser: Promise<User>;

  @ManyToOne(type => User)
  @JoinColumn({
    name: 'lastUpdateUserId',
    referencedColumnName: 'userId',
  })
  lastUpdateUser: Promise<User>;

  @OneToMany(
    type => ProjectEnvironmentConnection,
    projectConnection => projectConnection.projectEnvironment,
  )
  connections?: Promise<ProjectEnvironmentConnection[]>;

  @OneToMany(
    type => ProjectEnvironmentService,
    projectEnvironment => projectEnvironment.projectEnvironment,
  )
  projectEnvironmentServices: Promise<ProjectEnvironmentService[]>;
}
