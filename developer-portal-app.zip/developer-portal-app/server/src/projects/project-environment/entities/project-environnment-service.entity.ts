import { IProjectEnvironmentService } from '../interfaces';
import {
  BaseEntity,
  Entity,
  PrimaryGeneratedColumn,
  ManyToOne,
  JoinColumn,
  OneToOne,
  Column,
} from 'typeorm';
import { ProjectEnvironment } from '.';
import { Service } from '../../../services/entities/service.entity';
import { Status } from '../../../core/entities/status.entity';
import { User } from '../../../users/entities/user.entity';

@Entity({ name: 'ProjectEnvironmentService' })
export class ProjectEnvironmentService extends BaseEntity
  implements IProjectEnvironmentService {
  @PrimaryGeneratedColumn()
  projectEnvironmentServiceId: number;

  @ManyToOne(
    Type => ProjectEnvironment,
    projEnv => projEnv.projectEnvironmentServices,
  )
  @JoinColumn({
    name: 'projectEnvironmentId',
    referencedColumnName: 'projectEnvironmentId',
  })
  projectEnvironment: Promise<ProjectEnvironment>;

  @OneToOne(Type => Service)
  @JoinColumn({
    name: 'serviceId',
    referencedColumnName: 'serviceId',
  })
  service: Promise<Service>;

  @ManyToOne(type => Status, status => status.statusId)
  @JoinColumn({
    name: 'statusId',
    referencedColumnName: 'statusId',
  })
  status: Promise<Status>;

  @ManyToOne(type => User)
  @JoinColumn({
    name: 'createUserId',
    referencedColumnName: 'userId',
  })
  createUser: Promise<User>;

  @ManyToOne(type => User)
  @JoinColumn({
    name: 'lastUpdateUserId',
    referencedColumnName: 'userId',
  })
  lastUpdateUser: Promise<User>;

  @Column()
  createTimestamp: string;

  @Column()
  updateTimestamp: string;

  @Column()
  deleteTimestamp: string;
}
