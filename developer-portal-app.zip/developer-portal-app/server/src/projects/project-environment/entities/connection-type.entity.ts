import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  BaseEntity,
  OneToMany,
} from 'typeorm';
import { IConnectionType } from '../interfaces';
import { ProjectEnvironmentConnection } from './project-environment-connection.entity';

@Entity({ name: 'ConnectionType' })
export class ConnectionType extends BaseEntity implements IConnectionType {
  @PrimaryGeneratedColumn()
  connectionTypeId: number;

  @Column()
  connectionTypeName: string;

  @Column()
  connectionTypeDescription: string;

  @Column()
  sequenceNumber: number;

  @OneToMany(
    type => ProjectEnvironmentConnection,
    projectConnection => projectConnection.connectionType,
  )
  projectConnections: ProjectEnvironmentConnection[];
}
