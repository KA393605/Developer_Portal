import { Injectable } from '@nestjs/common';
import {
  IProjectEnvironment,
  IProjectEnvironmentRepository,
  IProjectEnvironmentConnectionDetails,
} from '../interfaces';
import {
  EntityRepository,
  AbstractRepository,
  Connection,
  UpdateResult,
} from 'typeorm';
import {
  ProjectEnvironment,
  ConnectionType,
  ProjectEnvironmentConnection,
} from '../entities';
import { Project } from '../../entities';
import { Status, Environment } from '../../../core/entities';
import {
  PROJECTS_CREATE_DEFAULT_CONNECTION_STATUS,
  PROJECTS_CREATE_DEFAULT_ENVIRONMENT_STATUS,
} from '../../projects.constants';
import { ProjectEnvironmentPatchRequestDTO } from '../dto';
import { User } from '../../../users/entities/user.entity';
import { IAirApplicationInstanceResponse } from '../../../air/interfaces';

@Injectable()
@EntityRepository(ProjectEnvironment)
export class ProjectEnvironmentRepository
  extends AbstractRepository<ProjectEnvironment>
  implements IProjectEnvironmentRepository {
  async findOne(projectEnvironmentId: number): Promise<IProjectEnvironment> {
    return await this.repository
      .createQueryBuilder('projectenvironment')
      .leftJoinAndSelect('projectenvironment.project', 'project')
      .leftJoinAndSelect('projectenvironment.environment', 'environment')
      .leftJoinAndSelect('projectenvironment.status', 'status')
      .leftJoinAndSelect('projectenvironment.createUser', 'createUser')
      .leftJoinAndSelect('projectenvironment.lastUpdateUser', 'lastUpdateUser')
      .leftJoinAndSelect('projectenvironment.connections', 'connections')
      .where(
        '"projectenvironment"."projectEnvironmentId" = :projectEnvironmentId',
        { projectEnvironmentId },
      )
      .getOne();
  }

  async create(
    project: Project,
    environmentName: string,
    connectionName: string,
    userId: number,
  ): Promise<IProjectEnvironment> {
    const user = User.findOneOrFail({ where: { userId } });
    const status = Status.findOneOrFail({
      where: { statusName: PROJECTS_CREATE_DEFAULT_ENVIRONMENT_STATUS },
    });
    const connectionStatus = await Status.findOneOrFail({
      where: { statusName: PROJECTS_CREATE_DEFAULT_CONNECTION_STATUS },
    });
    const environment = await Environment.findOneOrFail({
      where: { environmentName },
    });
    const connectionType = await ConnectionType.findOneOrFail({
      where: { connectionName },
    });

    let projectEnvironment = this.repository.create();
    projectEnvironment.environment = Promise.resolve(environment);
    projectEnvironment.status = status;
    projectEnvironment.project = Promise.resolve(project);
    projectEnvironment.airInstanceId = '';
    projectEnvironment.createUser = Promise.resolve(user);
    projectEnvironment.lastUpdateUser = Promise.resolve(user);
    projectEnvironment = await this.repository.save(projectEnvironment);

    let projectConnection = ProjectEnvironmentConnection.create();
    projectConnection.projectEnvironment = projectEnvironment;
    projectConnection.connectionType = connectionType;
    projectConnection.status = connectionStatus;
    projectConnection.connectionDetails = {};
    projectConnection.createUser = Promise.resolve(user);
    projectConnection.lastUpdateUser = Promise.resolve(user);
    projectConnection = await projectConnection.save();

    return projectEnvironment;
  }

  async patchAirInstance(
    projectEnvironmentId: number,
    airInstance: IAirApplicationInstanceResponse,
    userId: number,
  ) {
    const environment = await this.repository.findOneOrFail({
      where: {
        projectEnvironmentId,
      },
    });
    const user = await this.manager.findOneOrFail(User, { where: { userId } });
    environment.airInstanceId = airInstance.id;
    environment.lastUpdateUser = Promise.resolve(user);
    const connections = await environment.connections;
    const projectConnectionDetail: IProjectEnvironmentConnectionDetails = {
      callbackUrls: Array(
        airInstance.ssoSettings[0].consumerServiceURLs[0].value,
      ),
      clientId: airInstance.identifier,
      oAuth: airInstance.ssoSettings[0].protocol.name,
      secret: '',
    };
    if (airInstance.pandoraRecord) {
      projectConnectionDetail.pandoraId = airInstance.pandoraRecord.id;
    }
    connections[0].connectionDetails = projectConnectionDetail;
    connections[0].save();

    return await this.repository.save(environment);
  }

  async patch(
    projectEnvironmentId: number,
    patchRequest: ProjectEnvironmentPatchRequestDTO,
  ) {
    const projectEnvironment = await this.repository.findOneOrFail({
      where: {
        projectEnvironmentId,
      },
    });
    if (patchRequest.airInstanceId) {
      projectEnvironment.airInstanceId = patchRequest.airInstanceId;
    }
    if (patchRequest.statusId) {
      const status = Status.findOneOrFail({
        where: {
          statusId: patchRequest.statusId,
        },
        relations: [],
      });
      projectEnvironment.status = status;
    }
    return await this.repository.save(projectEnvironment);
  }

  async setStatus(
    projectEnvironmentId: number,
    statusName: string,
  ): Promise<UpdateResult> {
    const { statusId } = await this.repository.manager
      .createQueryBuilder(Status, 's')
      .where('"s"."statusName" = :statusName', {
        statusName,
      })
      .cache(true)
      .getOne();

    return await this.repository
      .createQueryBuilder()
      .update(ProjectEnvironment)
      .set({ statusId })
      .where('"projectEnvironmentId" = :projectEnvironmentId', {
        projectEnvironmentId,
      })
      .execute();
  }

  async findOneByEnvNameAndProjectId(
    environmentName: string,
    projectId: number,
  ): Promise<IProjectEnvironment> {
    const { environmentId } = await this.manager.findOneOrFail(Environment, {
      where: { environmentName },
    });
    return await this.manager
      .createQueryBuilder(ProjectEnvironment, 'project_environment')
      .leftJoinAndSelect(
        'project_environment.projectEnvironmentServices',
        'projectEnvironmentServices',
      )
      .leftJoinAndSelect('projectEnvironmentServices.service', 'service')
      .where('"project_environment"."projectId" = :projectId', { projectId })
      .andWhere('"project_environment"."environmentId" = :environmentId', {
        environmentId,
      })
      .getOne();
  }

  async exists(projectEnvironmentId: number): Promise<boolean> {
    try {
      const count = await this.repository
        .createQueryBuilder()
        .where('"projectEnvironmentId" = :projectEnvironmentId', {
          projectEnvironmentId,
        })
        .getCount();
      return count > 0;
    } catch (error) {
      return false;
    }
  }
}

// Provider so that repo can be injected
export const ProjectEnvironmentRepositoryProvider = {
  provide: 'ProjectEnvironmentRepository',
  useFactory: (connection: Connection) =>
    connection.getCustomRepository(ProjectEnvironmentRepository),
  inject: [Connection],
};
