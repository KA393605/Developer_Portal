import { AbstractRepository, Connection, EntityRepository } from 'typeorm';
import { ProjectEnvironmentConnectionCallbackUrlPutRequestDTO } from '../dto';
import {
  IProjectEnvironmentConnectionDetails,
  IProjectEnvironmentConnectionRepository,
} from '../interfaces';
import { Injectable } from '@nestjs/common';
import { ProjectEnvironmentConnection } from '../entities/project-environment-connection.entity';

Injectable();
@EntityRepository(ProjectEnvironmentConnection)
export class ProjectEnvironmentConnectionRepository
  extends AbstractRepository<ProjectEnvironmentConnection>
  implements IProjectEnvironmentConnectionRepository {
  async putCallbackUrls(
    projectEnvironmentId: number,
    data: ProjectEnvironmentConnectionCallbackUrlPutRequestDTO,
  ): Promise<ProjectEnvironmentConnection> {
    // concerning since this isn't a 1:1 relationship, but the same logic is present in the
    // GET project environment details flow
    const projectConnection = await this.repository.findOneOrFail({
      where: { projectEnvironmentId },
    });

    (projectConnection.connectionDetails as IProjectEnvironmentConnectionDetails).callbackUrls =
      data.urls;
    const res = await projectConnection.save();
    return res;
  }
}

// Provider so that repo can be injected
export const ProjectEnvironmentConnectionRepositoryProvider = {
  provide: 'ProjectConnectionRepository',
  useFactory: (connection: Connection) =>
    connection.getCustomRepository(ProjectEnvironmentConnectionRepository),
  inject: [Connection],
};
