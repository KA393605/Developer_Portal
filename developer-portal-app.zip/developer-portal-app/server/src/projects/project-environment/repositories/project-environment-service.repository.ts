import { Injectable } from '@nestjs/common';
import { ProjectEnvironment, ProjectEnvironmentService } from '../entities';
import { Service } from '../../../services/entities';
import { EntityRepository, AbstractRepository, Connection } from 'typeorm';
import { IProjectEnvironmentServiceRepository } from '../interfaces';
import { Status } from '../../../core/entities';
import { User } from '../../../users/entities/user.entity';

@Injectable()
@EntityRepository(ProjectEnvironmentService)
export class ProjectEnvironmentServiceRepository
  extends AbstractRepository<ProjectEnvironmentService>
  implements IProjectEnvironmentServiceRepository {
  async getProjectEnvironmentServiceByEnvironment(
    projectEnvironmentId: number,
  ): Promise<ProjectEnvironmentService[]> {
    const res = await this.repository
      .createQueryBuilder('projectEnvironmentService')
      .leftJoinAndSelect('projectEnvironmentService.service', 'service')
      .where(
        '"projectEnvironmentService"."projectEnvironmentId" = :projectEnvironmentId',
        {
          projectEnvironmentId,
        },
      )
      .andWhere('projectEnvironmentService.deleteTimestamp IS NULL')
      .getMany();
    return res;
  }

  async getProjectEnvironmentServiceById(
    projectEnvServiceId: number,
  ): Promise<ProjectEnvironmentService> {
    const projectEnvironmentService = await this.repository.findOneOrFail({
      where: {
        projectEnvironmentServiceId: projectEnvServiceId,
      },
      relations: ['projectEnvironment', 'service', 'status'],
    });
    return projectEnvironmentService;
  }

  async getProjectEnvironmentServiceByIds(
    projectEnvId: number,
    serviceId: number,
  ): Promise<ProjectEnvironmentService> {
    const projectEnvironmentService = await this.manager
      .createQueryBuilder(ProjectEnvironmentService, 'pes')
      .where('"pes"."projectEnvironmentId" = :projectEnvId', {
        projectEnvId,
      })
      .andWhere('"pes"."serviceId" = :serviceId', {
        serviceId,
      })
      .getOne();
    return projectEnvironmentService;
  }

  async create(
    projectEnv: ProjectEnvironment,
    serviceReq: Service,
    statusName: string,
    userId: number,
  ): Promise<ProjectEnvironmentService> {
    // Check if it got deleted.
    const projectEnvironmentId = projectEnv.projectEnvironmentId;
    const serviceId = serviceReq.serviceId;
    const deleted = await this.manager
      .createQueryBuilder(ProjectEnvironmentService, 'pes')
      .where('"pes"."projectEnvironmentId" = :projectEnvironmentId', {
        projectEnvironmentId,
      })
      .andWhere('"pes"."serviceId" = :serviceId', {
        serviceId,
      })
      .andWhere('"pes"."deleteTimestamp" IS NOT NULL')
      .getOne();
    // If it did get delete, undelete it.
    if (deleted) {
      deleted.deleteTimestamp = null;
      return await deleted.save();
    } else {
      const service = await this.repository.manager
        .createQueryBuilder(Service, 's')
        .where('"s"."serviceId" = :serviceId', { serviceId })
        .getOne();
      const status = await this.repository.manager
        .createQueryBuilder(Status, 's')
        .where('"s"."statusName" = :statusName', { statusName })
        .cache(true)
        .getOne();
      const user = await this.repository.manager
        .createQueryBuilder(User, 'u')
        .where('"u"."userId" = :userId', { userId })
        .getOne();
      const res = this.repository.manager.create(ProjectEnvironmentService);
      res.createUser = Promise.resolve(user);
      res.lastUpdateUser = Promise.resolve(user);
      res.projectEnvironment = Promise.resolve(projectEnv);
      res.service = Promise.resolve(service);
      res.status = Promise.resolve(status);
      return await this.repository.manager.save(res);
    }
  }

  async patch(
    projectServiceEnvId: number,
    statusName: string,
  ): Promise<ProjectEnvironmentService> {
    const status = await Status.findOneOrFail({ where: { statusName } });

    const projectEnvironmentService = await this.repository.findOneOrFail({
      where: {
        projectEnvironmentServiceId: projectServiceEnvId,
      },
      relations: ['projectEnvironment', 'service', 'status'],
    });

    projectEnvironmentService.status = new Promise(resolve => resolve(status));

    return await this.repository.save(projectEnvironmentService);
  }

  async remove(
    projectId: number,
    projectEnvironmentId: number,
    serviceId: number,
  ) {
    const deleteTimestamp = new Date().toISOString();
    const projectService = await this.repository
      .createQueryBuilder()
      .update(ProjectEnvironmentService)
      .set({
        deleteTimestamp,
      })
      .where('"projectEnvironmentId" = :projectEnvironmentId', {
        projectEnvironmentId,
      })
      .andWhere('"serviceId" = :serviceId', {
        serviceId,
      })
      .execute();
    return projectService;
  }

  async exists(projectEnvironmentId: number, serviceId: number) {
    try {
      const count = await this.repository
        .createQueryBuilder()
        .where(
          '"ProjectEnvironmentService"."projectEnvironmentId" = :projectEnvironmentId',
          {
            projectEnvironmentId,
          },
        )
        .andWhere('"ProjectEnvironmentService"."serviceId" = :serviceId', {
          serviceId,
        })
        .andWhere('"ProjectEnvironmentService"."deleteTimestamp" IS NULL')
        .getCount();
      return count > 0;
    } catch (error) {
      return false;
    }
  }

  // async replicateProjectEnvironmentServices(
  //   sourceProjectEnvironmentId: number,
  //   targetProjectEnvironmentId: number,
  // );
}

// Provider so that repo can be injected
export const ProjectEnvironmentServiceRepositoryProvider = {
  provide: 'ProjectServiceRepository',
  useFactory: (connection: Connection) =>
    connection.getCustomRepository(ProjectEnvironmentServiceRepository),
  inject: [Connection],
};
