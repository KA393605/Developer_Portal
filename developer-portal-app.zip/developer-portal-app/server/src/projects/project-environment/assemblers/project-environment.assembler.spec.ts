import { ProjectEnvironmentAssembler } from '.';
import {
  GoodProjectEnvironment,
  GoodProjectEnvironmentResponse,
  GoodProjectsPromoteResponse,
} from '../mocks';

describe('Project Environment Assembler', () => {
  const assembler = new ProjectEnvironmentAssembler();

  it('should be defined', () => {
    expect(assembler).toBeDefined();
  });

  describe('Build Patch Response', () => {
    it('should return a good response', async () => {
      const res = await assembler.buildPatchResponse(GoodProjectEnvironment);
      expect(res).toEqual(GoodProjectEnvironmentResponse);
    });
  });
  describe('Build Promote Response', () => {
    it('should return a good response', async () => {
      const res = await assembler.buildPromoteResponse(GoodProjectEnvironment);
      expect(res).toEqual(GoodProjectsPromoteResponse);
    });
  });
});
