import { Injectable } from '@nestjs/common';
import {
  IProjectEnvironmentAssembler,
  IProjectEnvironment,
  IProjectEnvironmentConnectionDetails,
  IProjectEnvironmentService,
  IProjectEnvironmentConnection,
} from '../interfaces';
import {
  ProjectEnvironmentGetResponseDTO,
  ProjectEnvironmentPostServiceResponseDTO,
  ProjectsPromoteResponseDTO,
  ProjectEnvironmentPatchResponseDTO,
} from '../dto';
import { CallbackUrlPutResponseDTO } from '../dto';
import { IProjectGatewayCredentials } from '../../../gateway-credentials/interfaces';
import { IStatus } from '../../../core/interfaces';

@Injectable()
export class ProjectEnvironmentAssembler
  implements IProjectEnvironmentAssembler {
  async buildGetResponse(
    pEnv: IProjectEnvironment,
    projectEnvironmentServices: IProjectEnvironmentService[],
    projConnection: IProjectEnvironmentConnection,
    gatewayCredentials: IProjectGatewayCredentials,
  ): Promise<ProjectEnvironmentGetResponseDTO> {
    const res = new ProjectEnvironmentGetResponseDTO();
    res.basic = { ApiKey: gatewayCredentials.apiKey };
    const projectConnectionDetails: IProjectEnvironmentConnectionDetails = projConnection.connectionDetails as IProjectEnvironmentConnectionDetails;
    res.OAuth = {
      callbackUrls: projectConnectionDetails.callbackUrls,
      clientId: projectConnectionDetails.clientId,
      secret: gatewayCredentials.clientSecret,
    } as IProjectEnvironmentConnectionDetails;
    res.connectedServices = [];
    const pEnvStatus = await pEnv.status;
    res.status = {
      statusName: pEnvStatus.statusName,
      statusId: pEnvStatus.statusId,
    };
    for (const projectEnvService of projectEnvironmentServices) {
      const status = await projectEnvService.status;
      const service = await projectEnvService.service;
      const registrationVersion = await service.registrationVersion;
      const environment = await service.environment;
      const registration = await registrationVersion.registration;

      const serveDTO = {
        registrationVersionId: registrationVersion.registrationVersionId,
        serviceName: registration.resourceName,
        serviceDescription: registration.resourceDescription,
        statusId: status.statusId,
        statusName: status.statusName,
        projectEnvironmentId: pEnv.projectEnvironmentId,
        serviceId: service.serviceId,
        environmentName: environment.environmentName,
        // apparently there can be more than 1 kong proxy path, but ui does not account for it
        // and i haven't seen it any of the data so far
        upstreamUrl: (service.serviceProperties.kong_proxy_path || [])[0] || '',
        authenticationType: service.serviceProperties
          .enabled_oidc_plugin_instead_of_keyauth
          ? 'OAuth'
          : 'Basic',
      };
      res.connectedServices.push(serveDTO);
    }

    return res;
  }

  async buildProvisioningGetResponse(status: IStatus) {
    const res = new ProjectEnvironmentGetResponseDTO();
    res.connectedServices = [];
    res.OAuth = {};
    res.basic = {};
    res.status = {
      statusId: status.statusId,
      statusName: status.statusName,
    };
    return res;
  }

  async buildCallbackUrlPatchResponse(
    connection: IProjectEnvironmentConnection,
  ): Promise<CallbackUrlPutResponseDTO> {
    const res = new CallbackUrlPutResponseDTO();

    connection = await connection;

    res.projectEnvironmentConnectionId =
      connection.projectEnvironmentConnectionId;
    res.projectEnvironmentId = connection.projectEnvironmentId;
    res.connectionDetails = connection.connectionDetails as IProjectEnvironmentConnectionDetails;
    return res;
  }
  async buildServiceEnvironmentResponse(
    projectEnvironmentService: IProjectEnvironmentService,
  ): Promise<ProjectEnvironmentPostServiceResponseDTO> {
    const projectEnvironment = await projectEnvironmentService.projectEnvironment;
    const service = await projectEnvironmentService.service;
    const status = await projectEnvironmentService.status;

    const project = await projectEnvironment.project;
    const res = new ProjectEnvironmentPostServiceResponseDTO();
    res.projectEnvironmentId = projectEnvironment.projectEnvironmentId;
    res.projectId = project.projectId;
    res.projectEnvironmentServiceId =
      projectEnvironmentService.projectEnvironmentServiceId;
    res.serviceId = service.serviceId;
    res.status = status.statusName;
    return res;
  }

  async buildPromoteResponse(
    projectEnvironment: IProjectEnvironment,
  ): Promise<ProjectsPromoteResponseDTO> {
    const res = new ProjectsPromoteResponseDTO();
    const environment = await projectEnvironment.environment;
    const status = await projectEnvironment.status;
    res.environmentId = environment.environmentId;
    res.environmentName = environment.environmentName;
    res.projectEnvironmentId = projectEnvironment.projectEnvironmentId;
    res.statusId = status.statusId;
    res.statusName = status.statusName;
    return res;
  }

  async buildPatchResponse(
    projectEnvironment: IProjectEnvironment,
  ): Promise<ProjectEnvironmentPatchResponseDTO> {
    const res = new ProjectEnvironmentPatchResponseDTO();
    const status = await projectEnvironment.status;
    const projectEnvironmentEnvironment = await projectEnvironment.environment;
    res.environmentId = projectEnvironmentEnvironment.environmentId;
    res.environmentName = projectEnvironmentEnvironment.environmentName;
    res.projectEnvironmentId = projectEnvironment.projectEnvironmentId;
    res.statusId = status.statusId;
    res.statusName = status.statusName;
    return res;
  }
}
