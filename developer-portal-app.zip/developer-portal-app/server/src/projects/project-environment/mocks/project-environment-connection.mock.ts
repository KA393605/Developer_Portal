import { IProjectEnvironmentConnection } from '../interfaces';
import { GoodProjectEnvironmentConnectionType } from './project-environment-connection-type.mock';
import { GoodStatus } from '../../../core/mocks/status.mock';
import { GoodUser } from '../../../users/mocks/user.mock';

export const GoodProjectEnvironmentConnection: IProjectEnvironmentConnection = {
  projectEnvironmentConnectionId: 1,
  projectEnvironmentId: 1,
  connectionDetails: {},
  connectionType: GoodProjectEnvironmentConnectionType,
  status: GoodStatus,
  createUser: Promise.resolve(GoodUser),
  lastUpdateUser: Promise.resolve(GoodUser),
};
