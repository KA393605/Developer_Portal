import { IConnectionType } from '../interfaces';
import { GoodProjectEnvironmentConnection } from './project-environment-connection.mock';

export const GoodProjectEnvironmentConnectionType: IConnectionType = {
  connectionTypeDescription: 'Good Conneciton Type Description',
  connectionTypeId: 1,
  connectionTypeName: 'Good Connection Type Name',
  projectConnections: [GoodProjectEnvironmentConnection],
};
