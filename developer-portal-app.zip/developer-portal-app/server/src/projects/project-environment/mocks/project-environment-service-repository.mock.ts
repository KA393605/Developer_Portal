import { IProjectEnvironmentServiceRepository } from '../interfaces';
import { GoodProjectEnvironmentService } from './project-environment-service.mock';

export const MockProjectServiceRepository: IProjectEnvironmentServiceRepository = {
  create: jest.fn(() => Promise.resolve(GoodProjectEnvironmentService)),
  getProjectEnvironmentServiceByEnvironment: jest.fn(() =>
    Promise.resolve([GoodProjectEnvironmentService]),
  ),
  getProjectEnvironmentServiceById: jest.fn(() =>
    Promise.resolve(GoodProjectEnvironmentService),
  ),
  patch: jest.fn(() => Promise.resolve(GoodProjectEnvironmentService)),
  remove: jest.fn(() => {
    return;
  }),
  exists: jest.fn(() => Promise.resolve(false)),
  getProjectEnvironmentServiceByIds: jest.fn(() =>
    Promise.resolve(GoodProjectEnvironmentService),
  ),
};
