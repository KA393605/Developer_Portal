import { IProjectEnvironmentPostServiceResponse } from '../interfaces';

export const GoodProjectEnvironmentPostServiceResponse: IProjectEnvironmentPostServiceResponse = {
  projectId: 123,
  projectEnvironmentId: 123,
  projectEnvironmentServiceId: 1,
  serviceId: 123,
  status: 'pending',
};
