import { IKongOnboardingRequest } from '../../interfaces';

export const GoodProjectEnvironmentPostServiceRequest: IKongOnboardingRequest = {
  clientId: 'Good ClientId',
  environment: 'Good Environment',
  requestTrackingId: 'Good Request Id',
  whiteListGroupName: 'Good Whitelist Group Name',
};
