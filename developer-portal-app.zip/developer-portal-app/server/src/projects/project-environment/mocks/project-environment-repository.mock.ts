import { IProjectEnvironmentRepository } from '../interfaces';
import { GoodProjectEnvironmentWithProject } from '.';
import { GoodCreateProjectEnvironmentWithProject } from './project-environment.mock';
import { UpdateResult } from 'typeorm';

export const MockProjectEnvironmentRepository: IProjectEnvironmentRepository = {
  create: jest.fn(() =>
    Promise.resolve(GoodCreateProjectEnvironmentWithProject),
  ),
  findOne: jest.fn(() => Promise.resolve(GoodProjectEnvironmentWithProject)),
  patch: jest.fn(() => Promise.resolve(GoodProjectEnvironmentWithProject)),
  patchAirInstance: jest.fn(() =>
    Promise.resolve(GoodProjectEnvironmentWithProject),
  ),
  exists: jest.fn(() => Promise.resolve(true)),
  setStatus: jest.fn(() =>
    Promise.resolve(
      (GoodProjectEnvironmentWithProject as unknown) as UpdateResult,
    ),
  ),
  findOneByEnvNameAndProjectId: jest.fn(() =>
    Promise.resolve(GoodProjectEnvironmentWithProject),
  ),
};
