import { IProjectEnvironmentService } from '../interfaces';
import { GoodProjectEnvironment } from './project-environment.mock';
import { GoodService } from '../../../services/mocks/service.mock';
import { GoodStatus } from '../../../core/mocks/status.mock';

export const GoodProjectEnvironmentService: IProjectEnvironmentService = {
  projectEnvironment: Promise.resolve(GoodProjectEnvironment),
  projectEnvironmentServiceId: 1,
  service: Promise.resolve(GoodService),
  status: Promise.resolve(GoodStatus),
  createTimestamp: 'Good Create Timestamp',
  updateTimestamp: 'Good Update Timestamp',
  deleteTimestamp: 'Good Delete Timestamp',
};
