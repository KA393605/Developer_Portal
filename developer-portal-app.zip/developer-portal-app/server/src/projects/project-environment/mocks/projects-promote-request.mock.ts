import { IProjectsPromoteToProdRequest } from '../interfaces';

export const GoodProjectsPromoteRequest: IProjectsPromoteToProdRequest = {
  businessJustification: 'Good Business Justification',
  projectDescription: 'Good Project Description',
  pandoraId: 'P123456789',
};
