export const GoodProjectEnvironmentGetResponseDTO = {
  OAuth: {},
  basic: {},
  connectedServices: [],
  status: {
    statusName: 'Provisioned',
    statusId: 2,
  },
};
