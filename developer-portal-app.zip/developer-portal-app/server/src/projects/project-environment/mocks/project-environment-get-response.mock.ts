import { IProjectEnvironmentGetResponse } from '../interfaces';

export const GoodProjectEnvironmentGetResponse: IProjectEnvironmentGetResponse = {
  OAuth: {},
  basic: {},
  connectedServices: [],
  status: {
    statusName: 'Provisioned',
    statusId: 2,
  },
};
