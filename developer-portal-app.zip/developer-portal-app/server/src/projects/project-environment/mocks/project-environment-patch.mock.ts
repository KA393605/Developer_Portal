import { IProjectEnvironmentResponse } from '../interfaces/project-environment-response.interface';

export const GoodProjectEnvironmentResponse: IProjectEnvironmentResponse = {
  environmentId: 1,
  environmentName: 'Good Environment Name',
  projectEnvironmentId: 1,
  statusId: 1,
  statusName: 'Good Status',
};
