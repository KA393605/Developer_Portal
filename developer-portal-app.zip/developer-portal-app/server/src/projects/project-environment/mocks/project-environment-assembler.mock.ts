import {
  IProjectEnvironmentAssembler,
  IProjectEnvironment,
  IProjectsPromoteResponse,
  IProjectEnvironmentResponse,
  IProjectEnvironmentConnection,
  IProjectEnvironmentService,
  ICallbackUrlPutResponse,
} from '../interfaces';
import {
  GoodProjectEnvironmentGetResponse,
  GoodProjectsPromoteResponse,
  GoodProjectEnvironmentResponse,
  GoodProjectEnvironmentPostServiceResponse,
} from '.';
import { GoodCallbackUrlPutResponse } from '../mocks';
import { IProjectGatewayCredentials } from '../../../gateway-credentials/interfaces';
import { IStatus } from '../../../core/interfaces';

export const GoodProjectEnvironmentAssembler: IProjectEnvironmentAssembler = {
  buildGetResponse: (
    pEnv: IProjectEnvironment,
    projectEnvironmentServices: IProjectEnvironmentService[],
    projConnection: IProjectEnvironmentConnection,
    gatewayCredentials: IProjectGatewayCredentials,
  ) => {
    return new Promise(resolve => resolve(GoodProjectEnvironmentGetResponse));
  },
  buildProvisioningGetResponse: (status: IStatus) => {
    return new Promise(resolve => resolve(GoodProjectEnvironmentGetResponse));
  },
  buildPromoteResponse: (
    projectEnvironment: IProjectEnvironment,
  ): Promise<IProjectsPromoteResponse> => {
    return Promise.resolve(GoodProjectsPromoteResponse);
  },
  buildPatchResponse: (
    projectEnvironment: IProjectEnvironment,
  ): Promise<IProjectEnvironmentResponse> => {
    return Promise.resolve(GoodProjectEnvironmentResponse);
  },
  buildServiceEnvironmentResponse: (entity: IProjectEnvironmentService) => {
    return Promise.resolve(GoodProjectEnvironmentPostServiceResponse);
  },
  buildCallbackUrlPatchResponse: (
    connection: IProjectEnvironmentConnection,
  ): Promise<ICallbackUrlPutResponse> => {
    return Promise.resolve(GoodCallbackUrlPutResponse);
  },
};
