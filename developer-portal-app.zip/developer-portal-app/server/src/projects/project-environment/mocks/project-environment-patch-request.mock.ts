import { IProjectEnvironmentPatchRequest } from '../interfaces/project-environment-patch-request.interface';

export const GoodProjectEnvironmentPatchRequest: IProjectEnvironmentPatchRequest = {
  airInstanceId: 'GoodInstance',
  statusId: 1,
};
