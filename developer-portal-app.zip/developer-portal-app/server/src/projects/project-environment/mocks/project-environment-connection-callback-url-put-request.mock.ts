import { ProjectEnvironmentConnectionCallbackUrlPutRequestDTO } from '../dto/project-environment-connection-callbackurl-put-request.dto';

export const GoodPutCallbackUrlrequest: ProjectEnvironmentConnectionCallbackUrlPutRequestDTO = {
  urls: ['https://goodurl.com'],
};
