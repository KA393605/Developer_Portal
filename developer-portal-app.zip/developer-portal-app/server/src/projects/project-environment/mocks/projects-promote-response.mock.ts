import { IProjectsPromoteResponse } from '../interfaces';

export const GoodProjectsPromoteResponse: IProjectsPromoteResponse = {
  environmentId: 1,
  environmentName: 'Good Environment Name',
  projectEnvironmentId: 1,
  statusId: 1,
  statusName: 'Good Status',
};
