import { IProjectEnvironmentDomainService } from '../interfaces';
import { GoodProjectEnvironmentWithProject } from '.';

export const MockProjectEnvironmentDomainService: IProjectEnvironmentDomainService = {
  exists: jest.fn(() => Promise.resolve(true)),
  findOne: jest.fn(() => Promise.resolve(GoodProjectEnvironmentWithProject)),
};
