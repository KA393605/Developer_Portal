import { ICallbackUrlPutResponse } from '../interfaces';

export const GoodCallbackUrlPutResponse: ICallbackUrlPutResponse = {
  projectEnvironmentConnectionId: 1,
  projectEnvironmentId: 1,
  airInstanceId: 'Good air instance',
  connectionDetails: {
    oAuth: 'Good oAuth',
    callbackUrls: ['Good url.com'],
    secret: 'Good Secret',
    clientId: 'Good Client Id',
  },
};
