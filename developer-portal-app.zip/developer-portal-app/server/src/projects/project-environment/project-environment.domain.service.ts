import { Injectable, Inject } from '@nestjs/common';
import {
  IProjectEnvironmentDomainService,
  IProjectEnvironmentRepository,
  IProjectEnvironment,
} from './interfaces';

@Injectable()
export class ProjectEnvironmentDomainService
  implements IProjectEnvironmentDomainService {
  constructor(
    @Inject('ProjectEnvironmentRepository')
    private readonly projectEnvironmentRepository: IProjectEnvironmentRepository,
  ) {}

  findOne(projectEnvironmentId: number): Promise<IProjectEnvironment> {
    return this.projectEnvironmentRepository.findOne(projectEnvironmentId);
  }

  exists(projectEnvironmentId: number): Promise<boolean> {
    return this.projectEnvironmentRepository.exists(projectEnvironmentId);
  }
}
