import { Module } from '@nestjs/common';
import { ProjectEnvironmentDomainService } from './project-environment.domain.service';
import { ProjectEnvironmentRepositoryProvider } from './repositories';
import { ProjectEnvironmentAssembler } from './assemblers';

const ProjectEnvironmentDomainServiceProvider = {
  provide: 'ProjectEnvironmentDomainService',
  useClass: ProjectEnvironmentDomainService,
};

const ProjectEnvironmentAssemblerProvider = {
  provide: 'ProjectEnvironmentAssembler',
  useClass: ProjectEnvironmentAssembler,
};

@Module({
  providers: [
    ProjectEnvironmentDomainServiceProvider,
    ProjectEnvironmentRepositoryProvider,
    ProjectEnvironmentAssemblerProvider,
  ],
})
export class ProjectEnvironmentModule {}
