import { IProjectsPromoteResponse } from '../interfaces';

export class ProjectsPromoteResponseDTO implements IProjectsPromoteResponse {
  projectEnvironmentId: number;
  environmentId: number;
  environmentName: string;
  statusName: string;
  statusId: number;
}
