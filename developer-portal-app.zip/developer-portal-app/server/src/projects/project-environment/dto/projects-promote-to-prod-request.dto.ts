import { IProjectsPromoteToProdRequest } from '../interfaces';
import { IsNotEmpty, IsString } from 'class-validator';

export class ProjectsPromoteToProdRequestDTO
  implements IProjectsPromoteToProdRequest {
  @IsNotEmpty()
  @IsString()
  projectDescription: string;
  @IsNotEmpty()
  @IsString()
  businessJustification: string;
  @IsNotEmpty()
  @IsString()
  pandoraId: string;
}
