import { ICallbackUrlPutResponse } from '../interfaces';
import { IProjectEnvironmentConnectionDetails } from '../interfaces';

export class CallbackUrlPutResponseDTO implements ICallbackUrlPutResponse {
  projectEnvironmentConnectionId: number;
  projectEnvironmentId: number;
  connectionDetails: IProjectEnvironmentConnectionDetails;
  airInstanceId: string;
}
