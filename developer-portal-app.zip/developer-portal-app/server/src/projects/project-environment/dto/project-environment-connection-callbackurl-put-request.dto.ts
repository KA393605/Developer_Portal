import { IsNotEmpty, IsUrl } from 'class-validator';
import { IProjectEnvironmentConnectionCallbackUrlPutRequest } from '../interfaces';

export class ProjectEnvironmentConnectionCallbackUrlPutRequestDTO
  implements IProjectEnvironmentConnectionCallbackUrlPutRequest {
  @IsNotEmpty()
  @IsUrl(
    {
      // rejects localhost without this
      require_tld: false,
    },
    {
      each: true,
    },
  )
  urls: string[];
}
