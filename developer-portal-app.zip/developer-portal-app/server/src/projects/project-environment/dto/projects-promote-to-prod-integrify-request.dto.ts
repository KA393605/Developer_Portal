import { IProjectsPromoteToProdIntegrifyRequest } from '../interfaces';
export class ProjectsPromoteToProdIntegrifyRequestDTO
  implements IProjectsPromoteToProdIntegrifyRequest {
  businessOwnerMudId: string;
  serviceName: string;
  serviceVersion: string;
  serviceEnvironment: string;
  userMudId: string;
  userFullName: string;
  userEmailAddress: string;
  projectName: string;
  projectDescription: string;
  businessJustification: string;
  businessUnit: string;
  approvalNeeded: string;
  pandoraId: string;
}
