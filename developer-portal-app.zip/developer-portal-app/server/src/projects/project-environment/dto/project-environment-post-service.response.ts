import { IProjectEnvironmentPostServiceResponse } from '../interfaces';

export class ProjectEnvironmentPostServiceResponseDTO
  implements IProjectEnvironmentPostServiceResponse {
  projectId: number;
  projectEnvironmentId: number;
  projectEnvironmentServiceId: number;
  serviceId: number;
  status: string;
}
