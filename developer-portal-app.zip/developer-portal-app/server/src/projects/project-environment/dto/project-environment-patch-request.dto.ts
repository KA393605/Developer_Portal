import { IsOptional, IsNumber, IsString } from 'class-validator';
import { IProjectEnvironmentPatchRequest } from '../interfaces';

export class ProjectEnvironmentPatchRequestDTO
  implements IProjectEnvironmentPatchRequest {
  @IsOptional()
  @IsNumber()
  statusId?: number;
  @IsOptional()
  @IsString()
  airInstanceId?: string;
}
