import { IProjectEnvironmentResponse } from '../interfaces';

export class ProjectEnvironmentPatchResponseDTO
  implements IProjectEnvironmentResponse {
  environmentId: number;
  environmentName: string;
  projectEnvironmentId: number;
  statusId: number;
  statusName: string;
}
