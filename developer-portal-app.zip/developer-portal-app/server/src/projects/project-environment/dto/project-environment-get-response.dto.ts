import { IProjectEnvironmentGetResponse } from '../interfaces';

export class ProjectEnvironmentGetResponseDTO
  implements IProjectEnvironmentGetResponse {
  OAuth:
    | {}
    | {
        clientId: string;
        secret: string;
        callbackUrls: string[];
      };
  basic: {} | object;
  connectedServices: Array<{
    registrationVersionId: number;
    serviceName: string;
    serviceDescription: string;
    statusId: number;
    statusName: string;
    projectEnvironmentId: number;
    serviceId: number;
    environmentName: string;
    upstreamUrl: string;
    authenticationType: string;
  }>;
  status: IProjectEnvironmentGetResponse['status'];
}
