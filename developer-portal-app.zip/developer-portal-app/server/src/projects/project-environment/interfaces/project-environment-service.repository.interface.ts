import { IProjectEnvironmentService, IProjectEnvironment } from '.';
import { IService } from '../../../services/interfaces';

export interface IProjectEnvironmentServiceRepository {
  getProjectEnvironmentServiceById(
    id: number,
  ): Promise<IProjectEnvironmentService>;
  getProjectEnvironmentServiceByEnvironment(
    projectEnvironmentId: number,
  ): Promise<IProjectEnvironmentService[]>;
  getProjectEnvironmentServiceByIds(
    projectEnvId: number,
    serviceId: number,
  ): Promise<IProjectEnvironmentService>;
  create(
    projectEnv: IProjectEnvironment,
    serviceEnv: IService,
    statusName: string,
    userId: number,
  ): Promise<IProjectEnvironmentService>;
  patch(
    projectEnvironmentServiceId: number,
    statusName: string,
  ): Promise<IProjectEnvironmentService>;
  remove(
    projectId: number,
    projectEnvironmentId: number,
    serviceId: number,
  ): void;
  exists(projectEnvironmentId: number, serviceId: number): Promise<boolean>;
}
