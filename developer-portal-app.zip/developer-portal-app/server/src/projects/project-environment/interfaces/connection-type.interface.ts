import { IProjectEnvironmentConnection } from '.';

export interface IConnectionType {
  connectionTypeId: number;
  connectionTypeName: string;
  connectionTypeDescription: string;
  projectConnections: IProjectEnvironmentConnection[];
}
