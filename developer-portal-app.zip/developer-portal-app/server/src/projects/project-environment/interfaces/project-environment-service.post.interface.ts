export interface IProjectEnvironmentPostServiceResponse {
  projectId: number;
  projectEnvironmentId: number;
  projectEnvironmentServiceId: number;
  serviceId: number;
  status: string;
}
