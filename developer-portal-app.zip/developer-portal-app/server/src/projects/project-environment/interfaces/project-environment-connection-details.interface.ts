export interface IProjectEnvironmentConnectionDetails {
  oAuth: string;
  clientId: string;
  secret: string;
  callbackUrls: string[];
  pandoraId?: string;
}
