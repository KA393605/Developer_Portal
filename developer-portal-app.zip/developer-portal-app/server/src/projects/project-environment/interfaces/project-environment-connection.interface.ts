import { IProjectEnvironmentConnectionDetails, IConnectionType } from '.';
import { IStatus } from '../../../core/interfaces';
import { IUser } from '../../../users/interfaces/user.interface';

export interface IProjectEnvironmentConnection {
  projectEnvironmentConnectionId: number;
  projectEnvironmentId: number;
  connectionDetails: IProjectEnvironmentConnectionDetails | {};
  connectionType: IConnectionType;
  status: IStatus;
  createUser: Promise<IUser>;
  lastUpdateUser: Promise<IUser>;
}
