export interface IProjectsPromoteResponse {
  projectEnvironmentId: number;
  environmentId: number;
  environmentName: string;
  statusName: string;
  statusId: number;
}
