import { IProjectEnvironmentConnection } from '.';
import { IProjectEnvironmentConnectionCallbackUrlPutRequest } from './project-environment-connection-callback-url-put-request.interface';

export interface IProjectEnvironmentConnectionRepository {
  putCallbackUrls(
    projectEnvirnonmentConnectionId: number,
    data: IProjectEnvironmentConnectionCallbackUrlPutRequest,
  ): Promise<IProjectEnvironmentConnection>;
}
