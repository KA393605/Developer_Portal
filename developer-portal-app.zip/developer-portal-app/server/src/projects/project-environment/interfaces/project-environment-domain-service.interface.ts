import { IProjectEnvironment } from '.';

export interface IProjectEnvironmentDomainService {
  exists(projectEnvironmentId: number): Promise<boolean>;
  findOne(projectEnvironmentId: number): Promise<IProjectEnvironment>;
}
