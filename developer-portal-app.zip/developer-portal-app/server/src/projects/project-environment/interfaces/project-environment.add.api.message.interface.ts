export interface IProjectEnvironmentAddApiMessage {}
