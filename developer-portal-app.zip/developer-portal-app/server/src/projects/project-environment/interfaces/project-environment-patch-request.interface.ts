export interface IProjectEnvironmentPatchRequest {
  statusId?: number;
  airInstanceId?: string;
}
