import { IStatus, IEnvironment } from '../../../core/interfaces';
import { IProject } from '../../interfaces';
import { IProjectEnvironmentConnection, IProjectEnvironmentService } from '.';
import { IUser } from '../../../users/interfaces';

export interface IProjectEnvironment {
  projectEnvironmentId: number;
  project: Promise<IProject>;
  environment: Promise<IEnvironment>;
  status: Promise<IStatus>;
  airInstanceId: string;
  createUser: Promise<IUser>;
  lastUpdateUser: Promise<IUser>;
  connections?: Promise<IProjectEnvironmentConnection[]>;
  projectEnvironmentServices: Promise<IProjectEnvironmentService[]>;
}
