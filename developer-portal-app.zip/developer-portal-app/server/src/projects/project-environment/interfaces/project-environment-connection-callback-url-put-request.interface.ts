export interface IProjectEnvironmentConnectionCallbackUrlPutRequest {
  urls: string[];
}
