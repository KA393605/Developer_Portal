export interface IProjectEnvironmentResponse {
  environmentId: number;
  projectEnvironmentId: number;
  environmentName: string;
  statusId: number;
  statusName: string;
}
