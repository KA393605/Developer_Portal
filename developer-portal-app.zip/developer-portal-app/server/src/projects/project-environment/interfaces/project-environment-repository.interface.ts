import { IProject } from '../../interfaces';
import { IProjectEnvironment, IProjectEnvironmentPatchRequest } from '.';
import { IAirApplicationInstanceResponse } from '../../../air/interfaces';
import { UpdateResult } from 'typeorm';

export interface IProjectEnvironmentRepository {
  exists(projectEnvironmentId: number): Promise<boolean>;
  findOne: (projEnvId: number) => Promise<IProjectEnvironment>;
  patchAirInstance: (
    id: number,
    airInstanceId: IAirApplicationInstanceResponse,
    userId: number,
  ) => Promise<IProjectEnvironment>;
  create: (
    project: IProject,
    environmentName: string,
    connectionName: string,
    userId: number,
  ) => Promise<IProjectEnvironment>;
  patch: (
    envId: number,
    patchRequest: IProjectEnvironmentPatchRequest,
  ) => Promise<IProjectEnvironment>;
  setStatus: (
    projectEnvironmentId: number,
    statusName: string,
  ) => Promise<UpdateResult>;
  findOneByEnvNameAndProjectId(
    environmentName: string,
    projectId: number,
  ): Promise<IProjectEnvironment>;
}
