export interface IProjectsPromoteToProdRequest {
  projectDescription: string;
  businessJustification: string;
  pandoraId: string;
}
