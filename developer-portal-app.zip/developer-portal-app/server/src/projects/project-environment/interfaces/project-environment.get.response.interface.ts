import { IStatus } from '../../../core/interfaces';

export interface IProjectEnvironmentGetResponse {
  OAuth:
    | {
        clientId: string;
        secret: string;
        callbackUrls: string[];
      }
    | {};
  basic: {} | object;
  connectedServices: Array<{
    registrationVersionId: number;
    serviceName: string;
    serviceDescription: string;
    statusId: number;
    statusName: string;
    projectEnvironmentId: number;
    serviceId: number;
    environmentName: string;
    upstreamUrl: string;
    authenticationType: string;
  }>;
  status: Pick<IStatus, 'statusName' | 'statusId'>;
}
