import { IProjectEnvironment } from '.';
import { IService } from '../../../services/interfaces';
import { IStatus } from '../../../core/interfaces';

export interface IProjectEnvironmentService {
  projectEnvironmentServiceId: number;
  projectEnvironment: Promise<IProjectEnvironment>;
  service: Promise<IService>;
  status: Promise<IStatus>;
  createTimestamp: string;
  updateTimestamp: string;
  deleteTimestamp: string;
}
