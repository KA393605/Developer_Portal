import { IProjectEnvironmentConnectionDetails } from '.';

export interface ICallbackUrlPutResponse {
  projectEnvironmentConnectionId: number;
  projectEnvironmentId: number;
  connectionDetails: IProjectEnvironmentConnectionDetails;
  airInstanceId: string;
}
