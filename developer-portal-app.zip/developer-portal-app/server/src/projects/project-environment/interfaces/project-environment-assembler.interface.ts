import {
  IProjectEnvironment,
  IProjectEnvironmentGetResponse,
  IProjectEnvironmentConnection,
  IProjectsPromoteResponse,
  IProjectEnvironmentResponse,
  IProjectEnvironmentPostServiceResponse,
  IProjectEnvironmentService,
} from '.';
import { ICallbackUrlPutResponse } from './callbackurl-put-response.interface';
import { IProjectGatewayCredentials } from '../../../gateway-credentials/interfaces';
import { IStatus } from '../../../core/interfaces';

export interface IProjectEnvironmentAssembler {
  buildGetResponse: (
    pEnv: IProjectEnvironment,
    projectEnvironmentServices: IProjectEnvironmentService[],
    projConnection: IProjectEnvironmentConnection,
    gatewayCredentials: IProjectGatewayCredentials,
  ) => Promise<IProjectEnvironmentGetResponse>;

  buildProvisioningGetResponse: (
    status: IStatus,
  ) => Promise<IProjectEnvironmentGetResponse>;

  // should be moved to a projectConnectionAssembler
  buildCallbackUrlPatchResponse: (
    connection: IProjectEnvironmentConnection,
  ) => Promise<ICallbackUrlPutResponse>;
  buildServiceEnvironmentResponse: (
    entity: IProjectEnvironmentService,
  ) => Promise<IProjectEnvironmentPostServiceResponse>;
  buildPromoteResponse: (
    projectEnvironment: IProjectEnvironment,
  ) => Promise<IProjectsPromoteResponse>;
  buildPatchResponse: (
    projectEnvironment: IProjectEnvironment,
  ) => Promise<IProjectEnvironmentResponse>;
}
