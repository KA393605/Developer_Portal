import { IProjectsPromoteToProdRequest } from '.';

export interface IProjectsPromoteToProdIntegrifyRequest
  extends IProjectsPromoteToProdRequest {
  businessOwnerMudId: string;
  serviceName: string;
  serviceVersion: string;
  serviceEnvironment: string;
  userMudId: string;
  userFullName: string;
  userEmailAddress: string;
  projectName: string;
  businessUnit: string;
  approvalNeeded: string;
}
