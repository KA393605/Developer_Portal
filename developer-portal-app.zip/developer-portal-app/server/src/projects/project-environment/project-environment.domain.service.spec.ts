import { ProjectEnvironmentDomainService } from './project-environment.domain.service';
import {
  IProjectEnvironmentRepository,
  IProjectEnvironment,
} from './interfaces';
import {
  MockProjectEnvironmentRepository,
  GoodProjectEnvironment,
} from './mocks';

describe('Project Environment Domain Service', () => {
  let service: ProjectEnvironmentDomainService;
  let mockProjectEnvironmentRepository: IProjectEnvironmentRepository;

  beforeEach(async () => {
    const ProjectEnvironmentRepositoryMock = jest.fn<
      IProjectEnvironmentRepository,
      []
    >(() => MockProjectEnvironmentRepository);

    mockProjectEnvironmentRepository = new ProjectEnvironmentRepositoryMock();

    service = new ProjectEnvironmentDomainService(
      mockProjectEnvironmentRepository,
    );
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('Find One', () => {
    let res: IProjectEnvironment;
    beforeAll(async () => {
      res = await service.findOne(1);
    });
    it('Should hit Repo', () => {
      expect(mockProjectEnvironmentRepository.findOne).toBeCalledTimes(1);
      expect(mockProjectEnvironmentRepository.findOne).toBeCalledWith(1);
    });
    it('Should return value on good call', () => {
      expect(res).toEqual(GoodProjectEnvironment);
    });
  });

  describe('Exists', () => {
    let res: boolean;
    beforeAll(async () => {
      res = await service.exists(1);
    });
    it('Should hit Repo', () => {
      expect(mockProjectEnvironmentRepository.exists).toBeCalledTimes(1);
      expect(mockProjectEnvironmentRepository.exists).toBeCalledWith(1);
    });
    it('Should return value on good call', () => {
      expect(res).toEqual(true);
    });
  });
});
