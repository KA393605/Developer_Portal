export interface IKongEnvironmentVariables {
  DEV: IKongEnvironmentVariableInstance;
  QA: IKongEnvironmentVariableInstance;
  PROD: IKongEnvironmentVariableInstance;
}

export interface IKongEnvironmentVariableInstance {
  env: string;
  clientId: string;
  secret: string;
  tokenUrl: string;
}
