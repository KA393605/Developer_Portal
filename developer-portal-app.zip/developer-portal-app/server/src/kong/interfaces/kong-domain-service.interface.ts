export interface IKongDomainService {
  getKongToken: (
    clientId: string,
    clientSecret: string,
    url: string,
  ) => Promise<string>;
  translateEnvironment(env: string): string;
}
