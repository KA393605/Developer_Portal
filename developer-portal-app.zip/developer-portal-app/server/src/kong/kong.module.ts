import { Module } from '@nestjs/common';
import { KongDomainService } from './kong.domain.service';
import { GatewayCredentialsModule } from '../gateway-credentials/gateway-credentials.module';

const KongDomainServiceProvider = {
  provide: 'KongDomainService',
  useClass: KongDomainService,
};

@Module({
  imports: [GatewayCredentialsModule],
  providers: [KongDomainServiceProvider],
  exports: [KongDomainServiceProvider],
})
export class KongModule {}
