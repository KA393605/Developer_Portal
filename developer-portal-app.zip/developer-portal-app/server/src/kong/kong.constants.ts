import { ENVIRONMENTS } from '../core/environments.constants';
import { IKongEnvironmentVariables } from './interfaces';

export const KONG_TOKEN_CONTENT_TYPE = 'application/x-www-form-urlencoded';
export const OAUTH_GRANT_TYPE = 'client_credentials';
export const enum KONG_EVENT_TYPES {
  CREATE_SERVICE = 'createservice',
  UPDATE_SERVICE = 'updateservice',
  CREATE_SERVICE_VERSION = 'createserviceversion',
}

export const KONG_ENVIRONMENT_VARIABLES: IKongEnvironmentVariables = {
  DEV: {
    env: ENVIRONMENTS.DEV,
    clientId: process.env.KONG_CLIENT_ID,
    secret: process.env.KONG_CLIENT_SECRET,
    tokenUrl: process.env.KONG_TOKEN_URL,
  },
  QA: {
    env: ENVIRONMENTS.QA,
    clientId: process.env.KONG_CLIENT_ID,
    secret: process.env.KONG_CLIENT_SECRET,
    tokenUrl: process.env.KONG_TOKEN_URL,
  },
  PROD: {
    env: ENVIRONMENTS.PROD,
    clientId: process.env.KONG_CLIENT_ID,
    secret: process.env.KONG_CLIENT_SECRET,
    tokenUrl: process.env.KONG_TOKEN_URL,
  },
};
