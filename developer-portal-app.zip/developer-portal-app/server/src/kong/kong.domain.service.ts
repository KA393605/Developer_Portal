import { Injectable } from '@nestjs/common';
import { KONG_TOKEN_CONTENT_TYPE } from './kong.constants';
import axios from 'axios';
import * as queryString from 'querystring';
import { OAUTH_GRANT_TYPE } from './kong.constants';
import { IKongDomainService } from './interfaces/kong-domain-service.interface';
import { ENVIRONMENTS } from '../core/environments.constants';
import { KONG_ENVIRONMENTS } from '../projects/projects.constants';

@Injectable()
export class KongDomainService implements IKongDomainService {
  async getKongToken(
    clientId: string,
    clientSecret: string,
    url: string,
  ): Promise<string> {
    const config = {
      headers: {
        'Content-Type': KONG_TOKEN_CONTENT_TYPE,
      },
    };
    const body: string = queryString.stringify({
      client_id: clientId,
      client_secret: clientSecret,
      grant_type: OAUTH_GRANT_TYPE,
    });
    const token = await axios.post(url, body, config);
    return token.data.access_token;
  }

  translateEnvironment(env: string): string {
    switch (env) {
      case ENVIRONMENTS.DEV:
        return KONG_ENVIRONMENTS.DEV;
      case ENVIRONMENTS.QA:
        return KONG_ENVIRONMENTS.QA;
      case ENVIRONMENTS.PROD:
        return KONG_ENVIRONMENTS.PROD;
      default:
        throw Error('Invalid Kong Environment');
    }
  }
}
