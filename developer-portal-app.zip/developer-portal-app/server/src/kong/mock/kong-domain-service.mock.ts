import { IKongDomainService } from '../interfaces';

export const MockKongDomainService: IKongDomainService = {
  getKongToken: jest.fn(() => Promise.resolve('Success')),
  translateEnvironment: jest.fn(env => 'Good Environment'),
};
