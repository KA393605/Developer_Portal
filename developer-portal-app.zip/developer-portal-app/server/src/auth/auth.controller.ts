import {
  Controller,
  Get,
  Req,
  Res,
  Session,
  Headers,
  Inject,
  UseGuards,
} from '@nestjs/common';
import { IAuthAppService } from './interfaces/auth.app.service.interface';
import { Response, Request } from 'express';
import { AUTH_BASE_PATH } from '../api.constants';
import { PingAuthGuard } from './guards/ping.guard';

@Controller(AUTH_BASE_PATH)
export class AuthController {
  constructor(
    @Inject('AuthAppService')
    private readonly authAppService: IAuthAppService,
  ) {}

  /**
   * This function seems to exist entirely to act to trigger the auth middleware.
   */
  @Get('ping/login')
  @UseGuards(PingAuthGuard)
  pingLogin() {
    return;
  }

  @Get('ping/callback')
  pingCallback(
    @Req() request: Request,
    @Res() response: Response,
    @Session() session,
  ) {
    this.authAppService.userAuthorization(request, response, session);
  }

  @Get('user')
  userInfo(@Session() session, @Headers('platforms-userid') userId?: string) {
    return this.authAppService.userInfo(session, userId);
  }

  @Get('logout')
  logoutUser(@Session() session) {
    return this.authAppService.logoutUser(session);
  }
}
