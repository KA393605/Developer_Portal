import { Injectable, Session, Req } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { PING_CONFIG } from './config/ping.config';
import { Request } from 'express';
import { Strategy } from 'passport-openidconnect';

@Injectable()
export class PingStrategy extends PassportStrategy(Strategy, 'oidc') {
  constructor() {
    super(PING_CONFIG);
  }
  async validate(
    @Req() request: Request,
    accessToken: string,
    refreshToken: string,
    userId: string,
    profile,
    // tslint:disable-next-line: ban-types
    cb: Function,
    @Session() session,
  ) {
    const props = profile._json;
    const dateTime = new Date();

    session.accessToken = accessToken;
    session.accessTokenExpiration = dateTime.setHours(dateTime.getHours() + 1);
    request.session.refreshToken = refreshToken;
    request.session.mudId = userId.toLowerCase();
    request.session.email = props.email;
    request.session.firstName = props.given_name;
    request.session.lastName = props.family_name;
    request.session.fullName = props.given_name + ' ' + props.family_name;

    return cb(null, profile);
  }
}
