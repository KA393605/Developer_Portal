import { NestMiddleware, Req, Res, Next } from '@nestjs/common';
import express from 'express';

export class AuthRouteMiddleware implements NestMiddleware {
  use(
    @Req() req: express.Request,
    @Res() res: express.Response,
    @Next() next: express.NextFunction,
  ) {
    this.passthru(req, res, next);
  }
  passthru(
    req: express.Request,
    res: express.Response,
    next: express.NextFunction,
  ) {
    next();
  }
}
