import {
  NestMiddleware,
  Req,
  Next,
  Headers,
  Logger,
  UnauthorizedException,
} from '@nestjs/common';
import express from 'express';
import { HEALTHCHECK_PATH, INTEGRIFY_RESPONSE_PATH } from '../../api.constants';

export class HeaderMiddleware implements NestMiddleware {
  use(
    @Req() req: express.Request,
    @Headers() headers,
    @Next() next: express.NextFunction,
  ) {
    const logger = new Logger(HeaderMiddleware.name);
    const { OAUTH_FEATURE_DISABLED, IGNORE_AUTH_USERID } = process.env;
    const useHeader = typeof IGNORE_AUTH_USERID === 'undefined';
    const useSession = !OAUTH_FEATURE_DISABLED;
    if (useSession) {
      headers['platforms-userid'] = req.session.userId;
      headers['access-token'] = req.session.access_token;
    } else if (useHeader) {
      // redundant, but just wanted the logic to be clear
      logger.log('Session Feature Disabled');
      headers['platforms-userid'] = req.headers['platforms-userid'];
    } else {
      logger.log('Setting Default UserId for Session');
      headers['platforms-userid'] = process.env.IGNORE_AUTH_USERID;
    }
    if (
      headers['platforms-userid'] === undefined &&
      !req.baseUrl.startsWith(INTEGRIFY_RESPONSE_PATH) &&
      !req.baseUrl.startsWith(HEALTHCHECK_PATH)
    ) {
      throw new UnauthorizedException();
    }
    req.headers = headers;
    next();
  }
}
