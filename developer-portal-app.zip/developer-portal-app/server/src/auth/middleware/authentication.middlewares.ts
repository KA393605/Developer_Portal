import { NestMiddleware, Req, Res, Next, Inject } from '@nestjs/common';
import express from 'express';
import { IAuthAppService } from '../interfaces/auth.app.service.interface';
import { shouldRedirectToLogin } from '../../core/utilities/auth';
import { LOGIN_PATH } from '../../api.constants';

export class AuthenticationMiddleware implements NestMiddleware {
  constructor(
    @Inject('AuthAppService')
    private readonly authAppService: IAuthAppService,
  ) {}

  use(
    @Req() req: express.Request,
    @Res() res: express.Response,
    @Next() next: express.NextFunction,
  ) {
    if (shouldRedirectToLogin(req)) {
      // this.logger.log(
      //   'Session not found or Session access token undefined',
      // );
      const { OAUTH_FEATURE_DISABLED } = process.env;
      if (!OAUTH_FEATURE_DISABLED) {
        res.redirect(LOGIN_PATH);
        return;
      } else {
        req.session.userId = req.headers['platforms-userid'];
      }
    }

    const dateTime = new Date();

    if (req.session.access_token_expiration < dateTime.getTime()) {
      this.authAppService.tokenRefresh(req, res, req.session);
    }
    next();
  }
}
