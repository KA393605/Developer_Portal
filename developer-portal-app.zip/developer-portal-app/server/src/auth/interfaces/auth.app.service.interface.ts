export interface IAuthAppService {
  userAuthorization: (...args: any) => any;
  userDetails: (...args: any) => any;
  tokenRefresh: (...args: any) => any;
  userInfo: (session, userId?: string) => Promise<unknown>;
  logoutUser: (...args: any) => unknown;
}
