export interface IPingService {
  authenticate: (...args: any) => any;
  authorizeCallback: (...args: any) => any;
  tokenValidate: (...args: any) => any;
  tokenRefresh: (...args: any) => any;
  userInfo: (...args: any) => any;
}
