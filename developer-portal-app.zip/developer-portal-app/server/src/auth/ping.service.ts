import { Injectable } from '@nestjs/common';
import { Request, Response } from 'express';
import { PING_CONFIG } from './config/ping.config';
import { IPingService } from './interfaces/ping.service.interface';
import * as querystring from 'querystring';
import * as axios from 'axios';

@Injectable()
export class PingService implements IPingService {
  private readonly clientId: string;
  private readonly clientSecret: string;
  private readonly authorizeUrl: string;
  private readonly redirectURI: string;
  private readonly tokenURL: string;
  private readonly userInfoURL: string;

  constructor() {
    this.clientId = PING_CONFIG.clientID;
    this.clientSecret = PING_CONFIG.clientSecret;
    this.authorizeUrl = PING_CONFIG.authorizationURL;
    this.tokenURL = PING_CONFIG.tokenURL;
    this.redirectURI = PING_CONFIG.callbackURL;
    this.userInfoURL = PING_CONFIG.userInfoURL;
  }
  /**
   * Authenticate User
   *
   * @param {Request} request
   * @param {Response} response
   * @param {Session} session
   * @returns
   * @memberof PingService
   */
  public authenticate(request: Request, response: Response, session) {
    response.redirect(
      `${this.authorizeUrl}?${querystring.stringify({
        client_id: this.clientId,
        response_type: 'code',
        redirect_uri: this.redirectURI,
        scope: ['email', 'profile'],
      })}`,
    );
    return;
  }

  /**
   * Authorize callback
   *
   * @param {Request} request
   * @returns
   * @memberof PingService
   */
  public async authorizeCallback(request: Request) {
    const code = request.query.code || null;

    const postData = querystring.stringify({
      client_id: this.clientId,
      client_secret: this.clientSecret,
      code,
      grant_type: 'authorization_code',
      redirect_uri: this.redirectURI,
    });
    const url = `${this.tokenURL}`;
    const config = {
      headers: {
        'Content-type': 'application/x-www-form-urlencoded',
      },
    };

    return axios.default.post<any>(url, postData, config);
  }

  /**
   * Validate bearer token
   *
   * @param {Request} request
   * @param {Response} response
   * @param {Session} session
   * @param bearerToken
   * @returns
   * @memberof PingService
   */
  public tokenValidate(bearerToken: string) {
    const postData = querystring.stringify({
      client_id: this.clientId,
      client_secret: this.clientSecret,
      token: bearerToken,
      grant_type: 'urn:pingidentity.com:oauth2:grant_type:validate_bearer',
    });
    const url = this.authorizeUrl;
    const config = {
      headers: {
        'Content-type': 'application/x-www-form-urlencoded',
      },
    };

    return axios.default.post<any>(url, postData, config);
  }

  /**
   * Refresh bearer token
   *
   * @param bearerToken
   * @param refreshToken
   * @returns
   * @memberof PingService
   */
  public tokenRefresh(bearerToken: string, refreshToken: string) {
    const postData = querystring.stringify({
      client_id: this.clientId,
      client_secret: this.clientSecret,
      refresh_token: refreshToken,
      grant_type: 'refresh_token',
    });
    const url = this.tokenURL;
    const config = {
      headers: {
        'Content-type': 'application/x-www-form-urlencoded',
        'Authorization': `Bearer ${bearerToken}`,
      },
    };

    return axios.default.post<any>(url, postData, config);
  }

  /**
   * Get User info
   *
   * @param bearerToken
   * @returns
   * @memberof PingService
   */
  public async userInfo(bearerToken: string) {
    const postData = querystring.stringify({
      client_id: this.clientId,
      client_secret: this.clientSecret,
      grant_type: 'client_credentials',
    });
    const url = this.userInfoURL;
    const config = {
      headers: {
        'Content-type': 'application/x-www-form-urlencoded',
        'Authorization': `Bearer ${bearerToken}`,
      },
    };

    return axios.default.post<any>(url, postData, config);
  }
}
