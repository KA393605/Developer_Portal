import { Module, HttpModule } from '@nestjs/common';
import { PassportModule } from '@nestjs/passport';
import { PingService } from './ping.service';
import { AuthAppService } from './auth.app.service';
import { PingStrategy } from './ping.strategy';
import { CookieSerializer } from './cookie.serializer';
import { AuthController } from './auth.controller';
import { UserRepositoryProvider } from '../users/repositories';
import { AuthenticationMiddleware } from './middleware/authentication.middlewares';

const AuthPingServiceProvider = {
  provide: 'PingService',
  useClass: PingService,
};

const AuthAppServiceProvider = {
  provide: 'AuthAppService',
  useClass: AuthAppService,
};

@Module({
  imports: [
    PassportModule.register({
      defaultStrategy: 'oidc',
      session: true,
      passReqToCallback: true,
    }),
    HttpModule,
  ],
  providers: [
    AuthPingServiceProvider,
    UserRepositoryProvider,
    AuthAppServiceProvider,
    AuthenticationMiddleware,
    PingStrategy,
    CookieSerializer,
  ],
  controllers: [AuthController],
  exports: [PassportModule, AuthenticationMiddleware, AuthAppServiceProvider],
})
export class AuthModule {}
