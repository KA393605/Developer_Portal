export const PING_CONFIG = {
  issuer: `https://${process.env.OIDC_URI}`,
  authorizationURL: `https://${process.env.OIDC_URI}/as/authorization.oauth2`,
  tokenURL: `https://${process.env.OIDC_URI}/as/token.oauth2`,
  userInfoURL: `https://${process.env.OIDC_URI}/idp/userinfo.openid`,
  clientID: process.env.OAUTH_CLIENT_ID,
  clientSecret: process.env.OAUTH_CLIENT_SECRET,
  callbackURL: process.env.OIDC_REDIRECT_URI,
  passReqToCallback: true,
  scope: ['profile', 'email'],
};
