import { v1 as guid } from 'uuid';

export const sessionConfig = {
  genid: guid,
  name: '_platformID',
  secret: process.env.SESSION_SECRET || 'crazysexycool',
  resave: false,
  saveUninitialized: false,
  rolling: false,
  cookie: {
    maxAge: 1000 * 60 * 60 * 24,
    secure: false,
  }, // 30 days
  store: null,
  proxy: false,
};
