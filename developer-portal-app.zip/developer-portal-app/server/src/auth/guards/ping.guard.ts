import { ExecutionContext, CanActivate } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

export class PingAuthGuard extends AuthGuard('oidc') implements CanActivate {
  public async canActivate(context: ExecutionContext): Promise<any> {
    const request = context.switchToHttp().getRequest();
    const result = await super.canActivate(context);

    await super.logIn(request);

    return result;
  }
}
