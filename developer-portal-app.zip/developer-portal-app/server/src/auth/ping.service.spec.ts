import { IPingService } from './interfaces/ping.service.interface';
// import { GoodPingCallbackRequest } from './mocks/ping-callback-request.mock';
// import { GoodPingValidateRequest } from './mocks/ping-validate-request.mock';
// import { GoodPingRefreshRequest } from './mocks/ping-refresh-request.mock';
// import { GoodPingUserRequest } from './mocks/ping-user-request.mock';
// import * as request from 'supertest';

describe('Auth Controller', () => {
  let mockService: IPingService;
  // let mockCallbackRequest = GoodPingCallbackRequest;
  // let mockValidateRequest = GoodPingValidateRequest;
  // let mockRefreshRequest = GoodPingRefreshRequest;
  // let mockUserRequest = GoodPingUserRequest;

  beforeEach(async () => {
    const Mock = jest.fn<IPingService, []>(() => ({
      authenticate: jest.fn(req => {
        return 'success';
      }),
      authorizeCallback: jest.fn(req => {
        return 'success';
      }),
      tokenValidate: jest.fn(req => {
        return 'success';
      }),
      tokenRefresh: jest.fn(req => {
        return 'success';
      }),
      userInfo: jest.fn(req => {
        return 'success';
      }),
    }));
    mockService = new Mock();
  });

  it('should be defined', () => {
    expect(mockService).toBeDefined();
  });

  describe('Authenticate User', () => {
    it('should be defined', () => {
      expect(mockService.authenticate).toBeDefined();
    });
    // it('should redirect the user to ping authentication page', done => {
    //   request
    //     .default(mockApp)
    //     .get('')
    //     .end(done);
    // });
  });

  describe('Callback Authorization', () => {
    it('should be defined', () => {
      expect(mockService.authorizeCallback).toBeDefined();
    });
    // it('should submit a post to the ping federate token url for code authorization', done => {
    //   request
    //     .default(mockApp)
    //     .post('')
    //     .send(mockCallbackRequest)
    //     .expect(201)
    //     .end(done);
    // });
  });

  describe('Token Validation', () => {
    it('should be defined', () => {
      expect(mockService.tokenValidate).toBeDefined();
    });
    // it('should submit a post to the ping federate authorizae url', done => {
    //   request
    //     .default(mockApp)
    //     .post('')
    //     .send(mockValidateRequest)
    //     .expect(201)
    //     .end(done);
    // });
  });

  describe('Token Refresh', () => {
    it('should be defined', () => {
      expect(mockService.tokenRefresh).toBeDefined();
    });
    // it('should submit a post to the ping federate authorizae url', done => {
    //   request
    //     .default(mockApp)
    //     .post('')
    //     .send(mockRefreshRequest)
    //     .expect(201)
    //     .end(done);
    // });
  });

  describe('User Info', () => {
    it('should be defined', () => {
      expect(mockService.userInfo).toBeDefined();
    });
    // it('should submit a post to the ping federate authorizae url', done => {
    //   request
    //     .default(mockApp)
    //     .post('')
    //     .send(mockUserRequest)
    //     .expect(201)
    //     .end(done);
    // });
  });
});
