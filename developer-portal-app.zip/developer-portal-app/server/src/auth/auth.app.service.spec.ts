import { IPingService } from './interfaces/ping.service.interface';
import { AuthAppService } from './auth.app.service';
import { IUserRepository } from '../users/interfaces/user.repository.interface';
import { MockUserRepository } from '../users/mocks/user.repository.mock';
import { PingServiceMock } from './mocks/ping.service.mock';
import { GoodPingResponse } from './mocks/ping-response.mock';
import { GoodCreateCall } from '../users/mocks/users-create.mocks';
import { GoodPingUserInfo } from './mocks/ping-user-info.mock';
import { GoodUser } from '../users/mocks/user.mock';

describe('AuthAppService', () => {
  let authAppService: AuthAppService;
  let mockPingService: IPingService;
  let mockUserRepo: IUserRepository;

  beforeEach(async () => {
    const MockUserRepo = jest.fn<IUserRepository, []>(() => MockUserRepository);
    const MockPingService = jest.fn<IPingService, []>(() => PingServiceMock);

    mockPingService = new MockPingService();
    mockUserRepo = new MockUserRepo();
    authAppService = new AuthAppService(mockPingService, mockUserRepo);
  });

  it('should be defined', () => {
    expect(authAppService).toBeDefined();
  });

  describe('User Authorization', () => {
    // let tokens;
    it('should be defined', () => {
      expect(authAppService.userAuthorization).toBeDefined();
    });

    it('should get tokens from ping federate', () => {
      const tokens = mockPingService.authorizeCallback();
      expect(tokens).toEqual(GoodPingResponse);
    });

    it('should get user details from ping federate', () => {
      const user = mockPingService.userInfo('');
      expect(user).toEqual(GoodPingUserInfo);
    });

    it('should add or find user to app db', () => {
      const user = mockUserRepo.createOrFindUsers(GoodCreateCall);
      expect(user).toEqual(GoodCreateCall);
    });
  });

  describe('User Info', () => {
    // let tokens;
    it('should be defined', () => {
      expect(authAppService.userInfo).toBeDefined();
    });

    it('should get user data by id in session', () => {
      const userData = mockUserRepo.findUserById(1);
      expect(userData).toEqual(Promise.resolve(GoodUser));
    });

    it('may run createOrUpdateUser', () => {
      const user = mockUserRepo.createOrFindUsers(GoodCreateCall);
      expect(user).toEqual(GoodCreateCall);
    });
  });
});
