import { NODE_ENVIRONMENTS } from '../core/node-environments';
import FileStore = require('session-file-store');

// tslint:disable-next-line: no-var-requires
const expressSession = require('express-session');
// tslint:disable-next-line: no-var-requires
const DocumentDBSession = require('documentdb-session');
// tslint:disable-next-line: no-var-requires
const sessionConfig = require('./config/session.config').sessionConfig;
const DocumentDBStore = DocumentDBSession(expressSession);
const dbConfig = {
  ttl: 60 * 60 * 24, // 1 day, to prevent refresh token expiration
};
const env = process.env.NODE_ENV || NODE_ENVIRONMENTS.DEV;

if (env === NODE_ENVIRONMENTS.DEV) {
  const fileStore = FileStore(expressSession);
  sessionConfig.store = new fileStore();
}

if (env === NODE_ENVIRONMENTS.PROD) {
  sessionConfig.proxy = true;
  sessionConfig.cookie.domain = process.env.SESSION_COOKIE_DOMAIN || '.gsk.com';
  sessionConfig.cookie.secure = true; // serve secure cookies
  sessionConfig.store = new DocumentDBStore(dbConfig);
}

module.exports = expressSession(sessionConfig);
