import { AuthController } from './auth.controller';
import { IAuthAppService } from './interfaces/auth.app.service.interface';

describe('Auth Controller', () => {
  let controller: AuthController;
  let mockService: IAuthAppService;

  beforeEach(async () => {
    const Mock = jest.fn<IAuthAppService, []>(() => ({
      userAuthorization: jest.fn(() => {
        return 'success';
      }),
      userDetails: jest.fn(() => {
        return 'success';
      }),
      tokenRefresh: jest.fn(() => {
        return 'success';
      }),
      userInfo: jest.fn(() => {
        return Promise.resolve('success');
      }),
      logoutUser: jest.fn(() => {
        return'success';
      }),
    }));
    mockService = new Mock();
    controller = new AuthController(mockService);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  // describe('Login', () => {
  //   it('get should hit service', () => {
  //     controller.pingLogin();
  //     expect('Passport').toBeCalledTimes(1);
  //   });

  //   it('get should return value on good call', () => {
  //     const res = controller.pingLogin();
  //     expect(res).toEqual('success');
  //   });
  // });

  // describe('Callback', () => {
  //   it('get should hit service', async () => {
  //     function checkCallback(req, res, next) {
  //       controller.pingCallback(req, res, next);
  //       expect(mockService.userAuthorization).toBeCalledTimes(1);
  //     }
  //   });

  //   it('get should return good value on call', async () => {
  //     function checkCallback(req, res, next) {
  //       controller.pingCallback(req, res, next);
  //       expect(mockService.userAuthorization).toBeCalledTimes(1);
  //     }
  //     expect(checkCallback);
  //   });
  // });
});
