import { Injectable, Logger } from '@nestjs/common';
import { PassportSerializer } from '@nestjs/passport';

@Injectable()
export class CookieSerializer extends PassportSerializer {
  private readonly logger = new Logger(CookieSerializer.name);

  // tslint:disable-next-line: ban-types
  serializeUser(user: any, done: Function): any {
    this.logger.log('serialize user: ' + JSON.stringify(user));
    done(null, user);
  }

  // tslint:disable-next-line: ban-types
  deserializeUser(obj: any, done: Function): any {
    this.logger.log('deserialize user');
    done(null, obj);
  }
}
