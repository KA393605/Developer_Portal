import {
  Injectable,
  Inject,
  Logger,
  UnauthorizedException,
  BadRequestException,
} from '@nestjs/common';
import { Request, Response } from 'express';
import { IPingService } from './interfaces/ping.service.interface';
import { IAuthAppService } from './interfaces/auth.app.service.interface';
import { IUserRepository } from '../users/interfaces';
import { reject } from 'bluebird';
import { IUser } from '../users/interfaces';
import { PING_CONFIG } from './config/ping.config';
import { BaseDBService } from '../core/base.service';

@Injectable()
export class AuthAppService extends BaseDBService implements IAuthAppService {
  private readonly logger: Logger = new Logger(AuthAppService.name);
  constructor(
    @Inject('PingService')
    private readonly pingService: IPingService,
    @Inject('UserRepository')
    private readonly usersRepo: IUserRepository,
  ) {
    super();
  }

  /**
   * User Login
   *
   * Function will take user through authentication and
   * callback flow, gather user details from Ping
   * and lookup/register user in app database
   *
   * @param {Request} request
   * @param {Response} response
   * @param {Session} session
   * @returns
   * @memberof AuthAppService
   */
  public async userAuthorization(
    request: Request,
    response: Response,
    session,
  ) {
    // Two legged auth, convert callback code to bearer tokens
    const tokens = await this.pingService
      .authorizeCallback(request)
      .catch(error => {
        if (error) {
          this.logger.log(error.response.status, error.response.data);
          reject(error || { statusCode: error.response.status });
        }
      })
      // tslint:disable-next-line: no-shadowed-variable
      .then((response: any) => response.data);

    // requesting user info from ping
    const pingUser = await this.pingService
      .userInfo(tokens.access_token)
      .catch(error => {
        if (error) {
          this.logger.log(error.response.status, error.response.data);
          reject(error || { statusCode: error.response.status });
        }
      })
      // tslint:disable-next-line: no-shadowed-variable
      .then((response: any) => response.data);

    // Add and or Get Application UserID
    const appUser = await this.usersRepo.createOrFindUsers([
      {
        mudId: pingUser.immutable_id.toLowerCase(),
        firstName: pingUser.given_name,
        lastName: pingUser.family_name,
        email: pingUser.email || process.env.USER_NO_EMAIL_DEFAULT,
        fullName: pingUser.given_name + ' ' + pingUser.family_name,
      },
    ]);

    // set session values
    // clear ping details
    session[`openidconnect:${PING_CONFIG.issuer}`] = '';
    const dateTime = new Date();
    session.access_token = tokens.access_token;
    session.refresh_token = tokens.refresh_token;
    session.access_token_expiration = dateTime.setSeconds(
      dateTime.getSeconds() + tokens.expires_in,
    );
    session.mudId = pingUser.immutable_id.toLowerCase();
    session.firstName = pingUser.given_name;
    session.lastName = pingUser.family_name;
    session.email = pingUser.email;
    session.fullName = pingUser.given_name + ' ' + pingUser.family_name;
    session.userId = appUser[0].userId;
    session.save(error => {
      if (!error) {
        response.redirect('/');
        return;
      }
      this.logger.log(error);
      reject(error || { statusCode: error.response.status });
    });
  }

  /**
   * Token Refresh
   *
   * Function will consume the access key and
   * refresh key from the session store to
   * refresh a user's bearer token that has expired
   *
   * @param {Request} request
   * @param {Response} response
   * @param {Session} session
   * @returns
   * @memberof AuthAppService
   */
  public async tokenRefresh(request: Request, response: Response, session) {
    // Two legged auth, convert callback code to bearer tokens
    await this.pingService
      .tokenRefresh(session.access_token, session.refresh_token)
      // tslint:disable-next-line: no-shadowed-variable
      .then((response: any) => {
        const tokens = response.data;
        const dateTime = new Date();
        session.access_token = tokens.access_token;
        session.refresh_token = tokens.refresh_token;
        session.access_token_expiration = dateTime.setSeconds(
          dateTime.getSeconds() + tokens.expires_in,
        );
        session.save(err => {
          return;
        });
        return tokens;
      })
      .catch(error => {
        this.logger.log(error.response.data);
        session.destroy(err => {
          return;
        });
      });

    return;
  }

  /**
   * User Details
   *
   * Function will retrieve the user details from the
   * session for consumption
   *
   * @param {Request} request
   * @param {Response} response
   * @param {Session} session
   * @returns
   * @memberof AuthAppService
   */
  public async userDetails(request: Request, response: Response, session) {
    // Two legged auth, convert callback code to bearer tokens
    const user = await this.pingService
      .userInfo(session.access_token)
      .catch(function(error) {
        if (error) {
          this.logger.log(error.response.status, error.response.data);
          reject(error || { statusCode: error.response.status });
        }
      })
      // tslint:disable-next-line: no-shadowed-variable
      .then((response: any) => response.data);

    return user;
  }

  /**
   * get user info from session, skip ping
   * handles oauth disabled
   */
  public async userInfo(session, userId?: string) {
    let userData: IUser | undefined;
    if (process.env.OAUTH_FEATURE_DISABLED) {
      if (!userId) {
        throw new BadRequestException(`no user id header: ${userId}`);
      }
      userData = await this.usersRepo.findUserById(Number(userId));
      this.logger.debug('oauth disabled: user info derived from header');
    } else {
      if (!session.userId) {
        throw new UnauthorizedException();
      }
      userData = await this.usersRepo.findUserById(session.userId);
      // Validate mudId in session matches DB
      if (session.mudId.toLowerCase() !== userData.mudId.toLowerCase()) {
        const appUser = await this.usersRepo.createOrFindUsers([
          {
            mudId: session.mudId.toLowerCase(),
            firstName: session.firstName,
            lastName: session.lastName,
            email: session.email,
            fullName: session.firstName + ' ' + session.lastName,
          },
        ]);

        session.userId = appUser[0].userId;
        session.save(error => {
          if (!error) {
            return;
          }
          this.logger.log(error);
          reject(error || { statusCode: error.response.status });
        });

        userData = session;
        this.logger.debug('oauth enabled: user info derived from session');
      }
    }

    // Get Roles + Privileges
    const permissions: any = await this.executeFunction(
      'getUserAppRolesPrivileges',
      'catalog',
      [userId],
    );

    return {
      mudId: userData.mudId.toLowerCase(),
      firstName: userData.firstName,
      lastName: userData.lastName,
      email: userData.email,
      fullName: userData.fullName,
      userId: userData.userId,
      accessToken: session.access_token,
      refreshToken: session.refresh_token,
      accessTokenExpiration: session.access_token_expiration,
      roles: permissions.roles || [],
      privileges: permissions.privileges || [],
    };
  }

  // Destroy both the local session and
  // revoke the access_token at OneLogin
  public logoutUser(session) {
    session.destroy();
    return;
  }
}
