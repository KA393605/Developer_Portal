import { IPingService } from '../interfaces/ping.service.interface';
import { GoodPingResponse } from './ping-response.mock';
import { GoodPingUserInfo } from './ping-user-info.mock';

export const PingServiceMock: IPingService = {
  authenticate: jest.fn((request: any, response: any, session: any) =>
    Promise.resolve(),
  ),
  authorizeCallback: jest.fn((request: any) => GoodPingResponse),
  tokenValidate: jest.fn((bearerToken: string) => Promise.resolve()),
  tokenRefresh: jest.fn((bearerToken: string, refreshToken: string) =>
    Promise.resolve(),
  ),
  userInfo: jest.fn((bearerToken: string) => GoodPingUserInfo),
};
