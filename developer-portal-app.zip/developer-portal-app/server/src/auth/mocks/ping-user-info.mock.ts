export const GoodPingUserInfo = {
  mudId: '',
  givenName: '',
  familyName: '',
  email: '',
};
