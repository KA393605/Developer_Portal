import { GoodPingResponse } from './ping-response.mock';

export const GoodAuthRequest = {
  session: GoodPingResponse,
};
