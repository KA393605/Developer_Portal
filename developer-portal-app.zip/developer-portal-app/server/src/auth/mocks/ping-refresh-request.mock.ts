export const GoodPingRefreshRequest = {
  client_id: '',
  client_secret: '',
  refresh_token: '',
  grant_type: 'refresh_token',
};
