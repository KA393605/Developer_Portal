export const GoodPingValidateRequest = {
  client_id: '',
  client_secret: '',
  token: '',
  grant_type: 'urn:pingidentity.com:oauth2:grant_type:validate_bearer',
};
