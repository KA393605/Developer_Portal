export const GoodPingCallbackRequest = {
  client_id: '',
  client_secret: '',
  code: '',
  grant_type: 'authorization_code',
  redirect_uri: '',
};
