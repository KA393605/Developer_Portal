export const GoodPingResponse = {
  access_token: '',
  refresh_token: '',
};
