export const GoodPingUserRequest = {
  client_id: '',
  client_secret: '',
  grant_type: 'client_credentials',
};
