import {
  MiddlewareConsumer,
  Module,
  NestModule,
  RequestMethod,
} from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthModule } from './auth/auth.module';
import { HealthModule } from './health/health.module';
import { ListingsModule } from './listings/listings.module';
import { ProjectsModule } from './projects/projects.module';
import { RequestsModule } from './requests/requests.module';
import { UsersModule } from './users/users.module';
import { HelpModule } from './help/help.module';
import { AirModule } from './air/air.module';
import { PublishingModule } from './publishing/publishing.module';
import { RpaAdminModule } from './rpa-admin/rpa-admin.module';
import { StaticModule } from './static/static.module';
import { StaticController } from './static/static.controller';
import {
  APP_HEADER_MIDDLEWARE_PATH,
  AUTH_BASE_PATH_EXCLUDE,
  AUTH_LOGIN_PATH,
  AUTH_USER_INFO_PATH,
} from './api.constants';
import { HeaderMiddleware } from './auth/middleware/header.middleware';
import { AuthRouteMiddleware } from './auth/middleware/auth-route.middleware';
import { AuthenticationMiddleware } from './auth/middleware/authentication.middlewares';
import { EnumsModule } from './enums/enums.module';
import { TeamsModule } from './teams/teams.module';

@Module({
  imports: [
    TypeOrmModule.forRoot(),
    HelpModule,
    AuthModule,
    HealthModule,
    ListingsModule,
    ProjectsModule,
    RequestsModule,
    UsersModule,
    AirModule,
    PublishingModule,
    RpaAdminModule,
    EnumsModule,
    TeamsModule,
    // Static Module must be last
    StaticModule,
  ],
  controllers: [],
})
export class AppModule implements NestModule {
  // private readonly logger = new Logger(AppModule.name);
  configure(consumer: MiddlewareConsumer) {
    // for /api/* routes use Header Middleware - adds headers for userId and token
    consumer.apply(HeaderMiddleware).forRoutes(
      {
        path: APP_HEADER_MIDDLEWARE_PATH,
        method: RequestMethod.ALL,
      },
      AUTH_USER_INFO_PATH,
    );

    // For /auth/* routes use AuthRoute Middleware
    consumer.apply(AuthRouteMiddleware).forRoutes({
      path: AUTH_LOGIN_PATH,
      method: RequestMethod.ALL,
    });

    // for static routes
    consumer
      .apply(AuthenticationMiddleware)
      .exclude({
        path: AUTH_BASE_PATH_EXCLUDE,
        method: RequestMethod.ALL,
      })
      .forRoutes(StaticController);
  }
}
