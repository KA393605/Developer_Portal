import { AxiosResponse } from 'axios';
import { ServiceBusMessage } from '@azure/service-bus';
import { IProjectsPromoteToProdRequest } from '../../projects/project-environment/interfaces';

export interface IAirDomainService {
  /**
   * Creates Air Application
   * @param airEnv
   * @param userId
   * @param projectId
   * @param projectTitle
   * @param description
   * @param submitterEmail
   * @param submitterMudId
   * @param serviceId Optional. Requested Service Attachment
   * @param request Optional. Request for prod access to Service
   * @param brokeredMessage Optional. Brokered Message
   */
  createAirApplication(
    airEnv: string,
    userId: number,
    projectId: number,
    projectTitle: string,
    description: string,
    submitterEmail: string,
    submitterMudId: string,
    serviceId?: number,
    request?: IProjectsPromoteToProdRequest,
    brokeredMessage?: ServiceBusMessage,
  ): void;
  /**
   * Creates Air Application Instance
   * @param airEnv Air Environment
   * @param userId
   * @param projectEnvId
   * @param airAppId
   * @param env Environment for instance
   * @param callbackUrls
   * @param projectId Optional. Project Id
   * @param serviceIds number[] Optional. Requested Services Attachment
   * @param request Optional. Request for prod access to Service
   * @param brokeredMessage Optional. Brokered Message
   */
  createAirApplicationInstance(
    airEnv: string,
    userId: number,
    projectEnvId: number,
    airAppId: string,
    env: string,
    callbackUrls?: string[],
    projectId?: number,
    serviceIds?: number[],
    request?: IProjectsPromoteToProdRequest,
    brokeredMessage?: ServiceBusMessage,
  ): void;
  /**
   * Put Callback URLs
   * @param airAppId
   * @param urls
   * @param airEnv
   */
  putCallbackUrls(airAppId: string, urls: string[], airEnv: string): void;
  /**
   * Send Create Request to AIR
   * @param url
   * @param formData
   * @param token
   */
  sendCreateRequestToAir(
    url: string,
    formData: object,
    token: string,
  ): Promise<AxiosResponse>;
  /**
   * Generates ClientId
   * Takes v4 uuid, and removes all non-alphanumeric characters.
   */
  generateClientId(): string;
  /**
   * Validates that ENV variables are set.
   */
  validateEnvironmentalVariables(): void;
  /**
   * Searchable term among Pandora Records
   * @param search
   */
  searchPandora(search: string): Promise<any>;
  /**
   * Put Callback URLs
   * @param pandoraId Unique Pandora Record ID
   */
  getPandora(pandoraId: string): Promise<any>;
}
