export interface IAirEnvironmentVariables {
  DEV: IAirEnvironmentVariableInstance;
  QA: IAirEnvironmentVariableInstance;
  PROD: IAirEnvironmentVariableInstance;
}

export interface IAirEnvironmentVariableInstance {
  env: string;
  airEnv: string;
  clientId: string;
  secret: string;
  appUrl: string;
  appInstanceUrl: string;
  appTokenUrl: string;
  pandoraUrl: string;
}
