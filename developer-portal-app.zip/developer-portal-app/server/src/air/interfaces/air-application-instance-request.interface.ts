export interface IAirApplicationInstanceRequest {
  applicationId: string;
  identifier: string;
  state: string;
  environment: {
    name: string;
    id: string;
  };
  pandoraRecord?: { id?: string };
  ssoSettings: [
    {
      $type: string;
      consumerServiceURLs: object[];
      protocol: { name: string };
      clientCredentials: string;
      refreshToken: string;
    },
  ];
}
