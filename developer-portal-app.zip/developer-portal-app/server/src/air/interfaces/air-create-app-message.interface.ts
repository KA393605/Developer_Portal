import { IProjectsPromoteToProdRequest } from '../../projects/project-environment/interfaces';

export interface IAirCreateAppMessage {
  eventType: string;
  request: {
    userId: number;
    projectId: number;
    projectTitle: string;
    description: string;
    submitterEmail: string;
    submitterMudId: string;
    env: string;
    serviceId?: number;
    request?: IProjectsPromoteToProdRequest;
  };
}
