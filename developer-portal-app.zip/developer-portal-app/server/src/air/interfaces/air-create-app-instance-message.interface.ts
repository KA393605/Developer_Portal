import { IProjectsPromoteToProdRequest } from '../../projects/project-environment/interfaces';

export interface IAirCreateAppInstanceMessage {
  eventType: string;
  request: {
    userId: number;
    projectEnvId: number;
    airAppId: string;
    env: string;
    callbackUrls?: string[];
    projectId?: number;
    serviceIds?: number[];
    request?: IProjectsPromoteToProdRequest;
  };
}
