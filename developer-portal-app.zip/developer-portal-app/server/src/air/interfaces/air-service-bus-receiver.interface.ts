import { IAzureServiceBusBase } from 'src/core/interfaces';

export interface IAirServiceBusReceiver extends IAzureServiceBusBase {
  createAirReceiver(onMessageHandler: any): void;
}
