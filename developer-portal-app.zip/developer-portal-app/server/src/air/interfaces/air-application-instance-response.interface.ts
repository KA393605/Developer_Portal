export interface IAirApplicationInstanceResponse {
  id: string;
  applicationId: string;
  applicationURL: string;
  identifier: string;
  name: string;
  createdDate: string;
  state: string;
  pendingChanges: boolean;
  environment: {
    displayName: string;
    key: string;
    order: number;
  };
  pandoraRecord: {
    name: string;
    itAssetOwner: string;
    urgency: string;
    impact: string;
    id: string;
  };
  ssoSettings: [
    {
      $type: string;
      clientSecret: string;
      consumerServiceURLs: [
        {
          value: string;
        },
      ];
      id: string;
      pendingChanges: false;
      protocol: {
        displayName: string;
        id: string;
        key: string;
        name: string;
        order: number;
      };
    },
  ];
}
