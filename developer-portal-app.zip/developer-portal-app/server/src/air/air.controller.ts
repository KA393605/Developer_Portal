import { Controller, Inject, Get, Param, Query, Headers } from '@nestjs/common';
import { IAuthService } from '../core/interfaces';
import { IAirDomainService } from './interfaces';

@Controller('api/air')
export class AirController {
  constructor(
    @Inject('AirDomainService')
    private readonly airDomainService: IAirDomainService,
    @Inject('AuthService')
    private readonly authService: IAuthService,
  ) {}

  @Get('/pandora')
  searchPandora(
    @Query('query') query,
    @Headers('platforms-userid') userId?: string,
  ) {
    this.authService.validateUserId(userId);
    return this.airDomainService.searchPandora(query);
  }

  @Get('/pandora/:id')
  getPandora(
    @Param('id') pandoraId: string,
    @Headers('platforms-userid') userId?: string,
  ) {
    this.authService.validateUserId(userId);
    return this.airDomainService.getPandora(pandoraId);
  }
}
