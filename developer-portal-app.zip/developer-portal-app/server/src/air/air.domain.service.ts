import {
  Injectable,
  Inject,
  Logger,
  NotFoundException,
  OnModuleInit,
  OnModuleDestroy,
  BadRequestException,
} from '@nestjs/common';
import {
  IProjectRepository,
  IProjectServiceConnectionMessage,
} from '../projects/interfaces';
import {
  IProjectEnvironmentRepository,
  IProjectsPromoteToProdRequest,
} from '../projects/project-environment/interfaces';
import {
  AIR_APP_SECONDARY_CONTACT_JSON,
  AIR_APP_TERTIARY_CONTACT_JSON,
  AIR_DEFAULT_SETTINGS,
  AIR_ENVIRONMENT_VARIABLES,
  AIR_ERROR_MESSAGES,
  AIR_FORM_CONSTANTS,
  AIR_SERVICEBUS_ACTION,
  AIR_ENVIRONMENT,
  AIR_PANDORA_URL,
  AIR_SERVICEBUS_HANDLER_OPTIONS,
  AIR_APP_NAME_PREPEND,
} from './air.constants';
import { IAzureServiceBusBase, ICryptService } from '../core/interfaces';
import {
  IAirDomainService,
  IAirEnvironmentVariableInstance,
  IAirApplicationInstanceResponse,
  IAirCreateAppInstanceMessage,
  IAirApplicationInstanceRequest,
} from './interfaces';
import axios, { AxiosResponse } from 'axios';
import { v4 } from 'uuid';
import { OnMessage, ServiceBusMessage } from '@azure/service-bus';
import { IAirCreateAppMessage } from './interfaces/air-create-app-message.interface';
import { GATEWAY_CREDENTIALS_ENVIRONMENT } from '../gateway-credentials/gateway-credentials.constants';
import {
  IKongDomainService,
  IKongEnvironmentVariableInstance,
} from '../kong/interfaces';
import { IGatewayCredentialsDomainService } from '../gateway-credentials/interfaces';
import { GatewayCredentialsRequestDTO } from '../gateway-credentials/dto';
import { KONG_ENVIRONMENT_VARIABLES } from '../kong/kong.constants';
import { ENVIRONMENTS } from '../core/environments.constants';
import {
  PROJECT_SERVICEBUS_ACTION,
  SERVICEBUS_SESSION_ID,
} from '../projects/projects.constants';
import { STATUS_NAMES } from '../core/status.constants';

@Injectable()
export class AirDomainService
  implements IAirDomainService, OnModuleInit, OnModuleDestroy {
  private readonly logger: Logger = new Logger(AirDomainService.name);
  constructor(
    @Inject('ProjectRepository')
    private readonly projectRepo: IProjectRepository,
    @Inject('ProjectEnvironmentRepository')
    private readonly projectEnvironmentRepo: IProjectEnvironmentRepository,
    @Inject('KongDomainService')
    private readonly kongService: IKongDomainService,
    @Inject('AirServiceBusReceiver')
    private readonly airServiceBusReceiver: IAzureServiceBusBase,
    @Inject('AirServiceBusSender')
    private readonly airServiceBusSender: IAzureServiceBusBase,
    @Inject('CryptService')
    private readonly cryptService: ICryptService,
    @Inject('GatewayCredentialsDomainService')
    private readonly gatewayCredentialsDomainService: IGatewayCredentialsDomainService,
    @Inject('ProjectsServiceBusSender')
    private readonly projectsServiceBusSender: IAzureServiceBusBase,
  ) {}

  /**
   * Starts up our Service Bus Receiver
   * Connects service bus to hte message handler
   */
  onModuleInit() {
    this.logger.log('Creating module');
    this.airServiceBusSender.connect();
    this.projectsServiceBusSender.connect();
    this.airServiceBusReceiver.awaitReceiver(
      this.MessageHandler,
      { sessionId: SERVICEBUS_SESSION_ID },
      AIR_SERVICEBUS_HANDLER_OPTIONS,
    );
    this.logger.log('Connected Service Bus Clients');
  }

  /**
   * Disconnect service bus.
   */
  onModuleDestroy() {
    this.logger.log('Destroying module');
    this.airServiceBusReceiver.disconnect();
    this.airServiceBusSender.disconnect();
    this.logger.log('Disconnecting Service Bus Clients');
  }

  /**
   * Routes messages based on event type
   */
  MessageHandler: OnMessage = async brokeredMessage => {
    this.logger.log(
      'Received Message: ' + JSON.stringify(brokeredMessage.body),
    );
    const messageStatus = brokeredMessage.body.eventType;

    switch (messageStatus) {
      case AIR_SERVICEBUS_ACTION.CREATE_APP:
        const createAppMsg = brokeredMessage.body as IAirCreateAppMessage;
        await this.createAirApplication(
          AIR_ENVIRONMENT,
          createAppMsg.request.userId,
          createAppMsg.request.projectId,
          createAppMsg.request.projectTitle,
          createAppMsg.request.description,
          createAppMsg.request.submitterEmail,
          createAppMsg.request.submitterMudId,
          createAppMsg.request.serviceId,
          createAppMsg.request.request,
          brokeredMessage,
        );
        break;
      case AIR_SERVICEBUS_ACTION.CREATE_APP_INSTANCE:
        const createAppInstanceMsg = brokeredMessage.body as IAirCreateAppInstanceMessage;
        await this.createAirApplicationInstance(
          AIR_ENVIRONMENT,
          createAppInstanceMsg.request.userId,
          createAppInstanceMsg.request.projectEnvId,
          createAppInstanceMsg.request.airAppId,
          createAppInstanceMsg.request.env,
          createAppInstanceMsg.request.callbackUrls,
          createAppInstanceMsg.request.projectId,
          createAppInstanceMsg.request.serviceIds,
          createAppInstanceMsg.request.request,
          brokeredMessage,
        );
        break;
      default:
        brokeredMessage.deadLetter({
          deadletterReason: brokeredMessage.body.eventType,
          deadLetterErrorDescription: 'Message eventType not recognized.',
        });
        this.logger.error(
          new NotFoundException(JSON.stringify(brokeredMessage)),
        );
    }
  };

  /**
   * Creates Air Application
   * @param airEnv
   * @param userId
   * @param projectId
   * @param projectTitle
   * @param description
   * @param submitterEmail
   * @param submitterMudId
   * @param serviceId Optional. Requested Service Attachment
   * @param request Optional. Request for prod access to Service
   * @param brokeredMessage Optional. Brokered Message
   */
  async createAirApplication(
    airEnv: string,
    userId: number,
    projectId: number,
    projectTitle: string,
    description: string,
    submitterEmail: string,
    submitterMudId: string,
    serviceId?: number,
    request?: IProjectsPromoteToProdRequest,
    brokeredMessage?: ServiceBusMessage,
  ) {
    const envVars = AIR_ENVIRONMENT_VARIABLES[
      airEnv
    ] as IAirEnvironmentVariableInstance;
    const token = await this.kongService.getKongToken(
      envVars.clientId,
      envVars.secret,
      envVars.appTokenUrl,
    );

    const formData = {
      name:
        AIR_APP_NAME_PREPEND + '-' + projectTitle + '-' + Date.now().toString(),
      shortName: projectTitle,
      description,
      state: AIR_FORM_CONSTANTS.SUBMITTED_STATE,
      userType: JSON.parse(AIR_DEFAULT_SETTINGS.USER_TYPE),
      informationCategorization: JSON.parse(
        AIR_DEFAULT_SETTINGS.INFORMATION_CATEGORIZATION,
      ),
      hosting: JSON.parse(AIR_DEFAULT_SETTINGS.HOSTING),
      contacts: [
        {
          contact: {
            // Project submitter info
            email: submitterEmail,
            mudId: submitterMudId,
          },
          role: JSON.parse(AIR_DEFAULT_SETTINGS.PRIMARY_CONTACT_ROLE),
          isPrimary: true,
        },
        {
          // Pulled from environment vars
          contact: AIR_APP_SECONDARY_CONTACT_JSON,
          role: JSON.parse(AIR_DEFAULT_SETTINGS.TECHNICAL_CONTACT_ROLE),
          isPrimary: true,
        },
        {
          // Pulled from environment vars
          contact: AIR_APP_TERTIARY_CONTACT_JSON,
          role: JSON.parse(AIR_DEFAULT_SETTINGS.TECHNICAL_CONTACT_ROLE),
          isPrimary: false,
        },
      ],
    };
    try {
      const project = await this.projectRepo.getProjectById(projectId);
      const projectEnvs = await project.environments;

      let airApplicationId;
      if (!project.airApplicationId) {
        const res = await this.sendCreateRequestToAir(
          envVars.appUrl,
          formData,
          token,
        );
        await this.projectRepo.patchProject(
          projectId,
          { airApplicationId: res.data.id },
          userId,
        );
        airApplicationId = res.data.id;
      } else {
        airApplicationId = project.airApplicationId;
      }

      const createEnvEvent: IAirCreateAppInstanceMessage = {
        eventType: AIR_SERVICEBUS_ACTION.CREATE_APP_INSTANCE,
        request: {
          airAppId: airApplicationId,
          env: ENVIRONMENTS.DEV,
          projectEnvId: projectEnvs[0].projectEnvironmentId,
          projectId: project.projectId,
          userId,
          request,
          serviceIds: [serviceId],
        },
      };

      this.logger.log(
        `Requesting Air App Instance ID: ${
          project.projectId
        } request: ${JSON.stringify(createEnvEvent)}`,
      );
      this.airServiceBusSender.publish(createEnvEvent, {
        sessionId: SERVICEBUS_SESSION_ID,
      });

      brokeredMessage.complete();
    } catch (e) {
      this.logger.error(
        'Abandoning request: ' + JSON.stringify(brokeredMessage.body),
      );
      brokeredMessage.abandon();
      throw new Error(AIR_ERROR_MESSAGES.FAILED_TO_CREATE_APP + e.message);
    }
  }

  /**
   * Creates Air Application Instance
   * @param airEnv Air Environment
   * @param userId
   * @param projectEnvId
   * @param airAppId
   * @param env Environment for instance
   * @param callbackUrls
   * @param projectId Optional. Project Id
   * @param serviceIds number[] Optional. Requested Service Attachment
   * @param request Optional. Request for prod access to Service
   * @param brokeredMessage Optional. Brokered Message
   */
  async createAirApplicationInstance(
    airEnv: string,
    userId: number,
    projectEnvId: number,
    airAppId: string,
    env: string,
    callbackUrls?: string[],
    projectId?: number,
    serviceIds?: number[],
    request?: IProjectsPromoteToProdRequest,
    brokeredMessage?: ServiceBusMessage,
  ) {
    // Get variables for Air environment
    const envVars = AIR_ENVIRONMENT_VARIABLES[
      airEnv
    ] as IAirEnvironmentVariableInstance;
    // Get kong token for Air environment
    const token = await this.kongService.getKongToken(
      envVars.clientId,
      envVars.secret,
      envVars.appTokenUrl,
    );

    // Build formData to send to Air
    const airEnvironment = AIR_ENVIRONMENT_VARIABLES[env.toUpperCase()].airEnv;
    const airAppClientId = this.generateClientId();
    const formData: IAirApplicationInstanceRequest = {
      environment: airEnvironment,
      identifier: airAppClientId,
      ssoSettings: [
        {
          $type: AIR_FORM_CONSTANTS.SSO_TYPE,
          consumerServiceURLs: callbackUrls
            ? callbackUrls.map(url => {
                return { value: url };
              })
            : [{ value: AIR_FORM_CONSTANTS.SSO_CALLBACK }],
          protocol: {
            name: AIR_FORM_CONSTANTS.AUTH,
          },
          clientCredentials: AIR_FORM_CONSTANTS.CLIENT_CREDENTIALS,
          refreshToken: AIR_FORM_CONSTANTS.REFRESH_TOKEN,
        },
      ],
      applicationId: airAppId,
      state: AIR_FORM_CONSTANTS.PENDING_STATE,
    };

    if (request) {
      formData.pandoraRecord = { id: request.pandoraId };
    }

    try {
      // Send Request to Air
      const airRes = await this.sendCreateRequestToAir(
        envVars.appInstanceUrl,
        formData,
        token,
      );
      const airResponseData = airRes.data as IAirApplicationInstanceResponse;
      // Patch Project Environment with new instance id
      const projectEnv = await this.projectEnvironmentRepo.patchAirInstance(
        projectEnvId,
        airResponseData,
        userId,
      );
      const apiKey: string = this.cryptService.generateSecret(true);
      const gatewayCreds: GatewayCredentialsRequestDTO = {
        apiKey,
        clientId: airResponseData.identifier,
        clientSecret: airResponseData.ssoSettings[0].clientSecret,
        env,
      };

      // Gets kong credentials for whichever gateway environment we are working with
      const gateWayVars = KONG_ENVIRONMENT_VARIABLES[
        GATEWAY_CREDENTIALS_ENVIRONMENT.toUpperCase()
      ] as IKongEnvironmentVariableInstance;
      const gateWayToken = await this.kongService.getKongToken(
        gateWayVars.clientId,
        gateWayVars.secret,
        gateWayVars.tokenUrl,
      );

      // Save gateway Credentials
      await this.gatewayCredentialsDomainService.saveGatewayCredentials(
        gatewayCreds,
        gateWayToken,
      );

      await this.projectEnvironmentRepo.setStatus(
        projectEnvId,
        STATUS_NAMES.PROVISIONED,
      );

      // If service Id provided, add to environment
      if (serviceIds) {
        for (const serviceId of serviceIds) {
          // If we don't have the projectId, get from project environment.
          if (!projectId) {
            const project = await projectEnv.project;
            projectId = project.projectId;
          }
          // Create a message to send to event hub
          const projectServiceMessage: IProjectServiceConnectionMessage = {
            eventType: PROJECT_SERVICEBUS_ACTION.ADD_SERVICE,
            request: {
              projectEnvironmentId: projectEnvId,
              projectId,
              serviceId,
              userId,
              request,
            },
          };

          this.logger.log(
            'Requesting Project Service Connection. Msg: ' +
              JSON.stringify(projectServiceMessage),
          );
          this.projectsServiceBusSender.publish(projectServiceMessage, {
            sessionId: SERVICEBUS_SESSION_ID,
          });
        }
      }

      if (brokeredMessage) {
        this.logger.log(
          'Completed event: ' + JSON.stringify(brokeredMessage.body),
        );
        brokeredMessage.complete();
      }
    } catch (e) {
      this.logger.error(
        'Abandoning request: ' + JSON.stringify(brokeredMessage.body),
      );
      brokeredMessage.abandon();
      throw new Error(
        AIR_ERROR_MESSAGES.FAILED_TO_CREATE_APP_INSTANCE + e.message,
      );
    }
  }

  /**
   * Put Callback URLs
   * @param airAppId
   * @param urls
   * @param airEnv
   */
  async putCallbackUrls(airAppId: string, urls: string[], airEnv: string) {
    // Get variables for Air environment
    const envVars = AIR_ENVIRONMENT_VARIABLES[
      airEnv
    ] as IAirEnvironmentVariableInstance;

    // Get kong token for Air environment
    const token = await this.kongService.getKongToken(
      envVars.clientId,
      envVars.secret,
      envVars.appTokenUrl,
    );

    const instanceUrl = envVars.appInstanceUrl + '/' + airAppId;

    const headers = {
      'Authorization': `Bearer ${token}`,
      'Content-Type': AIR_FORM_CONSTANTS.HEADER_TOKEN_CONTENT_TYPE_JSON,
    };
    const client = axios.create({ headers });

    const request = await client.get(instanceUrl);

    // Create an object so URLS can be in format AIR expects
    const urlsPutReq = [];
    for (const url of urls) {
      const urlObj = { value: url };
      urlsPutReq.push(urlObj);
    }

    // Replace SSO settings (an array of one member)
    // with an otherwise identical version, but with new URLS
    const sso = request.data.ssoSettings;
    sso[0].consumerServiceURLs = urlsPutReq;
    request.data.ssoSettings = sso;

    // Attempt to PUT
    await client.put(instanceUrl, request.data);
  }

  /**
   * Send Create Request to AIR
   * @param url
   * @param formData
   * @param token
   */
  sendCreateRequestToAir(
    url: string,
    formData: object,
    token: string,
  ): Promise<AxiosResponse> {
    const headers = {
      'Authorization': `Bearer ${token}`,
      'Content-Type': AIR_FORM_CONSTANTS.HEADER_TOKEN_CONTENT_TYPE_JSON,
    };
    const client = axios.create({ headers });
    return client.post(url, formData);
  }

  /**
   * Generates ClientId
   * Takes v4 uuid, and removes all non-alphanumeric characters.
   */
  generateClientId(): string {
    return (
      v4()
        .toLowerCase()
        .replace(/[^a-zA-Z0-9]+/gi, '') + Date.now()
    );
  }

  /**
   * Validates that ENV variables are set.
   */
  validateEnvironmentalVariables() {
    if (!AIR_APP_SECONDARY_CONTACT_JSON) {
      throw new Error(
        AIR_ERROR_MESSAGES.MISSING_SECONDARY_CONTACT_ENV_VARIABLE,
      );
    }
    if (!AIR_APP_TERTIARY_CONTACT_JSON) {
      throw new Error(AIR_ERROR_MESSAGES.MISSING_TERTIARY_CONTACT_ENV_VARIABLE);
    }
  }

  /**
   * Search Pandora
   * Searches for Pandora records, filtered by a search term
   *
   * @returns
   * @memberof AirDomainService
   */
  async searchPandora(search: string) {
    // Get variables for Air environment
    const url = `${AIR_PANDORA_URL[AIR_ENVIRONMENT]}?search=${search}`;

    // Gets kong credentials for whichever gateway environment we are working with
    const gateWayVars = KONG_ENVIRONMENT_VARIABLES[
      GATEWAY_CREDENTIALS_ENVIRONMENT.toUpperCase()
    ] as IKongEnvironmentVariableInstance;

    const gateWayToken = await this.kongService.getKongToken(
      gateWayVars.clientId,
      gateWayVars.secret,
      gateWayVars.tokenUrl,
    );

    const headers = {
      'Authorization': `Bearer ${gateWayToken}`,
      'Content-type': 'application/json',
    };

    const client = axios.create({ headers });

    return await client
      .get(`${url}`)
      .catch(error => {
        if (error) {
          this.logger.error(error.response.status, error.response.data);
          throw new Error(
            error || {
              statusCode: error.response.status,
              message: error.response.data.message,
            },
          );
        }
      })
      .then((response: any) => response.data);
  }

  /**
   * Get Pandora
   * Returns a Pandora Record matching the specified ID
   *
   * @returns
   * @memberof AirDomainService
   */
  async getPandora(pandoraId: string) {
    // Get variables for Air environment
    const url = `${AIR_PANDORA_URL[AIR_ENVIRONMENT]}/${pandoraId}`;

    // Gets kong credentials for whichever gateway environment we are working with
    const gateWayVars = KONG_ENVIRONMENT_VARIABLES[
      GATEWAY_CREDENTIALS_ENVIRONMENT.toUpperCase()
    ] as IKongEnvironmentVariableInstance;

    const gateWayToken = await this.kongService.getKongToken(
      gateWayVars.clientId,
      gateWayVars.secret,
      gateWayVars.tokenUrl,
    );

    const headers = {
      'Authorization': `Bearer ${gateWayToken}`,
      'Content-type': 'application/json',
    };

    const client = axios.create({ headers });

    return await client
      .get(`${url}`)
      .catch(error => {
        if (error) {
          throw new BadRequestException(
            AIR_ERROR_MESSAGES.PANDORA_ID_NOT_FOUND,
          );
        }
      })
      .then((response: any) => {
        if (response.status === 204) {
          throw new BadRequestException(
            AIR_ERROR_MESSAGES.PANDORA_ID_NOT_FOUND,
          );
        } else {
          return response.data;
        }
      });
  }
}
