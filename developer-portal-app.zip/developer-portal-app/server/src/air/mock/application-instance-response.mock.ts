import { IAirApplicationInstanceResponse } from '../interfaces';

export const GoodApplicationInstanceResponse: IAirApplicationInstanceResponse = {
  applicationId: 'foo',
  applicationURL: 'some.url.com',
  createdDate: 'bar',
  environment: {
    displayName: 'foo',
    key: 'bar',
    order: 1,
  },
  state: 'good',
  id: 'foo',
  identifier: 'foo',
  name: 'foobar',
  pendingChanges: false,
  pandoraRecord: {
    name: 'My Applicaiton',
    itAssetOwner: 'foo man',
    urgency: 'so high',
    impact: 'moneys',
    id: 'P05',
  },
  ssoSettings: [
    {
      $type: 'sometype',
      clientSecret: 'secret',
      consumerServiceURLs: [{ value: 'url' }],
      id: 'someid',
      pendingChanges: false,
      protocol: {
        displayName: 'foo',
        id: 'bar',
        key: 'foo',
        name: 'fooobar',
        order: 1,
      },
    },
  ],
};
