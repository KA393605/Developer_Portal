import { IAirDomainService } from '../interfaces';

export const MockAirDomainService: IAirDomainService = {
  createAirApplication: jest.fn(() => {
    return;
  }),
  createAirApplicationInstance: jest.fn(() => {
    return;
  }),
  generateClientId: jest.fn(() => {
    return 'GoodClientId';
  }),
  putCallbackUrls: jest.fn(() => {
    return;
  }),
  sendCreateRequestToAir: jest.fn(() =>
    Promise.resolve({
      data: {},
      status: 1,
      statusText: 'GoodStatus',
      headers: {},
      config: {},
    }),
  ),
  validateEnvironmentalVariables: jest.fn(() => {
    return;
  }),
  searchPandora: jest.fn(() => {
    return Promise.resolve();
  }),
  getPandora: jest.fn(() => {
    return Promise.resolve();
  }),
};
