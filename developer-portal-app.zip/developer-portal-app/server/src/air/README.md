# AIR

### Logic:

- AIR interactions are now done via service bus.
- All pre prod requests go to QA (that's what kong team was doing)
- When creating the AIR Instance, we need to create it in the same environment as we created the application in, but pass it the correct AIR environment object (set as env variable).

### Create Project Flow:

- When a project is created, a message is sent and received via service bus.
- Message triggers the creation of an application id.
- Project gets patched.
- An Application Instance is created.
- Project Env gets patched.

Please update this readme if you make changes to logic or flow.
