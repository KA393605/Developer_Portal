import { ENVIRONMENTS } from '../core/environments.constants';
import { IAirEnvironmentVariables } from './interfaces/air-environment-variables.interface';

// Defaults
export const AIR_APP_NAME_PREPEND = 'developer_portal';

export const AIR_APP_SECONDARY_CONTACT_JSON = JSON.parse(
  process.env.AIR_APP_SECONDARY_CONTACT_JSON,
);
export const AIR_APP_TERTIARY_CONTACT_JSON = JSON.parse(
  process.env.AIR_APP_TERTIARY_CONTACT_JSON,
);

export enum AIR_DEFAULT_SETTINGS {
  HOSTING = '{"name": "ThirdParty", "id": "65156e7a-63b1-b717-c7fa-bf65d7f4c869"}',
  USER_TYPE = '{"name": "InternalAndExternal", "id": "b1af77c5-028f-cb07-267d-27514213fa19"}',
  PRIMARY_CONTACT_ROLE = '{"name": "ApplicationOwner", "id": "0c7a54bf-b4cc-84fc-33d9-aea7d5445014"}',
  TECHNICAL_CONTACT_ROLE = '{"name": "TechnicalOwner", "id": "efba357e-a843-f3c9-555c-79bc76084727"}',
  INFORMATION_CATEGORIZATION = '{"name": "CSI", "id": "c8dfa8e5-f496-8635-8ee4-2a38a3ee6c85"}',
}

// Error messages
export enum AIR_ERROR_MESSAGES {
  FAILED_TO_CREATE_APP = 'Failed to create the Air Application.',
  FAILED_TO_CREATE_APP_INSTANCE = 'Failed to create the Air Application Instance.',
  MISSING_SECONDARY_CONTACT_ENV_VARIABLE = 'Missing Environment Variable: AIR_APP_SECONDARY_CONTACT_JSON must be defined.',
  MISSING_TERTIARY_CONTACT_ENV_VARIABLE = 'Missing Environment Variable: AIR_APP_TERTIARY_CONTACT_JSON must be defined.',
  AIR_ENV_NOT_ALLOWED = 'AIR Environment malformed',
  AIR_INSTANCE_ENV_NOT_ALLOWED = 'AIR Instance Environment malformed',
  PANDORA_ID_NOT_FOUND = 'Pandora ID not found',
}

// Form constants
export enum AIR_FORM_CONSTANTS {
  SSO_TYPE = 'PingFederateSSOSetting',
  SSO_CALLBACK = 'https://app.getpostman.com/oauth2/callback',
  PENDING_STATE = 'Pending',
  SUBMITTED_STATE = 'Submitted',
  AUTH = 'OAUTH2',
  HEADER_TOKEN_CONTENT_TYPE_JSON = 'application/json;charset=UTF-8',
  REFRESH_TOKEN = 'false',
  CLIENT_CREDENTIALS = 'true',
}

export const AIR_ENVIRONMENT = process.env.AIR_ENVIRONMENT;

// Service Bus
export enum AIR_SERVICEBUS_ACTION {
  CREATE_APP = 'createAirApplication',
  CREATE_APP_INSTANCE = 'createApplicationInstance',
}
export const AIR_SERVICEBUS_CONN_STRING =
  process.env.AIR_SERVICEBUS_CONN_STRING;
export const AIR_SERVICEBUS_QUEUE_NAME = process.env.AIR_SERVICEBUS_QUEUE_NAME;

export const SERVICEBUS_SESSION_ID = process.env.SERVICEBUS_SESSION_ID;

export const AIR_SERVICEBUS_HANDLER_OPTIONS = {
  autoComplete: process.env.AIR_SERVICEBUS_HANDLER_AUTOCOMPLETE === 'true',
  maxMessageAutoRenewLockDurationInSeconds: parseInt(
    process.env.AIR_SERVICEBUS_RECEIVER_HANDLER_RENEW_LOCK_DURATION,
    10,
  ),
  maxConcurrentCalls: parseInt(
    process.env.AIR_SERVICEBUS_RECEIVER_HANDLER_MAX_CONCURRENT_CALLS,
    10,
  ),
};

export enum AIR_ENVIRONMENTS {
  DEV = '{"name": "Development", "id": "df490f33-4382-6a75-8a4d-c7f7f7ee6dfe"}',
  QA = '{"name": "QA", "id": "1c6cdd19-50ec-c84a-5464-5f352eb03209"}',
  PROD = '{"name": "Production", "id": "bb976d75-6b25-8085-d4d7-1ee0c547804e"}',
}

export enum AIR_APP_URL {
  DEV = 'https://qa.api.gsk.com/air-api/api/applications',
  QA = 'https://qa.api.gsk.com/air-api/api/applications',
  PROD = 'https://access.gsk.com/air-api/api/applications',
}

export enum AIR_PANDORA_URL {
  DEV = 'https://qa.api.gsk.com/air-api/api/pandora',
  QA = 'https://qa.api.gsk.com/air-api/api/pandora',
  PROD = 'https://access.gsk.com/air-api/api/pandora',
}

export enum AIR_APP_INSTANCE_URL {
  DEV = 'https://qa.api.gsk.com/air-api/api/applicationinstances',
  QA = 'https://qa.api.gsk.com/air-api/api/applicationinstances',
  PROD = 'https://access.gsk.com/air-api/api/applicationinstances',
}

export enum AIR_APP_TOKEN_URL {
  DEV = 'https://qa.api.gsk.com/token',
  QA = 'https://qa.api.gsk.com/token',
  PROD = 'https://api.gsk.com/token',
}

// Variables for environment
export const AIR_ENVIRONMENT_VARIABLES: IAirEnvironmentVariables = {
  DEV: {
    env: ENVIRONMENTS.DEV,
    airEnv: JSON.parse(AIR_ENVIRONMENTS.DEV),
    clientId: process.env.KONG_CLIENT_ID,
    secret: process.env.KONG_CLIENT_SECRET,
    appUrl: AIR_APP_URL[AIR_ENVIRONMENT],
    appInstanceUrl: AIR_APP_INSTANCE_URL[AIR_ENVIRONMENT],
    appTokenUrl: AIR_APP_TOKEN_URL[AIR_ENVIRONMENT],
    pandoraUrl: AIR_PANDORA_URL[AIR_ENVIRONMENT],
  },
  QA: {
    env: ENVIRONMENTS.QA,
    airEnv: JSON.parse(AIR_ENVIRONMENTS.QA),
    clientId: process.env.KONG_CLIENT_ID,
    secret: process.env.KONG_CLIENT_SECRET,
    appUrl: AIR_APP_URL[AIR_ENVIRONMENT],
    appInstanceUrl: AIR_APP_INSTANCE_URL[AIR_ENVIRONMENT],
    appTokenUrl: AIR_APP_TOKEN_URL[AIR_ENVIRONMENT],
    pandoraUrl: AIR_PANDORA_URL[AIR_ENVIRONMENT],
  },
  PROD: {
    env: ENVIRONMENTS.PROD,
    airEnv: JSON.parse(AIR_ENVIRONMENTS.PROD),
    clientId: process.env.KONG_CLIENT_ID,
    secret: process.env.KONG_CLIENT_SECRET,
    appUrl: AIR_APP_URL[AIR_ENVIRONMENT],
    appInstanceUrl: AIR_APP_INSTANCE_URL[AIR_ENVIRONMENT],
    appTokenUrl: AIR_APP_TOKEN_URL[AIR_ENVIRONMENT],
    pandoraUrl: AIR_PANDORA_URL[AIR_ENVIRONMENT],
  },
};
