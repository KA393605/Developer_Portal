// ENV VAR SETUP
// This has to happen before any imports
if (!process.env.AIR_APP_SECONDARY_CONTACT_JSON) {
  process.env.AIR_APP_SECONDARY_CONTACT_JSON = '{"default":"default"}';
}
if (!process.env.AIR_APP_TERTIARY_CONTACT_JSON) {
  process.env.AIR_APP_TERTIARY_CONTACT_JSON = '{"default":"default"}';
}

// Imports
import { AirDomainService } from './air.domain.service';
import { IProjectRepository } from '../projects/interfaces';
import { MockProjectRepository, GoodProject } from '../projects/mocks';
import { IProjectEnvironmentRepository } from '../projects/project-environment/interfaces';
import {
  MockProjectEnvironmentRepository,
  GoodProjectEnvironment,
} from '../projects/project-environment/mocks';
import { IKongDomainService } from '../kong/interfaces';
import { MockKongDomainService } from '../kong/mock';
import { IGatewayCredentialsDomainService } from '../gateway-credentials/interfaces';
import { MockGatewayCredentialsDomainService } from '../gateway-credentials/mock';
import { ICryptService, IAzureServiceBusBase } from '../core/interfaces';
import { MockCryptService, MockAzureServiceBus } from '../core/mocks';
import { ENVIRONMENTS } from '../core/environments.constants';
import { AIR_SERVICEBUS_ACTION } from './air.constants';

describe('Air Domain Service', () => {
  let domainService: AirDomainService;

  let mockProjectRepo: IProjectRepository;
  let mockProjectEnvironmentRepo: IProjectEnvironmentRepository;
  let mockKongDomainService: IKongDomainService;
  let mockAzureServiceBusReceiver: IAzureServiceBusBase;
  let mockAzureServiceBusSender: IAzureServiceBusBase;
  let mockCryptService: ICryptService;
  let mockGatewayCredentialsDomainService: IGatewayCredentialsDomainService;
  let mockProjectServiceAzureServiceBusSender: IAzureServiceBusBase;
  let mockAirServiceBusSender: IAzureServiceBusBase;

  beforeEach(() => {
    const MockProjectRepo = jest.fn<IProjectRepository, []>(
      () => MockProjectRepository,
    );
    const MockProjectEnvRepo = jest.fn<IProjectEnvironmentRepository, []>(
      () => MockProjectEnvironmentRepository,
    );
    const KongDomainServiceMock = jest.fn<IKongDomainService, []>(
      () => MockKongDomainService,
    );
    const AzureServiceBusBaseMock = jest.fn<IAzureServiceBusBase, []>(
      () => MockAzureServiceBus,
    );
    const GatewayCredentialsDomainServiceMock = jest.fn<
      IGatewayCredentialsDomainService,
      []
    >(() => MockGatewayCredentialsDomainService);

    const CryptServiceMock = jest.fn<ICryptService, []>(() => MockCryptService);

    mockProjectRepo = new MockProjectRepo();
    mockProjectEnvironmentRepo = new MockProjectEnvRepo();
    mockKongDomainService = new KongDomainServiceMock();
    mockAzureServiceBusReceiver = new AzureServiceBusBaseMock();
    mockAzureServiceBusSender = new AzureServiceBusBaseMock();
    mockCryptService = new CryptServiceMock();
    mockGatewayCredentialsDomainService = new GatewayCredentialsDomainServiceMock();
    mockProjectServiceAzureServiceBusSender = new AzureServiceBusBaseMock();
    mockAirServiceBusSender = new AzureServiceBusBaseMock();

    domainService = new AirDomainService(
      mockProjectRepo,
      mockProjectEnvironmentRepo,
      mockKongDomainService,
      mockAzureServiceBusReceiver,
      mockAzureServiceBusSender,
      mockCryptService,
      mockGatewayCredentialsDomainService,
      mockProjectServiceAzureServiceBusSender,
    );
  });

  it('should be defined', () => {
    expect(domainService).toBeDefined();
  });

  describe('Create Application', () => {
    let sendCreateRequestToAir;
    let project;
    let projectEnvironments;
    beforeAll(async () => {
      sendCreateRequestToAir = jest
        .spyOn(domainService, 'sendCreateRequestToAir')
        .mockImplementation(() =>
          Promise.resolve({
            data: { id: 'Good Id' },
            status: 1,
            statusText: 'GoodStatus',
            headers: {},
            config: {},
          }),
        );
      it('Should get token', () => {
        expect(mockKongDomainService.getKongToken).toBeCalled();
      });

      it('Should get project by and projectEnvironment by Id', async () => {
        const _project = await mockProjectRepo.getProjectById(1);
        project = _project;

        expect(mockProjectRepo.getProjectById).toBeCalledWith(1);
        expect(_project).toEqual(GoodProject);
      });

      it('Should get project environment from project', async () => {
        const _projectEnvironments = await project.environments;
        projectEnvironments = _projectEnvironments;
        expect(_projectEnvironments).toEqual(GoodProjectEnvironment);
      });

      it('Should send request to air', () => {
        expect(sendCreateRequestToAir).toBeCalledTimes(1);
        expect(sendCreateRequestToAir).toBeCalledWith(
          undefined, // Env var, unset
          expect.anything(), // Hard to define, uses date.now()
          'Success',
        );
      });

      it('Should patch project', () => {
        expect(mockProjectRepo.patchProject).toBeCalledTimes(1);
        expect(mockProjectRepo.patchProject).toBeCalledWith(
          1,
          { airApplicationId: 'Good Id' },
          1,
        );
      });

      it('Should send AIR service bus request', () => {
        expect(mockAirServiceBusSender.publish).toBeCalledTimes(1);
        expect(mockAirServiceBusSender.publish).toBeCalledWith(
          {
            eventType: AIR_SERVICEBUS_ACTION.CREATE_APP_INSTANCE,
            request: {
              airAppId: 'Good Air Application Id',
              env: ENVIRONMENTS.DEV,
              projectEnvId: projectEnvironments[0].projectEnvironmentId,
              projectId: 1,
              userId: 1,
              request: undefined,
              serviceIds: [undefined],
            },
          },
          { sessionId: undefined },
        );
      });

      afterAll(() => {
        jest.clearAllMocks();
      });
    });
  });
  describe('Create Application Instance', () => {
    let sendCreateRequestToAir;
    let generateClientId;
    beforeAll(async () => {
      sendCreateRequestToAir = jest
        .spyOn(domainService, 'sendCreateRequestToAir')
        .mockImplementation(() =>
          Promise.resolve({
            data: {
              id: 'Good Id',
              identifier: 'Good Identifier',
              ssoSettings: [
                {
                  clientSecret: 'Good Secret',
                },
              ],
            },
            status: 1,
            statusText: 'GoodStatus',
            headers: {},
            config: {},
          }),
        );
      generateClientId = jest
        .spyOn(domainService, 'generateClientId')
        .mockImplementation(() => 'Good Client Id');
      await domainService.createAirApplicationInstance(
        'DEV',
        1,
        1,
        'Good Air App Id',
        'DEV',
      );
    });
    it('Should get a kong token', () => {
      // Twice, once for air and once for gateway service.
      expect(mockKongDomainService.getKongToken).toBeCalledTimes(2);
    });
    it('Should Generate Client Id', () => {
      expect(generateClientId).toBeCalled();
    });
    it('Should send request to air', () => {
      expect(sendCreateRequestToAir).toBeCalledTimes(1);
      expect(sendCreateRequestToAir).toBeCalledWith(
        undefined, // Env var, unset
        expect.anything(), // Hard to define, uses date.now()
        'Success',
      );
    });
    it('Should Patch Air Instance', () => {
      expect(mockProjectEnvironmentRepo.patchAirInstance).toBeCalledTimes(1);
      expect(mockProjectEnvironmentRepo.patchAirInstance).toBeCalledWith(
        1,
        {
          id: 'Good Id',
          identifier: 'Good Identifier',
          ssoSettings: [
            {
              clientSecret: 'Good Secret',
            },
          ],
        },
        1,
      );
    });
    it('Should Generate Secret', () => {
      expect(mockCryptService.generateSecret).toBeCalledTimes(1);
    });
    it('Should Save Gateway Credentials', () => {
      expect(
        mockGatewayCredentialsDomainService.saveGatewayCredentials,
      ).toBeCalledTimes(1);
      expect(
        mockGatewayCredentialsDomainService.saveGatewayCredentials,
      ).toBeCalledWith(
        {
          apiKey: 'GoodSecret',
          clientId: 'Good Identifier',
          clientSecret: 'Good Secret',
          env: 'DEV',
        },
        'Success',
      );
    });
    afterAll(() => {
      jest.clearAllMocks();
    });
  });
});
