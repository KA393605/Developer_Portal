import { Module } from '@nestjs/common';
import { AirController } from './air.controller';
import { AirDomainService } from './air.domain.service';
import { GatewayCredentialsModule } from '../gateway-credentials/gateway-credentials.module';
import { CryptService } from '../core/utilities';
import { AirServiceBusReceiver } from './air-service-bus-receiver';
import { AirServiceBusSender } from './air-service-bus-sender';
import { KongModule } from '../kong/kong.module';
import { ProjectRepositoryProvider } from '../projects/repositories';
import { ProjectEnvironmentRepositoryProvider } from '../projects/project-environment/repositories';
import { ProjectsServiceBusSender } from '../projects/projects-service-bus-sender';
import { AuthService } from '../core/auth.service';

const AirControllerProvider = {
  provide: 'AirController',
  useClass: AirController,
};

const AirDomainServiceProvider = {
  provide: 'AirDomainService',
  useClass: AirDomainService,
};

const CryptServiceProvider = {
  provide: 'CryptService',
  useClass: CryptService,
};

const AuthServiceProvider = {
  provide: 'AuthService',
  useClass: AuthService,
};

const AirServiceBusReceiverProvider = {
  provide: 'AirServiceBusReceiver',
  useClass: AirServiceBusReceiver,
};

const AirServiceBusSenderProvider = {
  provide: 'AirServiceBusSender',
  useClass: AirServiceBusSender,
};

const ProjectsServiceBusSenderProvider = {
  provide: 'ProjectsServiceBusSender',
  useClass: ProjectsServiceBusSender,
};

@Module({
  imports: [GatewayCredentialsModule, KongModule],
  providers: [
    AirControllerProvider,
    AirDomainServiceProvider,
    CryptServiceProvider,
    AuthServiceProvider,
    AirServiceBusReceiverProvider,
    AirServiceBusSenderProvider,
    ProjectRepositoryProvider,
    ProjectEnvironmentRepositoryProvider,
    ProjectsServiceBusSenderProvider,
  ],
  exports: [
    AirControllerProvider,
    AirDomainServiceProvider,
    CryptServiceProvider,
    AuthServiceProvider,
    AirServiceBusReceiverProvider,
    AirServiceBusSenderProvider,
    ProjectsServiceBusSenderProvider,
  ],
  controllers: [AirController],
})
export class AirModule {}
