import { Injectable } from '@nestjs/common';
import { AzureServiceBusBase } from '../core/utilities/service-bus.base';
import {
  AIR_SERVICEBUS_CONN_STRING,
  AIR_SERVICEBUS_QUEUE_NAME,
} from './air.constants';

@Injectable()
export class AirServiceBusReceiver extends AzureServiceBusBase {
  constructor() {
    super(AIR_SERVICEBUS_CONN_STRING, AIR_SERVICEBUS_QUEUE_NAME);
  }
}
