import { BadRequestException, Injectable } from '@nestjs/common';
import { getDbPool } from '../services/config/dbPool';
import fs from 'fs';
import { promisify } from 'util';
import axios, { AxiosInstance } from 'axios';

const readFile = promisify(fs.readFile);

@Injectable()
export class BaseDBService {
  private _dbClient: any;
  private _lastResponse: any;

  private async _getDBClient(): Promise<any> {
    this._dbClient = this._dbClient || (await getDbPool().connect());
    return this._dbClient;
  }

  protected static async readFile(path) {
    return await readFile(path, 'utf8');
  }

  protected async executeSql(sql, params?: any[]): Promise<boolean> {
    const client = await this._getDBClient();
    try {
      this._lastResponse = await client.query(sql, params || []);
    } catch (e) {
      // console.log('Error: ' + e.message);
      await this.rollback();
      throw e;
    }
    return true;
  }

  protected async begin(): Promise<boolean> {
    return await this.executeSql('BEGIN', []);
  }

  protected async commit(): Promise<boolean> {
    return this.executeSql('COMMIT', []);
  }

  protected response(key): Promise<any> {
    return new Promise<any>(() => {
      return this.getResult(key);
    });
  }

  protected async rollback(): Promise<boolean> {
    await this.executeSql('ROLLBACK', []);
    return true;
  }

  protected async done(): Promise<boolean> {
    const client = this._dbClient;
    if (typeof client !== 'undefined') {
      await client.release();
    }
    this._dbClient = undefined;
    return true;
  }

  protected async executeSqlFile(
    filePath: string,
    params: any[] = [],
  ): Promise<void> {
    const sql = await BaseDBService.readFile(filePath);

    try {
      await this.executeSql(sql, params);
      return;
    } catch (e) {
      if (e.code === '23505') {
        // business logic error raised
        throw new BadRequestException(e.message);
      } else {
        throw e;
      }
    }
  }

  protected async executeFunction(
    fnName: string,
    schema: string,
    params: any[],
  ): Promise<any> {
    const tokens = params.map((param, index) => '$' + (index + 1));
    const sql = `select * from "${schema}"."${fnName}"(${tokens});`;
    try {
      await this.executeSql(sql, params);
      return this.getResult(fnName);
    } catch (e) {
      if (e.code === '23505') {
        // business logic error raised
        throw new BadRequestException(e.message);
      } else {
        throw e;
      }
    }
  }

  protected getResult(key?): any {
    let resp = this._lastResponse;
    if (key) {
      if (resp && resp.rows[0] && resp.rows[0][key]) {
        resp = resp.rows[0][key];
      } else {
        resp = null;
      }
    } else {
      if (resp && resp.rows[0]) {
        resp = resp.rows[0];
      }
    }
    return resp;
  }

  protected createHttpClient(token: string): AxiosInstance {
    const headers = {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
    };
    const client: AxiosInstance = axios.create({ headers });
    return client;
  }

  protected formatAxiosError(axiosError): { status: number; message: string } {
    const response = axiosError.response;
    let error = { status: 500, message: 'Service Error' };
    if (response) {
      if (response.status === 401) {
        response.status = 403;
      }
      error = { status: response.status, message: response.data.message };
    }
    return error;
  }
}
