import {
  AUTH_BASE_PATH,
  AUTH_USER_INFO_PATH,
  INTEGRIFY_RESPONSE_PATH,
  HEALTHCHECK_PATH,
} from '../../api.constants';
import { Request } from 'express';

export function shouldRedirectToLogin(req: Request): boolean {
  // not the auth path, or is the auth/user path
  // session is undefined
  // access_token is undefined
  const { path, session } = req;

  if (
    path.startsWith(AUTH_USER_INFO_PATH) ||
    (!path.startsWith(AUTH_BASE_PATH) &&
      !path.startsWith(INTEGRIFY_RESPONSE_PATH) &&
      !path.startsWith(HEALTHCHECK_PATH))
  ) {
    return session === undefined || typeof session.access_token === 'undefined';
  }

  return false;
}
