import { MockAzureEventGridBase } from '../mocks/eventgrid.base.mock';
import { isNull } from 'util';

const mockSubscriptionInfo = {
  topic: 'some topic',
  destination: {
    endpointType: 'some endpoint type',
    resourceId: 'some resource id',
  },
};

describe('Azure Service Bus base', () => {
  const mock = new MockAzureEventGridBase({}, mockSubscriptionInfo);

  it('Should create or update subscription', async () => {
    const res = mock.createOrUpdateSubscription();
    expect(isNull(res));
  });

  it('Should connect with service principal', async () => {
    const res = mock.connectServicePrincipal();
    expect(isNull(res));
  });

  it('Should connect with topic keys', async () => {
    const res = mock.connectTopicKeys();
    expect(isNull(res));
  });

  it('Should publish a message', async () => {
    const res = mock.publish();
    expect(isNull(res));
  });
});
