import { CryptService } from './crypt.service';

describe('CryptService', () => {
  describe('generating api secrets', () => {
    let tokenA: string;
    let tokenB: string;

    beforeEach(() => {
      const service = new CryptService();
      tokenA = service.generateSecret();
      tokenB = service.generateSecret();
    });
    it('should not be null', () => {
      expect(tokenA).not.toBeNull();
      expect(tokenB).not.toBeNull();
    });

    it('should be unique', () => {
      expect(tokenA).not.toEqual(tokenB);
    });

    it('should be 92 characters', () => {
      expect(tokenA.length).toEqual(92);
      expect(tokenB.length).toEqual(92);
    });
  });
});
