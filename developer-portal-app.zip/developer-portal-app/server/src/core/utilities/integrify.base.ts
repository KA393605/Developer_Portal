import axios from 'axios';
import axiosRetry from 'axios-retry';
import { IIntegrifyQuestion } from '../interfaces/integrify.question.interface';
import { IIntegrifyRequest } from '../interfaces/integrify.request.interface';
import { IIntegrifyParsedResponse } from '../interfaces/integrify-parsed.response';
import { IIntegrifyParser } from '../interfaces/integrify-parser.interface';
/**
 * Integrify Parser Base Class
 * Author Hakon Jonsson
 * Version 0.0.1
 *
 * Changelog:
 */

/**
 * Integrify Parser Class
 * Extend and override the following methods:
 * isValidRequest (validation of intake object)
 * buildQuestions (builds questions based on form labels/keys)
 * Use send(yourintakeobject) to submit
 * @param _authurl Url to Integrify Authentication
 * @param _url Form endpoint
 */
export abstract class IntegrifyParserBase implements IIntegrifyParser {
  /**
   * Validate intake object integrity
   * @param obj This is your intake object
   * @returns True or False based on Validation
   */
  abstract isValidRequest(obj: any): boolean;
  /**
   * Build Questions based on your intake object
   * @example
   * let __questions:IIntegrifyQuestion[] = [];
   * questions.push(this._formatQuestion(
   *   12345,
   *   'YOURLABEL',
   *   obj.yourlabel,
   *   'ShortText'
   * ));
   * return questions;
   *
   * @param obj This is your intake object
   * @returns An array of Questions
   */
  abstract buildQuestions(obj: any): IIntegrifyQuestion[];
  /**
   * Builds Questions and sends them to integrify
   * @param obj This is your intake object
   * @param mudId MudId for validation
   */
  async send(
    obj: any,
    mudId: string,
    kongToken: string,
  ): Promise<IIntegrifyParsedResponse> {
    try {
      if (!this.isValidRequest(obj)) {
        throw new Error('INVALID REQUEST');
      }
      const token = await this._getToken(
        process.env.INTEGRIFY_KEY,
        mudId,
        process.env.INTEGRIFY_AUTH_URL,
        kongToken,
      );
      const requestBody = await this._buildRequestBody(obj);
      const integrifyResponse = await this._sendToIntegrify(
        process.env.INTEGRIFY_KEY,
        token,
        requestBody,
        process.env.INTEGRIFY_URL,
        kongToken,
      );
      return this._parseResponse(integrifyResponse);
    } catch (error) {
      throw error;
    }
  }

  /**
   * Try and figure out of Success or Fail
   * Both return 200 OK, Fails are html, success are JSON
   * @param res Result directly from Integrify API
   * @returns Result is cleaned and converted to JSON
   */
  _parseResponse(res: any): IIntegrifyParsedResponse {
    if (typeof res.instance_sid === 'string') {
      return {
        success: true,
        message: res.instance_sid,
      } as IIntegrifyParsedResponse;
    } else {
      return {
        success: false,
        message: res.toString(),
      } as IIntegrifyParsedResponse;
    }
  }

  /**
   * Uses key, mudId to authenticate with integrify auth and returns token
   * @param key Form key
   * @param user mudId of User
   * @param baseurl Authentication endpoint
   */
  async _getToken(
    key: string,
    user: string,
    baseurl: string,
    kongToken: string,
  ): Promise<string> {
    let urlstring = baseurl;
    urlstring += '?key=' + key;
    urlstring += '&user=' + user;
    const options = {
      baseUrl: urlstring,
      headers: {
        'Authorization': 'Bearer ' + kongToken,
        'Content-Type': 'application/json',
      },
    };
    const client = axios.create(options);

    axiosRetry(client, {
      retries: 5,
      retryDelay: retryCount => {
        return retryCount * 3000;
      },
    });

    const token = await client
      .get(urlstring)
      .then(res => {
        return res.data.token as string;
      })
      .catch(err => {
        throw new Error('Error with integrify authentication');
      });
    return token;
  }

  /**
   * Sends parsed intake object to integrify
   * @param key Form key
   * @param token Integrify Authentication key
   * @param body Parsed intake object
   * @param baseurl Form endpoint
   * @returns Integrify request response
   */
  async _sendToIntegrify(
    key: string,
    token: string,
    body: IIntegrifyRequest,
    baseurl: string,
    kongToken: string,
  ): Promise<any> {
    let urlstring = baseurl;
    urlstring += '?key=' + key;
    urlstring += '&token=' + token;
    const options = {
      uri: urlstring,
      headers: {
        'Authorization': 'Bearer ' + kongToken,
        'Content-Type': 'application/json',
      },
    };

    const client = axios.create(options);

    axiosRetry(client, {
      retries: 5,
      retryDelay: retryCount => {
        return retryCount * 3000;
      },
    });

    const result = await client
      .post(urlstring, body)
      .then(res => {
        return res;
      })
      .catch(err => {
        throw new Error(err.message);
      });
    return result;
  }

  /**
   * Builds your request object
   * @param obj This is your intake object
   * @returns Integrify Request Body object.
   */
  _buildRequestBody(obj: any): IIntegrifyRequest {
    try {
      const questions = this.buildQuestions(obj);
      return {
        isDraft: false,
        questions,
      } as IIntegrifyRequest;
    } catch (error) {
      throw new Error('Error Building Questions');
    }
  }

  /**
   * Formats questions into integrify intake format.
   * @param key Form key
   * @param label Label of field
   * @param value Value for field
   * @param questiontype Type of question, usually 'ShortText'
   */
  _formatQuestion(
    key: number,
    label: string,
    value: string,
    questiontype: string,
    domid: string,
  ): IIntegrifyQuestion {
    return {
      key,
      label,
      value,
      QuestionType: questiontype,
      dom_id: domid,
    } as IIntegrifyQuestion;
  }
}
