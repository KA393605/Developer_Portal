/*
  KEY           Label
  1558722420284 Name
  1558722426241 MUD ID
  1558722431345 Email
  1558722486815 Business Owner MUD ID
  1558722496000 Service Name
  1558722502170 Service Version
  1558722513060 Service Environment
  1558722618276 API
  1558722566652 Project Name
  1558722572786 Project Description
  1558722581250 Business Justification
  1558723276185 Business Unit
*/

import { Injectable } from '@nestjs/common';
import { IntegrifyParserBase } from '.';
import { IIntegrifyParser, IIntegrifyQuestion } from '../interfaces';
import { ProjectsPromoteToProdIntegrifyRequestDTO } from '../../projects/project-environment/dto';

@Injectable()
export class IntegrifyParser extends IntegrifyParserBase
  implements IIntegrifyParser {
  isValidRequest(obj: ProjectsPromoteToProdIntegrifyRequestDTO): boolean {
    let pass = false;
    try {
      if (
        typeof obj.userFullName === 'string' &&
        typeof obj.userMudId === 'string' &&
        typeof obj.userEmailAddress === 'string' &&
        typeof obj.businessOwnerMudId === 'string' &&
        typeof obj.serviceVersion === 'string' &&
        typeof obj.serviceEnvironment === 'string' &&
        typeof obj.serviceName === 'string' &&
        typeof obj.projectName === 'string' &&
        typeof obj.projectDescription === 'string' &&
        typeof obj.businessJustification === 'string' &&
        typeof obj.businessUnit === 'string' &&
        typeof obj.approvalNeeded === 'string'
      ) {
        pass = true;
      } else {
        pass = false;
      }
    } catch (e) {
      pass = false;
    }
    return pass;
  }

  buildQuestions(
    obj: ProjectsPromoteToProdIntegrifyRequestDTO,
  ): IIntegrifyQuestion[] {
    const questions: IIntegrifyQuestion[] = [];
    try {
      // Name:
      questions.push(
        this._formatQuestion(
          1558722420284,
          'Name',
          obj.userFullName,
          'ShortText',
          'Name',
        ),
      );
      // MUD ID
      questions.push(
        this._formatQuestion(
          1558722426241,
          'MUD ID',
          obj.userMudId,
          'ShortText',
          'MUD ID',
        ),
      );
      // Email:
      questions.push(
        this._formatQuestion(
          1558722431345,
          'Email',
          obj.userEmailAddress,
          'ShortText',
          'Email',
        ),
      );
      // Business Owner MUD ID:
      questions.push(
        this._formatQuestion(
          1558722486815,
          'Business Owner MUD ID',
          obj.businessOwnerMudId,
          'ShortText',
          'Business Owner MUD ID',
        ),
      );
      // Service Name:
      questions.push(
        this._formatQuestion(
          1558722496000,
          'Service Name',
          obj.serviceName,
          'ShortText',
          'Service Name',
        ),
      );
      // Service Version:
      questions.push(
        this._formatQuestion(
          1558722502170,
          'Service Version',
          obj.serviceVersion,
          'ShortText',
          'Service Version',
        ),
      );
      // Service Environment:
      questions.push(
        this._formatQuestion(
          1558722513060,
          'Service Environment',
          obj.serviceEnvironment,
          'ShortText',
          'Service Environment',
        ),
      );
      // API:
      questions.push(
        this._formatQuestion(
          1558722618276,
          'API',
          obj.serviceName,
          'ShortText',
          'API',
        ),
      );
      // Project Name:
      questions.push(
        this._formatQuestion(
          1558722566652,
          'Project Name',
          obj.projectName,
          'ShortText',
          'Project Name',
        ),
      );
      // Project Description:
      questions.push(
        this._formatQuestion(
          1558722572786,
          'Project Description',
          obj.projectDescription,
          'ShortText',
          'Project Description',
        ),
      );
      // Business Justification:
      questions.push(
        this._formatQuestion(
          1558722581250,
          'Business Justification',
          obj.businessJustification,
          'ShortText',
          'Business Justification',
        ),
      );
      // Business Unit:
      questions.push(
        this._formatQuestion(
          1558723276185,
          'Business Unit',
          obj.businessUnit,
          'ShortText',
          'Business Unit',
        ),
      );
      // Approval Needed:
      questions.push(
        this._formatQuestion(
          1559920074910,
          'Is Approval Needed?',
          obj.approvalNeeded,
          'ShortText',
          'Is Approval Needed?',
        ),
      );
    } catch (error) {
      throw new Error('Error building questions');
    }
    return questions;
  }
}
