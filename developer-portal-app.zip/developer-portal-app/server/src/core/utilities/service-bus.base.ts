// reference [https://github.com/Azure/azure-sdk-for-js/blob/master/sdk/servicebus/service-bus/samples/typescript/advancedFeatures/sessionState.ts]

import { Injectable, Logger } from '@nestjs/common';
import {
  OnMessage,
  OnError,
  ServiceBusClient,
  QueueClient,
  SendableMessageInfo,
  ReceiveMode,
  delay,
  SessionReceiver,
  MessageHandlerOptions,
} from '@azure/service-bus';
import { IEvent } from '@nestjs/cqrs/dist/interfaces/events/event.interface';
import { IAzureServiceBusBase, IServiceBusSession } from '../interfaces';

@Injectable()
export abstract class AzureServiceBusBase implements IAzureServiceBusBase {
  private readonly baseLogger: Logger = new Logger(AzureServiceBusBase.name);
  private serviceBusClient: ServiceBusClient;
  private queueClient: QueueClient;
  private sender: any;
  private receiver: SessionReceiver;

  constructor(private _connString: string, private _queueName: string) {}

  /**
   * Connect to the Service Bus; creating a Service Bus Client,
   * Queue Client, and Sender
   * @returns
   */
  async connect() {
    const serviceBusClient = ServiceBusClient.createFromConnectionString(
      this._connString,
    );
    this.serviceBusClient = serviceBusClient;

    const queueClient = this.serviceBusClient.createQueueClient(
      this._queueName,
    );
    this.queueClient = queueClient;

    this.sender = this.queueClient.createSender();
  }

  /**
   * Disconnect from the Service Bus and Queue Client
   * To be used OnModuleDestroy
   * @returns
   */
  disconnect() {
    this.queueClient.close();
    this.serviceBusClient.close();
  }

  /**
   * Close Receiver
   * closes the SessionReceiver
   * @returns
   */
  closeReceiver() {
    this.receiver.close();
  }

  /**
   * Close Receiver
   * closes the SessionReceiver
   * @returns
   */
  peek() {
    this.receiver.peek();
  }

  /**
   * Base onMessageHandler, business logic to be performed when
   * receiver picks up a message
   * @returns
   */
  onMessageHandler: OnMessage = async brokeredMessage => {
    // console.log(`Received message: ${JSON.stringify(brokeredMessage.body)}`);
    try {
      await brokeredMessage.complete();
    } catch (error) {
      brokeredMessage.abandon();
    }
  };

  /**
   * Base onErrorHandler, business logic to be performed when
   * receiver faces error
   * @returns
   */
  onErrorHandler: OnError = err => {
    throw err;
  };

  /**
   * Sends composed message to Service Bus Queue Client
   * @param sessionId unique sessionId for message
   * @param event composed message body
   * @returns
   */
  async publish<T extends IEvent>(event: T, SessionId: IServiceBusSession) {
    const message: SendableMessageInfo = {
      body: Buffer.from(JSON.stringify(event)),
      label: `${this._queueName}`,
    };

    if (SessionId.sessionId) {
      message.sessionId = SessionId.sessionId;
    }

    try {
      await this.sender.send(message);
    } catch (error) {
      throw error;
    }
  }

  /**
   * Establishes as sessionReceiver for the message queue
   * @param sessionId unique sessionId for message
   * @returns
   */
  async createReceiver(sessionId?: IServiceBusSession) {
    let receiver;
    if (sessionId && sessionId.sessionId) {
      receiver = this.queueClient.createReceiver(
        ReceiveMode.peekLock,
        sessionId,
      );
    } else {
      receiver = this.queueClient.createReceiver(ReceiveMode.peekLock);
    }
    this.receiver = receiver;
    return receiver;
  }

  /**
   * Returns the state of a message session, identifies any messages in queue
   * @param sessionId unique sessionId for message
   * @returns
   */
  async getSessionState() {
    const sessionState = await this.receiver.getState();
    if (sessionState) {
      return sessionState;
    } else {
      return null;
    }
  }

  /**
   * Registers a message handler to be running until module destruction
   * @param messageHandler business logic to apply to received message
   * @returns
   */
  async bridgeEventsTo(
    messageHandler: OnMessage,
    messageHandlerOptions?: MessageHandlerOptions,
  ) {
    try {
      this.receiver.registerMessageHandler(
        messageHandler,
        this.onErrorHandler,
        messageHandlerOptions,
      );
    } catch (error) {
      throw error;
    }
  }

  /**
   * Cycles through waiting for a session message to be available for processing
   * by the SessionReceiver
   * @param messageHandler business logic to apply to received message
   * @param sessionId unique sessionId for message
   * @returns
   */
  async awaitSessionReceiver(
    messageHandler: OnMessage,
    sessionId: IServiceBusSession,
    messageHandlerOptions?: MessageHandlerOptions,
  ) {
    this.connect();
    let peek;
    do {
      try {
        const receiver = await this.createReceiver(sessionId);
        peek = await receiver.peek();
        this.closeReceiver();
      } catch (UnhandledPromiseRejectionWarning) {
        // this.baseLogger.log(`No messages for session ${sessionId.sessionId}`);
        await delay(10000); // wait 10 seconds before attempting another receiver connection
        continue;
      }
    } while (!peek);
    this.baseLogger.log(
      `Message receiver initialized for session ${sessionId.sessionId}`,
    );
    await this.createReceiver(sessionId);
    await this.bridgeEventsTo(messageHandler, messageHandlerOptions);
  }

  async awaitReceiver(
    messageHandler: OnMessage,
    sessionId?: IServiceBusSession,
    messageHandlerOptions?: MessageHandlerOptions,
  ) {
    if (!sessionId.sessionId) {
      this.connect();
      await this.createReceiver();
      await this.bridgeEventsTo(messageHandler, messageHandlerOptions);
    } else {
      await this.awaitSessionReceiver(
        messageHandler,
        sessionId,
        messageHandlerOptions,
      );
    }
  }
}
