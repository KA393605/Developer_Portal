import { MockAzureServiceBusBase } from '../mocks';
import { isNull } from 'util';

describe('Azure Service Bus base', () => {
  const mock = new MockAzureServiceBusBase(
    'some_connection_string',
    'some_queuename',
  );

  it('Should make good connection', async () => {
    const res = mock.connect();
    expect(isNull(res));
  });

  it('Should disconnect', async () => {
    const res = mock.disconnect();
    expect(isNull(res));
  });

  // it('Should make an error handler', async () => {
  //   const res = mock.onErrorHandler(Error('This is an expected test error'));
  //   expect(isNull(res));
  // });

  it('Should publish messages', async () => {
    const res = mock.publish();
    expect(isNull(res));
  });

  it('Should set up receiver', async () => {
    const res = mock.bridgeEventsTo();
    expect(isNull(res));
  });
});
