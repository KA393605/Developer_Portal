import { MockIntegrifyParserBase } from '../mocks/integrify.base.mock';

describe('Integrify Parser Base', () => {
  let mock: MockIntegrifyParserBase;
  beforeEach(async () => {
    mock = new MockIntegrifyParserBase();
  });

  it('should parse good mock response', async () => {
    const res = mock._parseResponse({ instance_sid: 'good' });
    expect(res.success).toEqual(true);
  });
  it('should parse bad mock response', async () => {
    const res = mock._parseResponse('<html>bad</html>');
    expect(res.success).toEqual(false);
    expect(res.message).toEqual('<html>bad</html>');
  });
  it('parse good mock response', async () => {
    const testO = { name: 'John Doe', favoriteNumber: 12345 };
    const res = mock._buildRequestBody(testO);
    expect(res.isDraft).toEqual(false);
    expect(Array.isArray(res.questions));
    expect(res.questions).toHaveLength(2);
  });
});
