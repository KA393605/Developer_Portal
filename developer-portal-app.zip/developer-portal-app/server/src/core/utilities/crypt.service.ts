import { Injectable } from '@nestjs/common';
import v4 from 'uuid/v4';
import crypto from 'crypto';
import { ICryptService } from '../interfaces';

@Injectable()
export class CryptService implements ICryptService {
  public generateSecret(urlSafe = false): string {
    // 1. Generate a uuid for uniqueness
    const uuid: Buffer = Buffer.from(v4());

    // 2. bytes for randomness
    const randomBytes: Buffer = crypto.randomBytes(32);

    // 3. combine the two buffers
    const token: Buffer = Buffer.concat([uuid, randomBytes]);

    // 4. Return the base64 conversion of the buffer, make urlsafe if declared
    let secret;
    if (urlSafe === true) {
      secret = token
        .toString('base64')
        .replace(/\+/g, '-') // Convert '+' to '-'
        .replace(/\//g, '_') // Convert '/' to '_'
        .replace(/=+$/, 'e'); // Remove trailing '='
    } else {
      secret = token.toString('base64');
    }
    return secret;
  }
}
