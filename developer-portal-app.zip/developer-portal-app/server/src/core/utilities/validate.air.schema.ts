export const MISMATCH_KEY_LENGTH =
  'Schema Mismatch: Number of object keys in test object does not align to schema: ';
export const MISMATCH_TEST_OBJECT =
  'Schema Mistmatch: Given test object does not align to schema: ';
export const MISSING_SCHEMA =
  'A schema in the form of a string array of object keys is required for validation: ';
export const MISSING_TEST_OBJECT =
  'A test object to match against the object schema is required for validation: ';

export const ERROR_SCHEMA_FILLER = ' - Schema: ';
export const ERROR_GIVEN_FILLER = ' Given: ';

export const validateSchema = (schema: string[], testObject, strict?) => {
  // Verify parameters
  if (!schema) {
    throw new Error(MISSING_SCHEMA + schema);
  }
  if (!testObject) {
    throw new Error(MISSING_TEST_OBJECT + testObject);
  }
  // Collect given test object keys and verify key length if strict matching is required
  if (strict && Object.keys(testObject).length !== schema.length) {
    throw new Error(
      MISMATCH_KEY_LENGTH +
        ERROR_SCHEMA_FILLER +
        schema +
        ERROR_GIVEN_FILLER +
        testObject,
    );
  }
  // Verify that the tested object has all the keys in the schema
  schema.forEach(key => {
    if (!testObject.hasOwnProperty(key)) {
      throw new Error(
        MISMATCH_TEST_OBJECT +
          ERROR_SCHEMA_FILLER +
          schema +
          ERROR_GIVEN_FILLER +
          Object.keys(testObject),
      );
    }
  });
  return true;
};
