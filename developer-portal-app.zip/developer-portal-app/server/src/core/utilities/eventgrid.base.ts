import { Injectable } from '@nestjs/common';
import { EventGridClient } from 'azure-eventgrid';
import * as egManagement from 'azure-arm-eventgrid';
import * as msrestAzure from 'ms-rest-azure';
import { IEventGridSubscription } from '../interfaces/eventgrid.subscription.interface';
import { IEventGridConnection } from '../interfaces/eventgrid.connection.interface';
import * as url from 'url';

@Injectable()
export abstract class AzureEventGridBase {
  private credentials: any;
  private eventGridClient: EventGridClient;
  topicUrl = url.parse(this._eventSubscriptionInfo.topic, true);
  topicHostName = this.topicUrl.host;

  constructor(
    private _connectionObject: IEventGridConnection,
    private _eventSubscriptionInfo: IEventGridSubscription,
  ) {}

  async connectServicePrincipal() {
    const auth = await msrestAzure.loginWithServicePrincipalSecretWithAuthResponse(
      this._connectionObject.servicePrincipal.clientId,
      this._connectionObject.servicePrincipal.clientSecret,
      this._connectionObject.servicePrincipal.tenantId,
    );

    this.credentials = auth.credentials;

    const eventGridClient = await new EventGridClient(this.credentials);
    this.eventGridClient = eventGridClient;
  }

  async connectTopicKeys() {
    const topicCreds = new msrestAzure.TopicCredentials(
      this._connectionObject.topicKey.topicKey,
    );
    this.credentials = topicCreds;

    const eventGridClient = new EventGridClient(this.credentials);
    this.eventGridClient = eventGridClient;
  }

  createOrUpdateEventGridSubscription(
    azureSubscriptionId: string,
    topicScope: string,
    eventSubscriptionName: string,
  ) {
    const egMgmt = new egManagement.EventGridManagementClient(
      this.credentials,
      azureSubscriptionId,
    );
    egMgmt.eventSubscriptions.createOrUpdateWithHttpOperationResponse(
      topicScope,
      eventSubscriptionName,
      this._eventSubscriptionInfo,
    );
  }

  async publish(events) {
    await this.eventGridClient
      .publishEvents(this.topicHostName, events)
      .then(result => {
        return Promise.resolve(/*console.log('Published events successfully')*/);
      })
      .catch(err => {
        throw err;
      });
  }
}
