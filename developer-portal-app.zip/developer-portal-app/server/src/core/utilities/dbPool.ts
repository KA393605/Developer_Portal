import PgPool from 'pg-pool';
const { ssl } = JSON.parse(
  process.env.TYPEORM_DRIVER_EXTRAS || '{"ssl": false}',
);
let pool;

export function getDbPool() {
  const config = {
    user: process.env.TYPEORM_USERNAME || 'postgres',
    password: process.env.TYPEORM_PASSWORD || 'postgres',
    host: process.env.TYPEORM_HOST || 'localhost',
    database: process.env.TYPEORM_DATABASE || 'marketplace',
    port: process.env.TYPEORM_PORT || 5432,
    ssl,
  };
  if (typeof pool === 'undefined') {
    pool = new PgPool(config);
  }
  return pool;
}

export async function executeQuery(
  sqlString: string,
  params: Array<unknown>,
): Promise<any> {
  const client = await getDbPool().connect();
  let r;
  try {
    await client.query('BEGIN');
    r = await client.query(sqlString, params);
    await client.query('COMMIT');
  } catch (e) {
    await client.query('ROLLBACK');
    throw e;
  } finally {
    await client.release();
  }
  return r;
}
