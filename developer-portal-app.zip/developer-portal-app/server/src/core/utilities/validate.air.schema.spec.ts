import {
  validateSchema,
  MISMATCH_KEY_LENGTH,
  MISMATCH_TEST_OBJECT,
  MISSING_SCHEMA,
  MISSING_TEST_OBJECT,
} from './validate.air.schema';

describe('validateSchema', () => {
  let mockSchema;
  let testObject;
  afterEach(() => {
    mockSchema = null;
    testObject = null;
  });
  describe('When no schema is given', () => {
    beforeEach(() => {
      testObject = { foo: 'bar' };
    });
    it('Should throw an error for a missing schema', () => {
      expect(() => validateSchema(null, testObject)).toThrow(MISSING_SCHEMA);
    });
  });
  describe('When no tested object is given', () => {
    beforeEach(() => {
      mockSchema = ['foo', 'bar'];
    });
    it('Should throw an error for a missing object to test', () => {
      expect(() => validateSchema(mockSchema, null)).toThrow(
        MISSING_TEST_OBJECT,
      );
    });
  });
  describe(`When the 'strict matching' flag is set to true`, () => {
    describe('And the number of keys in the schema matches the number of keys in the tested object', () => {
      describe('And the tested object aligns to the schema', () => {
        beforeEach(() => {
          mockSchema = ['foo', 'bar'];
          testObject = { foo: true, bar: '' }; // Verify string values register
        });
        it('Should return true', () => {
          expect(validateSchema(mockSchema, testObject, true)).toBeTruthy();
        });
      });
      describe('And the tested object does not align to the schema', () => {
        beforeEach(() => {
          mockSchema = ['foo', 'bar'];
          testObject = { foo: true, goo: false };
        });
        it('Should throw an error for schema mismatch', () => {
          expect(() => validateSchema(mockSchema, testObject, true)).toThrow(
            MISMATCH_TEST_OBJECT,
          );
        });
      });
    });
    describe(`And the number of keys in the schema does not match the number of keys in the tested object`, () => {
      beforeEach(() => {
        mockSchema = ['foo', 'bar'];
        testObject = { foo: true };
      });
      it('should throw an error for schema mismatch', () => {
        expect(() => validateSchema(mockSchema, testObject, true)).toThrow(
          MISMATCH_KEY_LENGTH,
        );
      });
    });
    describe(`And the keys in the tested object do not match the schema`, () => {
      beforeEach(() => {
        mockSchema = ['foo', 'bar'];
        testObject = { foo: true, goo: true };
      });
      it('Should throw an error for schema mistmatch', () => {
        expect(() => validateSchema(mockSchema, testObject, true)).toThrow(
          MISMATCH_TEST_OBJECT,
        );
      });
    });
  });
  describe(`When the 'strict matching' flag is set to false`, () => {
    describe(`And the tested object has more keys than the schema outlines`, () => {
      beforeEach(() => {
        mockSchema = ['foo', 'bar'];
        testObject = { foo: true, bar: false, goo: true };
      });
      it('Should return true', () => {
        expect(validateSchema(mockSchema, testObject)).toBeTruthy();
      });
    });
    describe(`And the tested object contains all the schema's keys`, () => {
      beforeEach(() => {
        mockSchema = ['foo', 'bar'];
        testObject = { foo: true, bar: null }; // Verify null values register
      });
      it('Should return true', () => {
        expect(validateSchema(mockSchema, testObject)).toBeTruthy();
      });
    });
    describe(`And the tested object does not have all the schema's keys`, () => {
      beforeEach(() => {
        mockSchema = ['foo', 'bar'];
        testObject = { foo: true };
      });
      it('Should throw an exception for missing keys', () => {
        expect(() => validateSchema(mockSchema, testObject, true)).toThrow(
          MISMATCH_KEY_LENGTH,
        );
      });
    });
  });
});
