export const ROLES = {
  OWNER: 'owner',
};
