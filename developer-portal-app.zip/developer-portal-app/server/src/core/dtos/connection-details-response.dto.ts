import { IConnectionDetailsResponse } from '../interfaces/connection-details-response.interface';

export class ConnectionDetailsResponseDTO
  implements IConnectionDetailsResponse {
  oAuth: string;
  clientId: string;
  secret: string;
  callbackURLs?: string[];
}
