export class GithubContentDTO {
  repository: string;
  contentPath: string;
  org?: string;
}
