import { IGithubService } from './interfaces';
import {
  ENTERPRISE_GITHUB_API_BASE_URL,
  GSK_TECH_REPOS_BASE_URL,
  GITHUB_OAUTH_TOKEN,
} from './github.constants';
import { GithubContentDTO } from './dtos/github-content-get.dto';
import * as axios from 'axios';
import { reject } from 'bluebird';
import { Logger, NotFoundException } from '@nestjs/common';
import Octokit, {
  GitGetTreeParams,
  ReposGetContentsParams,
  ReposListCommitsParams,
  RequestOptions,
} from '@octokit/rest';
import _ from 'lodash';

// the lib is dumb so it doesn't work if the base url has a trailing slash
const baseUrl = ENTERPRISE_GITHUB_API_BASE_URL.replace(/\/$/, '');

export class GithubService implements IGithubService {
  private logger = new Logger(this.constructor.name);
  private octokit = new Octokit({
    baseUrl,
    auth: GITHUB_OAUTH_TOKEN,
  });

  getRepoFiles(
    owner: string,
    repo: string,
    opts: Partial<ReposListCommitsParams> = {},
  ): Promise<string[]> {
    return this.octokit.repos
      .listCommits({
        owner,
        repo,
        per_page: 1,
        ...opts,
      })
      .then(r => r.data[0].sha)
      .then(sha => {
        return this.octokit.git.getTree({
          owner,
          repo,
          tree_sha: sha,
          recursive: '1',
        });
      })
      .then(r => r.data.tree.map(t => t.path));
  }

  getFileTree(opts: GitGetTreeParams) {
    return this.octokit.git
      .getTree({
        ...opts,
        recursive: '1',
      })
      .then(r => r.data.tree.map(t => t.path));
  }

  searchFilesInRepo(
    repoFullName: string,
    fileName: string,
    fileType: string = 'md',
    limit: number = 15,
  ) {
    return this.octokit.search
      .code({
        q: `${fileName} in:path extension:${fileType} repo:${repoFullName}`,
        per_page: limit,
      })
      .then(res =>
        res.data.items.map(item => {
          return {
            name: item.name,
            path: item.path,
            owner: item.repository.owner.login,
            repo: item.repository.name,
          };
        }),
      );
  }

  getFileContents(owner: string, repo: string, path: string, ref?: string) {
    const opts: ReposGetContentsParams & RequestOptions = {
      owner,
      repo,
      path,
    };
    if (ref) {
      opts.ref = ref;
    }
    return (
      this.octokit.repos
        .getContents(opts)
        // the types are wrong here for some reason, data.content is required if
        // not requesting html back from github
        // @ts-ignore
        .then(r => Buffer.from(r.data.content, 'base64').toString())
        .catch(e => {
          if (e && e.status === 404) {
            throw new NotFoundException();
          }
          throw e;
        })
    );
  }

  searchRepos(q: string, limit: number = 15) {
    return this.octokit.search
      .repos({
        q,
        per_page: limit,
      })
      .then(res =>
        res.data.items.map(
          (r): Partial<Octokit.SearchReposResponseItemsItem> => ({
            name: r.name,
            full_name: r.full_name,
            id: r.id,
            html_url: r.html_url,
            description: r.description,
            language: r.language,
            stargazers_count: r.stargazers_count,
            default_branch: r.default_branch,
            // @ts-ignore /-- the types are wrong
            permissions: r.permissions,
          }),
        ),
      );
  }

  listUserRepos(mudId: string) {
    return this.octokit.repos
      .listForUser({
        username: mudId,
        type: 'all',
        sort: 'updated',
        per_page: 100,
      })
      .then(res =>
        res.data.map(
          (r): Partial<Octokit.SearchReposResponseItemsItem> => ({
            name: r.name,
            full_name: r.full_name,
            id: r.id,
            html_url: r.html_url,
            description: r.description,
            language: r.language,
            stargazers_count: r.stargazers_count,
            default_branch: r.default_branch,
          }),
        ),
      )
      .catch(e => {
        if (e.status === 404) {
          throw new NotFoundException('User does not exist');
        }

        throw e;
      });
  }

  async getGithubTags(owner: string, repo: string): Promise<string[]> {
    const out: string[][] = [];
    // max per page is 100
    const perPage = 100;
    const maxPages = 10;
    let page = 1;
    while (page) {
      const r = await this.octokit.repos
        .listTags({
          owner,
          repo,
          page,
          per_page: perPage,
        })
        .then(res => res.data.map(tag => tag.name))
        .catch(e => {
          if (e.status === 404) {
            throw new NotFoundException(
              'Either the Repo does not exist, or was given incorrect owner information',
            );
          }
          throw e;
        });
      out.push(r);
      if (r.length < perPage || page > maxPages) {
        page = 0;
      } else {
        page += 1;
      }
    }
    return _.flatten(out);
  }

  /**
   * Get Orgs
   * Finds all orgs available in GSK Enterprise Instance
   *
   * @returns
   * @memberof GithubService
   */
  getGitOrgs() {
    const url = ENTERPRISE_GITHUB_API_BASE_URL;

    const config = {
      headers: {
        Authorization: `token ${GITHUB_OAUTH_TOKEN}`,
      },
    };

    return axios.default
      .get(url, config)
      .catch(error => {
        if (error) {
          this.logger.log(error.response.status, error.response.data);
          reject(error || { statusCode: error.response.status });
        }
      })
      .then((response: any) => response.data);
  }

  /**
   * Get  Repositories
   * Finds all available repositories in Github
   *
   *
   * @returns
   * @memberof GithubService
   */
  getRepositories() {
    const url = ENTERPRISE_GITHUB_API_BASE_URL + 'repositories';

    const config = {
      headers: {
        Authorization: `token ${GITHUB_OAUTH_TOKEN}`,
      },
    };

    return axios.default
      .get(url, config)
      .catch(error => {
        if (error) {
          this.logger.log(error.response.status, error.response.data);
          reject(error || { statusCode: error.response.status });
        }
      })
      .then((response: any) => response.data);
  }

  /**
   * Get Organization Repositories
   * Finds all orgs available repositories in a Github org
   *
   * @param org
   *
   * @returns
   * @memberof GithubService
   */
  getOrgRepositories(org: string) {
    const url = ENTERPRISE_GITHUB_API_BASE_URL;

    // if an org is specified, set api endpoint to that of selected
    switch (url) {
      case org:
        return ENTERPRISE_GITHUB_API_BASE_URL + 'repos' + org;
    }

    const config = {
      headers: {
        Authorization: `token ${GITHUB_OAUTH_TOKEN}`,
      },
    };

    return axios.default
      .get(url, config)
      .catch(error => {
        if (error) {
          this.logger.log(error.response.status, error.response.data);
          reject(
            error || {
              statusCode: error.response.status,
            },
          );
        }
      })
      .then((response: any) => response.data);
  }

  /**
   * Get Readme
   * Consumes the readme from Github for a specified repository path
   * registers README files in the root directory
   *
   * @param repository
   * @param org
   * @returns
   * @memberof GithubService
   */
  getReadme(repository: string, org?: string) {
    const url = GSK_TECH_REPOS_BASE_URL;

    // if an org is specified, set api endpoint to that of selected
    switch (url) {
      case org:
        return ENTERPRISE_GITHUB_API_BASE_URL + 'repos' + org;
    }

    const readmeUrl = url + `${repository}/readme`;

    const config = {
      headers: {
        Authorization: `token ${GITHUB_OAUTH_TOKEN}`,
      },
    };

    return axios.default
      .get(readmeUrl, config)
      .catch(error => {
        if (error) {
          this.logger.log(error.response.status, error.response.data);
          reject(error || { statusCode: error.response.status });
        }
      })
      .then((response: any) => response.data);
  }

  /**
   * Get Content
   * Consumes any document from a specified GITHUB path
   *
   * @param repository
   * @param contentPath
   * @param org
   * @returns
   * @memberof GithubService
   */
  getContent(data: GithubContentDTO) {
    const url = GSK_TECH_REPOS_BASE_URL;

    // if an org is specified, set api endpoint to that of selected
    switch (url) {
      case data.org:
        return ENTERPRISE_GITHUB_API_BASE_URL + 'repos' + data.org;
    }

    const contentUrl =
      `${url}` + `${data.repository}/contents/${data.contentPath}`;

    const config = {
      headers: {
        Authorization: `token ${GITHUB_OAUTH_TOKEN}`,
      },
    };

    return axios.default
      .get(`${contentUrl}`, config)
      .then((response: any) => response.data)
      .catch(error => {
        if (error) {
          this.logger.log(error.response.status, error.response.data);
          reject(error || { statusCode: error.response.status });
        }
      });
  }
}
