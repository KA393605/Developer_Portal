// Integrify Form Constants
export const INTEGRIFY_BUSINESS_JUSTIFICATION_DEFAULT =
  'This is a notification request';
export const INTEGRIFY_BUSINESS_UNIT_DEFAULT = 'n/a';
