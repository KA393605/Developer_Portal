import { ICryptService } from '../interfaces';

export const MockCryptService: ICryptService = {
  generateSecret: jest.fn(() => 'GoodSecret'),
};
