import { IntegrifyParserBase } from '../utilities/integrify.base';
import { IIntegrifyQuestion } from '../interfaces/integrify.question.interface';

export class MockIntegrifyParserBase extends IntegrifyParserBase {
  isValidRequest(obj: any): boolean {
    try {
      return (
        typeof obj.name === 'string' && typeof obj.favoriteNumber === 'number'
      );
    } catch (e) {
      return false;
    }
  }
  buildQuestions(o: any): IIntegrifyQuestion[] {
    const questions: IIntegrifyQuestion[] = [];
    try {
      // Name:
      questions.push(
        this._formatQuestion(
          1234567890123,
          'Name',
          o.name,
          'ShortText',
          'Name',
        ),
      );
      // Fav Number:
      questions.push(
        this._formatQuestion(
          1234567890124,
          'Name',
          o.favoriteNumber.toString(),
          'ShortText',
          'Name',
        ),
      );
    } catch (error) {
      throw new Error('Error building questions');
    }
    return questions;
  }
}
