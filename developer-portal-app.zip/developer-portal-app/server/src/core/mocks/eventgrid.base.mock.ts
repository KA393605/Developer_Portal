import { AzureEventGridBase } from '../utilities/eventgrid.base';

export class MockAzureEventGridBase extends AzureEventGridBase {
  createOrUpdateSubscription(): Promise<void> {
    return;
  }

  connectServicePrincipal(): Promise<void> {
    return;
  }

  connectTopicKeys(): Promise<void> {
    return;
  }

  publish(): Promise<void> {
    return;
  }
}
