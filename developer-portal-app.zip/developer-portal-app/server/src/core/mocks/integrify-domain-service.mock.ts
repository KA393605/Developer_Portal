import { IIntegrifyDomainService } from '../interfaces';
import { GoodIntegrifyParsedResponse } from '.';

export const MockIntegrifyDomainService: IIntegrifyDomainService = {
  promoteProjectRequest: jest.fn(() =>
    Promise.resolve(GoodIntegrifyParsedResponse),
  ),
};
