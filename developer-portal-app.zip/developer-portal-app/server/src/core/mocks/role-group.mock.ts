import { IRoleGroup } from '../interfaces/role-group.interface';

export const GoodRoleGroup: IRoleGroup = {
  roleGroupDescription: 'Good Role Group Description',
  roleGroupId: 1,
  roleGroupName: 'Good Role Group Name',
};
