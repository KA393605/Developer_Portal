import { IAuthService } from '../interfaces/auth-service.interface';

export const MockAuthService: IAuthService = {
  validateUserId: jest.fn(req => true),
};
