import { IEnvironment } from '../interfaces';

export const GoodEnvironment: IEnvironment = {
  environmentDescription: 'Good Environment Description',
  environmentId: 1,
  displayName: 'GOOD',
  environmentName: 'Good Environment Name',
  sequenceNumber: 1,
};
