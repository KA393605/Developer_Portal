import { IAzureServiceBusBase } from '../interfaces';

export const MockAzureServiceBus: IAzureServiceBusBase = {
  bridgeEventsTo: jest.fn(() => {
    return;
  }),
  connect: jest.fn(() => {
    return;
  }),
  disconnect: jest.fn(() => {
    return;
  }),
  createReceiver: jest.fn(() => {
    return;
  }),
  awaitSessionReceiver: jest.fn(() => {
    return;
  }),
  awaitReceiver: jest.fn(() => {
    return;
  }),
  closeReceiver: jest.fn(() => {
    return;
  }),
  peek: jest.fn(() => {
    return;
  }),
  getSessionState: jest.fn(() => {
    return;
  }),
  onErrorHandler: jest.fn(() => {
    return;
  }),
  onMessageHandler: jest.fn(() => {
    return;
  }),
  publish: jest.fn(() => {
    return;
  }),
};
