import { IIntegrifyParsedResponse } from '../interfaces';

export const GoodIntegrifyParsedResponse: IIntegrifyParsedResponse = {
  message: 'Good integrify message',
  success: true,
};
