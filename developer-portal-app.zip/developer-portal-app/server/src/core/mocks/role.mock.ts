import { IRole } from '../interfaces';
import { GoodRoleGroup } from './role-group.mock';

export const GoodRole: IRole = {
  roleDescription: 'Good Role Description',
  roleId: 1,
  roleName: 'Good Role Name',
  roleGroup: GoodRoleGroup,
};
