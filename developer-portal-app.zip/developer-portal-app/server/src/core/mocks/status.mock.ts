import { IStatus } from '../interfaces';
import { GoodStatusType } from './status-type.mock';

export const GoodStatus: IStatus = {
  createTimestamp: 1,
  sequenceNumber: 1,
  statusDescription: 'Good Status Description',
  statusId: 1,
  statusName: 'Good Status',
  statusType: GoodStatusType,
  updateTimestamp: 1,
};
