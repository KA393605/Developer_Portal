import { IStatusType } from '../interfaces';

export const GoodStatusType: IStatusType = {
  statusTypeId: 1,
  statusTypeName: 'Good Status Type Name',
  statusTypeDescription: 'Good Status Type Description',
  sequenceNumber: 1,
  createTimestamp: 1,
  updateTimestamp: 1,
};
