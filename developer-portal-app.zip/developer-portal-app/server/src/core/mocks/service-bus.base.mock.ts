import { AzureServiceBusBase } from '../utilities/service-bus.base';
import { OnError } from '@azure/service-bus';

export class MockAzureServiceBusBase extends AzureServiceBusBase {
  connect(): Promise<void> {
    return;
  }

  disconnect(): Promise<void> {
    return;
  }

  onErrorHandler: OnError = err => {
    throw err;
  };

  publish(): Promise<void> {
    return;
  }

  bridgeEventsTo(): Promise<void> {
    return;
  }
}
