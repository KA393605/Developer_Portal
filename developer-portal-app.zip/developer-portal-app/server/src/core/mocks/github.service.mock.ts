import { IGithubService } from '../interfaces';

export const MockGithubService: IGithubService = {
  getGitOrgs: jest.fn(() => Promise.resolve({})),
  getRepositories: jest.fn(() => Promise.resolve({})),
  getOrgRepositories: jest.fn(() => Promise.resolve({})),
  getReadme: jest.fn(() => Promise.resolve({})),
  getContent: jest.fn(() => Promise.resolve({})),
};
