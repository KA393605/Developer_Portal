import { IAuthService } from './interfaces/auth-service.interface';
import { AuthService } from './auth.service';

describe('Auth Service', () => {
  let service: IAuthService;

  beforeEach(async () => {
    service = new AuthService();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('Validate User Id', () => {
    it('Should return number on good call', () => {
      const res = service.validateUserId('1');
      expect(res).toEqual(true);
    });
    it('Should throw error on bad call', async () => {
      try {
        expect(service.validateUserId(null)).toThrow();
      } catch (error) {
        expect(error.status).toEqual(401);
        expect(error.message.error).toEqual('Unauthorized');
      }
    });
  });
});
