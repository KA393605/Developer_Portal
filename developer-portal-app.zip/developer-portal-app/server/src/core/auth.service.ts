import { Injectable, UnauthorizedException } from '@nestjs/common';
import { IAuthService } from './interfaces/auth-service.interface';

@Injectable()
export class AuthService implements IAuthService {
  validateUserId(userId?: string): boolean {
    // Checks if undefined or null
    if (userId == null) {
      throw new UnauthorizedException();
    } else {
      return true;
    }
  }
}
