import { Entity, PrimaryGeneratedColumn, Column, BaseEntity } from 'typeorm';
import { IStatusType } from '../interfaces/statustype.interface';

@Entity({ name: 'StatusType' })
export class StatusType extends BaseEntity implements IStatusType {
  @PrimaryGeneratedColumn()
  statusTypeId: number;

  @Column()
  statusTypeName: string;

  @Column()
  statusTypeDescription: string;

  @Column()
  sequenceNumber: number;

  @Column()
  createTimestamp: number;

  @Column()
  updateTimestamp: number;

  @Column()
  deleteTimestamp: number;
}
