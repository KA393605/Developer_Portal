import { Entity, PrimaryGeneratedColumn, Column, BaseEntity } from 'typeorm';
import { IRoleGroup } from '../interfaces/role-group.interface';

@Entity({ name: 'RoleGroup' })
export class RoleGroup extends BaseEntity implements IRoleGroup {
  @PrimaryGeneratedColumn()
  roleGroupId: number;

  @Column()
  roleGroupName: string;

  @Column()
  roleGroupDescription: string;
}
