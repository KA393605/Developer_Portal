import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  BaseEntity,
  JoinColumn,
  OneToOne,
} from 'typeorm';
import { IStatus } from '../interfaces/status.interface';
import { INTEGRIFY_ALLOWED_STATUS } from '../integrify.status.constants';
import { STATUS_NAMES } from '../status.constants';
import { StatusType } from '../value-objects';

@Entity({ name: 'Status' })
export class Status extends BaseEntity implements IStatus {
  @PrimaryGeneratedColumn()
  statusId: number;

  @OneToOne(type => StatusType)
  @JoinColumn({
    name: 'statusTypeId',
    referencedColumnName: 'statusTypeId',
  })
  statusType: StatusType;

  @Column()
  statusName: string;

  @Column()
  statusDescription: string;

  @Column()
  sequenceNumber: number;

  @Column()
  createTimestamp: number;

  @Column()
  updateTimestamp: number;

  @Column()
  deleteTimestamp: number;

  static getStatusNameFromIntegrifyRequest(integrifyStatus: string) {
    switch (integrifyStatus) {
      case INTEGRIFY_ALLOWED_STATUS.APPROVED:
        return STATUS_NAMES.APPROVED;
      case INTEGRIFY_ALLOWED_STATUS.APPROVED_AND_PROVISIONED:
        return STATUS_NAMES.APPROVEDANDPROVISIONED;
      case INTEGRIFY_ALLOWED_STATUS.DELETED:
        return STATUS_NAMES.DELETED;
      case INTEGRIFY_ALLOWED_STATUS.KEYS_RECEIVED:
        return STATUS_NAMES.KEYRECEIVED;
      case INTEGRIFY_ALLOWED_STATUS.REJECTED:
        return STATUS_NAMES.REJECTED;
      default:
        return;
    }
  }
}
