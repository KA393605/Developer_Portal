import {
  BaseEntity,
  PrimaryGeneratedColumn,
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
} from 'typeorm';
import { ITeam } from '../interfaces/team.interface';
import { IsUrl } from 'class-validator';
import { User } from '../../users/entities/user.entity';

@Entity({ name: 'Team' })
export class Team extends BaseEntity implements ITeam {
  @PrimaryGeneratedColumn()
  teamId: number;

  @Column()
  teamName: string;

  @Column()
  teamDescription: string;

  @IsUrl()
  @Column()
  iconUrl: string;

  @ManyToOne(type => User)
  @JoinColumn({
    name: 'createUserId',
    referencedColumnName: 'userId',
  })
  createUser: Promise<User>;

  @ManyToOne(type => User)
  @JoinColumn({
    name: 'lastUpdateUserId',
    referencedColumnName: 'userId',
  })
  lastUpdateUser: Promise<User>;
}
