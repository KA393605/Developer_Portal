import { BaseEntity, Entity, PrimaryGeneratedColumn, Column } from 'typeorm';
import { IEnvironment } from '../interfaces/environment.interface';

@Entity({ name: 'Environment' })
export class Environment extends BaseEntity implements IEnvironment {
  @PrimaryGeneratedColumn()
  environmentId: number;

  @Column()
  sequenceNumber: number;

  @Column()
  displayName: string;

  @Column()
  environmentName: string;

  @Column()
  environmentDescription: string;
}
