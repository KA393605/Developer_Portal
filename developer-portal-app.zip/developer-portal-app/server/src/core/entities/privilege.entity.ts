import { BaseEntity, PrimaryGeneratedColumn, Column, Entity } from 'typeorm';
import { IPrivilege } from '../interfaces/privilege.interface';

@Entity('Privilege')
export class Privilege extends BaseEntity implements IPrivilege {
  @PrimaryGeneratedColumn()
  privilegeId: number;

  @Column()
  privilegeName: string;

  @Column()
  privilegeDescription: string;
}
