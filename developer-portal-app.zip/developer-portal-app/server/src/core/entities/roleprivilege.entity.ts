import {
  BaseEntity,
  PrimaryColumn,
  Entity,
  OneToMany,
  JoinColumn,
} from 'typeorm';
import { IRolePrivilege } from '../interfaces/roleprivilege.interface';
import { Role } from './role.entity';
import { Privilege } from './privilege.entity';

@Entity('RolePrivilege')
export class RolePrivilege extends BaseEntity implements IRolePrivilege {
  role: Promise<Role>;

  @PrimaryColumn()
  roleId: number;
  roleName: string;

  @PrimaryColumn()
  privilegeId: number;

  @OneToMany(type => Privilege, privilege => privilege.privilegeId)
  @JoinColumn({
    name: 'privilegeId',
    referencedColumnName: 'privilegeId',
  })
  privileges: Promise<Privilege[]>;
}
