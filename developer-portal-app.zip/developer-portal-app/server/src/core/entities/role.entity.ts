import {
  BaseEntity,
  PrimaryGeneratedColumn,
  Column,
  Entity,
  OneToOne,
  JoinColumn,
} from 'typeorm';
import { IRole } from '../interfaces/role.interface';
import { RoleGroup } from '../value-objects/role-group.vo';
@Entity({ name: 'Role' })
export class Role extends BaseEntity implements IRole {
  @PrimaryGeneratedColumn()
  roleId: number;

  @Column()
  roleName: string;

  @Column()
  roleDescription: string;

  @OneToOne(type => RoleGroup)
  @JoinColumn({
    name: 'roleGroupId',
    referencedColumnName: 'roleGroupId',
  })
  roleGroup: RoleGroup;
}
