import { Injectable, Inject, Logger } from '@nestjs/common';
import { IntegrifyParser } from './utilities/integrify.parser';
import { IProject } from '../projects/interfaces';
import {
  IService,
  IRegistration,
  IRegistrationVersion,
} from '../services/interfaces';
import { IUser } from '../users/interfaces';
import { IProjectsPromoteToProdRequest } from '../projects/project-environment/interfaces';
import {
  IIntegrifyParsedResponse,
  IIntegrifyDomainService,
} from './interfaces';
import { ProjectsPromoteToProdIntegrifyRequestDTO } from '../projects/project-environment/dto';
import {
  INTEGRIFY_BUSINESS_JUSTIFICATION_DEFAULT,
  INTEGRIFY_BUSINESS_UNIT_DEFAULT,
} from './integrify.constants';
import { ENVIRONMENTS } from './environments.constants';
import { IKongDomainService } from '../kong/interfaces';

@Injectable()
export class IntegrifyDomainService extends IntegrifyParser
  implements IIntegrifyDomainService {
  private logger = new Logger(IntegrifyDomainService.name);
  constructor(
    @Inject('KongDomainService')
    private readonly kongService: IKongDomainService,
  ) {
    super();
  }

  /**
   * Creates a form object that is sent to integrify.
   * If it requires approval but is non prod,
   * integrify will send a notification to business owner.
   * @param project project
   * @param service service
   * @param businessOwner business owner
   * @param requestor person making request
   * @param environment environment requested
   * @param registration service registration
   * @param registrationVersion version of service registration
   * @param request form object coming from promote to prod
   */
  async promoteProjectRequest(
    project: IProject,
    service: IService,
    businessOwner: IUser,
    requestor: IUser,
    environment: string,
    registration: IRegistration,
    registrationVersion: IRegistrationVersion,
    request?: IProjectsPromoteToProdRequest,
  ): Promise<IIntegrifyParsedResponse> {
    this.logger.log(
      `${requestor.fullName} 
      requested access from ${project.projectName} 
      to serviceId: ${service.serviceId} 
      in ${environment}. 
      Business Owner: ${businessOwner.fullName}`,
    );
    const integrifyRequest = new ProjectsPromoteToProdIntegrifyRequestDTO();
    integrifyRequest.approvalNeeded = service.requiresApproval ? 'yes' : 'no';
    request
      ? (integrifyRequest.businessJustification = request.businessJustification)
      : (integrifyRequest.businessJustification = INTEGRIFY_BUSINESS_JUSTIFICATION_DEFAULT);
    integrifyRequest.businessOwnerMudId = businessOwner.mudId;
    integrifyRequest.projectDescription = project.projectDescription;
    integrifyRequest.projectName = project.projectName;
    // pre production OR production
    integrifyRequest.serviceEnvironment =
      environment === ENVIRONMENTS.PROD ? 'production' : 'pre production';
    integrifyRequest.serviceName = registration.resourceName;
    integrifyRequest.serviceVersion = registrationVersion.versionId.toString();

    // Populate with user, from publisher.
    integrifyRequest.userEmailAddress = requestor.email;
    integrifyRequest.userFullName = requestor.fullName;
    integrifyRequest.userMudId = requestor.mudId;

    // There is no place to check for business unit.
    integrifyRequest.businessUnit = INTEGRIFY_BUSINESS_UNIT_DEFAULT;

    // mudId from header gets passed to here, placeholder until guard gets completed.
    let mudId = '';
    if (process.env.INTEGRIFY_TOKEN_MUDID) {
      mudId = process.env.INTEGRIFY_TOKEN_MUDID;
    } else {
      mudId = requestor.mudId;
    }

    // Get a kong token
    const kongToken = await this.kongService.getKongToken(
      process.env.KONG_CLIENT_ID,
      process.env.KONG_CLIENT_SECRET,
      process.env.KONG_TOKEN_URL,
    );
    // Send request to integrify.
    try {
      return await this.send(integrifyRequest, mudId, kongToken);
    } catch (error) {
      this.logger.error(error.message);
      throw error.message;
    }
  }
}
