export interface IDomainService {
  create?: (item: any) => any;
  findAll?: (...args: any[]) => void;
  findOne?: (id: any) => any;
  patch?: (...args: any) => any;
  remove?: (id: any) => void;
  updateRequest?: (...args: any) => void;
  getEnvironment?: (...args: any) => any;
  getProjectServiceByEnvironment?: (...args: any) => any;
  getServiceById?: (id: number) => any;
  addServiceById?: (...args: any) => any;
}
