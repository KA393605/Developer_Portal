export interface IRoleGroup {
  roleGroupId: number;
  roleGroupName: string;
  roleGroupDescription: string;
}
