import { IStatusType } from './statustype.interface';

export interface IStatus {
  statusId: number;
  statusType: IStatusType;
  statusName: string;
  statusDescription: string;
  sequenceNumber: number;
  createTimestamp: number;
  updateTimestamp: number;
}
