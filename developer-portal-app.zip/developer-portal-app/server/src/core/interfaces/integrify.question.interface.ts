export interface IIntegrifyQuestion {
  key: number;
  label: string;
  value: string;
  QuestionType: string;
  dom_id: string;
}
