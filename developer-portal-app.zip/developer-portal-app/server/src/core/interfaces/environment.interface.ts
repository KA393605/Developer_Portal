export interface IEnvironment {
  environmentId: number;
  sequenceNumber: number;
  displayName: string;
  environmentName: string;
  environmentDescription: string;
}
