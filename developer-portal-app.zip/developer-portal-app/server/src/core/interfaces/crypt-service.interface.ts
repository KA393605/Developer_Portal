export interface ICryptService {
  generateSecret(urlSafe): string;
}
