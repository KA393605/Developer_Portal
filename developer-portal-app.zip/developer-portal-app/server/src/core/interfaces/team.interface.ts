export interface ITeam {
  teamId: number;
  teamName: string;
  teamDescription: string;
  iconUrl: string;
}
