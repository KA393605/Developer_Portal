import { IRoleGroup } from './role-group.interface';

export interface IRole {
  roleId: number;
  roleName: string;
  roleDescription: string;
  roleGroup: IRoleGroup;
}
