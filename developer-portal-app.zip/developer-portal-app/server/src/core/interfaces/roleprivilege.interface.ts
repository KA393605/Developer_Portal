import { IRole } from './role.interface';
import { IPrivilege } from './privilege.interface';

export interface IRolePrivilege {
  role: Promise<IRole>;
  roleId: number;
  roleName: string;
  privilegeId: number;
  privileges: Promise<IPrivilege[]>;
}
