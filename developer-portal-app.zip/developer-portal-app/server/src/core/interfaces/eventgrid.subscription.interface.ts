interface IEventGridSubscriptionData {
  endpointType: string;
  resourceId: string;
}

export interface IEventGridSubscription {
  topic: string;
  destination: IEventGridSubscriptionData;
}
