import { IProject } from '../../projects/interfaces';
import {
  IService,
  IRegistration,
  IRegistrationVersion,
} from '../../services/interfaces';
import { IUser } from '../../users/interfaces';
import { IProjectsPromoteToProdRequest } from '../../projects/project-environment/interfaces';
import { IIntegrifyParsedResponse } from '.';

export interface IIntegrifyDomainService {
  promoteProjectRequest(
    project: IProject,
    service: IService,
    businessOwner: IUser,
    requestor: IUser,
    environment: string,
    registration: IRegistration,
    registrationVersion: IRegistrationVersion,
    request?: IProjectsPromoteToProdRequest,
  ): Promise<IIntegrifyParsedResponse>;
}
