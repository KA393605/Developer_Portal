export interface IPrivilege {
  privilegeId: number;
  privilegeName: string;
  privilegeDescription: string;
}
