/**
 * Integrify response after being cleaned and converted to JSON
 * Integrify sends back html errors.
 */
export interface IIntegrifyParsedResponse {
  success: boolean;
  message: string;
}
