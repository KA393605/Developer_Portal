export interface IConnectionDetailsResponse {
  oAuth?: string;
  clientId?: string;
  secret?: string;
  callbackURLs?: string[];
}
