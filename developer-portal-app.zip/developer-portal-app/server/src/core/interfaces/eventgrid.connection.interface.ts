import { IAzureServicePrincipal } from './azure.serviceprincipal.interface';

interface IEventGridTopic {
  topicKey: string;
}

export interface IEventGridConnection {
  servicePrincipal?: IAzureServicePrincipal;
  topicKey?: IEventGridTopic;
}
