export interface IAppService {
  create?: (...args: any) => any;
  findAll?: (...args: any[]) => any;
  findOne?: (...args: any) => any;
  patch?: (...args: any) => any;
  remove?: (id: any) => any;
}
