import { GithubContentDTO } from '../dtos/github-content-get.dto';

export interface IGithubService {
  getGitOrgs: () => Promise<object>;
  getRepositories: () => Promise<object>;
  getOrgRepositories(org: string);
  getReadme(path: string, org?: string);
  getContent(data: GithubContentDTO);
}
