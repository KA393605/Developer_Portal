export interface IBaseRequest {
  userId: number;
}
