export interface IAuthService {
  validateUserId(userId?: string): boolean;
}
