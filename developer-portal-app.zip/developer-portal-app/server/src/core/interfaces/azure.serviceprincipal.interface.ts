export interface IAzureServicePrincipal {
  tenantId: string;
  subscriptionId: string;
  resourceGroupName: string;
  clientId: string;
  clientSecret: string;
}
