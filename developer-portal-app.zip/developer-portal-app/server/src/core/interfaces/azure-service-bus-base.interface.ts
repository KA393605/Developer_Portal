import { IEvent } from '@nestjs/cqrs/dist/interfaces/events/event.interface';
import { MessagingError, MessageHandlerOptions } from '@azure/service-bus';
import { IServiceBusSession } from './';

export interface IAzureServiceBusBase {
  connect(): void;
  disconnect(): void;
  closeReceiver(): void;
  peek(): void;
  createReceiver(sessionId?: IServiceBusSession): void;
  awaitSessionReceiver(
    brokeredMessage: any,
    sessionId: IServiceBusSession,
    messageHandlerOptions?: MessageHandlerOptions,
  ): void;
  awaitReceiver(
    brokeredMessage: any,
    sessionId?: IServiceBusSession,
    messageHandlerOptions?: MessageHandlerOptions,
  ): void;
  onMessageHandler(brokeredMessage: any): void;
  publish<T extends IEvent>(event: T, sessionId?: IServiceBusSession): void;
  getSessionState(SessionId: IServiceBusSession): any;
  bridgeEventsTo(
    messageHandler: any,
    messageHandlerOptions?: MessageHandlerOptions,
  ): void;
  onErrorHandler(err: MessagingError): void;
}
