import { IIntegrifyQuestion } from './integrify.question.interface';

export interface IIntegrifyRequest {
  isDraft: boolean;
  questions: IIntegrifyQuestion[];
}
