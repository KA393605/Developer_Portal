import { IIntegrifyQuestion } from './integrify.question.interface';
import { IIntegrifyParsedResponse } from './integrify-parsed.response';
import { IIntegrifyRequest } from './integrify.request.interface';

export interface IIntegrifyParser {
  isValidRequest: (obj: any) => boolean;
  buildQuestions: (obj: any) => IIntegrifyQuestion[];
  send: (
    obj: any,
    mudId: string,
    kongToken: string,
  ) => Promise<IIntegrifyParsedResponse>;
  _parseResponse: (res: any) => IIntegrifyParsedResponse;
  _getToken: (
    key: string,
    user: string,
    baseurl: string,
    kongToken: string,
  ) => Promise<string>;
  _sendToIntegrify: (
    key: string,
    token: string,
    body: IIntegrifyRequest,
    baseurl: string,
    kongToken: string,
  ) => Promise<any>;
  _buildRequestBody: (obj: any) => IIntegrifyRequest;
  _formatQuestion: (
    key: number,
    label: string,
    value: string,
    questiontype: string,
    domid: string,
  ) => IIntegrifyQuestion;
}
