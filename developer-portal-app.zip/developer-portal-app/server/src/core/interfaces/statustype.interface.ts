export interface IStatusType {
  statusTypeId: number;
  statusTypeName: string;
  statusTypeDescription: string;
  sequenceNumber: number;
  createTimestamp: number;
  updateTimestamp: number;
  deleteTimestamp?: number;
}
