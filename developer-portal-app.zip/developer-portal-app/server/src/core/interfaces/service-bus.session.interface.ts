export interface IServiceBusSession {
  sessionId: string;
}
