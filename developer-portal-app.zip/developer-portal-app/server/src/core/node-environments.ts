export const NODE_ENVIRONMENTS = {
  PROD: 'production',
  DEV: 'development',
};
