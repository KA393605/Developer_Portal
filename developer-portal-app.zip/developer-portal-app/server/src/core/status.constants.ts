export const STATUS_NAMES = {
  PROVISIONING: 'Provisioning',
  PROVISIONED: 'Provisioned',
  SUCCESS: 'Success',
  APPROVED: 'Approved',
  APPROVEDANDPROVISIONED: 'ApprovedAndProvisioned',
  KEYRECEIVED: 'KeysReceived',
  ACTIVE: 'Active',
  REJECTED: 'Rejected',
  DELETED: 'Deleted',
  PENDINGAPPROVAL: 'PendingApproval',
  FAILED: 'Failed',
};
