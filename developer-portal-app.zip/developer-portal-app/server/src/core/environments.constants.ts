export const ENVIRONMENTS = {
  SANDBOX: 'Sandbox',
  DEV: 'Dev',
  QA: 'QA',
  PROD: 'Prod',
};
