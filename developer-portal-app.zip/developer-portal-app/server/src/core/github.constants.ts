export const ENTERPRISE_GITHUB_API_BASE_URL =
  'https://mygithub.gsk.com/api/v3/';
export const GSK_TECH_REPOS_BASE_URL =
  ENTERPRISE_GITHUB_API_BASE_URL + 'repos/gsk-tech/';
export const GITHUB_OAUTH_TOKEN = process.env.GITHUB_OAUTH_TOKEN;
