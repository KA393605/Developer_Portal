import { Controller, Get, Query } from '@nestjs/common';
import { GithubService } from '../core/github.service';
import { GitGetTreeParams } from '@octokit/rest';

interface GetFileDTO {
  owner: string;
  repo: string;
  path: string;
  ref: string;
}

@Controller('api/help')
export class HelpController {
  constructor(private readonly githubService: GithubService) {}
  // private readonly logger: Logger = new Logger(this.constructor.name);

  @Get('/tree')
  async getFileTree(@Query() dto: GitGetTreeParams) {
    return this.githubService.getFileTree(dto);
  }

  @Get('/file')
  async getFileContents(@Query() dto: GetFileDTO) {
    return this.githubService.getFileContents(
      dto.owner,
      dto.repo,
      dto.path,
      dto.ref,
    );
  }
}
