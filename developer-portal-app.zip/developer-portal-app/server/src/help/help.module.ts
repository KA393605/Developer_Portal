import { Module } from '@nestjs/common';
import { HelpController } from './help.controller';
import { HelpService } from './help.service';
import { GithubService } from '../core/github.service';

@Module({
  controllers: [HelpController],
  providers: [HelpService, GithubService],
})
export class HelpModule {}
