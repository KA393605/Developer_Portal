export const URL =
  'https://us6-corp-platforms-developer-proxy-dev.azurewebsites.net/v1';

export const APP_HEADER_MIDDLEWARE_PATH = '/api/*';
export const AUTH_LOGIN_PATH = '/auth/ping/login';
export const AUTH_BASE_PATH = '/auth';
export const AUTH_USER_INFO_PATH = '/auth/user';
export const AUTH_BASE_PATH_EXCLUDE = '/auth/*';
export const LOGIN_PATH = '/auth/ping/login';
export const INTEGRIFY_RESPONSE_PATH = '/api/requests';
export const HEALTHCHECK_PATH = '/api/health';
