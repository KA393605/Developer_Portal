import {
  Injectable,
  Inject,
  NotFoundException,
  InternalServerErrorException,
} from '@nestjs/common';
import { ListingCreateDTO } from './dto/listing-create.dto';
import { IListingsDomainService } from './interfaces/listings-domain-service.interface';
import { IListingAssembler } from './interfaces/listing-assembler.interface';
import { IGithubService } from '../core/interfaces';
import { GithubContentDTO } from '../core/dtos/github-content-get.dto';
import {
  GITHUB_FILE_EXTENSION_ERROR,
  LISTING_OPEN_API_SPEC_SECTION_TEMPLATE_TYPE,
} from './listings.constants';
import { IListingGetByIdResponse } from './interfaces/listing-get-response.interface';
import { BaseDBService } from '../core/base.service';
import { Readable } from 'stream';

@Injectable()
export class ListingsAppService extends BaseDBService {
  constructor(
    @Inject('IListingDomainService')
    private readonly listingDomainService: IListingsDomainService,
    @Inject('ListingAssembler')
    private readonly listingAssembler: IListingAssembler,
    @Inject('GithubService')
    private readonly githubService: IGithubService,
  ) {
    super();
  }

  async findAll(
    userId: number,
    filter?: object,
    results?: number,
    pageNumber?: number,
  ) {
    return await this.executeFunction('fn_filter_listing_search', 'catalog', [
      filter,
      results,
      pageNumber,
    ]);
  }

  async findOne(id: number, userId: number): Promise<IListingGetByIdResponse> {
    if (!(await this.listingDomainService.exists(id))) {
      throw new NotFoundException();
    }
    // if (!(await this.listingUsersDomainService.findOne(id, userId))) {
    //   throw new ForbiddenException();
    // }
    const res = await this.listingDomainService.findOne(id);
    return await this.listingAssembler.buildGetByIdResponse(res);
  }

  async getOpenApiSpec(id: number, userId: string): Promise<Buffer> {
    const listing = await this.findOne(id, parseInt(userId, 10));
    const docSections = listing.extendedProperties.documentationSections;
    if (Array.isArray(docSections)) {
      const section = docSections.find(
        sec =>
          sec.sectionTemplateType ===
          LISTING_OPEN_API_SPEC_SECTION_TEMPLATE_TYPE,
      );
      if (!section) {
        throw new NotFoundException('No open api spec found');
      }

      return section.sectionContent;
    }

    throw new InternalServerErrorException('Big Problems');
  }

  public getReadableStream(buffer: Buffer): Readable {
    const stream = new Readable();

    stream.push(buffer);
    stream.push(null);

    return stream;
  }

  async getPublishedListingImage(publishedListingId: number): Promise<Buffer> {
    const base64String: string = await this.executeFunction(
      'getListingImage',
      'catalog',
      [publishedListingId],
    );
    // Remove header
    const data =
      base64String.length > 0 ? base64String.split(';base64,')[1] : '';
    const buff = Buffer.from(data, 'base64');
    return buff;
  }

  async create(data: ListingCreateDTO, userId: number) {
    const listing = this.listingAssembler.createListingFromDTO(data, userId);
    return await this.listingDomainService.create(listing);
  }

  correctFormat(str: string): boolean {
    return str === 'md' || str === 'json' || str === 'yaml' || str === 'yml';
  }

  async getGithubContent(data: GithubContentDTO) {
    const fileFormat: string = data.contentPath.split('.').pop();
    if (!this.correctFormat(fileFormat)) {
      throw new Error(GITHUB_FILE_EXTENSION_ERROR);
    } else {
      return await this.githubService.getContent(data);
    }
  }
}
