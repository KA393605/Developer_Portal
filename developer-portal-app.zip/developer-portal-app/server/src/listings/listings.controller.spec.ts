import { ListingsController } from './listings.controller';
import { IListingCreate } from './interfaces/listing-create.interface';
import { IListingsAppService } from './interfaces/listings-app-service.interface';
import { MockListingsAppService } from './mocks/listings-app-service.mock';
import { GoodListingGetByIdResponse } from './mocks/listing-get-response.mock';
import { IAuthService } from '../core/interfaces/auth-service.interface';
import { MockAuthService } from '../core/mocks/auth-service.mock';

describe('Listings Controller', () => {
  let controller: ListingsController;
  let mockService: IListingsAppService;
  let authServiceMock: IAuthService;

  const goodReq: IListingCreate = {
    extendedProperties: {},
    iconUrl: 'url.com',
    listingDescription: 'disc',
    listingName: 'name',
    listingTypeId: 1,
  };
  beforeEach(async () => {
    const Mock = jest.fn<IListingsAppService, []>(() => MockListingsAppService);
    mockService = new Mock();
    const AuthServiceMock = jest.fn<IAuthService, []>(() => MockAuthService);
    authServiceMock = new AuthServiceMock();
    controller = new ListingsController(mockService, authServiceMock);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  it('get should hit service', () => {
    controller.findListingById(1, '1');
    expect(mockService.findOne).toBeCalledTimes(1);
  });

  it('get should return value on good call', async () => {
    const res = await controller.findListingById(1, '1');
    expect(res).toEqual(GoodListingGetByIdResponse);
  });

  it('create should hit service', () => {
    controller.createListing(goodReq, '1');
    expect(mockService.create).toBeCalledTimes(1);
  });

  it('create should return value on good call', () => {
    const res = controller.createListing(goodReq, '1');
    expect(res).toEqual(goodReq);
  });

  it('should hit the github service', () => {
    controller.getGithubReadme({ repository: '', contentPath: '' });
    expect(mockService.getGithubContent).toBeCalledTimes(1);
  });

  it('github service should return content', () => {
    const res = controller.getGithubReadme({ repository: '', contentPath: '' });
    expect(res).toEqual({ repository: '', contentPath: '' });
  });
  it('should hit open api spec app service', () => {
    expect(() => controller.getListingOpenApiSpec(1, '1')).not.toThrow();
    expect(mockService.getOpenApiSpec).toBeCalledTimes(1);
  });
});
