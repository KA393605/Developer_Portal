import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';
import { IKeyword } from '../interfaces/keyword.interface';

@Entity({ name: 'Keyword' })
export class Keyword implements IKeyword {
  @PrimaryGeneratedColumn()
  keywordId: number;

  @Column()
  keywordValue: string;

  @Column()
  createTimestamp: string;

  @Column()
  updateTimestamp: string;
}
