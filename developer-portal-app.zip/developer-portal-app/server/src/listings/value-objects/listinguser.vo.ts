import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  OneToOne,
  JoinColumn,
} from 'typeorm';
import { IListingUser } from '../interfaces/listing-user.interface';
import { PublishedListing } from '../entities/publishedlisting.entity';
import { User } from '../../users/entities/user.entity';

@Entity({ name: 'UserListingRole' })
export class ListingUser implements IListingUser {
  @PrimaryGeneratedColumn()
  uniqueKey: string;

  @ManyToOne(type => PublishedListing, listing => listing.users)
  @JoinColumn({
    name: 'listingId',
    referencedColumnName: 'listingId',
  })
  listing: PublishedListing;

  @OneToOne(type => User, { eager: true })
  @JoinColumn({
    name: 'userId',
    referencedColumnName: 'userId',
  })
  user: User;

  @Column()
  roleId: number;
}
