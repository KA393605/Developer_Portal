import { IListingPostSearchRequest } from '../interfaces/listing-post-search-request.interface';
import { IsNumber, IsOptional } from 'class-validator';

export class ListingsPostSearchRequestDTO implements IListingPostSearchRequest {
  @IsOptional()
  filter?: object;
  @IsOptional()
  @IsNumber()
  resultsPerPage?: number;
  @IsOptional()
  @IsNumber()
  pageNumber?: number;
}
