import { IListingCreate } from '../interfaces/listing-create.interface';
import { IsNotEmpty, IsUrl, IsJSON } from 'class-validator';

export class ListingCreateDTO implements IListingCreate {
  @IsNotEmpty()
  listingName: string;
  @IsNotEmpty()
  listingDescription: string;
  @IsUrl()
  iconUrl: string;
  @IsJSON()
  extendedProperties: Record<string, any>;
  @IsNotEmpty()
  listingTypeId: number;
}
