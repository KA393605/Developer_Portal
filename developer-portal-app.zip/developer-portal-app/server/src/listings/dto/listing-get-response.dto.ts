import { IListingGetByIdResponse } from '../interfaces/listing-get-response.interface';
import { IListingUser } from '../interfaces/listing-user.interface';
import { IUser } from '../../users/interfaces';

export class ListingGetByIdResponse implements IListingGetByIdResponse {
  listingId: number;
  listingTypeId: number;
  listingTypeName: string;
  listingName: string;
  listingDescription: string;
  publishedBy: IUser;
  iconUrl: string;
  version: string;
  listingTeamName: string;
  listingTeamIcon: string;
  isFeaturedFlag: boolean;
  createTimestamp: string;
  keywords: string[];
  owners: IListingUser[];
  extendedProperties: Record<string, any>;
}
