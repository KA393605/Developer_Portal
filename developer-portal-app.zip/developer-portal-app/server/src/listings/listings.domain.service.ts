import { Injectable, Inject } from '@nestjs/common';
import { Connection } from 'typeorm';
import { LISTINGS_GET_FUNCTION } from './listings.constants';
import { PublishedListingRepository } from './repositories/publishedlisting.repository';
import { PublishedListing } from './entities/publishedlisting.entity';
import { Listing } from './entities/listing.entity';
import _ from 'lodash';
import {
  IListingsRepository,
  IListingsDomainService,
  IListingsSearchFilter,
} from './interfaces';
import { GithubService } from '../core/github.service';

@Injectable()
export class ListingsDomainService implements IListingsDomainService {
  constructor(
    private readonly connection: Connection,
    private readonly publishedListingRepo: PublishedListingRepository,
    @Inject('ListingsRepository')
    private listingRepo: IListingsRepository,
    private readonly githubService: GithubService,
  ) {}

  async findAll(
    userId: number,
    filter?: IListingsSearchFilter,
    results?: number,
    pageNumber?: number,
  ) {
    const res = await this.connection.query(LISTINGS_GET_FUNCTION, [
      filter || {},
      results || 100,
      pageNumber || 1,
    ]);
    return res[0].fn_filter_listing_search;
  }

  async findOne(id: number): Promise<PublishedListing> {
    const listing: PublishedListing = await this.publishedListingRepo.getListingById(
      id,
    );
    // TODO: move this to it's own method in this service, add an endpoint in controller
    if (listing.extendedProperties.githubRepo) {
      const { full_name } = listing.extendedProperties.githubRepo;
      const [owner, repo] = full_name.split('/');
      const githubTags = await this.githubService.getGithubTags(owner, repo);
      if (!githubTags) {
        listing.extendedProperties.githubRepo.releaseTags = [];
      } else {
        listing.extendedProperties.githubRepo.releaseTags = _.uniqBy(
          // match semantic versions i.e. v1.12.123, but not v1.12.123-alpha etc
          githubTags.filter(t => /^v\d+\.\d+\.\d+$/.test(t)),
          tag => {
            // check if it follows semantic versioning
            // and attempt to keep only major/minor
            const match = tag.match(/^v\d+\.\d+/);
            return match ? match[0] : tag;
          },
        );
      }
    }
    return listing;
  }

  async create(listing: Promise<Listing>) {
    return this.listingRepo.createListing(listing);
  }

  async exists(listingId: number): Promise<boolean> {
    const listingExists = await this.listingRepo.exists(listingId);
    const publishedListingExists = await this.publishedListingRepo.exists(
      listingId,
    );
    return listingExists || publishedListingExists;
  }
}
