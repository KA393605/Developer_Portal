export const LISTINGS_PATH = 'api/listings';
export const LISTINGS_GET_FUNCTION =
  'SELECT * FROM "catalog"."fn_filter_listing_search"($1, $2, $3)';
export const LISTINGS_OWNER_ROLE_ID = 1;
export const GITHUB_FILE_EXTENSION_ERROR = 'File must be of type markdown!';
export const LISTING_OPEN_API_SPEC_SECTION_TEMPLATE_TYPE = 'open-api';
