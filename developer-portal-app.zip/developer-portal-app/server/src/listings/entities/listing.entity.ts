import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  JoinColumn,
  BaseEntity,
  ManyToOne,
  OneToMany,
} from 'typeorm';
import { ListingType } from '../../types/entities/listing-type.entity';
import { IListing } from '../interfaces/listing.interface';
import { ListingUser } from '../value-objects/listinguser.vo';

@Entity({ name: 'DraftListing' })
export class Listing extends BaseEntity implements IListing {
  @PrimaryGeneratedColumn('increment')
  listingId: number;

  @PrimaryGeneratedColumn('uuid')
  uniqueKey: string;

  @ManyToOne(type => ListingType, listingType => listingType.listingTypeId)
  @JoinColumn({
    name: 'listingTypeId',
    referencedColumnName: 'listingTypeId',
  })
  listingType: Promise<ListingType>;

  @Column()
  listingName: string;

  @Column()
  listingDescription: string;

  @Column()
  iconUrl: string;

  @Column()
  lastUpdateUserId: number;

  @Column()
  createTimestamp: string;

  @Column({ type: 'json' })
  extendedProperties: Record<string, any>;

  @OneToMany(type => ListingUser, listingUser => listingUser.listing)
  users: ListingUser[];
}
