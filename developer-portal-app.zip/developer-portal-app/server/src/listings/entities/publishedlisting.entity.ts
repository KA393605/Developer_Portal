import {
  Entity,
  Column,
  JoinColumn,
  OneToOne,
  OneToMany,
  ManyToMany,
  JoinTable,
  RelationId,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { Keyword } from '../value-objects/keyword.vo';
import { IListingDetails } from '../interfaces/listing-details.interface';
import { ListingType } from '../../types/entities/listing-type.entity';
import { User } from '../../users/entities/user.entity';
import { Status } from '../../core/entities/status.entity';
import { ListingUser } from '../value-objects/listinguser.vo';

@Entity({ name: 'PublishedListing' })
export class PublishedListing implements IListingDetails {
  @PrimaryGeneratedColumn()
  listingId: number;

  @OneToOne(type => ListingType)
  @JoinColumn({
    name: 'listingTypeId',
    referencedColumnName: 'listingTypeId',
  })
  listingType: Promise<ListingType>;

  @RelationId((listing: PublishedListing) => listing.listingType)
  listingTypeId: number;

  @Column()
  listingName: string;

  @Column()
  listingDescription: string;

  @OneToOne(type => User)
  @JoinColumn({
    name: 'lastUpdateUserId',
    referencedColumnName: 'userId',
  })
  publisher: Promise<User>;

  @Column()
  iconUrl: string;

  @Column()
  lastUpdateUserId: number;

  @ManyToOne(type => Status, status => status.statusId)
  @JoinColumn({
    name: 'statusId',
    referencedColumnName: 'statusId',
  })
  status: Promise<Status>;

  @Column()
  isFeaturedFlag: boolean;

  @Column()
  createTimestamp: string;

  @ManyToMany(type => Keyword)
  @JoinTable({
    name: 'ListingKeyword',
    joinColumns: [{ name: 'listingId' }],
    inverseJoinColumns: [{ name: 'keywordId' }],
  })
  keywords: Promise<Keyword[]>;

  @OneToMany(type => ListingUser, listingUser => listingUser.listing)
  users: Promise<ListingUser[]>;

  @Column({ type: 'json' })
  extendedProperties: Record<string, any>;
}
