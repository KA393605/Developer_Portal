import { Injectable, Inject } from '@nestjs/common';
import { IListingUsersDomainService } from './interfaces/listing-users-domain-service.interface';
import { IListingUser } from './interfaces/listing-user.interface';
import { IListingUserRepository } from './interfaces/listing-user-repository.interface';

@Injectable()
export class ListingUsersDomainService implements IListingUsersDomainService {
  constructor(
    @Inject('ListingUsersRepository')
    private readonly listingUserRepository: IListingUserRepository,
  ) {}
  findOne(listingId: number, userId: number): Promise<IListingUser> {
    return this.listingUserRepository.findOne(listingId, userId);
  }
}
