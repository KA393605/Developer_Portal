import { Module } from '@nestjs/common';
import { ListingsController } from './listings.controller';
import { ListingsAppService } from './listings.app.service';
import { ListingsDomainService } from './listings.domain.service';
import { PublishedListingRepositoryProvider } from './repositories/publishedlisting.repository';
import { ListingRepositoryProvider } from './repositories/listings.repository';
import { ListingAssembler } from './assemblers/listing.assembler';
import { ListingUsersDomainService } from './listing-users.domain.service';
import { ListingUsersRepositoryProvider } from './repositories/listing-user.repository';
import { AuthService } from '../core/auth.service';
import { GithubService } from '../core/github.service';

const ListingDomainServiceProvider = {
  provide: 'IListingDomainService',
  useClass: ListingsDomainService,
};

const ListingAppServiceProvider = {
  provide: 'IListingAppService',
  useClass: ListingsAppService,
};

const ListingUsersDomainServiceProvider = {
  provide: 'ListingUsersDomainService',
  useClass: ListingUsersDomainService,
};

const ListingAssemblerProvider = {
  provide: 'ListingAssembler',
  useClass: ListingAssembler,
};

const AuthServiceProvider = {
  provide: 'AuthService',
  useClass: AuthService,
};

const GithubServiceProvider = {
  provide: 'GithubService',
  useClass: GithubService,
};

@Module({
  controllers: [ListingsController],
  providers: [
    ListingAppServiceProvider,
    ListingDomainServiceProvider,
    PublishedListingRepositoryProvider,
    ListingRepositoryProvider,
    ListingUsersDomainServiceProvider,
    ListingUsersRepositoryProvider,
    ListingAssemblerProvider,
    AuthServiceProvider,
    GithubServiceProvider,
  ],
})
export class ListingsModule {}
