import { ListingsAppService } from './listings.app.service';
import { ListingCreateDTO } from './dto/listing-create.dto';
import { MockListingAssembler } from './mocks/listing-assembler.mock';
import { IListingAssembler } from './interfaces/listing-assembler.interface';
// import { IListingUsersDomainService } from './interfaces/listing-users-domain-service.interface';
import { IListingsDomainService } from './interfaces/listings-domain-service.interface';
import { MockListingsDomainService } from './mocks/listings-domain-service.mock';
// import { MockListingUsersDomainService } from './mocks/listing-user-domain-service.mock';
import {
  GoodListingGetByIdResponse,
  GoodListingGetByIdResponseWithOpenApiSpec,
  GoodListingGetByIdResponseWithoutOpenApiSpec,
} from './mocks/listing-get-response.mock';
import { IGithubService } from '../core/interfaces';
import { MockGithubService } from '../core/mocks';
import {
  InternalServerErrorException,
  NotFoundException,
} from '@nestjs/common';

describe('Listings App Service', () => {
  let appService: ListingsAppService;
  let mockListingsDomainService: IListingsDomainService;
  let mockAssembler: IListingAssembler;
  let mockGithubService: IGithubService;
  // let mockListingUsersDomainService: IListingUsersDomainService;
  const goodReq = new ListingCreateDTO();
  beforeEach(async () => {
    const MockListingsDomainServ = jest.fn<IListingsDomainService, []>(
      () => MockListingsDomainService,
    );
    mockListingsDomainService = new MockListingsDomainServ();
    const MockAssembler = jest.fn<IListingAssembler, []>(
      () => MockListingAssembler,
    );
    mockAssembler = new MockAssembler();
    const MockGitService = jest.fn<IGithubService, []>(() => MockGithubService);
    mockGithubService = new MockGitService();
    // const MockListingUsersDomainServ = jest.fn<IListingUsersDomainService, []>(
    //   () => MockListingUsersDomainService,
    // );
    // mockListingUsersDomainService = new MockListingUsersDomainServ();
    appService = new ListingsAppService(
      mockListingsDomainService,
      mockAssembler,
      mockGithubService,
      // mockListingUsersDomainService,
    );
  });

  it('should be defined', () => {
    expect(appService).toBeDefined();
  });

  it('get should hit service', async () => {
    await appService.findOne(1, 1);
    expect(mockListingsDomainService.findOne).toBeCalledTimes(1);
  });

  it('get should return value on good call', async () => {
    const res = await appService.findOne(1, 1);
    expect(res).toEqual(GoodListingGetByIdResponse);
  });

  it('create should hit service', () => {
    appService.create(goodReq, 1);
    expect(mockListingsDomainService.create).toBeCalledTimes(1);
  });

  it('create should return value on good call', async () => {
    const res = await appService.create(goodReq, 1);
    expect(res).toEqual({});
  });

  it('open api spec should throw internal server error when there are no documentation sections', async () => {
    return expect(appService.getOpenApiSpec(1, '1')).rejects.toThrowError(
      InternalServerErrorException,
    );
  });
  it('open api spec should throw not found error when no open api spec exists', async () => {
    appService.findOne = async () =>
      GoodListingGetByIdResponseWithoutOpenApiSpec;
    return expect(appService.getOpenApiSpec(1, '1')).rejects.toThrowError(
      NotFoundException,
    );
  });
  it('open api spec should return sectionContent of open api spec doc section', async () => {
    appService.findOne = async () => GoodListingGetByIdResponseWithOpenApiSpec;
    return expect(appService.getOpenApiSpec(1, '1')).resolves.toEqual(
      'SWAGGER',
    );
  });
});
