import { AbstractRepository, EntityRepository, Connection } from 'typeorm';
import { IListingUserRepository } from '../interfaces/listing-user-repository.interface';
import { Injectable } from '@nestjs/common';
import { ListingUser } from '../value-objects/listinguser.vo';
import { IListingUser } from '../interfaces/listing-user.interface';

@Injectable()
@EntityRepository(ListingUser)
export class ListingUserRepository extends AbstractRepository<ListingUser>
  implements IListingUserRepository {
  async findOne(listingId: number, userId: number): Promise<IListingUser> {
    return await this.repository
      .createQueryBuilder()
      .where('"listingId" = :listingId', {
        listingId,
      })
      .andWhere('"userId" = :userId', {
        userId,
      })
      .andWhere('"deleteTimestamp" = null')
      .getOne();
  }
}

// Provider so that repo can be injected
export const ListingUsersRepositoryProvider = {
  provide: 'ListingUsersRepository',
  useFactory: (connection: Connection) =>
    connection.getCustomRepository(ListingUserRepository),
  inject: [Connection],
};
