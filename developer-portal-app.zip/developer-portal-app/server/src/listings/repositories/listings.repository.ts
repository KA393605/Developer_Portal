import { IListingsRepository } from '../interfaces/listings-repository.interface';
import { Listing } from '../entities/listing.entity';
import { Injectable } from '@nestjs/common';
import { EntityRepository, Connection, AbstractRepository } from 'typeorm';

@Injectable()
@EntityRepository(Listing)
export class ListingsRepository extends AbstractRepository<Listing>
  implements IListingsRepository {
  async exists(listingId: number): Promise<boolean> {
    try {
      const count = await this.repository
        .createQueryBuilder()
        .where('"listingId" = :listingId', {
          listingId,
        })
        .getCount();
      return count > 0;
    } catch (error) {
      return false;
    }
  }

  async createListing(listing: Promise<Listing>) {
    const l = await listing;
    await l.listingType;
    const res = this.repository.save(l);
    return res;
  }
}

// Provider so that repo can be injected
export const ListingRepositoryProvider = {
  provide: 'ListingsRepository',
  useFactory: (connection: Connection) =>
    connection.getCustomRepository(ListingsRepository),
  inject: [Connection],
};
