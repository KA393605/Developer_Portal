import { PublishedListing } from '../entities/publishedlisting.entity';
import { AbstractRepository, EntityRepository, Connection } from 'typeorm';
import { Injectable } from '@nestjs/common';
import { IPublishedListingRepository } from '../interfaces/published-listing-repository.interface';

@Injectable()
@EntityRepository(PublishedListing)
export class PublishedListingRepository
  extends AbstractRepository<PublishedListing>
  implements IPublishedListingRepository {
  getListingById = async (id: number): Promise<PublishedListing> => {
    return await this.repository
      .createQueryBuilder('publishedlisting')
      .leftJoinAndSelect('publishedlisting.listingType', 'listingType')
      .leftJoinAndSelect('publishedlisting.publisher', 'publisher')
      .leftJoinAndSelect('publishedlisting.status', 'status')
      .leftJoinAndSelect('publishedlisting.keywords', 'keywords')
      .leftJoinAndSelect('publishedlisting.users', 'users')
      .leftJoinAndSelect('users.user', 'user')
      .where('"publishedlisting"."listingId" = :id', {
        id,
      })
      .andWhere('"users"."deleteTimestamp" IS NULL')
      .getOne();
  };

  async exists(listingId: number): Promise<boolean> {
    try {
      const count = await this.repository
        .createQueryBuilder()
        .where('"listingId" = :listingId', {
          listingId,
        })
        .getCount();
      return count > 0;
    } catch (error) {
      return false;
    }
  }
}

// Provider so that repo can be injected
export const PublishedListingRepositoryProvider = {
  provide: 'PublishedListingRepository',
  useFactory: (connection: Connection) =>
    connection.getCustomRepository(PublishedListingRepository),
  inject: [Connection],
};
