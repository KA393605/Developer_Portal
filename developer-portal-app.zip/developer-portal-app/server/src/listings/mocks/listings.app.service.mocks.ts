import { IListingDetails } from '../interfaces/listing-details.interface';

export const mockGetListingEntity: IListingDetails = {
  listingId: 1,
  listingName: 'published listing 1',
  listingDescription: 'something disc',
  listingType: Promise.resolve({
    createTimestamp: 'asdf',
    defaultIcon: 'www.iconic.com',
    listingTemplate: {},
    listingTypeId: 1,
    listingTypeName: 'type 1',
    updateTimestamp: '0',
  }),
  publisher: Promise.resolve({
    uniqueKey: '',
    deleteTimestamp: 'foo',
    createTimestamp: 'bar',
    email: 'myemail@email.com',
    fullName: 'john snow',
    mudId: 'JS999999',
    updateTimestamp: '0',
    userId: 2,
  }),
  keywords: Promise.resolve([
    {
      keywordId: 1,
      keywordValue: 'somekeyword',
      createTimestamp: '0',
      updateTimestamp: '0',
    },
    {
      keywordId: 1,
      keywordValue: 'keyword two',
      createTimestamp: '0',
      updateTimestamp: '0',
    },
  ]),
  iconUrl: 'www.iconurl.com',
  isFeaturedFlag: true,
  createTimestamp: '2019-05-22T01:24:09.000Z',
  extendedProperties: {},
  users: Promise.resolve([
    {
      roleId: 1,
      user: {
        uniqueKey: 'asd',
        fullName: 'somename',
        mudId: 'TE000000',
        deleteTimestamp: 'foobar',
        createTimestamp: 'foo',
        email: 'some@email.com',
        updateTimestamp: 'bar',
        userId: 1,
      },
    },
  ]),
  listingTypeId: 1,
};
