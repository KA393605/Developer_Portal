import { IListingsDomainService } from '../interfaces/listings-domain-service.interface';
import { mockGetListingEntity } from './listings.app.service.mocks';

export const MockListingsDomainService: IListingsDomainService = {
  create: jest.fn(req => {
    return req;
  }),
  findOne: jest.fn((id: number) => {
    return Promise.resolve(mockGetListingEntity);
  }),
  findAll: jest.fn(req => {
    return 'Success';
  }),
  exists: jest.fn((listingId: number) => {
    return Promise.resolve(true);
  }),
};
