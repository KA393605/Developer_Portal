import { IListingGetByIdResponse } from '../interfaces/listing-get-response.interface';
import { LISTING_OPEN_API_SPEC_SECTION_TEMPLATE_TYPE } from '../listings.constants';
const goodUser = {
  user: {
    uniqueKey: 'nice-uuid',
    fullName: 'Good User',
    firstName: 'Good',
    lastName: 'User',
    mudId: 'GU042069',
    email: 'good.x.user@gsk.com',
    userId: 1,
    createTimestamp: '2019-07-31T21:45:39.728Z',
    updateTimestamp: '2019-07-31T21:45:39.728Z',
  },
  roleId: 1,
};

export const GoodListingGetByIdResponse: IListingGetByIdResponse = {
  createTimestamp: 'Good Timestamp',
  extendedProperties: {},
  iconUrl: 'http://goodurl.com/icon.png',
  isFeaturedFlag: false,
  keywords: [],
  listingDescription: 'Good Listing Description',
  listingId: 1,
  listingName: 'Good Listing Name',
  listingTypeId: 1,
  listingTypeName: 'Good Listing Type Name',
  owners: [
    {
      roleId: goodUser.roleId,
      user: { ...goodUser.user },
    },
  ],
  publishedBy: { ...goodUser.user },
  listingTeamIcon: 'Good Icon',
  listingTeamName: 'Good Team Name',
  version: '1.0.0',
};

export const GoodListingGetByIdResponseWithOpenApiSpec: IListingGetByIdResponse = {
  createTimestamp: 'Good Timestamp',
  extendedProperties: {
    documentationSections: [
      {
        sectionName: 'Endpoints',
        sectionContent: 'SWAGGER',
        sectionContentUrl: '',
        sectionTemplateType: LISTING_OPEN_API_SPEC_SECTION_TEMPLATE_TYPE,
      },
    ],
  },
  iconUrl: 'http://goodurl.com/icon.png',
  isFeaturedFlag: false,
  keywords: [],
  listingDescription: 'Good Listing Description',
  listingId: 1,
  listingName: 'Good Listing Name',
  listingTypeId: 1,
  listingTypeName: 'Good Listing Type Name',
  owners: [
    {
      roleId: goodUser.roleId,
      user: { ...goodUser.user },
    },
  ],
  publishedBy: { ...goodUser.user },
  listingTeamIcon: 'Good Icon',
  listingTeamName: 'Good Team Name',
  version: '1.0.0',
};

export const GoodListingGetByIdResponseWithoutOpenApiSpec: IListingGetByIdResponse = {
  createTimestamp: 'Good Timestamp',
  extendedProperties: {
    documentationSections: [],
  },
  iconUrl: 'http://goodurl.com/icon.png',
  isFeaturedFlag: false,
  keywords: [],
  listingDescription: 'Good Listing Description',
  listingId: 1,
  listingName: 'Good Listing Name',
  listingTypeId: 1,
  listingTypeName: 'Good Listing Type Name',
  owners: [
    {
      roleId: goodUser.roleId,
      user: { ...goodUser.user },
    },
  ],
  publishedBy: { ...goodUser.user },
  listingTeamIcon: 'Good Icon',
  listingTeamName: 'Good Team Name',
  version: '1.0.0',
};
