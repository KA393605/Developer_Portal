import { IListingAssembler } from '../interfaces/listing-assembler.interface';
import { Listing } from '../entities/listing.entity';
import { GoodListingGetByIdResponse } from './listing-get-response.mock';

export const MockListingAssembler: IListingAssembler = {
  createListingFromDTO: jest.fn(req => {
    return Promise.resolve(new Listing());
  }),
  buildGetByIdResponse: jest.fn(req => {
    return Promise.resolve(GoodListingGetByIdResponse);
  }),
};
