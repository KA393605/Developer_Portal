import { IListingUser } from '../interfaces/listing-user.interface';

export const GoodListingUser: IListingUser = {
  roleId: 1,
};
