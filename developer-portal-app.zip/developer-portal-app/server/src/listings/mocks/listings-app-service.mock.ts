import { IListingsAppService } from '../interfaces/listings-app-service.interface';
import { GoodListingGetByIdResponse } from './listing-get-response.mock';
import { Readable } from 'stream';

export const MockListingsAppService: IListingsAppService = {
  create: jest.fn(req => {
    return req;
  }),
  findOne: jest.fn(req => {
    return Promise.resolve(GoodListingGetByIdResponse);
  }),
  getGithubContent: jest.fn(req => {
    return req;
  }),
  getOpenApiSpec: jest.fn(() => {
    return Promise.resolve('SWAGGER');
  }),
  getPublishedListingImage(publishedListingId: number): Promise<Buffer> {
    return undefined;
  },
  getReadableStream(buffer: Buffer): Readable {
    return undefined;
  },
};
