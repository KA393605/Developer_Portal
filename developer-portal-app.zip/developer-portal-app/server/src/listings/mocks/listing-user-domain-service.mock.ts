import { IListingUsersDomainService } from '../interfaces/listing-users-domain-service.interface';
import { GoodListingUser } from './listing-user.mock';

export const MockListingUsersDomainService: IListingUsersDomainService = {
  findOne: jest.fn((id: number, userId: number) => {
    return Promise.resolve(GoodListingUser);
  }),
};
