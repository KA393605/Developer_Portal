import { IListingTypes } from '../../types/interfaces/listing-types.interface';

export interface IListingList {
  count: number;
  types: IListingTypes[];
}
