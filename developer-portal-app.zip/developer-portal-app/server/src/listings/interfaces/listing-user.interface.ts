import { IPublishedListing } from './published-listing.interface';
import { IUser } from '../../users/interfaces/user.interface';

export interface IListingUser {
  listing?: IPublishedListing;
  user?: IUser;
  roleId: number;
}
