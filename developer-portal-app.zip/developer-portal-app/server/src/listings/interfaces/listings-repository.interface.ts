export interface IListingsRepository {
  createListing?: (any) => any;
  exists(listingId: number): Promise<boolean>;
}
