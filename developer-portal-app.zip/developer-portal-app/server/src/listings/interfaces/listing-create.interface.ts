export class IListingCreate {
  listingName: string;
  listingDescription: string;
  iconUrl: string;
  extendedProperties: Record<string, any>;
  listingTypeId: number;
}
