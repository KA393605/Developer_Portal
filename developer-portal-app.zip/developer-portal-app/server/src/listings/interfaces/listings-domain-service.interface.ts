import { IDomainService } from '../../core/interfaces';
import { IListing } from './listing.interface';
import { IListingDetails } from './listing-details.interface';

export interface IListingsDomainService extends IDomainService {
  findAll(
    userId: number,
    filter?: object,
    results?: number,
    pageNumber?: number,
  );
  findOne(id: number): Promise<IListingDetails>;
  create(listing: Promise<IListing>);
  exists(listingId: number): Promise<boolean>;
}
