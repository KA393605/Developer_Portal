import { IAppService } from '../../core/interfaces';
import { IListingGetByIdResponse } from './listing-get-response.interface';
import { IListingCreate } from './listing-create.interface';
import { GithubContentDTO } from '../../core/dtos/github-content-get.dto';
import { Readable } from 'stream';

export interface IListingsAppService extends IAppService {
  findOne(id: number, userId: number): Promise<IListingGetByIdResponse>;
  create(data: IListingCreate, userId: number);
  getGithubContent(data: GithubContentDTO);
  getOpenApiSpec(id: number, userId: string): Promise<string>;
  getPublishedListingImage(publishedListingId: number): Promise<Buffer>;
  getReadableStream(buffer: Buffer): Readable;
}
