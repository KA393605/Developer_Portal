import { IPublishedListing } from './published-listing.interface';

export interface IPublishedListingRepository {
  getListingById: (id: number) => Promise<IPublishedListing>;
  exists(listingId: number): Promise<boolean>;
}
