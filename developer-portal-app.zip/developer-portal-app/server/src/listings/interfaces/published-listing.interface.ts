export interface IPublishedListing {
  listingId: number;
  listingName: string;
  listingDescription: string;
  listingTypeId: number;
  iconUrl: string;
  isFeaturedFlag: boolean;
  createTimestamp: string;
}
