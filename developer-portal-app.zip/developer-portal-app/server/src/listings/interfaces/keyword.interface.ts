export interface IKeyword {
  keywordId: number;
  keywordValue: string;
  createTimestamp: string;
  updateTimestamp: string;
}
