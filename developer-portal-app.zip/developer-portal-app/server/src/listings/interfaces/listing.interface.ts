import { IStatus } from '../../core/interfaces/status.interface';
import { IListingType } from '../../types/interfaces/listing-type.interface';

export interface IListing {
  listingId: number;
  listingName: string;
  listingType: Promise<IListingType>;
  listingDescription: string;
  status?: IStatus;
  iconUrl: string;
  createTimestamp: string;
  isFeaturedFlag?: boolean;
}
