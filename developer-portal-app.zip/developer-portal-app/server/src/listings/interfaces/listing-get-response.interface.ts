import { IListingUser } from './listing-user.interface';
import { IUser } from '../../users/interfaces';

export interface IListingGetByIdResponse {
  listingId: number;
  listingTypeId: number;
  listingTypeName: string;
  listingName: string;
  listingDescription: string;
  publishedBy: IUser;
  iconUrl: string;
  version: string;
  listingTeamName: string;
  listingTeamIcon: string;
  isFeaturedFlag: boolean;
  createTimestamp: string;
  keywords: string[];
  owners: IListingUser[];
  extendedProperties: Record<string, any>;
}
