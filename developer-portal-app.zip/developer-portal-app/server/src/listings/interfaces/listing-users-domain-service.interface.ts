import { IListingUser } from './listing-user.interface';

export interface IListingUsersDomainService {
  findOne(listingId: number, userId: number): Promise<IListingUser>;
}
