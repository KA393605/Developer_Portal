export interface IListingPostSearchRequest {
  filter?: IListingsSearchFilter;
  results?: number;
  pageNumber?: number;
}

export interface IListingsSearchFilter {
  isFeatured?: boolean;
  typeId?: number;
  query?: string;
}
