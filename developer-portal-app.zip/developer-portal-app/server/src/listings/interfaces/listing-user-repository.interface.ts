import { IListingUser } from './listing-user.interface';

export interface IListingUserRepository {
  findOne(listingId: number, userId: number): Promise<IListingUser>;
}
