import { IListingDetails } from './listing-details.interface';
import { IListingGetByIdResponse } from './listing-get-response.interface';
import { IListingCreate } from './listing-create.interface';
import { IListing } from './listing.interface';

export interface IListingAssembler {
  buildGetByIdResponse(
    listing: IListingDetails,
  ): Promise<IListingGetByIdResponse>;
  createListingFromDTO(DTO: IListingCreate, userId: number): Promise<IListing>;
}
