import { ListingGetByIdResponse } from '../dto/listing-get-response.dto';
import { LISTINGS_OWNER_ROLE_ID } from '../listings.constants';
import { ListingCreateDTO } from '../dto/listing-create.dto';
import { Listing } from '../entities/listing.entity';
import { ListingType } from '../../types/entities/listing-type.entity';
import { IListingDetails } from '../interfaces/listing-details.interface';
import { IListingAssembler } from '../interfaces/listing-assembler.interface';

export class ListingAssembler implements IListingAssembler {
  public buildGetByIdResponse = async (
    listing: IListingDetails,
  ): Promise<ListingGetByIdResponse> => {
    // Lazy loading needed connections
    const listingType = await listing.listingType;
    const publisher = await listing.publisher;
    const keywords = await listing.keywords;
    const users = await listing.users;

    const dto = new ListingGetByIdResponse();
    dto.listingId = listing.listingId;
    dto.listingName = listing.listingName;
    dto.listingDescription = listing.listingDescription;
    dto.iconUrl = listing.iconUrl;
    dto.listingTypeId = listing.listingTypeId;
    dto.listingTypeName = listingType.listingTypeName;
    dto.publishedBy = publisher;
    dto.isFeaturedFlag = listing.isFeaturedFlag;
    dto.createTimestamp = listing.createTimestamp;
    dto.keywords = keywords.map(e => e.keywordValue);
    dto.extendedProperties = listing.extendedProperties;
    dto.owners = users
      .filter(e => e.roleId === LISTINGS_OWNER_ROLE_ID)
      .map(listingUser => ({
        ...listingUser.user,
        roleId: listingUser.roleId,
        user: listingUser.user,
      }));
    return dto;
  };

  public async createListingFromDTO(
    DTO: ListingCreateDTO,
    userId: number,
  ): Promise<Listing> {
    const listing = new Listing();
    listing.lastUpdateUserId = userId;
    listing.iconUrl = DTO.iconUrl;
    listing.listingDescription = DTO.listingDescription;
    listing.listingName = DTO.listingName;
    listing.extendedProperties = DTO.extendedProperties;
    const listingType = await ListingType.findOne(DTO.listingTypeId);
    // using custom promise to avoid Typeorm promise issue
    listing.listingType = new Promise(resolve => {
      resolve(listingType);
    });
    return listing;
  }
}
