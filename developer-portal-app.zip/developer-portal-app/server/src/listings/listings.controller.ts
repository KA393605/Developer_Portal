import {
  Controller,
  Get,
  Post,
  Body,
  UsePipes,
  ValidationPipe,
  Param,
  Inject,
  Headers,
  BadRequestException,
  Res,
} from '@nestjs/common';
import { Response } from 'express';
import { ListingsPostSearchRequestDTO } from './dto/listings-post-search-request.dto';
import { LISTINGS_PATH } from './listings.constants';
import { ListingCreateDTO } from './dto/listing-create.dto';
import { IListingsAppService } from './interfaces/listings-app-service.interface';
import { IAuthService } from '../core/interfaces';
import { GithubContentDTO } from '../core/dtos/github-content-get.dto';
import { executeQuery } from '../core/utilities/dbPool';
import { Readable } from 'stream';

@Controller(LISTINGS_PATH)
export class ListingsController {
  constructor(
    @Inject('IListingAppService')
    private readonly listingsAppService: IListingsAppService,
    @Inject('AuthService')
    private readonly authService: IAuthService,
  ) {}

  @Post('search')
  @UsePipes(new ValidationPipe())
  findAllByUserId(
    @Body() data: ListingsPostSearchRequestDTO,
    @Headers('platforms-userid') userId?: string,
  ) {
    return this.listingsAppService.findAll(
      userId,
      data.filter,
      data.resultsPerPage,
      data.pageNumber,
    );
  }

  @Get(':id')
  @UsePipes(new ValidationPipe())
  findListingById(
    @Param('id') id: number,
    @Headers('platforms-userid') userId?: string,
  ) {
    this.authService.validateUserId(userId);
    return this.listingsAppService.findOne(id, parseInt(userId, 10));
  }

  /**
   * this route is only necessary because of a limitation in the front end
   * open api spec rendering component: https://github.com/mrin9/RapiDoc/issues/44
   */
  @Get(':id/open-api-spec')
  getListingOpenApiSpec(
    @Param('id') id: number,
    @Headers('platforms-userid') userId?: string,
  ) {
    this.authService.validateUserId(userId);
    return this.listingsAppService.getOpenApiSpec(id, userId);
  }
  /**
   *  Return Image for associated listing
   */
  @Get(':id/image')
  async getListingImage(
    @Param('id') publishedListingId: number,
    @Res() res: Response,
  ) {
    const buffer: Buffer = await this.listingsAppService.getPublishedListingImage(
      publishedListingId,
    );
    const stream: Readable = this.listingsAppService.getReadableStream(buffer);
    stream.pipe(res);
  }

  @Post()
  @UsePipes(new ValidationPipe())
  createListing(
    @Body() data: ListingCreateDTO,
    @Headers('platforms-userid') userId?: string,
  ) {
    this.authService.validateUserId(userId);
    return this.listingsAppService.create(data, parseInt(userId, 10));
  }

  @Post('docs/github')
  @UsePipes(new ValidationPipe())
  getGithubReadme(
    @Body() data: GithubContentDTO,
    @Headers('platforms-userid') userId?: string,
  ) {
    return this.listingsAppService.getGithubContent(data);
  }

  @Get(':id/environments')
  async getListingAvailableEnvironments(
    @Param('id') listingId: number,
    @Headers('platforms-userid') userId?: string,
  ) {
    const sql = `
    SELECT to_json(array_agg(json_build_object(
      'environmentName', "Environment"."environmentName", 'environmentId',
      "Environment"."environmentId",
      'serviceId', "Service"."serviceId") ORDER BY "Environment"."sequenceNumber")) environments
    FROM catalog."PublishedListing"
      JOIN catalog."Registration" ON "PublishedListing"."registrationId" = "Registration"."registrationId"
      JOIN catalog."RegistrationVersion" ON "RegistrationVersion"."registrationId" = "Registration"."registrationId"
      JOIN catalog."Service" ON "Service"."registrationVersionId" = "RegistrationVersion"."registrationVersionId"
      JOIN catalog."Environment" ON "Service"."environmentId" = "Environment"."environmentId"
    WHERE "PublishedListing"."deleteTimestamp" IS NULL
      AND UPPER("Environment"."environmentName") != 'PROD'
      AND "PublishedListing"."listingId" = $1
    GROUP BY "PublishedListing"."listingId";
    `;
    const res = await executeQuery(sql, [listingId]);
    if (res.rows.length) {
      return res.rows[0].environments;
    }

    throw new BadRequestException();
  }
}
