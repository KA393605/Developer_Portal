// config need to be loaded before all of the nestjs core
import { config } from 'dotenv';
config();

import { NestFactory } from '@nestjs/core';
import { NestExpressApplication } from '@nestjs/platform-express';
import { AppModule } from './app.module';
import { join } from 'path';
import { renderFile } from 'ejs';
import * as bodyParser from 'body-parser';
import { NODE_ENVIRONMENTS } from './core/node-environments';
import helmet from 'helmet';
import cookiesMiddleware from 'universal-cookie-express';
import compression from 'compression';
import passport from 'passport';
import express from 'express';
import { AccessLogs, ErrorLogs } from './utils/logger';

// This file needs to be fixed
// tslint:disable-next-line: no-var-requires
const expressSession = require('./auth/session');
// tslint:disable-next-line: no-var-requires

/* When doing local testing https testing uncomment and set
 * NODE_ENV to production to enable secure cookies. Also update
 * the domain in ./auth/session.ts
 */
// if (process.env.NODE_ENV === 'production') {
//   var httpsOptions = {
//     key: fs.readFileSync('../ssl/local-server.key'),
//     cert: fs.readFileSync('../ssl/local-server.crt'),
//   };
// }

function shouldCompressAPIRoutes(req, res) {
  req.headers['accept-encoding'] = req['original-accept-encoding'];
  return true;
}

async function bootstrap() {
  const app = await NestFactory.create<NestExpressApplication>(AppModule);

  app.use(cookiesMiddleware());
  app.use(bodyParser.urlencoded({ limit: '5mb', extended: true }));
  app.use(bodyParser.json({ limit: '5mb' }));

  // If this is required by compliance then someone make a code comment explaining that please.
  app.use(helmet());
  app.use(helmet.hidePoweredBy({ setTo: 'Platforms' }));
  app.use(helmet.referrerPolicy({ policy: 'same-origin' }));

  if (process.env.NODE_ENV === NODE_ENVIRONMENTS.PROD) {
    app.set('trust proxy', 1); // trust first proxy
    app.use(AccessLogs);
    app.use(ErrorLogs);
  }

  // This is middleware. It belongs in a it's own file.
  app.use(
    (
      req: express.Request,
      res: express.Response,
      next: express.NextFunction,
    ) => {
      // Store accept-encoding for compression use
      req['original-accept-encoding'] = req.headers['accept-encoding'];

      // This allows access from all origins, disabling the CORS protection.
      // This should be pulled into an environmental variable.
      res.header('Access-Control-Allow-Origin', '*');
      res.header(
        'Access-Control-Allow-Headers',
        'Origin, X-Requested-With, Content-Type, Accept',
      );
      next();
    },
  );

  app.use(expressSession);
  app.use(passport.initialize());
  app.use(passport.session());

  app.engine('html', renderFile);
  app.setBaseViewsDir(join(__dirname, '../../client/dist'));
  app.useStaticAssets(join(__dirname, '../../client/dist'), {
    index: false,
    redirect: false,
  });

  app.use(compression({ filter: shouldCompressAPIRoutes }));
  await app.listen(process.env.PORT || 3000);
}
bootstrap();
