import { Injectable } from '@nestjs/common';
import { BaseDBService } from '../core/base.service';

@Injectable()
export class EnumsService extends BaseDBService {
  async getAllEnums(): Promise<any> {
    return await this.executeFunction('get_all_enums', 'catalog', []);
  }
}
