import { Controller, Get } from '@nestjs/common';
import { EnumsService } from './enums.service';

@Controller('/api/enums')
export class EnumsController {
  constructor(private readonly enumsService: EnumsService) {}

  @Get('/')
  async getAllEnumTypes(): Promise<any> {
    return this.enumsService.getAllEnums();
  }
}
