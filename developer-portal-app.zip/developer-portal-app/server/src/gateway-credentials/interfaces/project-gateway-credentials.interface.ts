export interface IProjectGatewayCredentials {
  apiKey: string;
  clientId?: string;
  clientSecret: string;
  env?: string;
}
