import { IProjectGatewayCredentials } from '.';

export interface IGatewayCredentialsDomainService {
  getGatewayCredentials(
    clientId: string,
    environment: string,
    token: string,
  ): Promise<IProjectGatewayCredentials>;
  saveGatewayCredentials(
    gatewayCreds: IProjectGatewayCredentials,
    token: string,
  ): Promise<string>;
}
