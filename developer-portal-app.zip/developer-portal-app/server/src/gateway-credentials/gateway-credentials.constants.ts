import { ENVIRONMENTS } from '../core/environments.constants';

export const GATEWAY_CREDENTIALS_ENVIRONMENT = ENVIRONMENTS.DEV;
export const SECRET_TYPE = 'all';
export const PROJECT_CREDENTIALS_API_URL =
  process.env.PROJECT_CREDENTIALS_API_URL;
