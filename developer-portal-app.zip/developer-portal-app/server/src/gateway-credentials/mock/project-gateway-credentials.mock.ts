import { IProjectGatewayCredentials } from '../interfaces';

export const GoodProjectGatewayCredentials: IProjectGatewayCredentials = {
  apiKey: 'Good API Key',
  clientId: 'Good Client Id',
  clientSecret: 'Good Client Secret',
  env: 'Good env',
};
