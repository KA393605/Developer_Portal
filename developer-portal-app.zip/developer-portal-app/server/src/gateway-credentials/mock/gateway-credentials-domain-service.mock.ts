import { IGatewayCredentialsDomainService } from '../interfaces';
import { GoodProjectGatewayCredentials } from '.';

export const MockGatewayCredentialsDomainService: IGatewayCredentialsDomainService = {
  getGatewayCredentials: jest.fn(() =>
    Promise.resolve(GoodProjectGatewayCredentials),
  ),
  saveGatewayCredentials: jest.fn(() => Promise.resolve('Good Credentials')),
};
