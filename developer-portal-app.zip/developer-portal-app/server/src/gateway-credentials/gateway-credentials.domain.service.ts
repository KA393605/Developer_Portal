import { Injectable } from '@nestjs/common';
import {
  IGatewayCredentialsDomainService,
  IProjectGatewayCredentials,
} from './interfaces';
import {
  PROJECT_CREDENTIALS_API_URL,
  SECRET_TYPE,
} from './gateway-credentials.constants';
import axios, { AxiosResponse } from 'axios';

@Injectable()
export class GatewayCredentialsDomainService
  implements IGatewayCredentialsDomainService {
  async getGatewayCredentials(
    clientId: string,
    environment: string,
    token: string,
  ): Promise<IProjectGatewayCredentials> {
    let keyVaultResponse: AxiosResponse;
    const projectCredentialsUrl: string = PROJECT_CREDENTIALS_API_URL;

    try {
      keyVaultResponse = await axios.get(projectCredentialsUrl + environment, {
        headers: {
          Authorization: `Bearer ${token}`,
          clientId,
        },
        params: {
          secretType: SECRET_TYPE,
        },
      });
    } catch (err) {
      throw err;
    }
    return keyVaultResponse.data;
  }

  async saveGatewayCredentials(
    gatewayCreds: IProjectGatewayCredentials,
    token: string,
  ): Promise<string> {
    const projectCredentialsUrl: string = PROJECT_CREDENTIALS_API_URL;
    const body: string = JSON.stringify(gatewayCreds);
    const config = {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
    };
    let keyVaultResponse: AxiosResponse;
    try {
      keyVaultResponse = await axios.post(projectCredentialsUrl, body, config);
    } catch (err) {
      throw new Error(err.response.data.message);
    }
    const message: string = keyVaultResponse.data.message;
    return message;
  }
}
