import { IProjectGatewayCredentials } from '../interfaces';

export class GatewayCredentialsRequestDTO
  implements IProjectGatewayCredentials {
  apiKey: string;
  clientId: string;
  clientSecret: string;
  env: string;
}
