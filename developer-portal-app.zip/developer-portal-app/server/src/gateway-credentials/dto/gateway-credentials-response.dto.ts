import { IProjectGatewayCredentials } from '../interfaces';

export class GatewayCredentialsResponseDTO
  implements IProjectGatewayCredentials {
  apiKey: string;
  clientSecret: string;
}
