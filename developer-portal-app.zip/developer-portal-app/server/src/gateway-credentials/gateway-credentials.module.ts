import { Module } from '@nestjs/common';
import { GatewayCredentialsDomainService } from './gateway-credentials.domain.service';

const GatewayCredentialsDomainServiceProvider = {
  provide: 'GatewayCredentialsDomainService',
  useClass: GatewayCredentialsDomainService,
};

@Module({
  exports: [GatewayCredentialsDomainServiceProvider],
  providers: [GatewayCredentialsDomainServiceProvider],
})
export class GatewayCredentialsModule {}
