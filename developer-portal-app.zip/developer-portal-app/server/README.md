<p align="center">
  <a href="http://nestjs.com/" target="blank"><img src="https://nestjs.com/img/logo_text.svg" width="320" alt="Nest Logo" /></a>
</p>

## Description

Developer portal back end. Made with [Nest](https://nestjs.com/) and[TypeOrm](https://typeorm.io/#/).

## Installation

```bash
$ npm install
```

## Running the app

```bash
# development
$ npm run start

# watch mode
$ npm run start:dev

# debug mode
$ npm run start:debug

# production mode
$ npm run start:prod
```

## Test

```bash
# unit tests
$ npm run test

# test coverage
$ npm run test:cov
```

## Flows

### Create Project Flow

<img src="./sequence-diagrams/Create Flow.svg">

### Promote Environment Flow

<img src="./sequence-diagrams/Promote Project Environment Flow.svg">
