import axios from 'axios';
import { initializeEnvironment } from '../environment-initializer';
import {
  GoodPublishNewDraftListingVersionRequest,
  GoodAddDraftListingRequest,
} from './mocks/publish-new-draft-listing-version-mocks';

describe('Publish New Draft Listing Version', () => {
  let versionId: number;
  let listingId: number;
  let res;

  beforeAll(async () => {
    // initialize
    initializeEnvironment(axios);
    const addListingRes = await axios.post(
      axios.defaults.baseURL + '/api/publishing/draftListing/publish',
      GoodAddDraftListingRequest,
    );
    listingId = addListingRes.data;

    // Publish the draft listing version
    const url =
      axios.defaults.baseURL +
      '/api/publishing/draftListing/' +
      listingId +
      '/publishNewVersion';

    res = await axios.post(url, GoodPublishNewDraftListingVersionRequest);
    versionId = res.data;
  });

  it('Should return a good result', async () => {
    expect(versionId).toBeGreaterThanOrEqual(0);
  });

  it('should return status of 201', async () => {
    expect(res.status).toEqual(201);
  });

  it('should create something that can be retrieved with subsequent GET', async () => {
    const getUrl =
      axios.defaults.baseURL +
      '/api/publishing/draftListingVersion/' +
      versionId;
    const getRes = await axios.get(getUrl);
    expect(getRes.data.listingName).toEqual(
      GoodPublishNewDraftListingVersionRequest.listingName,
    );
  });

  afterAll(async () => {
    const deleteUrl =
      axios.defaults.baseURL + '/api/publishing/draftListing/' + listingId;
    await axios.delete(deleteUrl);
  });
});
