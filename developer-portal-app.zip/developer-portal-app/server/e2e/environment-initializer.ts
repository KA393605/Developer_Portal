import { resolve } from 'path';
import { config } from 'dotenv';

export async function initializeEnvironment(axios): Promise<boolean> {
  config({ path: resolve(__dirname, '../.env') });
  axios.defaults.baseURL = process.env.API_BASE_URL;
  axios.defaults.headers = {
    'Content-Type': process.env.API_CONTENT_TYPE,
    'platforms-userid': process.env.IGNORE_AUTH_USERID,
  };
  axios.defaults.config = {};
  return true;
}
