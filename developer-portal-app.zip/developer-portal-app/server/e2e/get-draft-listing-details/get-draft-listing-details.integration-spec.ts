import axios from 'axios';
import { initializeEnvironment } from '../environment-initializer';
import { GoodAddDraftListingRequest } from '../add-draft-listing/mocks/add-draft-listing-mocks';

describe('get draft listing details', () => {
  let listingId: number;
  let getRes;
  beforeAll(async () => {
    initializeEnvironment(axios);
    const postUrl = axios.defaults.baseURL + '/api/publishing/draftListing/';
    const postRes = await axios.post(postUrl, GoodAddDraftListingRequest);
    listingId = postRes.data;
  });

  beforeEach(async () => {
    const getUrl =
      axios.defaults.baseURL + '/api/publishing/draftListing/' + listingId;
    getRes = await axios.get(getUrl);
  });

  it('should return a good result', async () => {
    expect(getRes.data.listingName).toEqual(
      GoodAddDraftListingRequest.listingName,
    );
  });
  it('should have a status of 200', async () => {
    expect(getRes.status).toEqual(200);
  });

  describe('bad get', () => {
    it('should not be able to get a deleted listing', async () => {
      const postUrl = axios.defaults.baseURL + '/api/publishing/draftListing/';
      const postRes = await axios.post(postUrl, GoodAddDraftListingRequest);
      const delId = postRes.data;
      await axios.delete(
        axios.defaults.baseURL + '/api/publishing/draftListing/' + delId,
      );
      const getUrl =
        axios.defaults.baseURL + '/api/publishing/draftListing/' + delId;
      try {
        expect(await axios.get(getUrl)).toThrow();
      } catch (error) {
        expect(error.response.status).toEqual(400);
      }
    });
  });

  afterAll(async () => {
    await axios.delete(
      axios.defaults.baseURL + '/api/publishing/draftListing/' + listingId,
    );
  });
});
