import axios from 'axios';
import { initializeEnvironment } from '../environment-initializer';
import {
  GoodAddDraftListingRequest,
  GoodAddDraftListingVersionRequest,
} from './mocks/delete-draft-listing-version-mocks';

describe('delete draft listing version', () => {
  let listingId;
  let res;
  beforeAll(async () => {
    // Initialize
    initializeEnvironment(axios);
    const postRes = await axios.post(
      axios.defaults.baseURL + '/api/publishing/draftListing/',
      GoodAddDraftListingRequest,
    );
    listingId = postRes.data;

    // Create and delete a draft listing version
    const versionRes = await axios.post(
      axios.defaults.baseURL +
        '/api/publishing/draftListing/' +
        listingId +
        '/version',
      GoodAddDraftListingVersionRequest,
    );
    const versionId = versionRes.data;

    res = await axios.delete(
      axios.defaults.baseURL +
        '/api/publishing/draftListingVersion/' +
        versionId,
    );
  });

  it('should return a good result', () => {
    expect(res.data).toEqual(true);
  });
  it('should return status of 200', () => {
    expect(res.status).toEqual(200);
  });

  afterAll(async () => {
    await axios.delete(
      axios.defaults.baseURL + '/api/publishing/draftListing/' + listingId,
    );
  });
});
