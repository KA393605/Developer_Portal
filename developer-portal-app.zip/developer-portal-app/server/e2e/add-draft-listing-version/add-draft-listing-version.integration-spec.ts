import axios from 'axios';
import { initializeEnvironment } from '../environment-initializer';
import { GoodDraftListingVersionRequest } from './mocks/add-draft-listing-version-request.mock';

describe('Publish new DraftListing', () => {
  let res;
  beforeAll(async () => {
    initializeEnvironment(axios);
    const url =
      axios.defaults.baseURL + '/api/publishing/draftListing/1/version';
    res = await axios.post(url, GoodDraftListingVersionRequest);
  });

  it('Status code should be 201', () => {
    expect(res.status).toBe(201);
  });

  it('Response should be number greater than 0', () => {
    expect(typeof res.data).toBe('number');
    expect(res.data).toBeGreaterThan(0);
  });
});
