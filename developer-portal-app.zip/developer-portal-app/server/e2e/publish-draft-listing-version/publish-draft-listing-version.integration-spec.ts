import axios from 'axios';
import { initializeEnvironment } from '../environment-initializer';
import {
  GoodAddDraftListingRequest,
  GoodAddDraftListingVersionRequest,
  GoodPublishDraftListingVersionRequest,
} from './mocks/publish-draft-listing-version.mocks';

describe('publish draft listing', () => {
  let listingId: number;
  let versionId: number;
  let res;

  beforeAll(async () => {
    initializeEnvironment(axios);
    const addListingRes = await axios.post(
      axios.defaults.baseURL + '/api/publishing/draftListing/publish',
      GoodAddDraftListingRequest,
    );
    listingId = addListingRes.data;

    // Create draft listing version, then publish it

    const postUrl =
      axios.defaults.baseURL +
      '/api/publishing/draftListing/' +
      listingId +
      '/version';
    const draftListingVersionRes = await axios.post(
      postUrl,
      GoodAddDraftListingVersionRequest,
    );
    versionId = draftListingVersionRes.data;
    const publishUrl =
      axios.defaults.baseURL +
      '/api/publishing/draftListingVersion/' +
      versionId +
      '/publish';

    res = await axios.post(publishUrl, GoodPublishDraftListingVersionRequest);
  });

  it('should return a good result', async () => {
    expect(res.data).toBe(true);
  });
  it('should return status of 201', async () => {
    expect(res.status).toEqual(201);
  });

  describe('bad promote', async () => {
    let deleteListingId: number;
    beforeAll(async () => {
      const addListingRes = await axios.post(
        axios.defaults.baseURL + '/api/publishing/draftListing/',
        GoodAddDraftListingRequest,
      );
      deleteListingId = addListingRes.data;

      const url =
        axios.defaults.baseURL +
        '/api/publishing/draftListing/' +
        listingId +
        '/version';

      const draftListingVersionRes = await axios.post(
        url,
        GoodAddDraftListingVersionRequest,
      );
      versionId = draftListingVersionRes.data;
      await axios.delete(
        axios.defaults.baseURL +
          '/api/publishing/draftListingVersion/' +
          versionId,
      );
    });
    it('should not promote a deleted version', async () => {
      let badRes;
      try {
        const url =
          axios.defaults.baseURL + '/api/publishing/' + versionId + '/publish';
        badRes = await axios.post(url, GoodAddDraftListingRequest);
        expect(badRes).toThrow();
      } catch (error) {
        expect(error.response.status).toBe(404);
      }
      await axios.delete(
        axios.defaults.baseURL +
          '/api/publishing/draftListing/' +
          deleteListingId,
      );
    });
  });
  afterAll(async () => {
    const deleteUrl =
      axios.defaults.baseURL + '/api/publishing/draftListing/' + listingId;
    await axios.delete(deleteUrl);
  });
});
