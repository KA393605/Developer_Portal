import axios from 'axios';
import { initializeEnvironment } from '../environment-initializer';

// This test suite can and should be expanded when POSTing registrations is enabled
describe('Get Available Registration Versions', () => {
  let res;
  beforeAll(async () => {
    initializeEnvironment(axios);
    res = await axios.get(
      axios.defaults.baseURL + '/api/publishing/availableRegistrations',
    );
  });
  it('should return a good result', () => {
    expect(res.data.count).toBeGreaterThanOrEqual(0);
  });
  it('should return a status of 200', () => {
    expect(res.status).toBe(200);
  });
  it('Should only return data when there are available registrations', () => {
    if (res.data.count > 0) {
      expect(res.data.data).toBeNaN();
    } else {
      expect(res.data.data).toBeNull();
    }
  });
});
