import axios from 'axios';
import { initializeEnvironment } from '../environment-initializer';

describe('Get available registrations', () => {
  let res;

  beforeAll(async () => {
    await initializeEnvironment(axios);
    const url =
      axios.defaults.baseURL + '/api/publishing/availableRegistrations';
    res = await axios.get(url, axios.defaults);
  });

  it('response data should be array', async () => {
    expect(Array.isArray(res.data.data)).toBe(true);
  });

  it('should return status 200', () => {
    expect(res.status).toEqual(200);
  });

  it('response data should contain correct structure', () => {
    expect(typeof res.data.count).toBe('number');
    expect(typeof res.data.data[0].resourceName).toBe('string');
    expect(typeof res.data.data[0].registrationId).toBe('number');
    expect(typeof res.data.data[0].resourceDescription).toBe('string');
  });
});
