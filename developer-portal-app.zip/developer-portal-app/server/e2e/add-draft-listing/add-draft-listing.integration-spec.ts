import axios from 'axios';
import { initializeEnvironment } from '../environment-initializer';
import { GoodAddDraftListingRequest } from './mocks/add-draft-listing-mocks';

describe('add draftListing', () => {
  let listingId: number;
  let postUrl: string;
  let res;
  beforeAll(() => {
    initializeEnvironment(axios);
    postUrl = axios.defaults.baseURL + '/api/publishing/draftListing/';
  });
  beforeEach(async () => {
    res = await axios.post(postUrl, GoodAddDraftListingRequest);
    listingId = res.data;
  });
  it('should return a good result', async () => {
    expect(listingId).toBeGreaterThanOrEqual(0);
  });
  it('should return with status of 201', async () => {
    expect(res.status).toEqual(201);
  });
  it('should create something that can be returned with a subsequent get', async () => {
    const getRes = await axios.get(postUrl + listingId);
    const listing = getRes.data;
    expect(listing.listingName).toEqual(GoodAddDraftListingRequest.listingName);
  });

  afterEach(async () => {
    await axios.delete(
      axios.defaults.baseURL + '/api/publishing/draftListing/' + listingId,
    );
  });
});
