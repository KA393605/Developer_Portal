export const GoodAddDraftListingRequest = {
  listingName: 'My Listing',
  listingDescription: 'test desc',
  listingTypeId: 1,
  registrationId: 1,
  registrationVersionId: 1,
  extendedProperties: {},
  listingUsers: [
    {
      roleId: 1,
      roleName: 'owner',
      mudId: 'jat80080',
      firstName: 'Jeff',
      lastName: 'Taylor',
      fullName: 'Jeff Taylor',
      email: 'jat80080',
    },
  ],
};
