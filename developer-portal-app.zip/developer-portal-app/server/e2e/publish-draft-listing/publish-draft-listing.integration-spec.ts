import axios from 'axios';
import { initializeEnvironment } from '../environment-initializer';
import {
  GoodAddDraftListingRequest,
  GoodPublishListingRequest,
} from '../mocks/integration-test-mocks';

describe('publish draftListing', () => {
  let postRes: any;
  let listingId: number;

  beforeAll(() => {
    initializeEnvironment(axios);
  });

  // Create a draft listing to promote
  beforeEach(async () => {
    postRes = await axios.post(
      axios.defaults.baseURL + '/api/publishing/draftListing/',
      GoodAddDraftListingRequest,
    );
    listingId = postRes.data;
  });

  afterEach(async () => {
    await axios.delete(
      axios.defaults.baseURL + '/api/publishing/draftListing/' + listingId,
    );
  });

  it('should return with a status of 201', async () => {
    const publishRes = await axios.post(
      axios.defaults.baseURL +
        '/api/publishing/draftListing/' +
        listingId +
        '/publish',
      GoodPublishListingRequest,
    );
    expect(publishRes.status).toEqual(201);
  });

  it('should update draft Listing status to Published', async () => {
    await axios.post(
      axios.defaults.baseURL +
        '/api/publishing/draftListing/' +
        listingId +
        '/publish',
      GoodPublishListingRequest,
    );
    const draftListing = await axios.get(
      axios.defaults.baseURL + '/api/publishing/draftListing/' + listingId,
    );
    // Consider making this an environmental var
    expect(draftListing.data.statusId).toEqual(15);
  });

  describe('Bad promote', () => {
    let deadListing: number;
    beforeAll(async () => {
      const listingToKill = await axios.post(
        axios.defaults.baseURL + '/api/publishing/draftListing/',
        GoodAddDraftListingRequest,
      );
      deadListing = listingToKill.data;
      await axios.delete(
        axios.defaults.baseURL + '/api/publishing/draftListing/' + deadListing,
      );
    });

    it('should not promote a deleted draft listing', async () => {
      let res;
      try {
        res = await axios.post(
          axios.defaults.baseURL +
            '/api/publishing/draftListing/' +
            deadListing +
            '/publish',
          GoodPublishListingRequest,
        );
        expect(res).toThrow();
      } catch (error) {
        expect(error.response.status).toBe(500);
      }
    });
  });
});
