import axios from 'axios';
import { initializeEnvironment } from '../environment-initializer';
import { GoodAddDraftListingRequest } from '../mocks/integration-test-mocks';

describe('delete DraftListing', async () => {
  let listingId: number;
  beforeAll(() => {
    initializeEnvironment(axios);
  });
  beforeEach(async () => {
    const body = GoodAddDraftListingRequest;
    const postCall = await axios.post(
      axios.defaults.baseURL + '/api/publishing/draftListing/publish',
      body,
    );
    listingId = postCall.data;
  });

  it('should be able to delete an extant draftListing', async () => {
    let get = await axios.get(
      axios.defaults.baseURL + '/api/publishing/draftListing/' + listingId,
    );
    expect(get.data.listingId).toBeDefined();
    await axios.delete(
      axios.defaults.baseURL + '/api/publishing/draftListing/' + listingId,
    );

    try {
      get = await axios.get(
        axios.defaults.baseURL + '/api/publishing/draftListing/' + listingId,
      );
      expect(get).toThrow();
    } catch (error) {
      expect(error.response.status).toBe(400);
    }
  });
  it('should return status of 200', async () => {
    const res = await axios.delete(
      axios.defaults.baseURL + '/api/publishing/draftListing/' + listingId,
    );
    expect(res.status).toEqual(200);
  });
});
