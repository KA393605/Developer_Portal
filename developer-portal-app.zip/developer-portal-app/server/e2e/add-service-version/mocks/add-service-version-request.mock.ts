export const GoodServiceVersionRequest = {
  resourceName: 'My New Reg',
  resourceDescription: 'Desc',
  serviceProperties: {
    acl_plugin_config: 'WL_GSK_SEARCH_API',
    enabled_oidc_plugin_instead_of_keyauth: 1,
    enabled_request_xform_plugin: 0,
    kong_proxy_path: ['/tools/search'],
    kong_service_name: 'platforms_search',
    request_transformer_plugin_config_appendheader: '',
    source: './modules/service_v1',
    upstream_full_uri: 'https://us6salx00156.corpnet2.com:8443/search',
  },
};
