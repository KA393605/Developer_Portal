import axios from 'axios';
import { initializeEnvironment } from '../environment-initializer';
import { GoodServiceVersionRequest } from './mocks/add-service-version-request.mock';
const SchemaArray = [
  'statusId',
  'serviceId',
  'uniqueKey',
  'versionId',
  'createUserId',
  'resourceName',
  'environmentId',
  'createTimestamp',
  'deleteTimestamp',
  'updateTimestamp',
  'lastUpdateUserId',
  'requiresApproval',
  'serviceProperties',
  'resourceDescription',
  'projectEnvironmentId',
  'requiresNotification',
  'registrationVersionId',
];

describe('Add Service Version', () => {
  let res;
  beforeAll(async () => {
    initializeEnvironment(axios);
    const url = axios.defaults.baseURL + '/api/projects/services/1/version/1';
    res = await axios.post(url, GoodServiceVersionRequest);
  });

  it('Status code should be 201', () => {
    expect(res.status).toBe(201);
  });

  it('Response should be an object', () => {
    expect(typeof res.data).toBe('object');
  });

  describe('Response should contain correct keys', () => {
    SchemaArray.forEach(key => {
      it(`Has key ${key}`, () => {
        expect(res.data.hasOwnProperty(key)).toBe(true);
      });
    });
  });
});
