import axios from 'axios';
import { initializeEnvironment } from '../environment-initializer';

const SchemaArray = [
  'statusId',
  'versions',
  'listingId',
  'versionId',
  'statusName',
  'listingName',
  'publishDate',
  'listingUsers',
  'listingTypeId',
  'registrationId',
  'updateTimestamp',
  'currentVersionId',
  'listingVersionId',
  'extendedProperties',
  'listingDescription',
  'registrationVersionId',
];

describe('Get Draft Listing Version Details', () => {
  let res;
  beforeAll(async () => {
    initializeEnvironment(axios);
    const url =
      axios.defaults.baseURL + '/api/publishing/draftListingVersion/1';
    res = await axios.get(url);
  });

  it('Status code should be 201', () => {
    expect(res.status).toBe(200);
  });

  describe('Response should contain correct keys', () => {
    SchemaArray.forEach(key => {
      it(`Has key ${key}`, () => {
        expect(res.data.hasOwnProperty(key)).toBe(true);
      });
    });
  });
});
