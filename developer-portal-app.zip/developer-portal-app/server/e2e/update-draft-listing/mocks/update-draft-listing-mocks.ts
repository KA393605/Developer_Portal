export const GoodAddDraftListingRequest = {
  listingName: 'Update Me Please',
  listingDescription: 'updateDraftListingTest',
  listingTypeId: 1,
  registrationId: 1,
  registrationVersionId: 1,
  extendedProperties: {},
  listingUsers: [
    {
      roleId: 1,
      roleName: 'owner',
      mudId: 'jat80080',
      firstName: 'Jeff',
      lastName: 'Taylor',
      fullName: 'Jeff Taylor',
      email: 'jeffrey.x.taylor@gsk.com',
    },
  ],
};

export const GoodUpdateDraftListingRequest = {
  listingName: 'An Updated Listing',
  listingDescription: 'updateDraftListingTest',
  listingTypeId: 1,
  registrationId: 1,
  registrationVersionId: 1,
  extendedProperties: {},
  listingUsers: [
    {
      roleId: 1,
      roleName: 'owner',
      mudId: 'jat80080',
      firstName: 'Jeff',
      lastName: 'Taylor',
      fullName: 'Jeff Taylor',
      email: 'jeffrey.x.taylor@gsk.com',
    },
  ],
};
