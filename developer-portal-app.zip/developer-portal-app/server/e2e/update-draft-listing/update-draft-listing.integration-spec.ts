import axios from 'axios';
import { initializeEnvironment } from '../environment-initializer';
import {
  GoodAddDraftListingRequest,
  GoodUpdateDraftListingRequest,
} from './mocks/update-draft-listing-mocks';

describe('update draft listing', () => {
  let res;
  let listingId: number;
  beforeAll(async () => {
    initializeEnvironment(axios);
    const postRes = await axios.post(
      axios.defaults.baseURL + '/api/publishing/draftListing/',
      GoodAddDraftListingRequest,
    );
    listingId = postRes.data;
    res = await axios.put(
      axios.defaults.baseURL + '/api/publishing/draftListing/' + listingId,
      GoodUpdateDraftListingRequest,
    );
  });
  it('should return a good result', () => {
    expect(res.data).toBe(true);
  });
  it('should have a status of 200', () => {
    expect(res.status).toEqual(200);
  });
  it('should create something that can be retrieved with a subsequent get', async () => {
    const getRes = await axios.get(
      axios.defaults.baseURL + '/api/publishing/draftListing/' + listingId,
    );
    expect(getRes.data.listingName).toEqual(
      GoodUpdateDraftListingRequest.listingName,
    );
    expect(getRes.data.listingDescription).toEqual(
      GoodUpdateDraftListingRequest.listingDescription,
    );
  });

  afterAll(async () => {
    await axios.delete(
      axios.defaults.baseURL + '/api/publishing/draftListing/' + listingId,
    );
  });
});
