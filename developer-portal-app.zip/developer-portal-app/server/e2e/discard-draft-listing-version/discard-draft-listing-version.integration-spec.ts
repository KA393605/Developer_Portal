import axios from 'axios';
import {
  GoodAddDraftListingRequest,
  GoodAddDraftListingVersionRequest,
  GoodDiscardDraftListingVersionRequest,
} from './mocks/discard-draft-listing-version-mocks';
import { initializeEnvironment } from '../environment-initializer';

describe('discard draft listing version', () => {
  let listingId: number;
  let res;
  beforeAll(async () => {
    // Initialize
    initializeEnvironment(axios);
    const postRes = await axios.post(
      axios.defaults.baseURL + '/api/publishing/draftListing/',
      GoodAddDraftListingRequest,
    );
    listingId = postRes.data;

    // Create and deiscard a draft listing version
    const versionRes = await axios.post(
      axios.defaults.baseURL +
        '/api/publishing/draftListing/' +
        listingId +
        '/version',
      GoodAddDraftListingVersionRequest,
    );
    const versionId = versionRes.data;
    const postUrl =
      axios.defaults.baseURL +
      '/api/publishing/draftListingVersion/' +
      versionId +
      '/discardDraft';

    res = await axios.post(postUrl, GoodDiscardDraftListingVersionRequest);
  });

  it('should return a good result', () => {
    expect(res.data).toBe(true);
  });
  it('should return a status of 201', () => {
    expect(res.status).toBe(201);
  });

  afterAll(async () => {
    await axios.delete(
      axios.defaults.baseURL + '/api/publishing/draftListing/' + listingId,
    );
  });
});
