export const GoodDiscardDraftListingVersionRequest = {
  isDraft: false,
  questions: [
    {
      key: '1539027380382',
      label: 'Name',
      value: 'ajit natarajan',
      QuestionType: 'ShortText',
    },
    {
      key: '1539027389925',
      label: 'MUD ID',
      value: 'azn15300',
      QuestionType: 'ShortText',
    },
    {
      key: '1539027395375',
      label: 'Email',
      value: 'ajitkumar.natarajan@gsk.com',
      QuestionType: 'ShortText',
    },
    {
      key: '1539027433403',
      label: 'Business Unit',
      value: 'Corporate',
      QuestionType: 'ShortText',
    },
    {
      key: '1539027444875',
      label: 'Department',
      value: 'Tech Ops',
      QuestionType: 'ShortText',
    },
    {
      key: '1539027453175',
      label: 'Location',
      value: 'GDC',
      QuestionType: 'ShortText',
    },
    {
      key: '1540222296851',
      label: 'Which Business Unit Environment are you requesting access to?',
      value: 'Corporate',
      QuestionType: 'ShortText',
    },
    {
      key: '1540222324524',
      label:
        'Please select which area of Corporate you are most closely aligned.',
      value: 'Tech Ops',
      QuestionType: 'ShortText',
    },
    {
      key: '1539027917710',
      label: 'Product Name',
      value: 'Azure',
      QuestionType: 'ShortText',
    },
    {
      key: '1539027963998',
      label: 'Short Product Description',
      value: 'test description',
      QuestionType: 'ShortText',
    },
    {
      key: '1540222354073',
      label: 'Business Owner',
      value: 'Ajit natarajan',
      QuestionType: 'ShortText',
    },
    {
      key: '1540222362947',
      label: 'Business Owner MUD ID',
      value: 'AZN15300',
      QuestionType: 'ShortText',
    },
    {
      key: '1540222381456',
      label: 'Environment Needed',
      value: 'Sandbox',
      QuestionType: 'ShortText',
    },
    {
      key: '1540222393517',
      label: 'Team Leader(s) name',
      value: 'Myself',
      QuestionType: 'ShortText',
    },
    {
      key: '1539028483820',
      label: 'Please describe the services you plan to consume in Azure?',
      value: 'Unsure',
      QuestionType: 'ShortText',
    },
  ],
};

export const GoodAddDraftListingRequest = {
  listingName: 'My Listing',
  listingDescription: 'test desc',
  listingTypeId: 1,
  registrationId: 1,
  registrationVersionId: 1,
  extendedProperties: {},
  listingUsers: [
    {
      roleId: 1,
      roleName: 'owner',
      mudId: 'jat80080',
      firstName: 'Jeff',
      lastName: 'Taylor',
      fullName: 'Jeff Taylor',
      email: 'jat80080',
    },
  ],
};

export const GoodAddDraftListingVersionRequest = {
  listingName: 'New Listing Version',
  listingDescription: 'A version update',
  listingTypeId: 1,
  registrationId: 1,
  registrationVersionId: 1,
  extendedProperties: {
    versionprop: true,
  },
  listingUsers: [
    {
      roleId: 1,
      roleName: 'owner',
      mudId: 'jat80080',
      firstName: 'Jeff',
      lastName: 'Taylor',
      fullName: 'Jeff Taylor',
      email: 'jat80080',
    },
  ],
};
