import axios from 'axios';
import { initializeEnvironment } from '../environment-initializer';
import { GoodAddDraftListingRequest } from '../update-draft-listing/mocks/update-draft-listing-mocks';
import { GoodDiscardDraftListingRequest } from './mocks/discard-draft-listing-mocks';

describe('discard draft listing', () => {
  let listingId: number;
  let res;
  beforeAll(async () => {
    initializeEnvironment(axios);
    const postRes = await axios.post(
      axios.defaults.baseURL + '/api/publishing/draftListing/',
      GoodAddDraftListingRequest,
    );
    listingId = postRes.data;
    const discardUrl =
      axios.defaults.baseURL +
      '/api/publishing/draftListing/' +
      listingId +
      '/discardDraft';
    res = await axios.post(discardUrl, GoodDiscardDraftListingRequest);
  });
  it('should return a good result', () => {
    expect(res.data).toEqual(true);
  });

  it('should return status of 201', () => {
    expect(res.status).toEqual(201);
  });


  // This test fails, but convo with Jeff 8/26/19
  // confirmed discarded draftListings should NOT be gettable
  it('should not be gettable', async () => {
    try {
      const getRes = await axios.get(
        axios.defaults.baseURL + '/api/publishing/draftListing/' + listingId,
      );
      expect(getRes.status).toBe(500);
    } catch (error) {
      expect(error.status).toBe(500);
    }
  });
});
