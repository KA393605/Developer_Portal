import axios from 'axios';
import { initializeEnvironment } from '../environment-initializer';
import {
  GoodAddServiceRequest,
  GoodAddProjectRequest,
} from './mocks/add-service-mocks';

const SchemaArray = [
  'serviceId',
  'registrationVersionId',
  'environmentId',
  'projectEnvironmentId',
  'serviceProperties',
  'requiresApproval',
  'requiresNotification',
  'statusId',
  'createUserId',
  'createTimestamp',
  'updateTimestamp',
];

describe('Add service', () => {
  let projectId: number;
  let res;
  let serviceId;
  beforeAll(async () => {
    initializeEnvironment(axios);
    const postRes = await axios.post(
      axios.defaults.baseURL + '/api/projects/',
      GoodAddProjectRequest,
    );
    projectId = postRes.data.projectId;
    const postServiceUrl =
      axios.defaults.baseURL + '/api/projects/' + projectId + '/services';
    res = await axios.post(postServiceUrl, GoodAddServiceRequest);
    serviceId = res.data.serviceId;
  });
  it('it should have a status of 201', () => {
    expect(res.status).toBe(201);
  });
  it('Should create something gettable', async () => {
    const getUrl =
      axios.defaults.baseURL + '/api/projects/services/' + serviceId;
    const getRes = await axios.get(getUrl);
    expect(getRes.data.resourceDescription).toEqual(
      GoodAddServiceRequest.resourceDescription,
    );
    expect(getRes.data.resourceName).toEqual(
      GoodAddServiceRequest.resourceName,
    );
  });

  describe('Response should contain correct keys', () => {
    SchemaArray.forEach(key => {
      it(`Has key ${key}`, () => {
        expect(res.data.hasOwnProperty(key)).toBe(true);
      });
    });
  });

  afterAll(async () => {
    await axios.delete(axios.defaults.baseURL + '/api/projects/' + projectId);
  });
});
