import axios from 'axios';
import { initializeEnvironment } from '../environment-initializer';
import { GoodPublishNewListingRequest } from './mocks/publish-new-draft-listing-mocks';

describe('Publish new DraftListing', () => {
  let listingId: number;
  let res;
  beforeAll(async () => {
    initializeEnvironment(axios);
    const body = GoodPublishNewListingRequest;
    const url = axios.defaults.baseURL + '/api/publishing/draftListing/publish';
    res = await axios.post(url, body);
    listingId = res.data;
  });

  it('should return a good result', async () => {
    expect(listingId).toBeGreaterThanOrEqual(1);
  });

  it('should return status 201', async () => {
    expect(res.status).toEqual(201);
  });

  it('should create something that can be retrieved with a subsequent GET', async () => {
    const get = await axios.get(
      axios.defaults.baseURL + '/api/publishing/draftListing/' + listingId,
      axios.defaults,
    );
    expect(get.data.listingName).toEqual(
      GoodPublishNewListingRequest.listingName,
    );
    expect(get.data.extendedProperties).toEqual(
      GoodPublishNewListingRequest.extendedProperties,
    );
  });

  afterAll(async () => {
    const delUrl =
      axios.defaults.baseURL + '/api/publishing/draftListing/' + listingId;
    await axios.delete(delUrl);
  });
});
