import axios from 'axios';
import { initializeEnvironment } from '../environment-initializer';

const SchemaArray = [
  'statusId',
  'serviceId',
  'uniqueKey',
  'versionId',
  'createUserId',
  'resourceName',
  'environmentId',
  'createTimestamp',
  'deleteTimestamp',
  'updateTimestamp',
  'lastUpdateUserId',
  'requiresApproval',
  'serviceProperties',
  'resourceDescription',
  'projectEnvironmentId',
  'requiresNotification',
  'registrationVersionId',
];

describe('Get Service Version', () => {
  let res;
  beforeAll(async () => {
    initializeEnvironment(axios);
    const url = axios.defaults.baseURL + '/api/projects/services/1';
    res = await axios.get(url);
  });

  it('Status code should be 200', () => {
    expect(res.status).toBe(200);
  });

  describe('Response should contain correct keys', () => {
    SchemaArray.forEach(key => {
      it(`Has key ${key}`, () => {
        expect(res.data.hasOwnProperty(key)).toBe(true);
      });
    });
  });
});
