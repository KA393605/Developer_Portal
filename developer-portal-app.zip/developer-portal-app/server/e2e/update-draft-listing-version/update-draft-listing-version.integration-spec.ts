import axios from 'axios';
import { initializeEnvironment } from '../environment-initializer';
import {
  GoodAddDraftListingRequest,
  GoodAddDraftListingVersionRequest,
  GoodUpdateDraftListingVerionRequest,
} from './mocks/update-draft-listing-version-mocks';

describe('Update Draft Listing Version', () => {
  let versionId: number;
  let listingId: number;
  let res;
  beforeAll(async () => {
    initializeEnvironment(axios);
    const postUrl = axios.defaults.baseURL + '/api/publishing/draftListing/';
    const postRes = await axios.post(postUrl, GoodAddDraftListingRequest);
    listingId = postRes.data;

    const postVersionUrl =
      axios.defaults.baseURL +
      '/api/publishing/draftListing/' +
      listingId +
      '/version';

    const versionPostRes = await axios.post(
      postVersionUrl,
      GoodAddDraftListingVersionRequest,
    );
    versionId = versionPostRes.data;
    const updateUrl =
      axios.defaults.baseURL +
      '/api/publishing/draftListingVersion/' +
      versionId;
    res = await axios.put(updateUrl, GoodUpdateDraftListingVerionRequest);
  });
  it('Should return a good result', async () => {
    expect(res.data).toBe(true);
  });
  it('Should return a status of 200', async () => {
    expect(res.status).toBe(200);
  });
  it('Should create something that can be retrieved with a subsequent GET', async () => {
    const getUrl =
      axios.defaults.baseURL +
      '/api/publishing/draftListingVersion/' +
      versionId;
    res = await axios.get(getUrl);
    res = res.data;
    expect(res.listingId).toEqual(listingId);
    expect(res.listingName).toEqual(
      GoodUpdateDraftListingVerionRequest.listingName,
    );
    expect(res.listingDescription).toEqual(
      GoodUpdateDraftListingVerionRequest.listingDescription,
    );
  });
  afterAll(async () => {
    await axios.delete(
      axios.defaults.baseURL + '/api/publishing/draftListing/' + listingId,
    );
  });
});
