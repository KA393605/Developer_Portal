export const GoodUpdateDraftListingVerionRequest = {
  listingName: 'ABC Listing Version',
  listingDescription: 'A version update',
  listingTypeId: 1,
  registrationId: 1,
  registrationVersionId: 1,
  extendedProperties: {
    versionprop: true,
  },
  listingUsers: [
    {
      roleId: 1,
      roleName: 'owner',
      mudId: 'jat80080',
      firstName: 'Jeff',
      lastName: 'Taylor',
      fullName: 'Jeff Taylor',
      email: 'jat80080',
    },
  ],
};

export const GoodAddDraftListingRequest = {
  listingName: 'My Listing',
  listingDescription: 'test desc',
  listingTypeId: 1,
  registrationId: 1,
  registrationVersionId: 1,
  extendedProperties: {},
  listingUsers: [
    {
      roleId: 1,
      roleName: 'owner',
      mudId: 'jat80080',
      firstName: 'Jeff',
      lastName: 'Taylor',
      fullName: 'Jeff Taylor',
      email: 'jat80080',
    },
  ],
};

export const GoodAddDraftListingVersionRequest = {
  listingName: 'New Listing Version',
  listingDescription: 'A version update',
  listingTypeId: 1,
  registrationId: 1,
  registrationVersionId: 1,
  extendedProperties: {
    versionprop: true,
  },
  listingUsers: [
    {
      roleId: 1,
      roleName: 'owner',
      mudId: 'jat80080',
      firstName: 'Jeff',
      lastName: 'Taylor',
      fullName: 'Jeff Taylor',
      email: 'jat80080',
    },
  ],
};
