import axios from 'axios';
import { initializeEnvironment } from '../environment-initializer';

describe('Get environment details', () => {
  let res;

  const SchemaArray = ['basic', 'OAuth', 'connectedServices', 'status'];
  beforeAll(async () => {
    initializeEnvironment(axios);
    // Once something like POST environment or POST addEnvironmentToProject exist
    // this test should be modified here to create a new project/environment/projectEnvironment
    // Once that's done, use those values for the project and projectEnvironmentID instead of the hardcode
    res = await axios.get(
      axios.defaults.baseURL + '/api/projects/1/environments/1',
    );
  });
  it('Should return a status of 200', () => {
    expect(res.status).toBe(200);
  });

  describe('Response should contain correct keys', () => {
    SchemaArray.forEach(key => {
      it(`Has key ${key}`, () => {
        expect(res.data.hasOwnProperty(key)).toBe(true);
      });
    });
  });

  // If/After an add environment call is implemented, a afterAll() block should go here that would remove
  // the projet and the stood up environment
});
