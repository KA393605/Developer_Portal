# Integration Testing Strategy

## Overview

A testing strategy for the API should instill confidence that the api is built to specification, can handle expected load, and appropriately secured. This strategy will focus on a plan
to build confidence in the specification of the API. Three objectives will enable the
fulfillment of the goal:

- Validate endpoints conform to feature definition
- Validate appropriate edge cases are covered
- Provide testing feedback accessible to members of the team

### Tools: Postman

Postman provides a variety of tools that support the development of apis. One of those tools is the ability to write tests that can be ran for endpoints. These collection runs provide a means to organize, write, and run the tests locally for developers. Additionally, once these tests are written, they can be exported and committed for source control. Finally, environments with variables can be defined and exported to support running the same tests in a variety of environments. Much like environment variables with applications.

Even though the Postman tool is a UI tool, the Postman organization provides a tool called Newman that will execute tests in the commandline. This approach allows for integration with CI/CD tools. The runner will also export test results in a variety testing report formats such as junit xml files. Newman has the ability to run any test defined with the Postman UI tool and import environment configurations.

[Postman Tests](https://learning.getpostman.com/docs/postman/scripts/test_scripts/)
[Postman Collection](https://learning.getpostman.com/docs/postman/collection_runs/intro_to_collection_runs/)
[Newman Test Runner](https://learning.getpostman.com/docs/postman/collection_runs/command_line_integration_with_newman/)
[Newman with Docker](https://learning.getpostman.com/docs/postman/collection_runs/newman_with_docker/)

## Recomendations

### Accessing Endpoints

As part of the implementation, authorization, i.e. tokens, network access, etc, should be standardized so that each developer can use the same methods for getting permissions to hit endpoints. This
should be abstracted away from developers as much as possible. If the testing suite needs to hit the api to gain access, then it's important not to forget to have tests around the sequence for gaining access.

### Environment for testing

When testing, it's important to have a dedicated and sanitary environment in which to test. This will minimize the impact of non-test related processes from influencing the testing results. For example, testing in a development environment could be impacted by:

1.  New code being deployed during a testing run. A valid test run should be ran against a fixed code base.
2.  Unexpected data in the database. A dev environment could have saved state within the database that produces false positives or false negatives.
3.  Expected data is mutated in database. Similar to unexpected data in the database, data could be manipulated by processes or individuals and impact test results.

### Start with clean state

Tear down entire database, rebuild schema, load initial data, load mock data.

Just as it's best practice with unit testing to run each test independent of the previous test, integration tests should be ran such that the tests do not impact the results of each other. It's important to clarify some vocabulary, in the case of integration testing:

1.  Postman Collection represents a "feature" test, i.e. create and fetch a new resource
2.  Test represents a set of Postman tests on a particular api call, i.e. check if the response is a 200

So, to apply the unit test clean slate principle to integration tests, each Postman Collection would be ran independently of each other. However, the tests within the collection can, and probably will, be dependent on each other. For example, if the Postman Collection is testing the creation of a resource, there will likely be two api calls within the collection. The first api call will create the new resource then run some tests to validate if the request completed as expected. The second api call will attempt to fetch that newly created resource and run tests to make sure that the correct resource is returned and its properties are as expected.

## Suggested Roadmap

1. Run tests locally
   Setup the project structure and tooling so that integration tests can be ran on the local development environment. This will enable developers to validate that their code is working before ever getting a code review, or the code getting committed.

2. Implement Tests
   Getting the appropriate "test coverage" will need to include a catchup strategy and a going forward strategy. Tickets will need to be made for the implementation of the tests for existing endpoints. Prioritization can likely be made based on the expected critical nature of the endpoint. Additionally, all new endpoints going forward should have integration tests. Finally, provide appropriate documentation for how tests should be written, what tests should cover, etc.

3. Run tests manually in development environment
   Run tests locally from the production branch to validate that endpoints are working as expected. The generated test reports can be stored for record keeping and auditing.

4. Run tests in automated pipeline
   Take the repeatable process that can be ran locally into a CI/CD pipeline so that tests are ran automatically. Where and when to run these tests can be a topic of conversation and is important in terms of both development velocity and confidence. One thing to consider is that CI/CD pipeline stages should start out less production like but fast and eventually get more production like and slower. This is so that defects can be caught more quickly and earlier. Ideally those that are caught later in the pipeline are "bigger and tricker" bugs than those caught earlier.
