import {
  MigrationInterface,
  QueryRunner,
  Table,
  TableIndex,
  TableForeignKey,
} from 'typeorm';

export class AddProjectEnvironmentConnection1563213826141
  implements MigrationInterface {
  private tableName: string = 'ProjectEnvironmentConnection';
  private indexName: string = 'ProjectEnvironmentConnectionId';
  private indexColumns: string[] = ['projectEnvironmentConnectionId'];

  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.createTable(
      new Table({
        name: this.tableName,
        columns: [
          {
            name: 'uniqueKey',
            type: 'uuid',
            isPrimary: true,
            isGenerated: true,
            isNullable: false,
            default: 'uuid_generate_v4()',
          },
          {
            name: 'projectEnvironmentConnectionId',
            type: 'integer',
            isGenerated: true,
            isUnique: true,
            isNullable: false,
          },
          {
            name: 'projectEnvironmentId',
            type: 'integer',
            isNullable: false,
          },
          {
            name: 'connectionTypeId',
            type: 'integer',
            isNullable: false,
          },
          {
            name: 'connectionDetails',
            type: 'json',
            isNullable: false,
          },
          {
            name: 'statusId',
            type: 'integer',
            isNullable: false,
          },
          {
            name: 'createUserId',
            type: 'integer',
            isNullable: false,
          },
          {
            name: 'lastUpdateUserId',
            type: 'integer',
            isNullable: false,
          },
          {
            name: 'createTimestamp',
            type: 'timestamp with time zone',
            isNullable: false,
            default: 'NOW()',
          },
          {
            name: 'updateTimestamp',
            type: 'timestamp with time zone',
            isNullable: false,
            default: 'NOW()',
          },
          {
            name: 'deleteTimestamp',
            type: 'timestamp with time zone',
            isNullable: true,
          },
        ],
        foreignKeys: [
          {
            columnNames: ['projectEnvironmentId'],
            referencedColumnNames: ['projectEnvironmentId'],
            referencedTableName: 'ProjectEnvironment',
            onDelete: 'CASCADE',
            onUpdate: 'CASCADE',
          },
          {
            columnNames: ['connectionTypeId'],
            referencedColumnNames: ['connectionTypeId'],
            referencedTableName: 'ConnectionType',
            onDelete: 'RESTRICT',
            onUpdate: 'CASCADE',
          },
          {
            columnNames: ['statusId'],
            referencedColumnNames: ['statusId'],
            referencedTableName: 'Status',
            onDelete: 'RESTRICT',
            onUpdate: 'CASCADE',
          },
          {
            columnNames: ['createUserId'],
            referencedColumnNames: ['userId'],
            referencedTableName: 'User',
            onDelete: 'RESTRICT',
            onUpdate: 'RESTRICT',
          },
          {
            columnNames: ['lastUpdateUserId'],
            referencedColumnNames: ['userId'],
            referencedTableName: 'User',
            onDelete: 'RESTRICT',
            onUpdate: 'RESTRICT',
          },
        ],
      }),
      true,
      true,
      true,
    );

    await queryRunner.createIndex(
      this.tableName,
      new TableIndex({
        name: this.indexName,
        columnNames: this.indexColumns,
        isUnique: true,
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    const table: Table = await queryRunner.getTable(this.tableName);
    const foreignKeys: TableForeignKey[] = table.foreignKeys;
    await queryRunner.dropForeignKeys(this.tableName, foreignKeys);
    await queryRunner.dropIndex(this.tableName, this.indexName);
    await queryRunner.dropTable(this.tableName, true, true, true);
  }
}
