import { MigrationInterface, QueryRunner } from 'typeorm';
import * as fs from 'fs';
import * as path from 'path';

export class AddProjectMasterView1563299259495 implements MigrationInterface {
  private sqlPath: string = './views/project_master.sql';

  public async up(queryRunner: QueryRunner): Promise<any> {
    const query: string = fs.readFileSync(
      path.resolve(__dirname, this.sqlPath),
      'utf8',
    );
    await queryRunner.query(query);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP VIEW catalog.user_projects_vw`);
    await queryRunner.query(`DROP VIEW catalog.project_vw`);
  }
}
