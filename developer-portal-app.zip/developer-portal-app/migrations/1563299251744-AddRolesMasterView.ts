import { MigrationInterface, QueryRunner } from 'typeorm';
import * as fs from 'fs';
import * as path from 'path';

export class AddRolesMasterView1563299251744 implements MigrationInterface {
  private sqlPath: string = './views/roles_master.sql';

  public async up(queryRunner: QueryRunner): Promise<any> {
    const query: string = fs.readFileSync(
      path.resolve(__dirname, this.sqlPath),
      'utf8',
    );
    await queryRunner.query(query);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP VIEW catalog.role_privileges_vw`);
  }
}
