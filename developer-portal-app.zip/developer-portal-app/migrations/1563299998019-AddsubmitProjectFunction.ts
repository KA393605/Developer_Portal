import { MigrationInterface, QueryRunner } from 'typeorm';
import * as fs from 'fs';
import * as path from 'path';

export class AddsubmitProjectFunction1563299998019
  implements MigrationInterface {
  private sqlPath: string = './functions/projects/submitProject.sql';

  public async up(queryRunner: QueryRunner): Promise<any> {
    const query: string = fs.readFileSync(
      path.resolve(__dirname, this.sqlPath),
      'utf8',
    );
    await queryRunner.query(query);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP FUNCTION catalog."submitProject"`);
  }
}
