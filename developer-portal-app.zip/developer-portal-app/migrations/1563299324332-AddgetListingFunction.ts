import { MigrationInterface, QueryRunner } from 'typeorm';
import * as fs from 'fs';
import * as path from 'path';

export class AddgetListingFunction1563299324332 implements MigrationInterface {
  private sqlPath: string = './functions/listings/getListing.sql';

  public async up(queryRunner: QueryRunner): Promise<any> {
    const query: string = fs.readFileSync(
      path.resolve(__dirname, this.sqlPath),
      'utf8',
    );
    await queryRunner.query(query);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP FUNCTION catalog."getListing"`);
  }
}
