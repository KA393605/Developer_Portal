import {
  MigrationInterface,
  QueryRunner,
  Table,
  TableIndex,
  TableForeignKey,
} from 'typeorm';

export class AddRolePrivilege1563213689987 implements MigrationInterface {
  private tableName: string = 'RolePrivilege';
  private indexName: string = 'RolePrivilegeId';
  private indexColumns: string[] = ['roleId', 'privilegeId'];

  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.createTable(
      new Table({
        name: this.tableName,
        columns: [
          {
            name: 'uniqueKey',
            type: 'uuid',
            isPrimary: true,
            isGenerated: true,
            isNullable: false,
            default: 'uuid_generate_v4()',
          },
          {
            name: 'roleId',
            type: 'integer',
            isNullable: false,
          },
          {
            name: 'privilegeId',
            type: 'integer',
            isNullable: false,
          },
          {
            name: 'createTimestamp',
            type: 'timestamp with time zone',
            isNullable: false,
            default: 'NOW()',
          },
          {
            name: 'updateTimestamp',
            type: 'timestamp with time zone',
            isNullable: false,
            default: 'NOW()',
          },
          {
            name: 'deleteTimestamp',
            type: 'timestamp with time zone',
            isNullable: true,
          },
        ],
        foreignKeys: [
          {
            columnNames: ['roleId'],
            referencedColumnNames: ['roleId'],
            referencedTableName: 'Role',
            onDelete: 'CASCADE',
            onUpdate: 'CASCADE',
          },
          {
            columnNames: ['privilegeId'],
            referencedColumnNames: ['privilegeId'],
            referencedTableName: 'Privilege',
            onDelete: 'CASCADE',
            onUpdate: 'CASCADE',
          },
        ],
      }),
      true,
      true,
      true,
    );

    await queryRunner.createIndex(
      this.tableName,
      new TableIndex({
        name: this.indexName,
        columnNames: this.indexColumns,
        isUnique: true,
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    const table: Table = await queryRunner.getTable(this.tableName);
    const foreignKeys: TableForeignKey[] = table.foreignKeys;
    await queryRunner.dropForeignKeys(this.tableName, foreignKeys);
    await queryRunner.dropIndex(this.tableName, this.indexName);
    await queryRunner.dropTable(this.tableName, true, true, true);
  }
}
