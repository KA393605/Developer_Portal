CREATE VIEW catalog.listing_keywords AS (
    SELECT
        "PublishedListing"."listingId",
        "PublishedListing"."listingName",
        array_agg("Keyword"."keywordValue") AS "keywordList"
    FROM
        catalog. "PublishedListing"
    LEFT OUTER JOIN catalog. "ListingKeyword" ON "PublishedListing"."listingId" = "ListingKeyword"."listingId"
    LEFT OUTER JOIN catalog. "Keyword" ON "ListingKeyword"."keywordId" = "Keyword"."keywordId"
        AND "Keyword"."deleteTimestamp" IS NULL
WHERE
    "PublishedListing"."deleteTimestamp" IS NULL
GROUP BY
    "PublishedListing"."listingId",
    "PublishedListing"."listingName"
);

CREATE VIEW catalog.listing_master AS (
    SELECT
        "PublishedListing"."listingId",
        "ListingType"."listingTypeId",
        "ListingType"."listingTypeName",
        "PublishedListing"."listingName",
        "PublishedListing"."listingDescription",
        "PublishedListing"."isFeaturedFlag",
        "PublishedListing"."iconUrl",
        "PublishedListing"."extendedProperties",
        "Status"."statusId",
        "Status"."statusName",
        "keywordList"
    FROM
        catalog. "PublishedListing"
        JOIN catalog. "ListingType" ON "PublishedListing"."listingTypeId" = "ListingType"."listingTypeId"
        JOIN catalog. "Status" ON "PublishedListing"."statusId" = "Status"."statusId"
        LEFT OUTER JOIN catalog.listing_keywords ON "PublishedListing"."listingId" = listing_keywords. "listingId"
    WHERE
        "PublishedListing"."deleteTimestamp" IS NULL
);

CREATE OR REPLACE VIEW catalog.listing_listingtypes AS
SELECT
    row_to_json(a.*) AS row_to_json
FROM (
    SELECT
        count(t.*) AS count,
        array_to_json(array_agg(row_to_json(t.*))) AS types
    FROM (
        SELECT
            "ListingType"."sequenceNumber",
            (
                SELECT
                    count(*) AS count
                FROM
                    catalog.listing_master
                WHERE
                    listing_master. "listingTypeId" = "ListingType"."listingTypeId") AS count, (
                    SELECT
                        array_to_json(array_agg(row_to_json(l.*))) AS listings
                    FROM (
                        SELECT
                            listing_master. "listingId",
                            listing_master. "listingTypeId",
                            listing_master. "listingTypeName",
                            listing_master. "listingName",
                            listing_master. "listingDescription",
                            listing_master. "isFeaturedFlag",
                            listing_master. "iconUrl",
                            listing_master. "extendedProperties",
                            listing_master. "statusId",
                            listing_master. "statusName",
                            listing_master. "keywordList"
                        FROM
                            catalog.listing_master
                        WHERE
                            listing_master. "listingTypeId" = "ListingType"."listingTypeId") l) AS listings
                FROM
                    catalog. "ListingType") t
    GROUP BY t.count) a;

