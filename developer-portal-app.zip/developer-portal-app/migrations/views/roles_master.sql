CREATE OR REPLACE VIEW catalog.role_privileges_vw as (
SELECT
  "Role"."roleGroupId",
  "RoleGroup"."roleGroupName",
  "Role"."roleId",
  "Role"."roleName",
  array_agg("Privilege"."privilegeName") as "privilegeList"
FROM catalog."Role"
JOIN catalog."RoleGroup"
  ON "RoleGroup"."roleGroupId" = "Role"."roleGroupId"
JOIN catalog."RolePrivilege"
  ON "RolePrivilege"."roleId" = "Role"."roleId"
JOIN catalog."Privilege"
  ON "RolePrivilege"."privilegeId" = "Privilege"."privilegeId"
GROUP BY
  "Role"."roleGroupId",
  "RoleGroup"."roleGroupName",
  "Role"."roleId",
  "Role"."roleName"
);
