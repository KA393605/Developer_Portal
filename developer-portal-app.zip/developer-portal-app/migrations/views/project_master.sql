CREATE VIEW catalog.project_vw AS (
  SELECT
      "Project"."projectId",
      "Project"."projectName",
      "Project"."projectDescription",
      "Project"."airApplicationId",
      "Project"."createUserId",
      "creator"."mudId" as "creatorMudId",
      "creator"."email" as "creatorEmail",
      "creator"."firstName" as "creatorFirstName",
      "creator"."lastName" as "creatorLastName",
      "creator"."fullName" as "creatorFullName",
      "billable"."mudId" as "billableMudId",
      "billable"."email" as "billableEmail",
      "billable"."firstName" as "billableFirstName",
      "billable"."lastName" as "billableLastName",
      "billable"."fullName" as "billableFullName",
      "updated"."mudId" as "lastUpdateMudId",
      "updated"."email" as "lastUpdateEmail",
      "updated"."firstName" as "lastUpdateFirstName",
      "updated"."lastName" as "lastUpdateLastName",
      "updated"."fullName" as "lastUpdateFullName",
      "Status"."statusId",
      "Status"."statusName",
      "Project"."createTimestamp",
      "Project"."updateTimestamp"
  FROM
    catalog."Project"
    JOIN catalog."User" creator ON "Project"."createUserId" = creator."userId"
    JOIN catalog."User" billable ON "Project"."billableUserId" = billable."userId"
    JOIN catalog."User" updated ON "Project"."lastUpdateUserId" = updated."userId"
    JOIN catalog."Status" ON "Project"."statusId" = "Status"."statusId"
    WHERE "Project"."deleteTimestamp" IS NULL
);

--DROP VIEW catalog.user_projects_vw;

CREATE OR REPLACE VIEW catalog.user_projects_vw as (
  SELECT
    "UserProjectRole"."userId",
    "User"."mudId",
    "User"."email",
    "User"."firstName",
    "User"."lastName",
    "User"."fullName",
    "UserProjectRole"."roleId",
    "Role"."roleName",
    role_privileges_vw."privilegeList",
    project_vw.*
  FROM catalog."UserProjectRole"
  JOIN catalog."User" ON "UserProjectRole"."userId" = "User"."userId"
  JOIN catalog.project_vw ON project_vw."projectId" = "UserProjectRole"."projectId"
  JOIN catalog."Role" ON "UserProjectRole"."roleId" = "Role"."roleId"
  JOIN catalog.role_privileges_vw ON "UserProjectRole"."roleId" = role_privileges_vw."roleId"
)
