-- Adding a user to a project
-- Inputs:
--     projectId
--     userId
--     roleId

CREATE OR REPLACE FUNCTION "catalog"."createProjectUser"("p_data" json)
  RETURNS "pg_catalog"."json" AS $BODY$
	DECLARE
  l_out json;
	l_message_text text;
	l_exception_detail text;
	l_exception_hint text;
	-------
	l_projectUser_userId int4;
	l_projectUser_projectId int4;
	l_projectUser_roleId int4;
	BEGIN

	l_projectUser_userId:= (p_data->>'userId')::int4;
	l_projectUser_projectId:= (p_data->>'projectId')::int4;
	l_projectUser_roleId:=(p_data->>'roleId')::int4;

	INSERT INTO "catalog"."ProjectUser"

	(
	"projectId",
	"userId",
	"roleId"
	)

	VALUES
	(
	l_projectUser_projectId,
	l_projectUser_userId,
	l_projectUser_roleId
	);


	----
	l_out :=  '{"status" : "S" , "message" : "OK" , "id" : "' || lastval() || '"}';
	RETURN l_out;
	EXCEPTION WHEN OTHERS THEN
	GET STACKED DIAGNOSTICS l_message_text = MESSAGE_TEXT,
	l_exception_detail = PG_EXCEPTION_DETAIL,
	l_exception_hint = PG_EXCEPTION_HINT;
	l_out := '{ "status" : "E" , "message" : "' || REPLACE(l_message_text, '"', E'\\"') || '" }';
	return l_out;
END$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100
