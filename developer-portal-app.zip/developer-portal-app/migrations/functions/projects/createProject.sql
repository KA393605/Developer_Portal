-- FUNCTION: catalog."createProject"(json)

CREATE OR REPLACE FUNCTION catalog."createProject"(
  p_data json)
    RETURNS json
    LANGUAGE 'plpgsql'

    COST 100
    VOLATILE
AS $BODY$
  DECLARE
  l_out json;
  l_message_text text;
  l_exception_detail text;
  l_exception_hint text;
  -------
  l_project_name text;
  l_project_desc text;
  l_project_userId int4;
  l_project_billable int4;
  l_project_airApp_id text;
  BEGIN
  l_project_userId := (p_data->>'userId')::int4;
  l_project_name := (p_data->>'projectName')::text;
  l_project_desc := (p_data->>'projectDescription')::text;
  l_project_billable := (p_data->>'projectBillable')::int4;
  l_project_airApp_id := (p_data->>'projectAirAppId')::text;
  INSERT INTO "catalog"."Project"
  (
  "uniqueKey",
  "projectId",
  "projectName",
  "projectDescription",
  "publishUserId",
  "billableUserId",
  "lastUpdateUserId",
  "airApplicationId",
  "statusId",
  "createTimestamp",
  "updateTimestamp"
  )
  VALUES
  (
  DEFAULT,
  DEFAULT,
  l_project_name,
  l_project_desc,
  l_project_userId,
  l_project_billable,
  l_project_userId,
  l_project_airApp_id,
  1,
  NOW(),
  NOW()
  );
  l_out :=  '{"status" : "S" , "message" : "OK" , "id" : "' || lastval() || '"}';
  RETURN l_out;
  EXCEPTION WHEN OTHERS THEN
  GET STACKED DIAGNOSTICS l_message_text = MESSAGE_TEXT,
  l_exception_detail = PG_EXCEPTION_DETAIL,
  l_exception_hint = PG_EXCEPTION_HINT;
  l_out := '{ "status" : "E" , "message" : "' || REPLACE(l_message_text, '"', E'\\"') || '" }';
  return l_out;
END
$BODY$;
