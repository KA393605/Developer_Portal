-- Creating a new environment for a project. Pending changes to come for passing services
-- Inputs:
--     projectId
--     environmentId
--     statusId

CREATE OR REPLACE FUNCTION "catalog"."createProjectEnvironment"("p_data" json)
  RETURNS "pg_catalog"."json" AS $BODY$
	DECLARE
	l_out json;
	l_message_text text;
	l_exception_detail text;
	l_exception_hint text;
	-------
	l_projectEnvironment_projectId int4;
	l_projectEnvironment_environmentId int4;
	l_projectEnvironment_statusId int4;

	BEGIN
	l_projectEnvironment_projectId := (p_data->>'projectId')::int4;
	l_projectEnvironment_environmentId := (p_data->>'environmentId')::int4;
	l_projectEnvironment_statusId := (p_data->>'statusId')::int4;
	INSERT INTO "catalog"."ProjectEnvironment"
	(
	"projectId",
	"environmentId",
	"statusId"
	)
	VALUES
	(
	l_projectEnvironment_projectId,
	l_projectEnvironment_environmentId,
	l_projectEnvironment_statusId
	);

	l_out :=  '{"status" : "S" , "message" : "OK" , "id" : "' || lastval() || '"}';
	RETURN l_out;
	EXCEPTION WHEN OTHERS THEN
	GET STACKED DIAGNOSTICS l_message_text = MESSAGE_TEXT,
	l_exception_detail = PG_EXCEPTION_DETAIL,
	l_exception_hint = PG_EXCEPTION_HINT;
	l_out := '{ "status" : "E" , "message" : "' || REPLACE(l_message_text, '"', E'\\"') || '" }';
	return l_out;
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100
