-- Creating a new environment for a project. Pending changes to come for passing services
-- Inputs:
--     projectEnvironmentId
--     connectionTypeId
--     connectionDetails
--	   statusId

CREATE OR REPLACE FUNCTION "catalog"."createProjectConnection"("p_data" json)
  RETURNS "pg_catalog"."json" AS $BODY$
	DECLARE
  l_out json;
	l_message_text text;
	l_exception_detail text;
	l_exception_hint text;
	-------
	l_projectConnection_projectEnvironmentId int4;
	l_projectConnection_connectionTypeId int4;
	l_projectConnection_connectionDetails json;
	l_projectConnection_statusId int4;

	BEGIN
	l_projectConnection_projectEnvironmentId := (p_data->>'projectEnvironmentId')::int4;
	l_projectConnection_connectionTypeId := (p_data->>'connectionTypeId')::int4;
	l_projectConnection_connectionDetails := (p_data->>'connectionDetails')::json;
	l_projectConnection_statusId := (p_data->>'statusId')::int4;
	INSERT INTO "catalog"."ProjectConnection"
	(
	"projectEnvironmentId",
	"connectionTypeId",
	"connectionDetails",
	"statusId"
	)
	VALUES
	(
	l_projectConnection_projectEnvironmentId,
	l_projectConnection_connectionTypeId,
	l_projectConnection_connectionDetails,
	l_projectConnection_statusId
	);

	l_out :=  '{"status" : "S" , "message" : "OK" , "id" : "' || lastval() || '"}';
	RETURN l_out;
	EXCEPTION WHEN OTHERS THEN
	GET STACKED DIAGNOSTICS l_message_text = MESSAGE_TEXT,
	l_exception_detail = PG_EXCEPTION_DETAIL,
	l_exception_hint = PG_EXCEPTION_HINT;
	l_out := '{ "status" : "E" , "message" : "' || REPLACE(l_message_text, '"', E'\\"') || '" }';
	return l_out;
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100
