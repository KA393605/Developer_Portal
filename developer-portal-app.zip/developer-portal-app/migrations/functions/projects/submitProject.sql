CREATE OR REPLACE FUNCTION "catalog"."submitProject" ("p_data" json)
    RETURNS "pg_catalog"."json"
    AS $BODY$
DECLARE
    /* Parameters */
    l_project_userId text;
    l_project_name text;
    l_project_desc text;
    l_requested_service_id int4;
    /* Error handling */
    l_message_text text;
    l_exception_detail text;
    l_exception_hint text;
    /* Variables */
    l_i_add_project_req json;
    l_i_add_project_res json;
    l_i_add_project_user_req json;
    l_i_add_project_user_res json;
    l_i_add_project_environment_req json;
    l_i_add_project_environment_res json;
    l_i_add_project_connection_req json;
    l_i_add_project_connection_res json;
    l_i_add_project_service_req json;
    l_i_add_project_service_res json;
    l_project_id int4;
    l_role_id int4;
    l_environment_id int4;
    l_status_id int4;
    l_project_env_id int4;
    l_connection_type_id int4;
    l_service_environment_id int4;
    /* Defaults */
    l_role_name_default varchar;
    l_env_name_default varchar;
    l_status_name_default varchar;
    l_connection_type_name_default varchar;
    l_connection_detail json;
    /* Return variable */
    l_out json;
BEGIN
    /* Defaults */
    l_role_name_default := 'OWNER';
    l_env_name_default := 'devtest';
    l_status_name_default := 'PROVISIONING';
    l_connection_type_name_default := 'AIR';
    l_connection_detail := '{}';
    /* Parameters */
    l_project_userId := (p_data ->> 'userId')::int4;
    l_project_name := (p_data ->> 'projectName')::text;
    l_project_desc := (p_data ->> 'projectDescription')::text;
    l_requested_service_id := (p_data ->> 'requestedServiceId')::int4;

    /* Get role id */
    SELECT
        "Role"."roleId"
    FROM
        catalog. "Role"
    WHERE
        "Role"."roleName" = l_role_name_default
    INTO l_role_id;
    /* Get environment id */
    SELECT
        "Environment"."environmentId"
    FROM
        catalog. "Environment"
    WHERE
        "Environment"."environmentName" = l_env_name_default
    INTO l_environment_id;

    /* Get status id */
    SELECT
        "Status"."statusId"
    FROM
        catalog. "Status"
    WHERE
        "Status"."statusName" = l_status_name_default
    INTO l_status_id;

    /* Get connection type id */
    SELECT
        "ConnectionType"."connectionTypeId"
    FROM
        catalog. "ConnectionType"
    WHERE
        "ConnectionType"."connectionTypeName" = l_connection_type_name_default
    INTO l_connection_type_id;

    /* Add Project */
    l_i_add_project_req := '{
        "userId":"' || l_project_userId || '",
        "projectName":"' || l_project_name || '",
        "projectDescription":"' || l_project_desc || '",
        "projectBillable":"' || l_project_userId || '",
        "projectAirAppId":""}';
    SELECT
        catalog. "createProject" (l_i_add_project_req::json)
    INTO l_i_add_project_res;
    l_project_id := l_i_add_project_res ->> 'id';

    /* Create Project User */
    l_i_add_project_user_req := '{
        "userId":"' || l_project_userId || '",
        "projectId":"' || l_project_id || '",
        "roleId":"' || l_role_id || '"}';
    SELECT
        catalog. "createProjectUser" (l_i_add_project_user_req)
    INTO l_i_add_project_user_res;

    /* Create Project Environment */
    l_i_add_project_environment_req := '{
        "projectId":"' || l_project_id || '",
        "environmentId":"' || l_environment_id || '",
        "statusId":"' || l_status_id || '"}';
    SELECT
        catalog. "createProjectEnvironment" (l_i_add_project_environment_req)
    INTO l_i_add_project_environment_res;
    l_project_env_id := l_i_add_project_environment_res ->> 'id';

    /* Create Project Connection */
    l_i_add_project_connection_req := '{
        "projectEnvironmentId":"' || l_project_env_id || '",
        "connectionTypeId":"' || l_connection_type_id || '",
        "connectionDetails":"' || l_connection_detail || '",
        "statusId":"' || l_status_id || '"}';
    SELECT
        catalog. "createProjectConnection" (l_i_add_project_connection_req)
    INTO l_i_add_project_connection_res;

    /* Create Project Service */
    SELECT
        "ServiceEnvironment"."serviceEnvironmentId"
    FROM
        catalog. "ServiceEnvironment"
    WHERE
        "ServiceEnvironment"."serviceId" = l_requested_service_id
    AND "ServiceEnvironment"."environmentId" = l_environment_id
    INTO l_service_environment_id;
    l_i_add_project_service_req := '{
        "projectEnvironmentId":"' || l_project_env_id || '",
        "serviceEnvironmentId":"' || l_service_environment_id || '",
        "statusId":"' || l_status_id || '"}';
    SELECT
        catalog. "createProjectService" (l_i_add_project_service_req)
    INTO l_i_add_project_service_res;

    /* Retrieve Project */
    SELECT
        row_to_json(a.*)
    FROM (
        SELECT
            "Project"."projectId",
            "Project"."projectName",
            "Project"."projectDescription",
            "Project"."publishUserId",
            "Project"."billableUserId",
            "Project"."lastUpdateUserId",
            "Project"."airApplicationId",
            "Project"."statusId"
        FROM
            catalog. "Project"
        WHERE
            "Project"."projectId" = l_project_id) a
    INTO l_out;

    RETURN l_out;
EXCEPTION
WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS l_message_text = MESSAGE_TEXT,
    l_exception_detail = PG_EXCEPTION_DETAIL,
    l_exception_hint = PG_EXCEPTION_HINT;
l_out := '{ "status" : "E" , "message" : "' || REPLACE(l_message_text, '"', E'\\"') || '" }';
RETURN l_out;
END
$BODY$
LANGUAGE plpgsql
VOLATILE
COST 100
