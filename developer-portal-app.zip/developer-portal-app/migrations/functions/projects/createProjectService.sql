-- Attaching a service to a project environment
-- Inputs:
--     projectEnvironmentId
--     serviceEnvironmentId
--     statusId

CREATE OR REPLACE FUNCTION "catalog"."createProjectService"("p_data" json)
  RETURNS "pg_catalog"."json" AS $BODY$
	DECLARE
  l_out json;
	l_message_text text;
	l_exception_detail text;
	l_exception_hint text;
	-------
	l_projectService_projectEnvironmentId int4;
	l_projectService_serviceEnvironmentId int4;
	l_projectService_statusId int4;
	BEGIN
	l_projectService_projectEnvironmentId := (p_data->>'projectEnvironmentId')::int4;
	l_projectService_serviceEnvironmentId := (p_data->>'serviceEnvironmentId')::int4;
	l_projectService_statusId := (p_data->>'statusId')::int4;
	INSERT INTO "catalog"."ProjectService"
	(
	"projectEnvironmentId",
	"serviceEnvironmentId",
	"statusId"
	)
	VALUES
	(
	l_projectService_projectEnvironmentId,
	l_projectService_serviceEnvironmentId,
	l_projectService_statusId
	);

	l_out :=  '{"status" : "S" , "message" : "OK" , "id" : "' || lastval() || '"}';
	RETURN l_out;
	EXCEPTION WHEN OTHERS THEN
	GET STACKED DIAGNOSTICS l_message_text = MESSAGE_TEXT,
	l_exception_detail = PG_EXCEPTION_DETAIL,
	l_exception_hint = PG_EXCEPTION_HINT;
	l_out := '{ "status" : "E" , "message" : "' || REPLACE(l_message_text, '"', E'\\"') || '" }';
	return l_out;
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100
