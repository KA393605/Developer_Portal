CREATE OR REPLACE FUNCTION "catalog"."addListingUser"("p_data" json)
  RETURNS "pg_catalog"."json" AS $BODY$
	DECLARE
  l_out json;
	l_message_text text;
	l_exception_detail text;
	l_exception_hint text;
	-------
	l_listing_id int;
	l_user_id int;
	l_role_id int;
	BEGIN
	l_listing_id := (p_data->>'listingId')::int;
	l_user_id := (p_data->>'userId')::int;
	l_role_id := (p_data->>'roleId')::int;
	INSERT INTO "catalog"."ListingUser" (
		"uniqueKey",
		"listingId",
		"userId",
		"roleId",
		"createTimestamp",
		"updateTimestamp"
	)
	VALUES (
		DEFAULT,
		l_listing_id,
		l_user_id,
		l_role_id,
		NOW(),
		NOW()
	);
	l_out :=  '{"status" : "S" , "message" : "OK" , "userId" : "' || l_user_id || '" , "listingId" : "' || l_listing_id || '"}';
	RETURN l_out;
	EXCEPTION WHEN OTHERS THEN
	GET STACKED DIAGNOSTICS l_message_text = MESSAGE_TEXT,
	l_exception_detail = PG_EXCEPTION_DETAIL,
	l_exception_hint = PG_EXCEPTION_HINT;
	l_out := '{ "status" : "E" , "message" : "' || REPLACE(l_message_text, '"', E'\\"') || '" }';
	return l_out;
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100
