CREATE OR REPLACE FUNCTION "catalog"."addListing"("p_data" json)
  RETURNS "pg_catalog"."json" AS $BODY$	DECLARE
  l_out json;
	l_message_text text;
	l_exception_detail text;
	l_exception_hint text;
	-------
	l_listing_id int;
	l_listing_type_id int;
	l_name text;
	l_short_description text;
	l_listing_status text;
	l_publisher_id int;
	l_icon_url text;
	l_extended_properties json;
	l_user_role_return json;
	-------
	l_user_listing_request json;
	l_user_listing_result json;
	BEGIN
	l_listing_type_id := (p_data->>'listingTypeId')::int;
	l_name := (p_data->>'listingName')::text;
	l_short_description := (p_data->>'shortDescription')::text;
	l_publisher_id := (p_data->>'publisherUserId')::int;
	l_icon_url := (p_data->>'iconUrl')::text;
	l_extended_properties := (p_data->>'extendedProperties')::json;
	-- Insert listing record into database
	INSERT INTO "catalog"."Listing" (
		"uniqueKey",
		"listingId",
		"listingTypeId",
		"name",
		"shortDescription",
		"publisherUserId",
		"iconUrl",
		"statusId",
		"isFeatured",
		"extendedProperties",
		"createTimestamp",
		"updateTimestamp"
	)
	VALUES (
		DEFAULT,
		DEFAULT,
		l_listing_type_id,
		l_name,
		l_short_description,
		l_publisher_id,
		l_icon_url,
		1, --statusId
		false, --isFeatured
		l_extended_properties,
		NOW(),
		NOW()
	)
	RETURNING "listingId" INTO l_listing_id;
	-- Assign publisher of listing as Owner
	l_user_listing_request := '{"userId":"' || l_publisher_id || '","listingId":"' || l_listing_id || '","roleId":"1"}';
	SELECT catalog."addListingUser"(l_user_listing_request) INTO l_user_listing_result;
	l_out :=  '{"status" : "S" , "message" : "OK" , "id" : "' || l_listing_id || '"}';
	RETURN l_out;
	EXCEPTION WHEN OTHERS THEN
	GET STACKED DIAGNOSTICS l_message_text = MESSAGE_TEXT,
	l_exception_detail = PG_EXCEPTION_DETAIL,
	l_exception_hint = PG_EXCEPTION_HINT;
	l_out := '{ "status" : "E" , "message" : "' || REPLACE(l_message_text, '"', E'\\"') || '" }';
	return l_out;
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100
