-- FUNCTION: catalog."getListing"(integer, json, integer, integer)
DROP FUNCTION IF EXISTS catalog. "getListing" (integer, json, integer, integer);

CREATE OR REPLACE FUNCTION catalog. "getListing" (id integer, FILTER json DEFAULT '{}' ::json, results integer DEFAULT 100, page integer DEFAULT 1)
    RETURNS json
    LANGUAGE 'plpgsql'
    COST 100 VOLATILE
    AS $BODY$
DECLARE
    l_out json;
    l_message_text text;
    l_exception_detail text;
    l_exception_hint text;
    l_filter_keys text[];
    l_filter_key text;
    l_filter_value text;
    l_filter_sql varchar;
    l_filter_offset integer;
BEGIN
    l_filter_sql := '';
    l_filter_offset := (page * results) - results;
    /* Populate l_filter_keys */
    SELECT
        (ARRAY (
                SELECT
                    json_object_keys(FILTER))) AS keys INTO l_filter_keys;
    /* Loop through and build filter string */
    FOREACH l_filter_key IN ARRAY l_filter_keys LOOP
        l_filter_value := (FILTER ->> l_filter_key)::text;
        l_filter_sql := ' AND ul.' || l_filter_key || ' LIKE ''%' || l_filter_value || '%''';
    END LOOP;
    /* Get Listings as JSON */
    EXECUTE FORMAT('
 	SELECT
 		row_to_json(a.*) AS row_to_json
 	FROM
 		(SELECT
 			COALESCE(sum(t.count),0) AS count,
 			COALESCE(array_to_json(array_agg(row_to_json(t.*))),''[]'') AS types
 		FROM
 			(SELECT
 				"ListingType"."sequenceNumber",
                 (SELECT
                     count(*)
                 FROM (
                     SELECT
                         *
                     FROM catalog."getUserListings"($1)) as ul
                 WHERE ul.listingTypeId = "ListingType"."listingTypeId"
                 %s),
 				(SELECT
 					array_agg(row_to_json(l.*)) listings
 				FROM
                     (SELECT * FROM
                         (SELECT
                             listingId,
                             listingTypeId,
                             listingTypeName,
                             listingName,
                             listingDescription,
                             isFeaturedFlag,
                             iconUrl,
                             extendedProperties,
                             statusId,
                             statusName,
                             keywordList
                         FROM catalog."getUserListings"($1)) ul
 					WHERE ul.listingTypeId = "ListingType"."listingTypeId"
 					%s
                     LIMIT $2 OFFSET $3) l
 				)
 			FROM catalog."ListingType"
 		) t
         WHERE count > 0
 	) a;', l_filter_sql, l_filter_sql)
    USING id,
    results,
    l_filter_offset INTO l_out;
    RETURN l_out;
EXCEPTION
WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS l_message_text = MESSAGE_TEXT,
    l_exception_detail = PG_EXCEPTION_DETAIL,
    l_exception_hint = PG_EXCEPTION_HINT;
l_out := '{ "status" : "E" , "message" : "' || REPLACE(l_message_text, '"', E'\\"') || '" }';
RETURN l_out;
END;
$BODY$;

