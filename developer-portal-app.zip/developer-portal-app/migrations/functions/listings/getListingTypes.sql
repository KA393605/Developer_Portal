-- A function to get the listing types available to perform a filter on
-- returns

CREATE OR REPLACE FUNCTION catalog."getListingTypes"()
  RETURNS TABLE(
	"dataOut" "pg_catalog"."json"
  ) AS $BODY$
	BEGIN
	RETURN QUERY
	SELECT row_to_json(dataOut)
	FROM (
		SELECT count(*), (
			select array_to_json(array_agg(row_to_json(ret)))
			from (
				SELECT
				lt."listingTypeId",
				lt."listingTypeName",
				lt."defaultIcon"
				FROM catalog."ListingType" as lt
				WHERE "deleteTimestamp" IS NULL
			) ret
		) listingTypes
		FROM catalog."ListingType"
		WHERE "deleteTimestamp" IS NULL
	) dataOut;
END;$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100
  ROWS 1000
