DROP FUNCTION IF EXISTS catalog. "getUserListings" (integer);

CREATE OR REPLACE FUNCTION "catalog"."getUserListings" (id integer)
    RETURNS TABLE (
        listingId int,
        listingTypeId int,
        listingTypeName varchar,
        listingName varchar,
        listingDescription varchar,
        isFeaturedFlag boolean,
        iconUrl text,
        extendedProperties json,
        statusId int,
        statusName varchar,
        keywordList varchar[])
    AS $$
BEGIN
    RETURN QUERY
    SELECT
        "listing_master"."listingId",
        "listing_master"."listingTypeId",
        "listing_master"."listingTypeName",
        "listing_master"."listingName",
        "listing_master"."listingDescription",
        "listing_master"."isFeaturedFlag",
        "listing_master"."iconUrl",
        "listing_master"."extendedProperties",
        "listing_master"."statusId",
        "listing_master"."statusName",
        "listing_master"."keywordList"
    FROM
        catalog.listing_master
    LEFT OUTER JOIN catalog. "ListingUser" ON "listing_master"."listingId" = "ListingUser"."listingId"
WHERE
    "ListingUser"."userId" = $1;
END;
$$
LANGUAGE 'plpgsql';

