CREATE OR REPLACE FUNCTION "catalog"."addUser"("p_data" json)
  RETURNS "pg_catalog"."json" AS $BODY$
	DECLARE
  l_out json;
	l_message_text text;
	l_exception_detail text;
	l_exception_hint text;
	-------
	l_mud_id text;
	l_email text;
	BEGIN
	l_mud_id := (p_data->>'mudId')::text;
	l_email := (p_data->>'email')::text;
	INSERT INTO "catalog"."User"
	(
	"uniqueKey",
	"userId",
	"mudId",
	"email",
	"createTimestamp",
	"updateTimestamp"
	)
	VALUES
	(
	DEFAULT,
	DEFAULT,
	l_mud_id,
	l_email,
	true,
	NOW(),
	NOW()
	);
	l_out :=  '{"status" : "S" , "message" : "OK" , "id" : "' || l_mud_id || '"}';
	RETURN l_out;
	EXCEPTION WHEN OTHERS THEN
	GET STACKED DIAGNOSTICS l_message_text = MESSAGE_TEXT,
	l_exception_detail = PG_EXCEPTION_DETAIL,
	l_exception_hint = PG_EXCEPTION_HINT;
	l_out := '{ "status" : "E" , "message" : "' || REPLACE(l_message_text, '"', E'\\"') || '" }';
	return l_out;
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100
