import { MigrationInterface, QueryRunner, Table, TableIndex } from 'typeorm';

export class AddRoleGroup1563213600702 implements MigrationInterface {
  private tableName: string = 'RoleGroup';
  private indexName: string = 'roleGroupId';
  private indexColumns: string[] = ['roleGroupId'];

  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.createTable(
      new Table({
        name: this.tableName,
        columns: [
          {
            name: 'uniqueKey',
            type: 'uuid',
            isPrimary: true,
            isGenerated: true,
            isNullable: false,
            default: 'uuid_generate_v4()',
          },
          {
            name: 'roleGroupId',
            type: 'integer',
            isGenerated: true,
            isUnique: true,
            isNullable: false,
          },
          {
            name: 'roleGroupName',
            type: 'character varying',
            length: '50',
            isNullable: false,
          },
          {
            name: 'roleGroupDescription',
            type: 'character varying',
            length: '255',
            isNullable: false,
          },
          {
            name: 'createTimestamp',
            type: 'timestamp with time zone',
            isNullable: false,
            default: 'NOW()',
          },
          {
            name: 'updateTimestamp',
            type: 'timestamp with time zone',
            isNullable: false,
            default: 'NOW()',
          },
          {
            name: 'deleteTimestamp',
            type: 'timestamp with time zone',
            isNullable: true,
          },
        ],
      }),
      true,
      true,
      true,
    );

    await queryRunner.createIndex(
      this.tableName,
      new TableIndex({
        name: this.indexName,
        columnNames: this.indexColumns,
        isUnique: true,
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.dropIndex(this.tableName, this.indexName);
    await queryRunner.dropTable(this.tableName, true, true, true);
  }
}
