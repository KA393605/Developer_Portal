import {
  MigrationInterface,
  QueryRunner,
  Table,
  TableIndex,
  TableForeignKey,
} from 'typeorm';

export class AddIntegrifyRequest1563213880786 implements MigrationInterface {
  private tableName: string = 'IntegrifyRequest';
  private indexName: string = 'IntegrifyRequestId';
  private indexColumns: string[] = ['requestId'];

  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.createTable(
      new Table({
        name: 'IntegrifyRequest',
        columns: [
          {
            name: 'id',
            type: 'uuid',
            isPrimary: true,
            isGenerated: true,
            isNullable: false,
            default: 'uuid_generate_v4()',
          },
          {
            name: 'requestId',
            type: 'character varying',
          },
          {
            name: 'projectEnvironmentServiceId',
            type: 'integer',
            isNullable: false,
          },
          {
            name: 'statusId',
            type: 'integer',
            isNullable: false,
          },
          {
            name: 'createUserId',
            type: 'integer',
            isNullable: false,
          },
          {
            name: 'createTimestamp',
            type: 'timestamp with time zone',
            isNullable: false,
            default: 'NOW()',
          },
          {
            name: 'updateTimestamp',
            type: 'timestamp with time zone',
            isNullable: false,
            default: 'NOW()',
          },
        ],
        foreignKeys: [
          {
            columnNames: ['projectEnvironmentServiceId'],
            referencedColumnNames: ['projectEnvironmentServiceId'],
            referencedTableName: 'ProjectEnvironmentService',
            onDelete: 'RESTRICT',
            onUpdate: 'CASCADE',
          },
          {
            columnNames: ['statusId'],
            referencedColumnNames: ['statusId'],
            referencedTableName: 'Status',
            onDelete: 'RESTRICT',
            onUpdate: 'CASCADE',
          },
          {
            columnNames: ['createUserId'],
            referencedColumnNames: ['userId'],
            referencedTableName: 'User',
            onDelete: 'RESTRICT',
            onUpdate: 'RESTRICT',
          },
        ],
      }),
      true,
      true,
      true,
    );

    await queryRunner.createIndex(
      this.tableName,
      new TableIndex({
        name: this.indexName,
        columnNames: this.indexColumns,
        isUnique: true,
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    const table: Table = await queryRunner.getTable(this.tableName);
    const foreignKeys: TableForeignKey[] = table.foreignKeys;
    await queryRunner.dropForeignKeys(this.tableName, foreignKeys);
    await queryRunner.dropIndex(this.tableName, this.indexName);
    await queryRunner.dropTable(this.tableName, true, true, true);
  }
}
