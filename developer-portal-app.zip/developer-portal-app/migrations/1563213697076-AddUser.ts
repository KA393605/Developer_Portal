import { MigrationInterface, QueryRunner, Table, TableIndex } from 'typeorm';

export class AddUser1563213697076 implements MigrationInterface {
  private tableName: string = 'User';
  private indexName: string = 'UserId';
  private indexColumns: string[] = ['userId'];

  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.createTable(
      new Table({
        name: this.tableName,
        columns: [
          {
            name: 'uniqueKey',
            type: 'uuid',
            isPrimary: true,
            isGenerated: true,
            isNullable: false,
            default: 'uuid_generate_v4()',
          },
          {
            name: 'userId',
            type: 'integer',
            isGenerated: true,
            isUnique: true,
            isNullable: false,
          },
          {
            name: 'mudId',
            type: 'character',
            length: '8',
            isNullable: false,
          },
          {
            name: 'email',
            type: 'character varying',
            length: '255',
            isNullable: false,
          },
          {
            name: 'firstName',
            type: 'character varying',
            length: '255',
            isNullable: true,
          },
          {
            name: 'lastName',
            type: 'character varying',
            length: '255',
            isNullable: true,
          },
          {
            name: 'fullName',
            type: 'character varying',
            length: '255',
            isNullable: false,
          },
          {
            name: 'createTimestamp',
            type: 'timestamp with time zone',
            isNullable: false,
            default: 'NOW()',
          },
          {
            name: 'updateTimestamp',
            type: 'timestamp with time zone',
            isNullable: false,
            default: 'NOW()',
          },
          {
            name: 'deleteTimestamp',
            type: 'timestamp with time zone',
            isNullable: true,
          },
        ],
      }),
      true,
      true,
      true,
    );

    await queryRunner.createIndex(
      this.tableName,
      new TableIndex({
        name: this.indexName,
        columnNames: this.indexColumns,
        isUnique: true,
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.dropIndex(this.tableName, this.indexName);
    await queryRunner.dropTable(this.tableName, true, true, true);
  }
}
