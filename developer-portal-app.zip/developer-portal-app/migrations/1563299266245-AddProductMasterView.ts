import { MigrationInterface, QueryRunner } from 'typeorm';
import * as fs from 'fs';
import * as path from 'path';

export class AddProductMasterView1563299266245 implements MigrationInterface {
  private sqlPath: string = './views/product_master.sql';

  public async up(queryRunner: QueryRunner): Promise<any> {
    const query: string = fs.readFileSync(
      path.resolve(__dirname, this.sqlPath),
      'utf8',
    );
    await queryRunner.query(query);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP VIEW catalog.listing_listingtypes`);
    await queryRunner.query(`DROP VIEW catalog.listing_master`);
    await queryRunner.query(`DROP VIEW catalog.listing_keywords`);
  }
}
