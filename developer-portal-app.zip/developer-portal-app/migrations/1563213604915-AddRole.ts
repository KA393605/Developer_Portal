import {
  MigrationInterface,
  QueryRunner,
  Table,
  TableIndex,
  TableForeignKey,
} from 'typeorm';

export class AddRole1563213604915 implements MigrationInterface {
  private tableName: string = 'Role';
  private indexName: string = 'RoleId';
  private indexColumns: string[] = ['roleId'];

  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.createTable(
      new Table({
        name: this.tableName,
        columns: [
          {
            name: 'uniqueKey',
            type: 'uuid',
            isPrimary: true,
            isGenerated: true,
            isNullable: false,
            default: 'uuid_generate_v4()',
          },
          {
            name: 'roleId',
            type: 'integer',
            isGenerated: true,
            isUnique: true,
            isNullable: false,
          },
          {
            name: 'roleGroupId',
            type: 'integer',
            isNullable: false,
          },
          {
            name: 'roleName',
            type: 'character varying',
            length: '50',
            isNullable: false,
          },
          {
            name: 'roleDescription',
            type: 'character varying',
            length: '255',
            isNullable: false,
          },
          {
            name: 'createTimestamp',
            type: 'timestamp with time zone',
            isNullable: false,
            default: 'NOW()',
          },
          {
            name: 'updateTimestamp',
            type: 'timestamp with time zone',
            isNullable: false,
            default: 'NOW()',
          },
          {
            name: 'deleteTimestamp',
            type: 'timestamp with time zone',
            isNullable: true,
          },
        ],
        foreignKeys: [
          {
            columnNames: ['roleGroupId'],
            referencedColumnNames: ['roleGroupId'],
            referencedTableName: 'RoleGroup',
            onDelete: 'CASCADE',
            onUpdate: 'CASCADE',
          },
        ],
      }),
      true,
      true,
      true,
    );

    await queryRunner.createIndex(
      this.tableName,
      new TableIndex({
        name: this.indexName,
        columnNames: this.indexColumns,
        isUnique: true,
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.dropIndex(this.tableName, this.indexName);
    const table: Table = await queryRunner.getTable(this.tableName);
    const foreignKeys: TableForeignKey[] = table.foreignKeys;
    await queryRunner.dropForeignKeys(this.tableName, foreignKeys);
    await queryRunner.dropTable(this.tableName, true, true, true);
  }
}
