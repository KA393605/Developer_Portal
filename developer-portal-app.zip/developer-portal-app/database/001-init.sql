-- Configuration reference: https://aws.amazon.com/blogs/database/managing-postgresql-users-and-roles/

-- Create database and connect
CREATE DATABASE marketplace;
\connect marketplace;

-- UUID generation support
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create schema on database
CREATE SCHEMA IF NOT EXISTS catalog;


-- Revoke privileges from 'public' role
REVOKE CREATE ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON DATABASE marketplace FROM PUBLIC;

-- Read-only role
CREATE ROLE readonly;
GRANT CONNECT ON DATABASE marketplace TO readonly;
GRANT USAGE ON SCHEMA catalog TO readonly;
GRANT SELECT ON ALL TABLES IN SCHEMA catalog TO readonly;
ALTER DEFAULT PRIVILEGES IN SCHEMA catalog GRANT SELECT ON TABLES TO readonly;

-- Read/write role
CREATE ROLE readwrite;
GRANT CONNECT ON DATABASE marketplace TO readwrite;
GRANT USAGE, CREATE ON SCHEMA catalog TO readwrite;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA catalog TO readwrite;
ALTER DEFAULT PRIVILEGES IN SCHEMA catalog GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO readwrite;
GRANT USAGE ON ALL SEQUENCES IN SCHEMA catalog TO readwrite;
ALTER DEFAULT PRIVILEGES IN SCHEMA catalog GRANT USAGE ON SEQUENCES TO readwrite;
