echo create deploy directory
rm -rf ../deployPlatformCatalog;
mkdir ../deployPlatformCatalog;
#mkdir ../deployPlatformCatalog/frontend;
mkdir ../deployPlatformCatalog/server;

echo running server build
cd server;
rm -rf dist;
npm install;
npm run build;
mv -f dist/* ../../deployPlatformCatalog/server/;\
cp -R deploy-package.json ../../deployPlatformCatalog/package.json;

echo running ui build
cd ..;
cd frontend;
rm -rf dist;
npm install;
npm run build;
mkdir -p ../../deployPlatformCatalog/server/frontend/dist/;
mv -f dist ../../deployPlatformCatalog/server/frontend/;\
cd ..

echo deploying...
cd ../deployPlatformCatalog;
git init;
git config --global user.email "jeffrey.x.taylor@gsk.com";
git config --global user.name "Jeff Taylor";
git add server/frontend -f;
git add *;
git commit -m "added files";


git remote add devportal https://\elion-pc-user:3Z9xi6hBBnwkcHlBsAoHKarXZsEufdiwFAljLbXxjYXd19CqDgmkMZYWFk4J@developer-portal.scm.azurewebsites.net:443/developer-portal.git;
git push --set-upstream devportal master -f;

